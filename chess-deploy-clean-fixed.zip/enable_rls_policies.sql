-- Supabase RLS Enablement & Security Fix Script
-- Run this script in Supabase -> SQL Editor -> New Query

DO $$
DECLARE
  t text;
BEGIN
  FOR t IN 
    SELECT table_name 
    FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', t);
    EXECUTE format('DROP POLICY IF EXISTS "Public access policy" ON public.%I;', t);
    -- (no permissive policy: RLS on + no policies = anon/authenticated get no access; the server uses the owner role)
  END LOOP;
END $$;
