import { Pool } from 'pg';

const BASE_URL = 'http://localhost:3000';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function runTests() {
  console.log('=== STARTING P0 #2 STAKES & PRIZE COINS E2E VERIFICATION ===\n');

  // Test User IDs
  const user1Id = 'test_player_stake_1';
  const user2Id = 'test_player_stake_2';

  // 1. Ensure test users exist in users and player_stats with known balances
  await pool.query(`
    INSERT INTO users (id, username, email, password_hash)
    VALUES 
      ($1, 'StakeTester1', 'staketest1@chess.com', 'testhash'),
      ($2, 'StakeTester2', 'staketest2@chess.com', 'testhash')
    ON CONFLICT (id) DO UPDATE SET username = EXCLUDED.username;
  `, [user1Id, user2Id]);

  // Set initial balances: User 1 has 2000, User 2 has 1500
  await pool.query(`
    INSERT INTO player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
    VALUES 
      ($1, 2000, 50, 1200, 0, 0, 0, 0, 1),
      ($2, 1500, 50, 1200, 0, 0, 0, 0, 1)
    ON CONFLICT (id) DO NOTHING;
  `, [user1Id, user2Id]);
  await pool.query("UPDATE player_stats SET coins = 2000 WHERE id = 'test_player_stake_1';");
  await pool.query("UPDATE player_stats SET coins = 1500 WHERE id = 'test_player_stake_2';");

  const getBalance = async (uid: string): Promise<number> => {
    const res = await pool.query('SELECT coins FROM player_stats WHERE id = $1;', [uid]);
    return res.rows[0]?.coins ?? 0;
  };

  console.log('Initial Balances in Supabase / Postgres:');
  console.log(`- Player 1 (${user1Id}): ${await getBalance(user1Id)} coins`);
  console.log(`- Player 2 (${user2Id}): ${await getBalance(user2Id)} coins`);

  // ==========================================
  // TEST 1: STAKE DEDUCTION ON MATCH INIT
  // ==========================================
  console.log('\n--- TEST 1: Stake deduction on match init ---');
  const match1Id = `stake_match_${Date.now()}_1`;
  const stakeAmount = 500;
  const prizePool = 1000;

  // Player 1 inits the match with stake
  const initRes1 = await fetch(`${BASE_URL}/api/match/${match1Id}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user1Id,
      assignedColor: 'w',
      stake: stakeAmount,
      prize: prizePool,
      tableId: '2'
    })
  });
  const initData1 = await initRes1.json();
  console.log('Player 1 init response:', initData1);

  // Player 2 inits the match as black
  const initRes2 = await fetch(`${BASE_URL}/api/match/${match1Id}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user2Id,
      assignedColor: 'b',
      stake: stakeAmount,
      prize: prizePool,
      tableId: '2'
    })
  });
  const initData2 = await initRes2.json();
  console.log('Player 2 init response:', initData2);

  const balP1AfterDeduct = await getBalance(user1Id);
  const balP2AfterDeduct = await getBalance(user2Id);
  console.log(`Balances after match start:`);
  console.log(`- Player 1: ${balP1AfterDeduct} (expected: 1500)`);
  console.log(`- Player 2: ${balP2AfterDeduct} (expected: 1000)`);

  if (balP1AfterDeduct !== 1500 || balP2AfterDeduct !== 1000) {
    throw new Error(`TEST 1 FAILED: Expected 1500 and 1000, got ${balP1AfterDeduct} and ${balP2AfterDeduct}`);
  }
  console.log('✅ TEST 1 PASSED: Stakes deducted exactly once from both players.');

  // ==========================================
  // TEST 2: PREVENT DOUBLE DEDUCTION (IDEMPOTENCY)
  // ==========================================
  console.log('\n--- TEST 2: Prevent double deduction ---');
  const duplicateInit = await fetch(`${BASE_URL}/api/match/${match1Id}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user1Id,
      assignedColor: 'w',
      stake: stakeAmount,
      prize: prizePool
    })
  });
  const dupData = await duplicateInit.json();
  console.log('Duplicate init response:', dupData);

  const balP1AfterDup = await getBalance(user1Id);
  console.log(`Player 1 balance after duplicate init: ${balP1AfterDup} (expected: 1500)`);
  if (balP1AfterDup !== 1500) {
    throw new Error(`TEST 2 FAILED: Balance changed on duplicate init! ${balP1AfterDup}`);
  }
  console.log('✅ TEST 2 PASSED: Duplicate deduction successfully prevented.');

  // ==========================================
  // TEST 3: REJECT IF INSUFFICIENT BALANCE
  // ==========================================
  console.log('\n--- TEST 3: Reject match if insufficient balance ---');
  const poorUserId = 'test_poor_player';
  await pool.query(`
    INSERT INTO users (id, username, email, password_hash)
    VALUES ($1, 'PoorPlayer', 'poor@chess.com', 'testhash')
    ON CONFLICT (id) DO NOTHING;
  `, [poorUserId]);
  await pool.query(`
    INSERT INTO player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
    VALUES ($1, 100, 50, 1200, 0, 0, 0, 0, 1)
    ON CONFLICT (id) DO UPDATE SET coins = 100;
  `, [poorUserId]);

  const poorMatchId = `stake_match_poor_${Date.now()}`;
  // Poor player tries to enter a 500 coin match
  const poorInit1 = await fetch(`${BASE_URL}/api/match/${poorMatchId}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: poorUserId,
      assignedColor: 'w',
      stake: 500,
      prize: 1000
    })
  });
  const poorData1 = await poorInit1.json();

  const poorInit2 = await fetch(`${BASE_URL}/api/match/${poorMatchId}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user1Id,
      assignedColor: 'b',
      stake: 500,
      prize: 1000
    })
  });
  const poorData2 = await poorInit2.json();
  console.log('Poor match init response:', poorData2);

  const poorBalAfter = await getBalance(poorUserId);
  const p1BalAfterPoor = await getBalance(user1Id);
  console.log(`Poor player balance: ${poorBalAfter} (expected: 100, no negative balance)`);
  console.log(`Player 1 balance: ${p1BalAfterPoor} (expected: 1500, unchanged)`);

  if (poorBalAfter !== 100 || p1BalAfterPoor !== 1500) {
    throw new Error(`TEST 3 FAILED: Expected balances 100 and 1500, got ${poorBalAfter} and ${p1BalAfterPoor}`);
  }
  console.log('✅ TEST 3 PASSED: Insufficient balance rejected and negative balance prevented.');

  // ==========================================
  // TEST 4: WINNER PRIZE PAYOUT
  // ==========================================
  console.log('\n--- TEST 4: Winner receives prize pool on game completion ---');
  // Complete match 1 with Player 1 (White) as winner
  const endRes1 = await fetch(`${BASE_URL}/api/match/${match1Id}/end`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      reason: 'checkmate',
      winner: 'w',
      userId: user1Id
    })
  });
  const endData1 = await endRes1.json();
  console.log('Match end response:', endData1);

  const balP1AfterWin = await getBalance(user1Id);
  const balP2AfterWin = await getBalance(user2Id);
  console.log(`Balances after Player 1 victory:`);
  console.log(`- Player 1: ${balP1AfterWin} (expected: 1500 + 1000 = 2500)`);
  console.log(`- Player 2: ${balP2AfterWin} (expected: 1000)`);

  if (balP1AfterWin !== 2500 || balP2AfterWin !== 1000) {
    throw new Error(`TEST 4 FAILED: Expected 2500 and 1000, got ${balP1AfterWin} and ${balP2AfterWin}`);
  }
  console.log('✅ TEST 4 PASSED: Winner received the full prize pool.');

  // ==========================================
  // TEST 5: PREVENT DUPLICATE PRIZE PAYOUT
  // ==========================================
  console.log('\n--- TEST 5: Prevent duplicate prize payout ---');
  const duplicateEnd = await fetch(`${BASE_URL}/api/match/${match1Id}/end`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      reason: 'checkmate',
      winner: 'w',
      userId: user1Id
    })
  });
  const dupEndData = await duplicateEnd.json();
  console.log('Duplicate end response:', dupEndData);

  const balP1AfterDupEnd = await getBalance(user1Id);
  console.log(`Player 1 balance after duplicate end: ${balP1AfterDupEnd} (expected: 2500)`);
  if (balP1AfterDupEnd !== 2500) {
    throw new Error(`TEST 5 FAILED: Duplicate prize was awarded! ${balP1AfterDupEnd}`);
  }
  console.log('✅ TEST 5 PASSED: Duplicate prize payout successfully prevented.');

  // ==========================================
  // TEST 6: DRAW REFUNDS STAKES TO BOTH PLAYERS
  // ==========================================
  console.log('\n--- TEST 6: Draw refunds stakes correctly to both players ---');
  const drawMatchId = `stake_match_draw_${Date.now()}`;
  const drawStake = 300;
  const drawPrize = 600;

  // Initialize draw match
  await fetch(`${BASE_URL}/api/match/${drawMatchId}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user1Id,
      assignedColor: 'w',
      stake: drawStake,
      prize: drawPrize
    })
  });

  await fetch(`${BASE_URL}/api/match/${drawMatchId}/init`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userId: user2Id,
      assignedColor: 'b',
      stake: drawStake,
      prize: drawPrize
    })
  });

  const balP1DuringMatch = await getBalance(user1Id);
  const balP2DuringMatch = await getBalance(user2Id);
  console.log(`Balances during draw match:`);
  console.log(`- Player 1: ${balP1DuringMatch} (expected: 2500 - 300 = 2200)`);
  console.log(`- Player 2: ${balP2DuringMatch} (expected: 1000 - 300 = 700)`);

  if (balP1DuringMatch !== 2200 || balP2DuringMatch !== 700) {
    throw new Error(`TEST 6 FAILED on stake deduction: Expected 2200 and 700, got ${balP1DuringMatch} and ${balP2DuringMatch}`);
  }

  // End match as DRAW
  const drawEndRes = await fetch(`${BASE_URL}/api/match/${drawMatchId}/end`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      reason: 'stalemate',
      winner: null,
      userId: user1Id
    })
  });
  const drawEndData = await drawEndRes.json();
  console.log('Draw end response:', drawEndData);

  const balP1AfterRefund = await getBalance(user1Id);
  const balP2AfterRefund = await getBalance(user2Id);
  console.log(`Balances after draw refund:`);
  console.log(`- Player 1: ${balP1AfterRefund} (expected: 2500)`);
  console.log(`- Player 2: ${balP2AfterRefund} (expected: 1000)`);

  if (balP1AfterRefund !== 2500 || balP2AfterRefund !== 1000) {
    throw new Error(`TEST 6 FAILED on refund: Expected 2500 and 1000, got ${balP1AfterRefund} and ${balP2AfterRefund}`);
  }
  console.log('✅ TEST 6 PASSED: Both players received exact refunds on draw.');

  // ==========================================
  // TEST 7: TRANSACTION AUDIT LOG INTEGRITY
  // ==========================================
  console.log('\n--- TEST 7: Audit log verification in match_coin_transactions ---');
  const txs = await pool.query(
    'SELECT match_id, user_id, type, amount, balance_before, balance_after FROM match_coin_transactions WHERE match_id IN ($1, $2) ORDER BY created_at ASC;',
    [match1Id, drawMatchId]
  );
  console.log('Transaction records recorded:');
  console.table(txs.rows);

  if (txs.rows.length < 5) {
    throw new Error(`TEST 7 FAILED: Expected at least 5 transactions recorded, found ${txs.rows.length}`);
  }
  console.log('✅ TEST 7 PASSED: All stake deductions, prize awards, and refunds are logged in match_coin_transactions.');

  // Clean up test pool
  await pool.end();
  console.log('\n🎉 ALL P0 #2 STAKES & PRIZE COINS VERIFICATION TESTS PASSED SUCCESSFULLY! 🎉');
}

runTests().catch(async (err) => {
  console.error('VERIFICATION ERROR:', err);
  await pool.end();
  process.exit(1);
});
