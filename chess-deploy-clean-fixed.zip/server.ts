import express from 'express';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import { eq , and, not, sql, desc, or, ilike } from 'drizzle-orm';
import { Chess } from 'chess.js';
import jwt from 'jsonwebtoken';
import { Server as SocketIOServer, Socket } from 'socket.io';
import { createClient } from '@supabase/supabase-js';
import * as schema from './src/db/schema';
import { SHOP_CATALOG } from './src/lib/shopCatalog';
import { CHESS_40_STAGES } from './src/data/stagesData';

// SECURITY: the old hard-coded fallback secret was public in the repo, so
// anyone could forge a token for any user. Without a configured secret we
// now use a random per-process one (tokens then reset on restart) and warn.
const JWT_SECRET = process.env.JWT_SECRET || process.env.SUPABASE_JWT_SECRET || (() => {
  console.warn('[SECURITY] JWT_SECRET is not set! Using a random temporary secret; set JWT_SECRET in your environment.');
  return crypto.randomBytes(48).toString('hex');
})();

const SUPABASE_URL = ((process.env.SUPABASE_URL && process.env.SUPABASE_URL.trim()) || (process.env.VITE_SUPABASE_URL && process.env.VITE_SUPABASE_URL.trim()) || 'https://wetbwuwtjgaufqpwmunp.supabase.co').replace(/\/+$/, '');
const SUPABASE_SERVICE_ROLE = (process.env.SUPABASE_SECRET_KEY && process.env.SUPABASE_SECRET_KEY.trim()) || (process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY.trim()) || '';

// Startup configuration check. Presence only - values are never logged.
const HAS_SERVICE_KEY = !!((process.env.SUPABASE_SECRET_KEY && process.env.SUPABASE_SECRET_KEY.trim()) || (process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY.trim()));
const HAS_JWT_SECRET = !!(process.env.JWT_SECRET || process.env.SUPABASE_JWT_SECRET);
const HAS_DB_URL = !!process.env.DATABASE_URL;
(global as any).__configStatus = { jwtSecret: HAS_JWT_SECRET, databaseUrl: HAS_DB_URL, supabaseServiceKey: HAS_SERVICE_KEY, redis: !!process.env.REDIS_URL };
{
  const missing: string[] = [];
  if (!HAS_JWT_SECRET) missing.push('JWT_SECRET');
  if (!HAS_DB_URL) missing.push('DATABASE_URL');
  if (!HAS_SERVICE_KEY) missing.push('SUPABASE_SECRET_KEY');
  if (!process.env.REDIS_URL && process.env.NODE_ENV === 'production') {
    console.warn('[CONFIG] REDIS_URL is not set: running single-instance only (matchmaking/presence live in this process memory). Active games are persisted to PostgreSQL and restored on demand, but do NOT run more than one server instance.');
  }
  if (missing.length) {
    const msg = `[CONFIG] Missing environment variables: ${missing.join(', ')}. ` +
      (HAS_SERVICE_KEY ? '' : 'Without SUPABASE_SECRET_KEY (server-side service key; the public/publishable key is NOT a substitute) account creation, guest accounts and admin user actions will fail. ');
    if (process.env.NODE_ENV === 'production' && (!HAS_JWT_SECRET || !HAS_DB_URL || !HAS_SERVICE_KEY)) {
      console.error(msg + 'Refusing to start in production until JWT_SECRET, DATABASE_URL, and SUPABASE_SECRET_KEY are configured.');
      process.exit(1);
    }
    console.error(msg);
  }
}

// No fallback to the public/publishable/anon key: it is NOT a service-role key and
// silently fails for every privileged call. With no key, a placeholder is used so
// the process boots, and every privileged call fails loudly (see [CONFIG] above).
const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE || 'MISSING_SUPABASE_SECRET_KEY', {
  auth: { autoRefreshToken: false, persistSession: false }
});

// Public (publishable/anon) client: used ONLY for operations that need no special
// rights - verifying a user's own token and password sign-in. Privileged calls
// (auth.admin.*) always use supabaseAdmin with the real service key.
const SUPABASE_PUBLIC_KEY = (process.env.SUPABASE_PUBLISHABLE_KEY && process.env.SUPABASE_PUBLISHABLE_KEY.trim()) || (process.env.VITE_SUPABASE_ANON_KEY && process.env.VITE_SUPABASE_ANON_KEY.trim()) || '';
const supabasePublic = SUPABASE_PUBLIC_KEY
  ? createClient(SUPABASE_URL, SUPABASE_PUBLIC_KEY, { auth: { autoRefreshToken: false, persistSession: false } })
  : supabaseAdmin;

// CORS allowlist. Before, the server echoed back ANY Origin together with
// Access-Control-Allow-Credentials: true. Now only trusted origins are allowed:
// ALLOWED_ORIGINS (comma separated) + APP_URL, the Capacitor app origins, the
// server's own host, and localhost outside production.
const CORS_ALLOWED = new Set<string>(
  [...(process.env.ALLOWED_ORIGINS || '').split(','), process.env.APP_URL || '']
    .map(o => o.trim().replace(/\/+$/, ''))
    .filter(o => /^https?:\/\//.test(o))
);
const CAPACITOR_ORIGINS = new Set(['capacitor://localhost', 'ionic://localhost', 'https://localhost', 'http://localhost']);
function isAllowedOrigin(origin: string | undefined, host: string | undefined): boolean {
  if (!origin) return false;
  const o = origin.replace(/\/+$/, '');
  if (CORS_ALLOWED.has(o) || CAPACITOR_ORIGINS.has(o)) return true;
  try {
    const u = new URL(o);
    if (host && u.host === host) return true; // same site as this server
    if (process.env.NODE_ENV !== 'production' && (u.hostname === 'localhost' || u.hostname === '127.0.0.1')) return true;
  } catch {}
  return false;
}
if (process.env.NODE_ENV === 'production' && CORS_ALLOWED.size === 0) {
  console.warn('[CONFIG] ALLOWED_ORIGINS / APP_URL not set: cross-origin browser requests are blocked (only same-origin and the Capacitor app are allowed).');
}

// Setup PostgreSQL Connection safely
const dbUrl = process.env.DATABASE_URL || '';
const pool = new Pool({
  connectionString: dbUrl,
  ssl: { rejectUnauthorized: false },
  // Sized for many concurrent players: the default of 10 connections makes
  // match settlement, rewards and auth queue behind each other under load.
  max: Number(process.env.PG_POOL_MAX) || 20,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
});
pool.on('error', (err) => console.error('[pg] idle client error:', err.message));

const db = dbUrl ? drizzle(pool, { schema }) : null;

async function ensureSupabaseAuthUser(email: string, pass: string, username: string) {
  const cleanEmail = email.toLowerCase().trim();
  console.log('ensureSupabaseAuthUser calling for:', cleanEmail);
  try {
    const { data, error } = await supabaseAdmin.auth.admin.createUser({
      email: cleanEmail,
      password: pass,
      email_confirm: true,
      user_metadata: { username } as any as any
    });
    if (data?.user) {
      // log user
      return data.user.id;
    }
    if (error) {
      console.log('Supabase admin createUser note:', error.message);
      if (error.message.includes('already registered') || error.message.includes('exists') || error.message.includes('already been registered')) {
        const { data: listData } = await supabaseAdmin.auth.admin.listUsers();
        const existingUser = listData?.users?.find(u => (u as any).email?.toLowerCase() === cleanEmail);
        if (existingUser) {
          await supabaseAdmin.auth.admin.updateUserById(existingUser.id, {
            password: pass,
            email_confirm: true,
            user_metadata: { username } as any as any
          }).catch(() => {});
          return existingUser.id;
        }
      }
    }
  } catch (err: any) {
    console.log('Supabase admin API exception (will fallback to direct DB):', err?.message || err);
  }

  // Direct PostgreSQL fallback: create or update user in auth.users directly
  if (pool) {
    try {
      const checkAuth = await pool.query('SELECT id FROM auth.users WHERE email = $1 LIMIT 1;', [cleanEmail]);
      if (checkAuth.rows.length > 0) {
        const existingId = checkAuth.rows[0].id;
        await pool.query(
          "UPDATE auth.users SET encrypted_password = crypt($1, gen_salt('bf')), raw_user_meta_data = jsonb_build_object('username', $2::text), updated_at = now() WHERE id = $3;",
          [pass, username, existingId]
        );
        return existingId;
      }

      const insertRes = await pool.query(
        `INSERT INTO auth.users (
          id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
          raw_app_meta_data, raw_user_meta_data, created_at, updated_at
        ) VALUES (
          gen_random_uuid(), '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
          $1, crypt($2, gen_salt('bf')), now(),
          '{"provider":"email","providers":["email"]}'::jsonb,
          jsonb_build_object('username', $3::text),
          now(), now()
        ) RETURNING id;`,
        [cleanEmail, pass, username]
      );
      if (insertRes.rows.length > 0) {
        console.log('Direct Postgres auth.users insert success:', insertRes.rows[0].id);
        return insertRes.rows[0].id;
      }
    } catch (dbErr: any) {
      console.error('Direct auth.users insert error:', dbErr?.message || dbErr);
    }
  }
  return null;
}

const dbInitialization: Promise<void> = dbUrl
  ? pool.query('SELECT 1;')
    .then(async () => {
      console.log('PostgreSQL database connected successfully.');
      try {
        await pool.query(`
          CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            avatar_url TEXT,
            is_guest BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT NOW()
          );
          ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash TEXT DEFAULT '';
          ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_url TEXT;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS is_guest BOOLEAN DEFAULT FALSE;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS name_changes INTEGER DEFAULT 0;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS bio TEXT;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS equipped_piece_skin TEXT;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS equipped_board_skin TEXT;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS tokens_valid_after TIMESTAMP;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS is_banned BOOLEAN DEFAULT FALSE;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS ban_reason TEXT;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS is_suspended BOOLEAN DEFAULT FALSE;
          ALTER TABLE users ADD COLUMN IF NOT EXISTS suspended_until TIMESTAMP;
          CREATE TABLE IF NOT EXISTS admin_audit_log (
            id TEXT PRIMARY KEY, admin_id TEXT NOT NULL, action TEXT NOT NULL, target_user_id TEXT,
            old_value JSONB, new_value JSONB, reason TEXT, created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS user_reports (
            id TEXT PRIMARY KEY, reporter_id TEXT NOT NULL, reported_user_id TEXT NOT NULL, match_id TEXT,
            reason TEXT NOT NULL, status TEXT DEFAULT 'open', resolution_notes TEXT, resolved_by TEXT,
            created_at TIMESTAMP DEFAULT NOW(), resolved_at TIMESTAMP
          );
          CREATE TABLE IF NOT EXISTS announcements (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, is_active BOOLEAN DEFAULT TRUE,
            created_by TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT DEFAULT '', banner_url TEXT,
            event_type TEXT NOT NULL, start_at TIMESTAMP NOT NULL, end_at TIMESTAMP NOT NULL,
            status TEXT DEFAULT 'draft', max_participants INTEGER, leaderboard_enabled BOOLEAN DEFAULT TRUE,
            created_by TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW(), updated_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS event_tasks (
            id TEXT PRIMARY KEY, event_id TEXT NOT NULL, task_type TEXT NOT NULL, target_amount INTEGER NOT NULL,
            task_order INTEGER DEFAULT 0, is_enabled BOOLEAN DEFAULT TRUE, reward_coins INTEGER DEFAULT 0,
            reward_gems INTEGER DEFAULT 0, reward_item_id TEXT, reward_xp INTEGER DEFAULT 0, created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS event_participants (
            id TEXT PRIMARY KEY, event_id TEXT NOT NULL, user_id TEXT NOT NULL, joined_at TIMESTAMP DEFAULT NOW(),
            games_played INTEGER DEFAULT 0, games_won INTEGER DEFAULT 0, current_win_streak INTEGER DEFAULT 0,
            best_win_streak INTEGER DEFAULT 0, puzzles_solved INTEGER DEFAULT 0,
            UNIQUE(event_id, user_id)
          );
          CREATE TABLE IF NOT EXISTS event_task_claims (
            id TEXT PRIMARY KEY, event_id TEXT NOT NULL, task_id TEXT NOT NULL, user_id TEXT NOT NULL,
            claimed_at TIMESTAMP DEFAULT NOW(),
            UNIQUE(event_id, task_id, user_id)
          );
          CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
          CREATE INDEX IF NOT EXISTS idx_event_tasks_event ON event_tasks(event_id);
          CREATE INDEX IF NOT EXISTS idx_event_participants_user ON event_participants(user_id);
          CREATE TABLE IF NOT EXISTS player_stats (
            id TEXT PRIMARY KEY,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            draws INTEGER DEFAULT 0,
            rating INTEGER DEFAULT 1200,
            coins INTEGER DEFAULT 5000,
            gems INTEGER DEFAULT 50,
            xp INTEGER DEFAULT 0,
            level INTEGER DEFAULT 1,
            last_played_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS royal_pass (
            id TEXT PRIMARY KEY,
            is_premium BOOLEAN DEFAULT FALSE,
            claimed_free_tiers JSONB DEFAULT '[]',
            claimed_premium_tiers JSONB DEFAULT '[]',
            season_xp INTEGER DEFAULT 0,
            updated_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS user_challenges (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            challenge_type TEXT NOT NULL,
            description TEXT NOT NULL,
            target INTEGER NOT NULL,
            progress INTEGER DEFAULT 0,
            xp_reward INTEGER DEFAULT 50,
            is_completed BOOLEAN DEFAULT FALSE,
            is_claimed BOOLEAN DEFAULT FALSE,
            expires_at TIMESTAMP NOT NULL,
            created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS user_inventory (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            item_id TEXT NOT NULL,
            item_type TEXT NOT NULL,
            acquired_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS user_purchases (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            item_id TEXT NOT NULL,
            price_coins INTEGER DEFAULT 0,
            price_gems INTEGER DEFAULT 0,
            purchased_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS matches (
            id TEXT PRIMARY KEY,
            white_player_id TEXT NOT NULL,
            black_player_id TEXT NOT NULL,
            winner_id TEXT,
            moves_san TEXT DEFAULT '',
            fen TEXT DEFAULT 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
            status TEXT DEFAULT 'active',
            turn TEXT DEFAULT 'w',
            white_time_ms INTEGER DEFAULT 600000,
            black_time_ms INTEGER DEFAULT 600000,
            last_move_timestamp TIMESTAMP,
            stake INTEGER DEFAULT 0,
            prize INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT NOW()
          );

          ALTER TABLE matches ADD COLUMN IF NOT EXISTS stake INTEGER DEFAULT 0;
          ALTER TABLE matches ADD COLUMN IF NOT EXISTS prize INTEGER DEFAULT 0;

          CREATE TABLE IF NOT EXISTS match_coin_transactions (
            id TEXT PRIMARY KEY,
            match_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            type TEXT NOT NULL,
            amount INTEGER NOT NULL,
            balance_before INTEGER NOT NULL,
            balance_after INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_match_coin_tx_match_id ON match_coin_transactions (match_id);
          CREATE INDEX IF NOT EXISTS idx_match_coin_tx_user_id ON match_coin_transactions (user_id);

          CREATE TABLE IF NOT EXISTS custom_rooms (
            code VARCHAR(6) PRIMARY KEY,
            host_id TEXT NOT NULL,
            guest_id TEXT,
            match_id TEXT NOT NULL,
            time_min INTEGER DEFAULT 5,
            stake INTEGER DEFAULT 0,
            prize INTEGER DEFAULT 0,
            status TEXT DEFAULT 'waiting',
            created_at TIMESTAMP DEFAULT NOW(),
            updated_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_custom_rooms_host ON custom_rooms (host_id);
          CREATE INDEX IF NOT EXISTS idx_custom_rooms_match ON custom_rooms (match_id);

          CREATE TABLE IF NOT EXISTS user_daily_rewards (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            reward_type TEXT NOT NULL,
            tier INTEGER DEFAULT 1,
            streak_day INTEGER DEFAULT 1,
            coins_awarded INTEGER DEFAULT 0,
            gems_awarded INTEGER DEFAULT 0,
            claim_date TEXT NOT NULL,
            claimed_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_user_daily_rewards_user ON user_daily_rewards (user_id);
          CREATE INDEX IF NOT EXISTS idx_user_daily_rewards_date ON user_daily_rewards (claim_date);

          CREATE TABLE IF NOT EXISTS user_puzzles (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            puzzle_id TEXT NOT NULL,
            level_number INTEGER NOT NULL,
            status TEXT DEFAULT 'completed',
            completed_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_user_puzzles_user ON user_puzzles (user_id);

          CREATE TABLE IF NOT EXISTS friendships (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            friend_id TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_friendships_user_id ON friendships (user_id);
          CREATE INDEX IF NOT EXISTS idx_friendships_friend_id ON friendships (friend_id);
          CREATE TABLE IF NOT EXISTS global_chat_messages (
            id TEXT PRIMARY KEY, user_id TEXT NOT NULL, username TEXT NOT NULL, avatar TEXT,
            level INTEGER DEFAULT 1, text TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_global_chat_created ON global_chat_messages (created_at DESC);
          CREATE TABLE IF NOT EXISTS user_puzzle_completions (
            id TEXT PRIMARY KEY, user_id TEXT NOT NULL, puzzle_id TEXT NOT NULL, level_number INTEGER NOT NULL,
            coins_awarded INTEGER NOT NULL, completed_at TIMESTAMP DEFAULT NOW()
          );
          CREATE INDEX IF NOT EXISTS idx_puzzle_completions_user ON user_puzzle_completions (user_id);
          CREATE TABLE IF NOT EXISTS tournaments (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT DEFAULT 'monthly', status TEXT DEFAULT 'registration',
            start_time TIMESTAMP, entry_fee INTEGER DEFAULT 0, prize_pool INTEGER DEFAULT 0,
            max_participants INTEGER DEFAULT 16, created_at TIMESTAMP DEFAULT NOW()
          );
          CREATE TABLE IF NOT EXISTS tournament_participants (
            tournament_id TEXT NOT NULL, user_id TEXT NOT NULL, registered_at TIMESTAMP DEFAULT NOW(),
            status TEXT DEFAULT 'active', rank INTEGER, PRIMARY KEY (tournament_id, user_id)
          );
          CREATE TABLE IF NOT EXISTS tournament_matches (
            id TEXT PRIMARY KEY, tournament_id TEXT NOT NULL, round INTEGER NOT NULL, match_index INTEGER NOT NULL,
            player1_id TEXT, player2_id TEXT, winner_id TEXT, match_id TEXT, status TEXT DEFAULT 'pending'
          );
          ALTER TABLE player_stats ALTER COLUMN coins SET DEFAULT 5000;
          -- Load indexes: leaderboards, daily-quest counts, login/search by username
          CREATE INDEX IF NOT EXISTS idx_player_stats_rating ON player_stats (rating DESC);
          CREATE INDEX IF NOT EXISTS idx_player_stats_wins ON player_stats (wins DESC);
          CREATE INDEX IF NOT EXISTS idx_player_stats_coins ON player_stats (coins DESC);
          CREATE INDEX IF NOT EXISTS idx_matches_white ON matches (white_player_id, created_at);
          CREATE INDEX IF NOT EXISTS idx_matches_black ON matches (black_player_id, created_at);
          CREATE INDEX IF NOT EXISTS idx_matches_winner ON matches (winner_id, created_at);
          CREATE INDEX IF NOT EXISTS idx_users_lower_username ON users (LOWER(username));

          -- Enable RLS on all public tables
          DO $$
          DECLARE
            t text;
          BEGIN
            FOR t IN 
              SELECT table_name 
              FROM information_schema.tables 
              WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
            LOOP
              EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', t);
              -- SECURITY: this used to create a "FOR ALL USING (true) WITH CHECK (true)"
              -- policy on every table. The Supabase anon key ships inside the app, so
              -- anyone could then read or WRITE any table (coins, is_admin, password
              -- hashes...) straight through Supabase's REST API, bypassing this server.
              -- Now RLS stays ON with NO policies = anon/authenticated roles get no
              -- access. The server connects directly (DATABASE_URL, owner role) and
              -- is unaffected; the app only uses Supabase for Auth.
              EXECUTE format('DROP POLICY IF EXISTS "Public access policy" ON public.%I;', t);
            END LOOP;
            BEGIN
              REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon, authenticated;
            EXCEPTION WHEN OTHERS THEN NULL;
            END;
          END $$;

          -- Collision-proof trigger for Supabase Auth new user synchronization
          CREATE OR REPLACE FUNCTION public.handle_new_user()
          RETURNS trigger
          LANGUAGE plpgsql
          SECURITY DEFINER
          AS $$
          DECLARE
            user_name TEXT;
            base_name TEXT;
          BEGIN
            user_name := COALESCE(
              new.raw_user_meta_data->>'username',
              new.raw_user_meta_data->>'full_name',
              new.raw_user_meta_data->>'name',
              split_part(new.email, '@', 1),
              'Player'
            );
            base_name := user_name;

            -- Ensure username never collides with another existing user
            WHILE EXISTS (SELECT 1 FROM public.users WHERE LOWER(username) = LOWER(user_name) AND id <> new.id) LOOP
              user_name := base_name || '_' || floor(random() * 9000 + 1000)::text;
            END LOOP;

            INSERT INTO public.users (id, username, email, password_hash, is_guest)
            VALUES (
              new.id,
              user_name,
              COALESCE(new.email, new.id || '@user.local'),
              '',
              COALESCE((new.raw_app_meta_data->>'provider' = 'anonymous' OR new.is_anonymous), false)
            )
            ON CONFLICT (id) DO UPDATE
            SET email = EXCLUDED.email,
                is_guest = EXCLUDED.is_guest;

            INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
            VALUES (new.id, 5000, 50, 1200, 0, 0, 0, 0, 1)
            ON CONFLICT (id) DO NOTHING;

            RETURN new;
          EXCEPTION WHEN OTHERS THEN
            RAISE WARNING 'handle_new_user trigger error handled: %', SQLERRM;
            RETURN new;
          END;
          $$;

          DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
          CREATE TRIGGER on_auth_user_created
            AFTER INSERT ON auth.users
            FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
        `);
        console.log('PostgreSQL schema, triggers, and RLS policies auto-configured.');
        
        // No default/demo accounts are created on server startup.
      } catch (e: any) {
        console.warn('PostgreSQL table check:', e.message);
        if (process.env.NODE_ENV === 'production') throw e;
      }
    })
    .catch((err) => {
      console.warn('PostgreSQL database connection warning:', err.message);
      if (process.env.NODE_ENV === 'production') throw err;
    })
  : Promise.resolve();

// --- Auth Middleware ---
// Strictly verifies Supabase Auth tokens with fallback support for server-signed JWT tokens.
// Resolve a bearer token (Supabase access token, server-signed JWT, or a
// guest account id) to a user id, or null. Used by the realtime socket, which
// previously trusted whatever `userId` the client claimed in `identify`.
async function verifyTokenToUid(token: string): Promise<string | null> {
  token = (token || '').trim();
  if (!token) return null;
  let uid: string | null = null;
  try {
    const cached = tokenCache.get(token);
    if (cached && cached.exp > Date.now()) uid = cached.user?.id || null;
    else {
      const { data, error } = await supabasePublic.auth.getUser(token);
      if (!error && data?.user) {
        uid = data.user.id;
        boundedSet(tokenCache, token, { user: data.user, exp: Date.now() + 60_000 }, 20000);
      }
    }
  } catch {}
  if (!uid) {
    try {
      const d: any = jwt.verify(token, JWT_SECRET);
      if (d?.sub) {
        if (await isJwtRevoked(String(d.sub), d.iat)) return null;
        uid = String(d.sub);
      }
    } catch {}
  }
  if (!uid) return null;
  // Banned accounts can't open a realtime session either.
  try { if ((await getAuthRow(uid))?.is_banned === true) return null; } catch {}
  return uid;
}

// Server-signed JWTs (guests, /api/auth/login) are valid for 30 days, so
// "logout" must be able to kill them: /api/auth/logout stores a cut-off time
// in users.tokens_valid_after and any token issued before it is refused.
// Hot-path caches. requireAuth runs on EVERY REST call (including every chess
// move). It used to call Supabase over the network and run 1-2 SQL queries each
// time, which at ~1000 concurrent players means thousands of Supabase calls per
// minute (slow moves, rate limits). Verified tokens are now cached for 60 s and
// the ban/suspend/revocation row for 10 s (admin actions and logout clear it).
const tokenCache = new Map<string, { user: any; exp: number }>();
const authRowCache = new Map<string, { row: any; exp: number }>();
function boundedSet<V>(m: Map<string, V>, k: string, v: V, max: number) {
  if (m.size >= max) { const first = m.keys().next().value; if (first !== undefined) m.delete(first); }
  m.set(k, v);
}
function invalidateAuthRow(uid: string) { authRowCache.delete(uid); }
async function getAuthRow(uid: string): Promise<any | null> {
  if (!pool) return null;
  const c = authRowCache.get(uid);
  if (c && c.exp > Date.now()) return c.row;
  const r = await pool.query('SELECT is_banned, is_suspended, suspended_until, tokens_valid_after FROM public.users WHERE id = $1 LIMIT 1;', [uid]);
  const row = r.rows[0] || null;
  boundedSet(authRowCache, uid, { row, exp: Date.now() + 10_000 }, 20000);
  return row;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of tokenCache) if (v.exp <= now) tokenCache.delete(k);
  for (const [k, v] of authRowCache) if (v.exp <= now) authRowCache.delete(k);
}, 60_000).unref?.();

async function isJwtRevoked(uid: string, iat: any): Promise<boolean> {
  if (!pool || !iat) return false;
  try {
    const row = await getAuthRow(uid);
    const t = row?.tokens_valid_after;
    return !!t && Number(iat) < Math.floor(new Date(t).getTime() / 1000);
  } catch { return false; }
}

const requireAuth = async (req: any, res: any, next: any) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header' });
  }
  const token = authHeader.split(' ')[1];
  try {
    let user: any = null;
    const cachedTok = tokenCache.get(token);
    const { data, error } = cachedTok && cachedTok.exp > Date.now()
      ? { data: { user: cachedTok.user }, error: null as any }
      : await supabasePublic.auth.getUser(token);
    if (!error && data?.user) {
      user = data.user;
      if (!cachedTok || cachedTok.exp <= Date.now()) boundedSet(tokenCache, token, { user, exp: Date.now() + 60_000 }, 20000);
    } else {
      // Fallback: verify server-signed JWT token
      try {
        const decoded: any = jwt.verify(token, JWT_SECRET);
        if (decoded && decoded.sub && await isJwtRevoked(String(decoded.sub), decoded.iat)) {
          return res.status(401).json({ error: 'Session ended. Please sign in again.' });
        }
        if (decoded && decoded.sub) {
          user = {
            id: decoded.sub,
            email: decoded.email,
            user_metadata: { username: decoded.username },
            is_anonymous: decoded.is_anonymous || false,
          };
        }
      } catch (jwtErr) {
        // invalid token
      }
    }

    if (!user) {
      return res.status(401).json({ error: 'Invalid or expired authentication token' });
    }

    // Banned accounts can't use any authenticated endpoint.
    if (pool) {
      try {
        const brow = await getAuthRow(user.id);
        if (brow?.is_banned === true) {
          return res.status(403).json({ error: 'This account has been banned.' });
        }
        // A suspended account can still read (GET) but cannot act (play, buy, claim...).
        if (brow?.is_suspended === true && req.method !== 'GET' &&
            (!brow.suspended_until || new Date(brow.suspended_until) > new Date())) {
          return res.status(403).json({ error: 'This account is suspended.' });
        }
      } catch {}
    }

    const isStatsGet = req.method === 'GET' && req.path.includes('/stats');
    if (!isStatsGet && !req.path.startsWith('/api/match/') && req.params.id && req.params.id !== 'me' && req.params.id !== user.id) {
      let isMatch = false;
      if (pool) {
        try {
          const checkRes = await pool.query(
            'SELECT id FROM public.users WHERE (id = $1 OR username = $1) AND (id = $2 OR email = $3) LIMIT 1;',
            [req.params.id, user.id, (user as any).email]
          );
          if (checkRes.rows.length > 0) {
            isMatch = true;
          }
        } catch {}
      }
      if (!isMatch) {
        return res.status(403).json({ error: 'Unauthorized: Cannot modify or access data for another user' });
      }
    }
    req.user = {
      uid: user.id,
      email: (user as any).email,
      username: user.user_metadata?.username || user.user_metadata?.full_name || (user.is_anonymous ? `Guest_${user.id.substring(0, 6)}` : (user as any).email?.split('@')[0]),
      isGuest: user.is_anonymous || false
    };
    next();
  } catch (e: any) {
    return res.status(401).json({ error: 'Failed to authorize token' });
  }
};

const optionalAuth = async (req: any, _res: any, next: any) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1]?.trim();
    if (token) {
      try {
        const { data, error } = await supabasePublic.auth.getUser(token);
        if (!error && data?.user) {
          req.user = {
            uid: data.user.id,
            email: 'user created',
            username: data.user.user_metadata?.username || data.user.user_metadata?.full_name,
            isGuest: data.user.is_anonymous || false,
          };
        } else {
          try {
            const decoded: any = jwt.verify(token, JWT_SECRET);
            if (decoded && decoded.sub) {
              req.user = {
                uid: decoded.sub,
                email: decoded.email,
                username: decoded.username,
                isGuest: decoded.is_anonymous || false,
              };
            }
          } catch {}
        }
      } catch {}
    }
  }
  next();
};

// --- Server-Authoritative Match State (Redis with In-Memory Fallback) ---
// Guarantees zero hanging when Redis is unavailable, with authoritative chess validation,
// atomic state updates, and clock synchronization.
import Redis from 'ioredis';

let redis: Redis | null = null;
let isRedisAvailable = false;

const redisUrl = process.env.REDIS_URL;
if (redisUrl && redisUrl.trim() !== '' && redisUrl !== 'none') {
  try {
    redis = new Redis(redisUrl, {
      tls: (redisUrl.startsWith('rediss://') || redisUrl.includes('upstash.io')) ? { rejectUnauthorized: false } : undefined,
      enableOfflineQueue: false, // CRITICAL: Never hang or buffer commands when disconnected
      maxRetriesPerRequest: 1,  // Fail fast so fallback kicks in immediately
      connectTimeout: 1000,
      lazyConnect: true,
      retryStrategy: (times) => {
        if (times > 3) return null; // Avoid infinite reconnection spam
        return 2000;
      }
    });

    redis.on('connect', () => {
      isRedisAvailable = true;
      console.log('Redis connected successfully for match state.');
    });
    redis.on('ready', () => {
      isRedisAvailable = true;
    });
    redis.on('error', (_err) => {
      isRedisAvailable = false;
    });
    redis.on('close', () => {
      isRedisAvailable = false;
    });
    redis.on('end', () => {
      isRedisAvailable = false;
    });

    redis.connect().catch(() => {
      isRedisAvailable = false;
    });
  } catch {
    redis = null;
    isRedisAvailable = false;
  }
} else {
  console.log('No external REDIS_URL configured; using reliable server In-Memory Match State.');
}

interface ServerMatchMove {
  from: string;
  to: string;
  promotion?: string;
  san?: string;
  lan?: string;
  fen: string;
  by: string;
  at: number;
  moveNumber: number;
}

interface ServerMatch {
  id: string;
  whiteId: string | null;
  blackId: string | null;
  fen: string;
  turn: 'w' | 'b';
  whiteTimeMs: number;
  blackTimeMs: number;
  lastMoveAt: number;
  status: 'waiting' | 'active' | 'completed' | 'resigned' | 'timeout' | 'draw' | 'abandoned';
  winner: 'w' | 'b' | null;
  moveHistory?: ServerMatchMove[];
  tableId?: string;
  stake: number;
  prize: number;
  stakesDeducted: boolean;
  prizeAwarded: boolean;
  disconnectedUserId?: string | null;
  disconnectExpiresAt?: number | null;
}

// Minimum player level per table (mirrors TablesSelectionModal). Enforced on
// the server; before, only the client UI checked it.
const TABLE_MIN_LEVEL: Record<string, number> = {
  '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 15, '9': 18, '10': 20,
};

const TABLE_STAKES: Record<string, { entryFee: number; prizePool: number; timeMin: number }> = {
  '1': { entryFee: 250, prizePool: 500, timeMin: 5 },
  '2': { entryFee: 500, prizePool: 1000, timeMin: 5 },
  '3': { entryFee: 5000, prizePool: 10000, timeMin: 5 },
  '4': { entryFee: 10000, prizePool: 20000, timeMin: 10 },
  '5': { entryFee: 25000, prizePool: 50000, timeMin: 5 },
  '6': { entryFee: 50000, prizePool: 100000, timeMin: 3 },
  '7': { entryFee: 100000, prizePool: 200000, timeMin: 5 },
  '8': { entryFee: 500000, prizePool: 1000000, timeMin: 5 },
  '9': { entryFee: 1000000, prizePool: 2000000, timeMin: 5 },
  '10': { entryFee: 2500000, prizePool: 5000000, timeMin: 3 },
  'custom': { entryFee: 0, prizePool: 0, timeMin: 5 },
  'default': { entryFee: 1000, prizePool: 2000, timeMin: 5 },
};

export interface CustomRoomRecord {
  code: string;
  hostId: string;
  hostUsername: string;
  guestId?: string | null;
  guestUsername?: string | null;
  matchId: string;
  timeMin: number;
  stake: number;
  prize: number;
  status: 'waiting' | 'active' | 'completed' | 'expired';
  createdAt: number;
  hostColor?: 'w' | 'b';
  guestColor?: 'w' | 'b';
}

const customRooms = new Map<string, CustomRoomRecord>();
const inviteThrottle = new Map<string, number[]>();
const matchChatThrottle = new Map<string, number[]>();
setInterval(() => { matchChatThrottle.clear(); inviteThrottle.clear(); }, 10 * 60 * 1000).unref?.();
const failedJoinAttempts = new Map<string, { count: number; resetAt: number }>();

async function generateUniqueRoomCode(): Promise<string> {
  for (let attempt = 0; attempt < 50; attempt++) {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const existing = customRooms.get(code);
    if (!existing || existing.status === 'completed' || existing.status === 'expired') {
      if (pool) {
        try {
          const res = await pool.query(
            "SELECT code FROM public.custom_rooms WHERE code = $1 AND status IN ('waiting', 'active') LIMIT 1;",
            [code]
          );
          if (res.rows.length === 0) return code;
        } catch {
          return code;
        }
      } else {
        return code;
      }
    }
  }
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function checkJoinRateLimit(ipOrUserId: string): boolean {
  const now = Date.now();
  const entry = failedJoinAttempts.get(ipOrUserId);
  if (!entry || entry.resetAt < now) {
    failedJoinAttempts.set(ipOrUserId, { count: 1, resetAt: now + 60000 });
    return true;
  }
  if (entry.count >= 6) {
    return false;
  }
  entry.count++;
  return true;
}

let notifyUserBalance: ((userId: string, coins: number, matchId?: string) => void) | null = null;

// Module-level WebSocket State
const socketsByUser = new Map<string, Socket>();
const matchRooms = new Map<string, Set<string>>(); // matchId -> connected userIds
const sendJson = (ws: Socket, payload: any) => {
  if (ws && ws.connected) ws.emit('message', JSON.stringify(payload));
};

// In-Memory Match Store & Mutex for thread-safe atomic updates
const inMemoryMatches = new Map<string, ServerMatch>();
const matchMutexes = new Map<string, Promise<void>>();

let broadcastToMatchRoom: ((matchId: string, payload: any, excludeUserId?: string) => void) | null = null;

async function acquireMatchMutex(id: string): Promise<() => void> {
  const currentMutex = matchMutexes.get(id) || Promise.resolve();
  let release: () => void;
  const nextMutex = new Promise<void>((resolve) => {
    release = resolve;
  });
  matchMutexes.set(id, currentMutex.then(() => nextMutex));
  await currentMutex;
  return release!;
}

async function runWithTimeout<T>(promise: Promise<T>, ms = 300): Promise<T> {
  let timeoutHandle: any;
  const timeoutPromise = new Promise<T>((_, reject) => {
    timeoutHandle = setTimeout(() => reject(new Error('Redis operation timed out')), ms);
  });
  try {
    return await Promise.race([promise, timeoutPromise]);
  } finally {
    clearTimeout(timeoutHandle);
  }
}

async function getPlayerCoinBalance(userId: string): Promise<number> {
  if (!pool) return 0;
  try {
    const res = await pool.query('SELECT coins FROM public.player_stats WHERE id = $1 LIMIT 1;', [userId]);
    if (res.rows.length === 0) {
      await pool.query(
        `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
         VALUES ($1, 5000, 50, 1200, 0, 0, 0, 0, 1)
         ON CONFLICT (id) DO NOTHING;`,
        [userId]
      );
      return 500;
    }
    return res.rows[0].coins ?? 0;
  } catch (err) {
    console.error('Error fetching player coin balance:', err);
    return 0;
  }
}

interface StakeDeductionResult {
  success: boolean;
  error?: string;
  whiteBalance?: number;
  blackBalance?: number;
  alreadyDeducted?: boolean;
}

async function deductMatchStakes(match: ServerMatch): Promise<StakeDeductionResult> {
  if (!match.stake || match.stake <= 0) {
    match.stakesDeducted = true;
    const wBal = match.whiteId ? await getPlayerCoinBalance(match.whiteId) : 0;
    const bBal = match.blackId ? await getPlayerCoinBalance(match.blackId) : 0;
    return { success: true, whiteBalance: wBal, blackBalance: bBal };
  }

  if (match.stakesDeducted) {
    const wBal = match.whiteId ? await getPlayerCoinBalance(match.whiteId) : 0;
    const bBal = match.blackId ? await getPlayerCoinBalance(match.blackId) : 0;
    return { success: true, alreadyDeducted: true, whiteBalance: wBal, blackBalance: bBal };
  }

  if (!match.whiteId || !match.blackId) {
    return { success: false, error: 'Both players must be present to start match and deduct stakes' };
  }

  if (!pool) {
    return { success: false, error: 'Database connection is unavailable' };
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Double deduction protection: check transaction records
    const existingTx = await client.query(
      "SELECT id FROM public.match_coin_transactions WHERE match_id = $1 AND type = 'stake_deduction';",
      [match.id]
    );
    if (existingTx.rows.length >= 2) {
      await client.query('COMMIT');
      match.stakesDeducted = true;
      const wBal = await getPlayerCoinBalance(match.whiteId);
      const bBal = await getPlayerCoinBalance(match.blackId);
      return { success: true, alreadyDeducted: true, whiteBalance: wBal, blackBalance: bBal };
    }

    // Ensure rows exist in player_stats
    const sortedIds = [match.whiteId, match.blackId].sort();
    for (const uid of sortedIds) {
      await client.query(
        `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
         VALUES ($1, 5000, 50, 1200, 0, 0, 0, 0, 1)
         ON CONFLICT (id) DO NOTHING;`,
        [uid]
      );
    }

    // Lock both players in sorted order to avoid deadlock
    const statsRes = await client.query(
      'SELECT id, coins FROM public.player_stats WHERE id IN ($1, $2) ORDER BY id FOR UPDATE;',
      [sortedIds[0], sortedIds[1]]
    );

    const whiteRow = statsRes.rows.find((r: any) => r.id === match.whiteId);
    const blackRow = statsRes.rows.find((r: any) => r.id === match.blackId);

    const whiteCoins = whiteRow ? (whiteRow.coins ?? 0) : 0;
    const blackCoins = blackRow ? (blackRow.coins ?? 0) : 0;

    if (whiteCoins < match.stake) {
      await client.query('ROLLBACK');
      return {
        success: false,
        error: `White player has insufficient coins: ${whiteCoins} available, ${match.stake} required`,
        whiteBalance: whiteCoins,
        blackBalance: blackCoins
      };
    }
    if (blackCoins < match.stake) {
      await client.query('ROLLBACK');
      return {
        success: false,
        error: `Black player has insufficient coins: ${blackCoins} available, ${match.stake} required`,
        whiteBalance: whiteCoins,
        blackBalance: blackCoins
      };
    }

    // Deduct stakes atomically with non-negative constraints
    const newWhiteCoins = whiteCoins - match.stake;
    const newBlackCoins = blackCoins - match.stake;

    await client.query(
      'UPDATE public.player_stats SET coins = coins - $1 WHERE id = $2 AND coins >= $1;',
      [match.stake, match.whiteId]
    );
    await client.query(
      `INSERT INTO public.match_coin_transactions (id, match_id, user_id, type, amount, balance_before, balance_after)
       VALUES ($1, $2, $3, 'stake_deduction', $4, $5, $6)
       ON CONFLICT (id) DO NOTHING;`,
      [`${match.id}_stake_${match.whiteId}`, match.id, match.whiteId, match.stake, whiteCoins, newWhiteCoins]
    );

    await client.query(
      'UPDATE public.player_stats SET coins = coins - $1 WHERE id = $2 AND coins >= $1;',
      [match.stake, match.blackId]
    );
    await client.query(
      `INSERT INTO public.match_coin_transactions (id, match_id, user_id, type, amount, balance_before, balance_after)
       VALUES ($1, $2, $3, 'stake_deduction', $4, $5, $6)
       ON CONFLICT (id) DO NOTHING;`,
      [`${match.id}_stake_${match.blackId}`, match.id, match.blackId, match.stake, blackCoins, newBlackCoins]
    );

    await client.query('COMMIT');
    match.stakesDeducted = true;

    if (notifyUserBalance) {
      notifyUserBalance(match.whiteId, newWhiteCoins, match.id);
      notifyUserBalance(match.blackId, newBlackCoins, match.id);
    }

    return {
      success: true,
      whiteBalance: newWhiteCoins,
      blackBalance: newBlackCoins
    };
  } catch (err: any) {
    await client.query('ROLLBACK').catch(() => {});
    return {
      success: false,
      error: err?.message || 'Transaction error during stake deduction'
    };
  } finally {
    client.release();
  }
}

async function awardMatchPrize(match: ServerMatch): Promise<{ success: boolean; error?: string }> {
  if (match.prizeAwarded) return { success: true };
  if (!match.stakesDeducted && match.stake > 0) return { success: false, error: 'Stakes were not deducted' };
  if (!pool) return { success: false, error: 'Database unavailable' };

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Duplicate payout protection
    const existingTx = await client.query(
      "SELECT id FROM public.match_coin_transactions WHERE match_id = $1 AND type IN ('prize_payout', 'draw_refund');",
      [match.id]
    );
    if (existingTx.rows.length > 0) {
      await client.query('COMMIT');
      match.prizeAwarded = true;
      return { success: true };
    }

    if (match.status === 'draw' || match.winner === null) {
      // Draw: Refund both players their full stake
      if (match.stake > 0 && match.whiteId && match.blackId) {
        const sortedIds = [match.whiteId, match.blackId].sort();
        const statsRes = await client.query(
          'SELECT id, coins FROM public.player_stats WHERE id IN ($1, $2) ORDER BY id FOR UPDATE;',
          [sortedIds[0], sortedIds[1]]
        );
        const wRow = statsRes.rows.find((r: any) => r.id === match.whiteId);
        const bRow = statsRes.rows.find((r: any) => r.id === match.blackId);
        const wBefore = wRow ? (wRow.coins ?? 0) : 0;
        const bBefore = bRow ? (bRow.coins ?? 0) : 0;

        const wAfter = wBefore + match.stake;
        const bAfter = bBefore + match.stake;

        await client.query('UPDATE public.player_stats SET coins = coins + $1 WHERE id = $2;', [match.stake, match.whiteId]);
        await client.query(
          `INSERT INTO public.match_coin_transactions (id, match_id, user_id, type, amount, balance_before, balance_after)
           VALUES ($1, $2, $3, 'draw_refund', $4, $5, $6)
           ON CONFLICT (id) DO NOTHING;`,
          [`${match.id}_refund_${match.whiteId}`, match.id, match.whiteId, match.stake, wBefore, wAfter]
        );

        await client.query('UPDATE public.player_stats SET coins = coins + $1 WHERE id = $2;', [match.stake, match.blackId]);
        await client.query(
          `INSERT INTO public.match_coin_transactions (id, match_id, user_id, type, amount, balance_before, balance_after)
           VALUES ($1, $2, $3, 'draw_refund', $4, $5, $6)
           ON CONFLICT (id) DO NOTHING;`,
          [`${match.id}_refund_${match.blackId}`, match.id, match.blackId, match.stake, bBefore, bAfter]
        );

        if (notifyUserBalance) {
          notifyUserBalance(match.whiteId, wAfter, match.id);
          notifyUserBalance(match.blackId, bAfter, match.id);
        }
      }
    } else {
      // Winner takes prize
      const winnerId = match.winner === 'w' ? match.whiteId : match.blackId;
      const prizeAmount = match.prize > 0 ? match.prize : (match.stake * 2);

      if (winnerId && prizeAmount > 0) {
        const statsRes = await client.query(
          'SELECT id, coins FROM public.player_stats WHERE id = $1 FOR UPDATE;',
          [winnerId]
        );
        const currentCoins = statsRes.rows.length > 0 ? (statsRes.rows[0].coins ?? 0) : 0;
        const newCoins = currentCoins + prizeAmount;

        await client.query('UPDATE public.player_stats SET coins = coins + $1 WHERE id = $2;', [prizeAmount, winnerId]);
        await client.query(
          `INSERT INTO public.match_coin_transactions (id, match_id, user_id, type, amount, balance_before, balance_after)
           VALUES ($1, $2, $3, 'prize_payout', $4, $5, $6)
           ON CONFLICT (id) DO NOTHING;`,
          [`${match.id}_prize_${winnerId}`, match.id, winnerId, prizeAmount, currentCoins, newCoins]
        );

        if (notifyUserBalance) {
          notifyUserBalance(winnerId, newCoins, match.id);
        }
      }
    }

    await client.query('COMMIT');
    match.prizeAwarded = true;
    return { success: true };
  } catch (err: any) {
    await client.query('ROLLBACK').catch(() => {});
    return { success: false, error: err?.message || 'Failed to award prize' };
  } finally {
    client.release();
  }
}

async function getServerMatch(id: string): Promise<ServerMatch | null> {
  // 1. In-memory check (fastest, guaranteed available)
  const mem = inMemoryMatches.get(id);
  if (mem) return mem;

  // 2. If Redis is available, check Redis with strict timeout
  if (redis && isRedisAvailable) {
    try {
      const data = await runWithTimeout(redis.get(`match:${id}`), 300);
      if (data) {
        const parsed = JSON.parse(data) as ServerMatch;
        inMemoryMatches.set(id, parsed);
        return parsed;
      }
    } catch {
      // Redis unavailable or timed out
    }
  }

  // 3. Fallback: check PostgreSQL matches table
  if (pool) {
    try {
      const res = await pool.query('SELECT * FROM public.matches WHERE id = $1 LIMIT 1;', [id]);
      if (res.rows.length > 0) {
        const row = res.rows[0];
        const match: ServerMatch = {
          id: row.id,
          whiteId: row.white_player_id,
          blackId: row.black_player_id,
          fen: row.fen || 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          turn: (row.turn as 'w' | 'b') || 'w',
          whiteTimeMs: row.white_time_ms ?? 600000,
          blackTimeMs: row.black_time_ms ?? 600000,
          // For a restored ACTIVE match the clock restarts now, so the time the
          // server was down is not charged to the player whose turn it was.
          lastMoveAt: row.status === 'active' ? Date.now() : (row.last_move_timestamp ? new Date(row.last_move_timestamp).getTime() : 0),
          status: (row.status as any) || 'completed',
          winner: row.winner_id ? (row.winner_id === row.white_player_id ? 'w' : 'b') : null,
          // Only the SAN list is persisted; from/to/fen are not available after a restore.
          moveHistory: String(row.moves_san || '').trim() ? String(row.moves_san).trim().split(/\s+/).map((san: string, i: number) => ({ san, from: '', to: '', fen: '', by: '', at: 0, moveNumber: i + 1 })) : [],
          tableId: undefined,
          stake: row.stake ?? 0,
          prize: row.prize ?? 0,
          stakesDeducted: true,
          prizeAwarded: row.status !== 'active'
        };
        inMemoryMatches.set(id, match);
        return match;
      }
    } catch {}
  }

  return null;
}

// Atomic update helper: serializes concurrent moves and guarantees zero hangs
async function updateMatchAtomic(
  id: string,
  modifier: (match: ServerMatch | null) => any
): Promise<{
  match?: ServerMatch;
  moveResult?: any;
  shouldFinalize?: boolean;
  error?: string;
  status?: number;
  whiteBalance?: number;
  blackBalance?: number;
  userBalance?: number;
}> {
  const release = await acquireMatchMutex(id);
  try {
    const current = await getServerMatch(id);
    const result = await modifier(current ? JSON.parse(JSON.stringify(current)) : null);

    if (!result) {
      return { error: 'Unknown modifier error', status: 500 };
    }
    if (result.error) {
      return result;
    }

    const updatedMatch: ServerMatch = result.match || result;

    // 1. Immediately store in-memory (guaranteed, non-hanging, instantaneous)
    inMemoryMatches.set(id, updatedMatch);

    // 1b. Durable write-through to PostgreSQL for ACTIVE matches (non-blocking).
    // Without this, a server restart (or no Redis) lost every live game: the row
    // kept the starting FEN and fresh clocks while stakes were already deducted.
    if (pool && updatedMatch.status === 'active') {
      const sanNow = (updatedMatch.moveHistory || []).map(m => m.san).filter(Boolean).join(' ');
      pool.query(
        `UPDATE public.matches SET fen = $2, turn = $3, white_time_ms = $4, black_time_ms = $5,
                last_move_timestamp = $6, moves_san = $7
         WHERE id = $1 AND status = 'active';`,
        [id, updatedMatch.fen, updatedMatch.turn, Math.round(updatedMatch.whiteTimeMs), Math.round(updatedMatch.blackTimeMs),
         new Date(updatedMatch.lastMoveAt || Date.now()), sanNow]
      ).catch((e: any) => console.error('[match persist]', e?.message));
    }

    // 2. If Redis is available, attempt to write to Redis (non-blocking)
    if (redis && isRedisAvailable) {
      runWithTimeout(
        redis.set(`match:${id}`, JSON.stringify(updatedMatch), 'EX', 86400),
        300
      ).catch(() => {
        isRedisAvailable = false;
      });
    }

    return {
      match: updatedMatch,
      moveResult: result?.moveResult,
      shouldFinalize: result?.shouldFinalize,
      whiteBalance: result?.whiteBalance,
      blackBalance: result?.blackBalance,
      userBalance: result?.userBalance
    };
  } finally {
    release();
  }
}


async function advanceTournamentMatch(match: ServerMatch) {
  if (!db || !match.winner) return;
  try {
     const tMatchResult = await db.select().from(schema.tournament_matches).where(eq(schema.tournament_matches.match_id, match.id));
     const tMatch = tMatchResult[0];
     if (!tMatch) return;

     await db.transaction(async (tx: any) => {
        // Set winner
        await tx.update(schema.tournament_matches)
          .set({ winner_id: match.winner, status: 'completed' })
          .where(eq(schema.tournament_matches.id, tMatch.id));
        
        const nextRound = tMatch.round + 1;
        const nextMatchIndex = Math.floor(tMatch.match_index / 2);

        // Check if there are only 16 max participants, then max rounds = 4
        // To be safer, we check if it's the final. But we know 4 is final for 16.
        if (nextRound > 4) {
           await tx.update(schema.tournaments).set({ status: 'completed' }).where(eq(schema.tournaments.id, tMatch.tournament_id));
           const [t] = await tx.select().from(schema.tournaments).where(eq(schema.tournaments.id, tMatch.tournament_id));
           
           await tx.update(schema.tournament_participants)
             .set({ status: 'winner', rank: 1 })
             .where(and(eq(schema.tournament_participants.tournament_id, tMatch.tournament_id), eq(schema.tournament_participants.user_id, match.winner)));
             
           await tx.update(schema.player_stats)
             .set({ coins: sql`${schema.player_stats.coins} + ${t.prize_pool}` })
             .where(eq(schema.player_stats.id, match.winner));
        } else {
           const [nextMatch] = await tx.select().from(schema.tournament_matches)
              .where(and(eq(schema.tournament_matches.tournament_id, tMatch.tournament_id), eq(schema.tournament_matches.round, nextRound), eq(schema.tournament_matches.match_index, nextMatchIndex)));
              
           if (nextMatch) {
              if (tMatch.match_index % 2 === 0) {
                 await tx.update(schema.tournament_matches).set({ player1_id: match.winner }).where(eq(schema.tournament_matches.id, nextMatch.id));
              } else {
                 await tx.update(schema.tournament_matches).set({ player2_id: match.winner }).where(eq(schema.tournament_matches.id, nextMatch.id));
              }
           } else {
              await tx.insert(schema.tournament_matches).values({
                 id: crypto.randomUUID(),
                 tournament_id: tMatch.tournament_id,
                 round: nextRound,
                 match_index: nextMatchIndex,
                 player1_id: tMatch.match_index % 2 === 0 ? match.winner : null,
                 player2_id: tMatch.match_index % 2 !== 0 ? match.winner : null,
              });
           }
        }
     });
  } catch (e) {
     console.error('Failed to advance tournament bracket', e);
  }
}

// Real event progress. Called ONLY from server-verified places (finalizeMatch,
// inside its idempotent transaction). A player is auto-enrolled in every live
// (published, inside its time window) event the first time they finish a real
// match, so no client call can create or inflate progress.
async function bumpEventProgress(tx: any, userId: string, result: 'win' | 'loss' | 'draw') {
  try {
    await tx.transaction(async (t: any) => {
      const live = await t.select().from(schema.events).where(
        and(eq(schema.events.status, 'published'), sql`${schema.events.start_at} <= now()`, sql`${schema.events.end_at} >= now()`)
      );
      for (const ev of live) {
        if (!['games_played', 'games_won', 'win_streak'].includes(ev.event_type)) continue;
        let p = (await t.select().from(schema.event_participants)
          .where(and(eq(schema.event_participants.event_id, ev.id), eq(schema.event_participants.user_id, userId))).for('update'))[0];
        if (!p) {
          if (ev.max_participants) {
            const cnt = await t.select({ c: sql<number>`count(*)::int` }).from(schema.event_participants).where(eq(schema.event_participants.event_id, ev.id));
            if ((cnt[0]?.c || 0) >= ev.max_participants) continue;
          }
          await t.insert(schema.event_participants).values({ id: crypto.randomUUID(), event_id: ev.id, user_id: userId }).onConflictDoNothing();
          p = (await t.select().from(schema.event_participants)
            .where(and(eq(schema.event_participants.event_id, ev.id), eq(schema.event_participants.user_id, userId))).for('update'))[0];
          if (!p) continue;
        }
        const streak = result === 'win' ? (p.current_win_streak || 0) + 1 : 0;
        await t.update(schema.event_participants).set({
          games_played: (p.games_played || 0) + 1,
          games_won: (p.games_won || 0) + (result === 'win' ? 1 : 0),
          current_win_streak: streak,
          best_win_streak: Math.max(p.best_win_streak || 0, streak),
        }).where(eq(schema.event_participants.id, p.id));
      }
    });
  } catch (e) {
    // Event bookkeeping must never break match settlement.
    console.error('bumpEventProgress failed:', e);
  }
}

async function finalizeMatch(match: ServerMatch) {
  if (!db || match.status === 'active' || !match.whiteId || !match.blackId) return;

  try {
    // Update custom_rooms status if applicable
    for (const [, r] of customRooms) {
      if (r.matchId === match.id) {
        r.status = 'completed';
      }
    }
    if (pool) {
      pool.query("UPDATE public.custom_rooms SET status = 'completed', updated_at = NOW() WHERE match_id = $1;", [match.id]).catch(() => {});
    }

    // 1. Authoritative prize / draw payout in Supabase
    await awardMatchPrize(match);

    await advanceTournamentMatch(match);

    // 2. Persist match record and stats in Supabase
    const txResult = await db.transaction(async (tx: any) => {
      // Idempotency check: see if match is already saved
      const existing = await tx.select().from(schema.matches).where(eq(schema.matches.id, match.id));
      if (existing.length > 0) return; // Already processed

      // Get or create player stats helper
      const getPlayer = async (userId: string) => {
        let stats = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, userId));
        if (stats.length === 0) {
          const inserted = await tx.insert(schema.player_stats).values({ id: userId }).returning();
          return inserted[0];
        }
        return stats[0];
      };

      const whiteStats = await getPlayer(match.whiteId!);
      const blackStats = await getPlayer(match.blackId!);

      // Calculate ELO (K-factor = 32)
      const K = 32;
      const expectedWhite = 1 / (1 + Math.pow(10, (blackStats.rating - whiteStats.rating) / 400));
      const expectedBlack = 1 / (1 + Math.pow(10, (whiteStats.rating - blackStats.rating) / 400));

      let scoreWhite = 0.5;
      let scoreBlack = 0.5;
      let xpWhite = 15;
      let xpBlack = 15;
      const isLeaverMatch = match.status === 'abandoned' || match.status === 'resigned';
      if (match.winner === 'w') {
        scoreWhite = 1;
        scoreBlack = 0;
        xpWhite = 35;
        xpBlack = isLeaverMatch ? 0 : 10;
      } else if (match.winner === 'b') {
        scoreWhite = 0;
        scoreBlack = 1;
        xpWhite = isLeaverMatch ? 0 : 10;
        xpBlack = 35;
      }

      // Anti-farming: a match that ends by resign/abandon/timeout within the
      // first few moves (two accounts instantly resigning to each other) gives
      // NO XP and NO rating change. Checkmate/draw always count.
      const pliesPlayed = match.moveHistory?.length || 0;
      if (['resigned', 'abandoned', 'timeout'].includes(match.status) && pliesPlayed < 6) {
        xpWhite = 0;
        xpBlack = 0;
        scoreWhite = expectedWhite;
        scoreBlack = expectedBlack;
      }

      const newWhiteRating = Math.round(whiteStats.rating + K * (scoreWhite - expectedWhite));
      const newBlackRating = Math.round(blackStats.rating + K * (scoreBlack - expectedBlack));

      // Simple level calculation (e.g., Level = floor(xp / 100) + 1)
      const calculateLevel = (totalXp: number) => Math.floor(totalXp / 100) + 1;

      // Update White Stats
      const updatedWhiteXp = (whiteStats.xp || 0) + xpWhite;
      await tx.update(schema.player_stats).set({
        rating: newWhiteRating,
        xp: sql`COALESCE(xp, 0) + ${xpWhite}`,
        level: sql`TRUNC((COALESCE(xp, 0) + ${xpWhite}) / 100) + 1`,
        wins: sql`wins + ${match.winner === 'w' ? 1 : 0}`,
        losses: sql`losses + ${match.winner === 'b' ? 1 : 0}`,
        draws: sql`draws + ${match.winner === null ? 1 : 0}`,
        last_played_at: new Date(),
      }).where(eq(schema.player_stats.id, match.whiteId!));

      // Update Black Stats
      const updatedBlackXp = (blackStats.xp || 0) + xpBlack;
      await tx.update(schema.player_stats).set({
        rating: newBlackRating,
        xp: sql`COALESCE(xp, 0) + ${xpBlack}`,
        level: sql`TRUNC((COALESCE(xp, 0) + ${xpBlack}) / 100) + 1`,
        wins: sql`wins + ${match.winner === 'b' ? 1 : 0}`,
        losses: sql`losses + ${match.winner === 'w' ? 1 : 0}`,
        draws: sql`draws + ${match.winner === null ? 1 : 0}`,
        last_played_at: new Date(),
      }).where(eq(schema.player_stats.id, match.blackId!));

      // Update Royal Pass XP for both
      const updateRoyalPass = async (userId: string, gainedXp: number, isWin: boolean) => {
        let rp = await tx.select().from(schema.royal_pass).where(eq(schema.royal_pass.id, userId));
        if (rp.length === 0) {
          await tx.insert(schema.royal_pass).values({ id: userId, season_xp: gainedXp });
        } else {
          await tx.update(schema.royal_pass).set({ season_xp: sql`COALESCE(season_xp, 0) + ${gainedXp}` }).where(eq(schema.royal_pass.id, userId));
        }

        // Update challenges
        let chals = await tx.select().from(schema.user_challenges).where(eq(schema.user_challenges.user_id, userId));
        for (let chal of chals) {
          if (chal.is_completed) continue;
          if (chal.expires_at && new Date(chal.expires_at).getTime() < Date.now()) continue; // expired
          let newProgress = chal.progress || 0;
          if (chal.challenge_type === 'play_games') newProgress += 1;
          if (chal.challenge_type === 'win_games' && isWin) newProgress += 1;

          if (newProgress !== (chal.progress || 0)) {
            await tx.update(schema.user_challenges)
              .set({ progress: newProgress, is_completed: newProgress >= chal.target })
              .where(eq(schema.user_challenges.id, chal.id));
          }
        }
      };
      await updateRoyalPass(match.whiteId!, xpWhite, match.winner === 'w');
      await updateRoyalPass(match.blackId!, xpBlack, match.winner === 'b');

      // Events: count only matches that also count for XP/rating (same
      // anti-farming rule), so instant resign swaps can't farm event tasks.
      if (!(['resigned', 'abandoned', 'timeout'].includes(match.status) && pliesPlayed < 6)) {
        await bumpEventProgress(tx, match.whiteId!, match.winner === 'w' ? 'win' : match.winner === 'b' ? 'loss' : 'draw');
        await bumpEventProgress(tx, match.blackId!, match.winner === 'b' ? 'win' : match.winner === 'w' ? 'loss' : 'draw');
      }

      const sanMoves = match.moveHistory && match.moveHistory.length > 0 
        ? match.moveHistory.map(m => m.san).filter(Boolean).join(' ') 
        : '';
      
      await tx.insert(schema.matches).values({
        id: match.id,
        white_player_id: match.whiteId!,
        black_player_id: match.blackId!,
        winner_id: match.winner === 'w' ? match.whiteId : (match.winner === 'b' ? match.blackId : null),
        moves_san: sanMoves,
        fen: match.fen,
        status: match.status,
        turn: match.turn,
        white_time_ms: match.whiteTimeMs,
        black_time_ms: match.blackTimeMs,
        last_move_timestamp: new Date(match.lastMoveAt || Date.now()),
        stake: match.stake || 0,
        prize: match.prize || 0,
      });
    });
    
    // Clean up Redis and in-memory state safely without hanging
    if (redis && isRedisAvailable) {
      setTimeout(() => {
        if (redis && isRedisAvailable) {
          redis.del(`match:${match.id}`).catch(() => {});
        }
      }, 60000);
    }
    setTimeout(() => {
      inMemoryMatches.delete(match.id);
      matchMutexes.delete(match.id);
    }, 10 * 60 * 1000);
  } catch (err) {
    console.error("Failed to finalize match in DB:", err);
  }
}

const DISCONNECT_GRACE_PERIOD_MS = 35000; // 35 seconds (30-45s authoritative reconnect grace period)

interface DisconnectGraceInfo {
  matchId: string;
  userId: string;
  expiresAt: number;
  timer: NodeJS.Timeout;
}
const disconnectGraceTimers = new Map<string, DisconnectGraceInfo>(); // key: `${matchId}:${userId}`

async function handleDisconnectAbandonment(matchId: string, disconnectedUserId: string) {
  console.log(`[Disconnect Grace] Grace period expired for user ${disconnectedUserId} in match ${matchId}. Resolving as abandoned.`);
  const result = await updateMatchAtomic(matchId, (match) => {
    if (!match) return { error: 'Match not found', status: 404 };
    if (match.status !== 'active') return match; // Already completed or resigned
    if (match.disconnectedUserId !== disconnectedUserId) return match; // Reconnected or cancelled

    const isWhite = match.whiteId === disconnectedUserId;
    const isBlack = match.blackId === disconnectedUserId;
    if (!isWhite && !isBlack) return match;

    match.status = 'abandoned';
    match.winner = isWhite ? 'b' : 'w';
    match.disconnectedUserId = null;
    match.disconnectExpiresAt = null;
    return { match, shouldFinalize: true };
  });

  if (result.shouldFinalize && result.match) {
    if (broadcastToMatchRoom) {
      broadcastToMatchRoom(matchId, {
        type: 'match_abandoned',
        matchId,
        winner: result.match.winner,
        reason: 'abandonment',
        status: 'abandoned',
        disconnectedUserId
      });

      try {
        const payloadStr = JSON.stringify({
          op_code: 2,
          reason: 'abandonment',
          winner: result.match.winner,
          status: 'abandoned'
        });
        broadcastToMatchRoom(matchId, {
          type: 'match_data',
          matchId,
          opCode: 2,
          data: Buffer.from(payloadStr).toString('base64')
        });
      } catch {}
    }

    await finalizeMatch(result.match);
  }
}

function handleUserDisconnect(userId: string) {
  for (const [matchId, match] of inMemoryMatches) {
    if (match.status === 'active' && (match.whiteId === userId || match.blackId === userId)) {
      const graceKey = `${matchId}:${userId}`;
      if (disconnectGraceTimers.has(graceKey)) {
        clearTimeout(disconnectGraceTimers.get(graceKey).timer);
      }

      const otherUserId = match.whiteId === userId ? match.blackId : match.whiteId;
      const otherGraceKey = `${matchId}:${otherUserId}`;

      if (disconnectGraceTimers.has(otherGraceKey)) {
        console.log(`[Disconnect Grace] Both users disconnected from match ${matchId}. Resolving as draw immediately.`);
        
        // Clear the other user's timer
        clearTimeout(disconnectGraceTimers.get(otherGraceKey).timer);
        disconnectGraceTimers.delete(otherGraceKey);

        match.status = 'draw';
        match.winner = null;
        match.disconnectedUserId = null;
        match.disconnectExpiresAt = null;
        inMemoryMatches.set(matchId, match);

        finalizeMatch(match);
        
        if (broadcastToMatchRoom) {
          try {
            const payloadStr = JSON.stringify({
              op_code: 2,
              reason: 'both_disconnected',
              winner: null,
              status: 'draw'
            });
            broadcastToMatchRoom(matchId, {
              type: 'match_data',
              matchId,
              opCode: 2,
              data: Buffer.from(payloadStr).toString('base64')
            });
          } catch {}
        }
        continue;
      }

      const expiresAt = Date.now() + 40000; // 40 seconds
      match.disconnectedUserId = userId;
      match.disconnectExpiresAt = expiresAt;
      inMemoryMatches.set(matchId, match);

      console.log(`[Disconnect Grace] User ${userId} disconnected from match ${matchId}. Grace period expires at ${new Date(expiresAt).toISOString()}`);

      if (broadcastToMatchRoom) {
        broadcastToMatchRoom(matchId, {
          type: 'opponent_disconnected',
          matchId,
          userId,
          gracePeriodMs: 40000,
          expiresAt
        });
        // also send via match_data for redundancy
        try {
          const payloadStr = JSON.stringify({
            op_code: 2,
            reason: 'opponent_disconnected',
            expiresAt,
            disconnectedUserId: userId
          });
          broadcastToMatchRoom(matchId, {
            type: 'match_data',
            matchId,
            opCode: 2,
            data: Buffer.from(payloadStr).toString('base64')
          });
        } catch {}
      }

      const timer = setTimeout(async () => {
        disconnectGraceTimers.delete(graceKey);
        await handleDisconnectAbandonment(matchId, userId);
      }, 40000);

      disconnectGraceTimers.set(graceKey, { matchId, userId, expiresAt, timer });
    }
  }
}

function handleUserReconnect(matchId: string, userId: string): ServerMatch | null {
  const graceKey = `${matchId}:${userId}`;
  if (disconnectGraceTimers.has(graceKey)) {
    console.log(`[Disconnect Grace] User ${userId} reconnected to match ${matchId} within grace period! Cancelling abandonment timer.`);
    clearTimeout(disconnectGraceTimers.get(graceKey)!.timer);
    disconnectGraceTimers.delete(graceKey);
  }

  const match = inMemoryMatches.get(matchId);
  if (match) {
    if (match.disconnectedUserId === userId) {
      match.disconnectedUserId = null;
      match.disconnectExpiresAt = null;
      inMemoryMatches.set(matchId, match);

      if (broadcastToMatchRoom) {
        broadcastToMatchRoom(matchId, {
          type: 'opponent_reconnected',
          matchId,
          userId
        });
        try {
          const payloadStr = JSON.stringify({
            op_code: 2,
            reason: 'opponent_reconnected',
            reconnectedUserId: userId
          });
          broadcastToMatchRoom(matchId, {
            type: 'match_data',
            matchId,
            opCode: 2,
            data: Buffer.from(payloadStr).toString('base64')
          });
        } catch {}
      }
    }
    return match;
  }
  return null;
}

// Live (waiting/active) matches. This server keeps match state in memory and
// ALSO in Redis when Redis is configured, so the admin panel must read both
// (the old admin code only looked at Redis and crashed when it was not set).
async function listLiveMatches(limit = 200): Promise<any[]> {
  const byId = new Map<string, any>();
  for (const [id, m] of inMemoryMatches) {
    if (m && (m.status === 'active' || m.status === 'waiting')) byId.set(id, m);
  }
  if (redis && isRedisAvailable) {
    try {
      let cursor = '0';
      do {
        const [next, keys] = await redis.scan(cursor, 'MATCH', 'match:*', 'COUNT', 200);
        cursor = next;
        for (const key of keys) {
          const raw = await redis.get(key);
          if (!raw) continue;
          const m = JSON.parse(raw);
          if (m && (m.status === 'active' || m.status === 'waiting') && !byId.has(m.id)) byId.set(m.id, m);
        }
      } while (cursor !== '0' && byId.size < limit);
    } catch {}
  }
  return Array.from(byId.values()).slice(0, limit);
}

// ---- Auth hardening helpers ----
// Small in-memory limiter for the public auth routes (login/register/guest/
// resolve-email) so passwords can't be brute-forced at full speed.
const authRateBuckets = new Map<string, number[]>();
function authRateLimit(windowMs: number, max: number) {
  return (req: any, res: any, next: any) => {
    const key = `${req.path}:${req.ip || 'unknown'}`;
    const now = Date.now();
    const ts = (authRateBuckets.get(key) || []).filter((t) => now - t < windowMs);
    if (ts.length >= max) return res.status(429).json({ error: 'Too many attempts, please wait a minute and try again.' });
    ts.push(now);
    authRateBuckets.set(key, ts);
    next();
  };
}
setInterval(() => { authRateBuckets.clear(); }, 15 * 60 * 1000).unref?.();

// Passwords: scrypt with a random per-user salt. The old scheme was pbkdf2
// with ONE shared salt and 1000 rounds (fast to crack, identical passwords
// look identical). Old hashes are still accepted and silently upgraded on the
// next successful login.
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const dk = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${dk}`;
}
function verifyPassword(password: string, stored: string): { ok: boolean; needsRehash: boolean } {
  if (!stored) return { ok: false, needsRehash: false };
  if (stored.startsWith('scrypt$')) {
    const [, salt, dk] = stored.split('$');
    const test = crypto.scryptSync(password, salt, 64);
    const real = Buffer.from(dk, 'hex');
    return { ok: real.length === test.length && crypto.timingSafeEqual(real, test), needsRehash: false };
  }
  const legacy = crypto.pbkdf2Sync(password, 'kurdistan_chess_salt_2026', 1000, 64, 'sha512').toString('hex');
  const a = Buffer.from(legacy), b = Buffer.from(stored);
  return { ok: a.length === b.length && crypto.timingSafeEqual(a, b), needsRehash: true };
}

// ================= ADMIN PANEL API =================
// Every /api/admin/* route goes through requireAdmin, which verifies the
// server-signed JWT and then re-reads users.is_admin FROM THE DATABASE on
// every request (never from the token, body or client).
function registerAdmin(app: any, ctx: { db: any; pool: any; redis: any; JWT_SECRET: string; requireAuth: any }) {
  const { db, pool, redis, JWT_SECRET } = ctx;
  const requireAuthAny = ctx.requireAuth;
  const isRedisHealthy = () => !!redis && redis.status === 'ready';

  const rateBuckets = new Map<string, number[]>();
  const rateLimit = (windowMs: number, max: number) => (req: any, res: any, next: any) => {
    const key = `${req.path}:${req.user?.uid || req.ip || 'unknown'}`;
    const now = Date.now();
    const ts = (rateBuckets.get(key) || []).filter((t) => now - t < windowMs);
    if (ts.length >= max) return res.status(429).json({ error: 'Too many requests, please slow down.' });
    ts.push(now);
    rateBuckets.set(key, ts);
    next();
  };

  const requireAdmin = async (req: any, res: any, next: any) => {
    const h = req.headers.authorization;
    if (!h || !h.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing or invalid authorization header' });
    let uid = '';
    try {
      const d: any = jwt.verify(h.split(' ')[1], JWT_SECRET);
      uid = String(d?.sub || d?.uid || '');
      if (!uid) return res.status(401).json({ error: 'Invalid token payload' });
    } catch {
      return res.status(401).json({ error: 'Invalid or expired token' });
    }
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const rows = await db.select().from(schema.users).where(eq(schema.users.id, uid));
      if (rows.length === 0 || !rows[0].is_admin) return res.status(403).json({ error: 'Admin access required' });
      req.user = { uid };
      req.adminUser = rows[0];
      next();
    } catch (e) {
      console.error('Admin authorization check failed:', e);
      return res.status(500).json({ error: 'Authorization check failed' });
    }
  };

  async function logAdminAction(adminId: string, action: string, targetUserId: string | null, oldValue: any, newValue: any, reason: string | null) {
    if (!db) return;
    try {
      await db.insert(schema.admin_audit_log).values({
        id: crypto.randomUUID(), admin_id: adminId, action, target_user_id: targetUserId,
        old_value: oldValue ?? null, new_value: newValue ?? null, reason: reason ?? null,
      });
    } catch (e) { console.error('Failed to write admin audit log:', e); }
  }

  app.get('/api/admin/verify', requireAdmin, async (req, res) => {
    res.json({ isAdmin: true, id: req.adminUser.id, username: req.adminUser.username });
  });

  app.get('/api/admin/dashboard', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });

      const userCountRows = await db.select({ count: sql<number>`count(*)::int` }).from(schema.users);
      const guestCountRows = await db.select({ count: sql<number>`count(*)::int` }).from(schema.users).where(eq(schema.users.is_guest, true));
      const bannedCountRows = await db.select({ count: sql<number>`count(*)::int` }).from(schema.users).where(eq(schema.users.is_banned, true));
      const matchCountRows = await db.select({ count: sql<number>`count(*)::int` }).from(schema.matches);
      const economyRows = await db.select({
        totalCoins: sql<number>`coalesce(sum(${schema.player_stats.coins}),0)::bigint`,
        totalGems: sql<number>`coalesce(sum(${schema.player_stats.gems}),0)::bigint`,
      }).from(schema.player_stats);
      const recentRegs = await db.select({
        id: schema.users.id, username: schema.users.username, email: schema.users.email, created_at: schema.users.created_at,
      }).from(schema.users).orderBy(desc(schema.users.created_at)).limit(10);
      const recentMatches = await db.select().from(schema.matches).orderBy(desc(schema.matches.created_at)).limit(10);
      const todayRegs = await db.select({ count: sql<number>`count(*)::int` }).from(schema.users).where(sql`${schema.users.created_at} >= CURRENT_DATE`);
      const todayMatches = await db.select({ count: sql<number>`count(*)::int` }).from(schema.matches).where(sql`${schema.matches.created_at} >= CURRENT_DATE`);

      // Live counts from the in-memory realtime layer (real, not estimated).
      const onlineCount = (global as any).__getOnlineCount ? (global as any).__getOnlineCount() : 0;
      const activeMatchCount = (await listLiveMatches(1000)).filter((m: any) => m.status === 'active').length;

      res.json({
        totalUsers: userCountRows[0]?.count || 0,
        guestUsers: guestCountRows[0]?.count || 0,
        bannedUsers: bannedCountRows[0]?.count || 0,
        onlinePlayers: onlineCount,
        totalMatches: matchCountRows[0]?.count || 0,
        activeMatches: activeMatchCount,
        totalCoinsInEconomy: Number(economyRows[0]?.totalCoins || 0),
        totalGemsInEconomy: Number(economyRows[0]?.totalGems || 0),
        newUsersToday: todayRegs[0]?.count || 0,
        matchesToday: todayMatches[0]?.count || 0,
        recentRegistrations: recentRegs,
        recentMatches: recentMatches,
        systemStatus: { dbConnected: true, redisConnected: isRedisHealthy() },
      });
    } catch (e: any) {
      console.error('Admin dashboard error:', e);
      res.status(500).json({ error: e.message || 'Failed to load dashboard' });
    }
  });

  app.get('/api/admin/users/search', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const q = ((req.query.q as string) || '').trim();
      if (q.length < 1) return res.json({ users: [] });

      const rows = await db.select({
        id: schema.users.id,
        username: schema.users.username,
        email: schema.users.email,
        is_guest: schema.users.is_guest,
        is_admin: schema.users.is_admin,
        is_banned: schema.users.is_banned,
        is_suspended: schema.users.is_suspended,
        created_at: schema.users.created_at,
        coins: schema.player_stats.coins,
        gems: schema.player_stats.gems,
        rating: schema.player_stats.rating,
        level: schema.player_stats.level,
      })
        .from(schema.users)
        .leftJoin(schema.player_stats, eq(schema.users.id, schema.player_stats.id))
        .where(or(
          ilike(schema.users.username, `%${q}%`),
          ilike(schema.users.email, `%${q}%`),
          eq(schema.users.id, q)
        ))
        .limit(25);

      res.json({ users: rows });
    } catch (e: any) {
      console.error('Admin user search error:', e);
      res.status(500).json({ error: e.message || 'Search failed' });
    }
  });

  app.get('/api/admin/users/:id', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const targetId = req.params.id;

      const userRows = await db.select().from(schema.users).where(eq(schema.users.id, targetId));
      if (userRows.length === 0) return res.status(404).json({ error: 'User not found' });

      const statsRows = await db.select().from(schema.player_stats).where(eq(schema.player_stats.id, targetId));
      const inventory = await db.select().from(schema.user_inventory).where(eq(schema.user_inventory.user_id, targetId));
      const recentMatches = await db.select().from(schema.matches)
        .where(or(eq(schema.matches.white_player_id, targetId), eq(schema.matches.black_player_id, targetId)))
        .orderBy(desc(schema.matches.created_at))
        .limit(20);

      const { password_hash, ...safeUser } = userRows[0];
      res.json({
        user: safeUser,
        stats: statsRows[0] || null,
        inventory,
        recentMatches,
        isOnline: (global as any).__isUserOnline ? (global as any).__isUserOnline(targetId) : false,
      });
    } catch (e: any) {
      console.error('Admin user detail error:', e);
      res.status(500).json({ error: e.message || 'Failed to load user' });
    }
  });

  app.post('/api/admin/users/:id/ban', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const targetId = req.params.id;
      const { reason } = req.body;
      if (!reason || !String(reason).trim()) return res.status(400).json({ error: 'A reason is required to ban a user.' });

      const rows = await db.select().from(schema.users).where(eq(schema.users.id, targetId));
      if (rows.length === 0) return res.status(404).json({ error: 'User not found' });
      if (rows[0].is_admin) return res.status(400).json({ error: 'Cannot ban another admin.' });

      await db.update(schema.users).set({ is_banned: true, ban_reason: reason }).where(eq(schema.users.id, targetId));
      invalidateAuthRow(targetId);
      (global as any).__disconnectUser?.(targetId); // kick any live realtime connection
      await logAdminAction(req.adminUser.id, 'ban', targetId, { is_banned: rows[0].is_banned }, { is_banned: true, ban_reason: reason }, reason);
      res.json({ success: true });
    } catch (e: any) {
      console.error('Admin ban error:', e);
      res.status(500).json({ error: e.message || 'Failed to ban user' });
    }
  });

  app.post('/api/admin/users/:id/unban', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const targetId = req.params.id;
      await db.update(schema.users).set({ is_banned: false, ban_reason: null }).where(eq(schema.users.id, targetId));
      invalidateAuthRow(targetId);
      await logAdminAction(req.adminUser.id, 'unban', targetId, { is_banned: true }, { is_banned: false }, req.body?.reason || null);
      res.json({ success: true });
    } catch (e: any) {
      console.error('Admin unban error:', e);
      res.status(500).json({ error: e.message || 'Failed to unban user' });
    }
  });

  app.post('/api/admin/users/:id/suspend', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const targetId = req.params.id;
      const { untilISO, reason } = req.body;
      if (!untilISO || isNaN(new Date(untilISO).getTime())) return res.status(400).json({ error: 'A valid suspend-until date is required.' });
      if (!reason || !String(reason).trim()) return res.status(400).json({ error: 'A reason is required to suspend a user.' });

      const rows = await db.select().from(schema.users).where(eq(schema.users.id, targetId));
      if (rows.length === 0) return res.status(404).json({ error: 'User not found' });
      if (rows[0].is_admin) return res.status(400).json({ error: 'Cannot suspend another admin.' });

      await db.update(schema.users).set({ is_suspended: true, suspended_until: new Date(untilISO) }).where(eq(schema.users.id, targetId));
      invalidateAuthRow(targetId);
      await logAdminAction(req.adminUser.id, 'suspend', targetId, { is_suspended: rows[0].is_suspended }, { is_suspended: true, suspended_until: untilISO }, reason);
      res.json({ success: true });
    } catch (e: any) {
      console.error('Admin suspend error:', e);
      res.status(500).json({ error: e.message || 'Failed to suspend user' });
    }
  });

  app.post('/api/admin/users/:id/unsuspend', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const targetId = req.params.id;
      await db.update(schema.users).set({ is_suspended: false, suspended_until: null }).where(eq(schema.users.id, targetId));
      invalidateAuthRow(targetId);
      await logAdminAction(req.adminUser.id, 'unsuspend', targetId, { is_suspended: true }, { is_suspended: false }, req.body?.reason || null);
      res.json({ success: true });
    } catch (e: any) {
      console.error('Admin unsuspend error:', e);
      res.status(500).json({ error: e.message || 'Failed to unsuspend user' });
    }
  });

  // Manual economy adjustment — the ONLY admin action that touches coins/
  // gems directly. Always requires a reason and always writes a full
  // before/after audit record; nothing about a player's balance is ever
  // changed silently.
  app.post('/api/admin/users/:id/economy', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const targetId = req.params.id;
      const { coinsDelta, gemsDelta, reason } = req.body;
      if (!reason || !String(reason).trim()) return res.status(400).json({ error: 'A reason is required for any economy change.' });
      const cDelta = Number(coinsDelta) || 0;
      const gDelta = Number(gemsDelta) || 0;
      if (!Number.isInteger(cDelta) || !Number.isInteger(gDelta) || Math.abs(cDelta) > 10_000_000 || Math.abs(gDelta) > 100_000) {
        return res.status(400).json({ error: 'Deltas must be whole numbers within allowed limits.' });
      }
      if (cDelta === 0 && gDelta === 0) return res.status(400).json({ error: 'No change specified.' });
      if ((await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.id, targetId))).length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }

      const result = await db.transaction(async (tx: any) => {
        const rows = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, targetId)).for('update');
        const before = rows[0] || { coins: 0, gems: 0 };
        const newCoins = Math.max(0, (before.coins || 0) + cDelta);
        const newGems = Math.max(0, (before.gems || 0) + gDelta);

        if (rows.length > 0) {
          await tx.update(schema.player_stats).set({ coins: newCoins, gems: newGems }).where(eq(schema.player_stats.id, targetId));
        } else {
          await tx.insert(schema.player_stats).values({ id: targetId, coins: newCoins, gems: newGems });
        }
        return { before: { coins: before.coins || 0, gems: before.gems || 0 }, after: { coins: newCoins, gems: newGems } };
      });

      await logAdminAction(req.adminUser.id, 'economy_adjust', targetId, result.before, result.after, reason);
      res.json({ success: true, ...result });
    } catch (e: any) {
      console.error('Admin economy adjust error:', e);
      res.status(500).json({ error: e.message || 'Failed to adjust economy' });
    }
  });

  // --- Reports ---
  // Minimal player-facing creation endpoint (not wired into the existing
  // player UI — out of scope here — but real and functional so the admin
  // moderation view below has genuine data to work with).
  app.post('/api/reports', requireAuthAny, rateLimit(60 * 1000, 5), async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const { reportedUserId, reason, matchId } = req.body;
      if (!reportedUserId || !reason || !String(reason).trim()) {
        return res.status(400).json({ error: 'reportedUserId and reason are required' });
      }
      if (typeof reportedUserId !== 'string' || reportedUserId === req.user.uid) return res.status(400).json({ error: 'Invalid reported user' });
      if (String(reason).length > 500) return res.status(400).json({ error: 'Reason too long (max 500)' });
      if ((await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.id, reportedUserId))).length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
      const id = crypto.randomUUID();
      await db.insert(schema.user_reports).values({
        id,
        reporter_id: req.user.uid,
        reported_user_id: reportedUserId,
        match_id: typeof matchId === 'string' ? matchId.slice(0, 100) : null,
        reason: String(reason),
      });
      res.json({ success: true, id });
    } catch (e: any) {
      console.error('Report creation error:', e);
      res.status(500).json({ error: e.message || 'Failed to file report' });
    }
  });

  app.get('/api/admin/reports', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const status = (req.query.status as string) || 'open';
      const rows = status === 'all'
        ? await db.select().from(schema.user_reports).orderBy(desc(schema.user_reports.created_at)).limit(100)
        : await db.select().from(schema.user_reports).where(eq(schema.user_reports.status, status)).orderBy(desc(schema.user_reports.created_at)).limit(100);
      res.json({ reports: rows });
    } catch (e: any) {
      console.error('Admin reports fetch error:', e);
      res.status(500).json({ error: e.message || 'Failed to load reports' });
    }
  });

  app.post('/api/admin/reports/:id/resolve', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const { notes } = req.body;
      await db.update(schema.user_reports).set({
        status: 'resolved',
        resolution_notes: notes || null,
        resolved_by: req.adminUser.id,
        resolved_at: new Date(),
      }).where(eq(schema.user_reports.id, req.params.id));
      await logAdminAction(req.adminUser.id, 'resolve_report', null, null, { reportId: req.params.id, notes }, notes || null);
      res.json({ success: true });
    } catch (e: any) {
      console.error('Admin resolve report error:', e);
      res.status(500).json({ error: e.message || 'Failed to resolve report' });
    }
  });

  // --- Announcements ---
  app.get('/api/announcements', async (_req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const rows = await db.select().from(schema.announcements).where(eq(schema.announcements.is_active, true)).orderBy(desc(schema.announcements.created_at)).limit(20);
      res.json({ announcements: rows });
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to load announcements' });
    }
  });

  app.get('/api/admin/announcements', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const rows = await db.select().from(schema.announcements).orderBy(desc(schema.announcements.created_at)).limit(100);
      res.json({ announcements: rows });
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to load announcements' });
    }
  });

  app.post('/api/admin/announcements', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const { title, body } = req.body;
      if (!title || !body) return res.status(400).json({ error: 'title and body are required' });
      const id = crypto.randomUUID();
      await db.insert(schema.announcements).values({ id, title, body, created_by: req.adminUser.id });
      await logAdminAction(req.adminUser.id, 'announcement_create', null, null, { id, title }, null);
      res.json({ success: true, id });
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to create announcement' });
    }
  });

  app.patch('/api/admin/announcements/:id', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const updates: any = { updated_at: new Date() };
      if (typeof req.body.title === 'string') updates.title = req.body.title;
      if (typeof req.body.body === 'string') updates.body = req.body.body;
      if (typeof req.body.isActive === 'boolean') updates.is_active = req.body.isActive;
      await db.update(schema.announcements).set(updates).where(eq(schema.announcements.id, req.params.id));
      await logAdminAction(req.adminUser.id, 'announcement_update', null, null, { id: req.params.id, ...updates }, null);
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to update announcement' });
    }
  });

  app.delete('/api/admin/announcements/:id', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      await db.delete(schema.announcements).where(eq(schema.announcements.id, req.params.id));
      await logAdminAction(req.adminUser.id, 'announcement_delete', null, { id: req.params.id }, null, null);
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to delete announcement' });
    }
  });

  // --- Match monitoring (read-only — admin can watch, never move) ---
  app.get('/api/admin/matches', requireAdmin, async (req, res) => {
    try {
      const active = await listLiveMatches(200);

      let recentCompleted: any[] = [];
      if (db) {
        recentCompleted = await db.select().from(schema.matches).orderBy(desc(schema.matches.created_at)).limit(50);
      }

      // Real usernames for the player ids shown in the tables.
      const names: Record<string, string> = {};
      try {
        const ids = [...new Set([
          ...active.flatMap((m: any) => [m.whiteId, m.blackId]),
          ...recentCompleted.flatMap((m: any) => [m.white_player_id, m.black_player_id]),
        ].filter(Boolean))] as string[];
        if (ids.length && pool) {
          const r = await pool.query('SELECT id, username FROM public.users WHERE id = ANY($1::text[]);', [ids]);
          for (const row of r.rows) names[row.id] = row.username;
        }
      } catch {}
      res.json({ activeMatches: active, recentCompleted, names });
    } catch (e: any) {
      console.error('Admin matches error:', e);
      res.status(500).json({ error: e.message || 'Failed to load matches' });
    }
  });

  // --- System health ---
  app.get('/api/admin/system-health', requireAdmin, async (req, res) => {
    let dbConnected = false;
    try { await pool.query('SELECT 1'); dbConnected = true; } catch {}
    res.json({
      dbConnected,
      redisConnected: isRedisHealthy(),
      config: (global as any).__configStatus,
      note: redis ? undefined : 'Redis is not configured: match state is kept in server memory (single instance).',
      websocketOnlineCount: (global as any).__getOnlineCount ? (global as any).__getOnlineCount() : 0,
      uptimeSeconds: Math.floor(process.uptime()),
      nodeVersion: process.version,
      serverTime: new Date().toISOString(),
    });
  });

  // --- Audit log ---
  app.get('/api/admin/audit-log', requireAdmin, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const rows = await db.select().from(schema.admin_audit_log).orderBy(desc(schema.admin_audit_log.created_at)).limit(200);
      res.json({ log: rows });
    } catch (e: any) {
      res.status(500).json({ error: e.message || 'Failed to load audit log' });
    }
  });


  // Chat moderation (admin): list latest messages and delete one (audited).
  app.get('/api/admin/chat', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const rows = await db.select().from(schema.global_chat_messages).orderBy(desc(schema.global_chat_messages.created_at)).limit(100);
      res.json({ messages: rows.map((m: any) => ({ id: m.id, userId: m.user_id, senderName: m.username, level: m.level, text: m.text, createdAt: m.created_at })) });
    } catch (e: any) { res.status(500).json({ error: 'Failed to load chat' }); }
  });
  app.delete('/api/admin/chat/:id', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const rows = await db.select().from(schema.global_chat_messages).where(eq(schema.global_chat_messages.id, req.params.id));
      if (!rows[0]) return res.status(404).json({ error: 'Message not found' });
      await db.delete(schema.global_chat_messages).where(eq(schema.global_chat_messages.id, req.params.id));
      await logAdminAction(req.adminUser.id, 'delete_chat_message', rows[0].user_id, { text: rows[0].text }, null, req.body?.reason || null);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: 'Failed to delete message' }); }
  });

  // ================= EVENT SYSTEM (admin) =================
  const EVENT_TYPES = ['games_played', 'games_won', 'win_streak', 'puzzles_solved'];
  const RP_REWARD_ITEM_IDS = ['board_goldencitadel', 'avatar_supremecrown', 'board_redyellow', 'avatar_redcrown', 'chest_ruby'];
  const itemTypeOf = (id: string) => (SHOP_CATALOG.find((i) => i.id === id)?.type) || id.split('_')[0];
  const isKnownItem = (id: any) => typeof id === 'string' && (SHOP_CATALOG.some((i) => i.id === id) || RP_REWARD_ITEM_IDS.includes(id));

  const eventScore = (type: string, p: any) => {
    if (!p) return 0;
    if (type === 'games_played') return p.games_played || 0;
    if (type === 'games_won') return p.games_won || 0;
    if (type === 'win_streak') return p.best_win_streak || 0;
    if (type === 'puzzles_solved') return p.puzzles_solved || 0;
    return 0;
  };
  const computeDisplayStatus = (ev: any) => {
    const now = Date.now();
    if (ev.status === 'draft') return 'draft';
    if (ev.status === 'ended' || now > new Date(ev.end_at).getTime()) return 'ended';
    if (ev.status === 'paused') return 'paused';
    if (now < new Date(ev.start_at).getTime()) return 'upcoming';
    return 'active';
  };
  // ---- Admin event management (requireAdmin checks DB is_admin on every call) ----
  const toDate = (v: any) => { const d = new Date(v); return isNaN(d.getTime()) ? null : d; };
  const posInt = (v: any, def = 0) => { const n = Math.floor(Number(v)); return Number.isFinite(n) && n >= 0 ? n : def; };

  app.get('/api/admin/events', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const rows = await db.select().from(schema.events).orderBy(desc(schema.events.created_at));
      const counts = await db.select({ event_id: schema.event_participants.event_id, c: sql<number>`count(*)::int` }).from(schema.event_participants).groupBy(schema.event_participants.event_id);
      const cm = new Map(counts.map((c: any) => [c.event_id, c.c]));
      res.json({ events: rows.map((e: any) => ({ ...e, displayStatus: computeDisplayStatus(e), participants: cm.get(e.id) || 0 })) });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.post('/api/admin/events', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const { name, description, bannerUrl, eventType, startAt, endAt, maxParticipants, leaderboardEnabled } = req.body || {};
      const s = toDate(startAt), e2 = toDate(endAt);
      if (!name || typeof name !== 'string' || !name.trim()) return res.status(400).json({ error: 'name is required' });
      if (!EVENT_TYPES.includes(eventType)) return res.status(400).json({ error: 'invalid eventType' });
      if (!s || !e2 || s >= e2) return res.status(400).json({ error: 'startAt must be before endAt' });
      const id = crypto.randomUUID();
      const row = { id, name: name.trim().slice(0, 120), description: String(description || '').slice(0, 2000), banner_url: bannerUrl || null, event_type: eventType, start_at: s, end_at: e2, status: 'draft', max_participants: maxParticipants ? posInt(maxParticipants) || null : null, leaderboard_enabled: leaderboardEnabled !== false, created_by: req.adminUser.id };
      await db.insert(schema.events).values(row);
      await logAdminAction(req.adminUser.id, 'event_create', null, null, row, null);
      res.json({ event: row });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.get('/api/admin/events/:id', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const ev = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
      if (!ev) return res.status(404).json({ error: 'Event not found' });
      const tasks = await db.select().from(schema.event_tasks).where(eq(schema.event_tasks.event_id, ev.id)).orderBy(schema.event_tasks.task_order);
      res.json({ event: { ...ev, displayStatus: computeDisplayStatus(ev) }, tasks });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.put('/api/admin/events/:id', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const old = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
      if (!old) return res.status(404).json({ error: 'Event not found' });
      const b = req.body || {};
      const patch: any = { updated_at: new Date() };
      if (b.name !== undefined) patch.name = String(b.name).trim().slice(0, 120) || old.name;
      if (b.description !== undefined) patch.description = String(b.description).slice(0, 2000);
      if (b.bannerUrl !== undefined) patch.banner_url = b.bannerUrl || null;
      if (b.eventType !== undefined) { if (!EVENT_TYPES.includes(b.eventType)) return res.status(400).json({ error: 'invalid eventType' }); patch.event_type = b.eventType; }
      if (b.startAt !== undefined) { const d = toDate(b.startAt); if (!d) return res.status(400).json({ error: 'invalid startAt' }); patch.start_at = d; }
      if (b.endAt !== undefined) { const d = toDate(b.endAt); if (!d) return res.status(400).json({ error: 'invalid endAt' }); patch.end_at = d; }
      if ((patch.start_at || old.start_at) >= (patch.end_at || old.end_at)) return res.status(400).json({ error: 'startAt must be before endAt' });
      if (b.maxParticipants !== undefined) patch.max_participants = b.maxParticipants ? posInt(b.maxParticipants) || null : null;
      if (b.leaderboardEnabled !== undefined) patch.leaderboard_enabled = !!b.leaderboardEnabled;
      await db.update(schema.events).set(patch).where(eq(schema.events.id, old.id));
      await logAdminAction(req.adminUser.id, 'event_update', null, old, patch, null);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.delete('/api/admin/events/:id', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const old = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
      if (!old) return res.status(404).json({ error: 'Event not found' });
      await db.transaction(async (tx: any) => {
        await tx.delete(schema.event_task_claims).where(eq(schema.event_task_claims.event_id, old.id));
        await tx.delete(schema.event_participants).where(eq(schema.event_participants.event_id, old.id));
        await tx.delete(schema.event_tasks).where(eq(schema.event_tasks.event_id, old.id));
        await tx.delete(schema.events).where(eq(schema.events.id, old.id));
      });
      await logAdminAction(req.adminUser.id, 'event_delete', null, old, null, null);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  const setEventStatus = (path: string, newStatus: string, action: string) => {
    app.post(`/api/admin/events/:id/${path}`, requireAdmin, async (req: any, res) => {
      try {
        if (!db) return res.status(503).json({ error: 'Database disconnected.' });
        const old = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
        if (!old) return res.status(404).json({ error: 'Event not found' });
        if (old.status === 'ended') return res.status(400).json({ error: 'Event already ended' });
        if (path === 'publish') {
          const n = await db.select({ c: sql<number>`count(*)::int` }).from(schema.event_tasks).where(eq(schema.event_tasks.event_id, old.id));
          if (!(n[0]?.c > 0)) return res.status(400).json({ error: 'Add at least one task before publishing' });
        }
        await db.update(schema.events).set({ status: newStatus, updated_at: new Date() }).where(eq(schema.events.id, old.id));
        await logAdminAction(req.adminUser.id, action, null, { status: old.status }, { status: newStatus }, null);
        res.json({ success: true, status: newStatus });
      } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
    });
  };
  setEventStatus('publish', 'published', 'event_publish');
  setEventStatus('pause', 'paused', 'event_pause');
  setEventStatus('resume', 'published', 'event_resume');
  setEventStatus('end', 'ended', 'event_end');

  app.post('/api/admin/events/:id/tasks', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const ev = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
      if (!ev) return res.status(404).json({ error: 'Event not found' });
      const b = req.body || {};
      const target = posInt(b.targetAmount);
      if (target < 1) return res.status(400).json({ error: 'targetAmount must be >= 1' });
      if (b.rewardItemId && !isKnownItem(b.rewardItemId)) return res.status(400).json({ error: 'Unknown rewardItemId (must be a real shop/pass item id)' });
      const row = { id: crypto.randomUUID(), event_id: ev.id, task_type: ev.event_type, target_amount: target, task_order: posInt(b.order), is_enabled: b.isEnabled !== false, reward_coins: posInt(b.rewardCoins), reward_gems: posInt(b.rewardGems), reward_item_id: b.rewardItemId || null, reward_xp: posInt(b.rewardXp) };
      await db.insert(schema.event_tasks).values(row);
      await logAdminAction(req.adminUser.id, 'event_task_create', null, null, row, null);
      res.json({ task: row });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.put('/api/admin/events/:id/tasks/:taskId', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const old = (await db.select().from(schema.event_tasks).where(and(eq(schema.event_tasks.id, req.params.taskId), eq(schema.event_tasks.event_id, req.params.id))))[0];
      if (!old) return res.status(404).json({ error: 'Task not found' });
      const b = req.body || {}; const patch: any = {};
      if (b.targetAmount !== undefined) { const t = posInt(b.targetAmount); if (t < 1) return res.status(400).json({ error: 'targetAmount must be >= 1' }); patch.target_amount = t; }
      if (b.order !== undefined) patch.task_order = posInt(b.order);
      if (b.isEnabled !== undefined) patch.is_enabled = !!b.isEnabled;
      if (b.rewardCoins !== undefined) patch.reward_coins = posInt(b.rewardCoins);
      if (b.rewardGems !== undefined) patch.reward_gems = posInt(b.rewardGems);
      if (b.rewardXp !== undefined) patch.reward_xp = posInt(b.rewardXp);
      if (b.rewardItemId && !isKnownItem(b.rewardItemId)) return res.status(400).json({ error: 'Unknown rewardItemId (must be a real shop/pass item id)' });
      if (b.rewardItemId !== undefined) patch.reward_item_id = b.rewardItemId || null;
      if (!Object.keys(patch).length) return res.status(400).json({ error: 'Nothing to update' });
      await db.update(schema.event_tasks).set(patch).where(eq(schema.event_tasks.id, old.id));
      await logAdminAction(req.adminUser.id, 'event_task_update', null, old, patch, null);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.delete('/api/admin/events/:id/tasks/:taskId', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const old = (await db.select().from(schema.event_tasks).where(and(eq(schema.event_tasks.id, req.params.taskId), eq(schema.event_tasks.event_id, req.params.id))))[0];
      if (!old) return res.status(404).json({ error: 'Task not found' });
      await db.transaction(async (tx: any) => {
        await tx.delete(schema.event_task_claims).where(eq(schema.event_task_claims.task_id, old.id));
        await tx.delete(schema.event_tasks).where(eq(schema.event_tasks.id, old.id));
      });
      await logAdminAction(req.adminUser.id, 'event_task_delete', null, old, null, null);
      res.json({ success: true });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.get('/api/admin/events/:id/participants', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const ev = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
      if (!ev) return res.status(404).json({ error: 'Event not found' });
      const rows = await db.select({ p: schema.event_participants, username: schema.users.username }).from(schema.event_participants)
        .innerJoin(schema.users, eq(schema.users.id, schema.event_participants.user_id)).where(eq(schema.event_participants.event_id, ev.id)).limit(500);
      res.json({ participants: rows.map((r: any) => ({ userId: r.p.user_id, username: r.username, joinedAt: r.p.joined_at, gamesPlayed: r.p.games_played, gamesWon: r.p.games_won, bestWinStreak: r.p.best_win_streak, puzzlesSolved: r.p.puzzles_solved, score: eventScore(ev.event_type, r.p) })).sort((a: any, b: any) => b.score - a.score) });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });

  app.get('/api/admin/events/:id/analytics', requireAdmin, async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Database disconnected.' });
      const ev = (await db.select().from(schema.events).where(eq(schema.events.id, req.params.id)))[0];
      if (!ev) return res.status(404).json({ error: 'Event not found' });
      const tasks = await db.select().from(schema.event_tasks).where(eq(schema.event_tasks.event_id, ev.id));
      const parts = await db.select().from(schema.event_participants).where(eq(schema.event_participants.event_id, ev.id));
      const claims = await db.select().from(schema.event_task_claims).where(eq(schema.event_task_claims.event_id, ev.id));
      const tm = new Map(tasks.map((t: any) => [t.id, t]));
      let coins = 0, gems = 0, xp = 0, items = 0;
      for (const c of claims) { const t: any = tm.get(c.task_id); if (!t) continue; coins += t.reward_coins || 0; gems += t.reward_gems || 0; xp += t.reward_xp || 0; if (t.reward_item_id) items++; }
      const enabled = tasks.filter((t: any) => t.is_enabled);
      let completions = 0;
      for (const p of parts) for (const t of enabled) if (eventScore(ev.event_type, p) >= t.target_amount) completions++;
      const possible = parts.length * enabled.length;
      const top = await db.select({ p: schema.event_participants, username: schema.users.username }).from(schema.event_participants).innerJoin(schema.users, eq(schema.users.id, schema.event_participants.user_id)).where(eq(schema.event_participants.event_id, ev.id));
      res.json({
        displayStatus: computeDisplayStatus(ev), totalParticipants: parts.length, totalTasks: tasks.length, totalCompletions: completions,
        completionPercent: possible ? Math.round((completions / possible) * 100) : 0, rewardsClaimedCount: claims.length,
        coinsDistributed: coins, gemsDistributed: gems, xpDistributed: xp, itemsDistributed: items,
        topParticipants: top.map((r: any) => ({ username: r.username, score: eventScore(ev.event_type, r.p) })).sort((a: any, b: any) => b.score - a.score).slice(0, 10),
      });
    } catch (e: any) { res.status(500).json({ error: e.message || 'Failed' }); }
  });


  return { requireAdmin };
}

async function startServer() {
  // Do not accept traffic until the database connection and schema bootstrap finish.
  await dbInitialization;
  const app = express();
  app.set('trust proxy', 1);
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Online-player count for the admin dashboard (socket.io presence map).
  (global as any).__getOnlineCount = () => socketsByUser.size;
  (global as any).__disconnectUser = (uid: string) => { try { socketsByUser.get(uid)?.disconnect(true); } catch {} };
  (global as any).__isUserOnline = (uid: string) => { const s = socketsByUser.get(uid); return !!(s && s.connected); };

  // Admin panel API (separate module) + its static page at /admin.
  const { requireAdmin: adminMw } = registerAdmin(app, { db, pool, redis, JWT_SECRET, requireAuth });
  app.use('/admin', (_req, res, next) => {
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Content-Security-Policy', "frame-ancestors 'none'");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    next();
  });
  app.use('/admin', express.static(path.join(process.cwd(), 'admin')));

  // Global CORS and Security Headers to ensure cross-origin IFRAME and API access works
  app.use((req, res, next) => {
    const origin = req.headers.origin as string | undefined;
    if (origin && isAllowedOrigin(origin, req.headers.host)) {
      res.header('Access-Control-Allow-Origin', origin);
      res.header('Vary', 'Origin');
      res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, PATCH, DELETE, OPTIONS');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
      res.header('Access-Control-Allow-Credentials', 'true');
    } else if (origin && req.method === 'OPTIONS') {
      // Untrusted origin: no CORS headers, so the browser blocks the request.
      res.sendStatus(403);
      return;
    }
    // Allow iframing explicitly
    res.header('X-Frame-Options', 'ALLOWALL');
    res.header('Content-Security-Policy', "frame-ancestors *;");
    
    // Set a dummy secure cookie to test Safari storage access
    res.cookie('app_sec_check', '1', { 
      sameSite: 'none', 
      secure: true, 
      httpOnly: false,
      maxAge: 3600000 
    });

    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });


  // Health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString(), dbConnected: !!db });
  });

  // --- Real Authentication & User Persistence API ---
  // SECURITY: this used to return the email address of ANY username to anyone
  // (privacy leak + account enumeration). Username logins now go through
  // /api/auth/username-login below, which never reveals the email.
  app.get('/api/auth/resolve-email', (_req, res) => {
    res.status(404).json({ error: 'Not available' });
  });

  // Sign out: invalidates every server-signed token this user holds (all
  // devices). Supabase-issued tokens are revoked by the client's own signOut.
  app.post('/api/auth/logout', requireAuth, async (req: any, res) => {
    try {
      if (pool) await pool.query('UPDATE public.users SET tokens_valid_after = $2 WHERE id = $1;', [req.user.uid, new Date()]);
      invalidateAuthRow(req.user.uid);
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: 'Logout failed' });
    }
  });

  app.post('/api/auth/username-login', authRateLimit(60 * 1000, 10), async (req, res) => {
    const generic = { error: 'ئیمەیڵ یان وشەی نهێنی هەڵەیە / Invalid email or password' };
    try {
      const username = String(req.body?.username || '').trim().slice(0, 40);
      const password = String(req.body?.password || '');
      if (!username || !password || !pool) return res.status(401).json(generic);
      const found = await pool.query('SELECT email, is_banned FROM public.users WHERE LOWER(username) = LOWER($1) LIMIT 1;', [username]);
      const email = found.rows[0]?.email;
      if (!email || String(email).endsWith('@guest.local')) return res.status(401).json(generic);
      const { data, error } = await supabasePublic.auth.signInWithPassword({ email, password });
      if (error || !data?.session) {
        const code = (error as any)?.code || '';
        if (code === 'email_not_confirmed') {
          return res.status(401).json({ error: 'تکایە یەکەمجار ئیمەیڵەکەت بپشکنە بۆ پشتڕاستکردنەوە / Email not confirmed. Please check your inbox.' });
        }
        return res.status(401).json(generic);
      }
      res.json({
        access_token: data.session.access_token,
        refresh_token: data.session.refresh_token,
        email,
      });
    } catch (e: any) {
      console.error('username-login error:', e);
      res.status(500).json({ error: 'Login failed' });
    }
  });

  app.get('/api/auth/check-username', authRateLimit(60 * 1000, 30), async (req, res) => {
    try {
      const rawUsername = (req.query.username as string || '').trim();
      if (!rawUsername) {
        return res.status(400).json({ available: false, error: 'Username required' });
      }
      if (pool) {
        const check = await pool.query(
          'SELECT id FROM public.users WHERE LOWER(username) = LOWER($1) LIMIT 1;',
          [rawUsername]
        );
        if (check.rows.length > 0) {
          return res.json({ available: false, error: 'ئەم ناوی بەکارهێنەرە پێشتر بەکارهاتووە / This username is already taken' });
        }
      }
      return res.json({ available: true });
    } catch (err: any) {
      return res.status(500).json({ available: false, error: err.message });
    }
  });

  app.post('/api/auth/register', authRateLimit(60 * 1000, 5), async (req, res) => {
    try {
      const { email, password, username, emailOrUser } = req.body;
      const inputEmail = (email || emailOrUser || '').toLowerCase().trim();
      
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(inputEmail)) {
        return res.status(400).json({ error: 'تکایە ئیمەیڵێکی دروست و ڕاستەقینە بنووسە (نموونە: name@gmail.com)' });
      }

      if (!password || password.length < 6) {
        return res.status(400).json({ error: 'پاسۆرد دەبێت لانیکەم ٦ پیت یان ژمارە بێت' });
      }

      const finalUsername = (username || inputEmail.split('@')[0]).trim();

      // Check existing email and username in public.users and auth.users
      if (pool) {
        const existingUsers = await pool.query(
          'SELECT username, email FROM public.users WHERE LOWER(username) = LOWER($1) OR LOWER(email) = LOWER($2) LIMIT 1;',
          [finalUsername, inputEmail]
        );
        if (existingUsers.rows.length > 0) {
          const row = existingUsers.rows[0];
          if (row.username && row.username.toLowerCase() === finalUsername.toLowerCase()) {
            return res.status(400).json({ error: 'ئەم ناوی بەکارهێنەرە پێشتر بەکارهاتووە / This username is already taken' });
          }
          if (row.email && row.email.toLowerCase() === inputEmail.toLowerCase()) {
            return res.status(400).json({ error: 'ئەم ئیمەیڵە پێشتر تۆمارکراوە / This email is already registered' });
          }
        }

        const existingAuth = await pool.query(
          'SELECT id FROM auth.users WHERE LOWER(email) = LOWER($1) LIMIT 1;',
          [inputEmail]
        );
        if (existingAuth.rows.length > 0) {
          return res.status(400).json({ error: 'ئەم ئیمەیڵە پێشتر تۆمارکراوە / This email is already registered' });
        }
      }

      // Ensure user is created in Supabase Auth (returns the Supabase Auth UUID)
      const supaUserId = await ensureSupabaseAuthUser(inputEmail, password, finalUsername);
      if (!supaUserId) {
        return res.status(500).json({ error: 'تۆمارکردن لە Supabase Auth سەرکەوتوو نەبوو' });
      }

      const passwordHash = hashPassword(password);

      // Insert directly into public.users and player_stats
      if (pool) {
        await pool.query(
          `INSERT INTO public.users (id, username, email, password_hash, is_guest, created_at)
           VALUES ($1, $2, $3, $4, false, now())
           ON CONFLICT (id) DO UPDATE
           SET username = EXCLUDED.username,
               email = EXCLUDED.email,
               password_hash = EXCLUDED.password_hash,
               is_guest = false;`,
          [supaUserId, finalUsername, inputEmail, passwordHash]
        );
      }

      try {
        await supabaseAdmin.from('users').upsert({
          id: supaUserId,
          username: finalUsername,
          email: inputEmail,
          password_hash: passwordHash,
          is_guest: false,
        });
      } catch {}

      const token = jwt.sign(
        {
          sub: supaUserId,
          email: inputEmail,
          username: finalUsername,
          role: 'authenticated',
        },
        JWT_SECRET,
        { expiresIn: '30d' }
      );

      res.json({ success: true, token, user: { id: supaUserId, email: inputEmail, username: finalUsername } });
    } catch (e: any) {
      console.error('Register error:', e);
      res.status(500).json({ error: e.message || 'خۆتۆمارکردن سەرکەوتوو نەبوو' });
    }
  });

  app.post('/api/auth/login', authRateLimit(60 * 1000, 10), async (req, res) => {
    try {
      const { emailOrUser, password, email } = req.body;
      const searchInput = (emailOrUser || email || '').toLowerCase().trim();
      if (!searchInput || !password) {
        return res.status(400).json({ error: 'ئیمەیڵ/ناوی بەکارهێنەر و پاسۆرد پێویستە' });
      }

      let targetEmail = searchInput;
      let targetUsername = searchInput;
      if (!targetEmail.includes('@')) {
        if (pool) {
          const userQuery = await pool.query('SELECT email, username FROM public.users WHERE LOWER(username) = LOWER($1) LIMIT 1;', [searchInput]);
          if (userQuery.rows.length > 0 && userQuery.rows[0].email) {
            targetEmail = userQuery.rows[0].email;
            targetUsername = userQuery.rows[0].username || searchInput;
          }
        }
      }

      if (!targetEmail.includes('@')) {
        return res.status(404).json({ error: 'ئەم ناوی بەکارهێنەرە نەدۆزرایەوە / User not found' });
      }

      let authenticatedUser: { id: string; email: string; username: string } | null = null;

      // 1. Try auth.users via pgcrypto crypt
      if (pool) {
        try {
          const authCheck = await pool.query(
            `SELECT id, email, raw_user_meta_data->>'username' as username,
                    (encrypted_password = crypt($2, encrypted_password)) AS is_valid
             FROM auth.users WHERE email = $1 LIMIT 1;`,
            [targetEmail, password]
          );
          if (authCheck.rows.length > 0 && authCheck.rows[0].is_valid) {
            authenticatedUser = {
              id: authCheck.rows[0].id,
              email: authCheck.rows[0].email,
              username: authCheck.rows[0].username || targetUsername || targetEmail.split('@')[0],
            };
          }
        } catch (dbAuthErr) {
          console.warn('DB auth.users check notice:', dbAuthErr);
        }
      }

      // 2. Try public.users with password_hash (scrypt, or legacy pbkdf2)
      if (!authenticatedUser && pool) {
        try {
          const pubCheck = await pool.query(
            'SELECT id, email, username, password_hash FROM public.users WHERE LOWER(email) = $1 LIMIT 1;',
            [targetEmail]
          );
          if (pubCheck.rows.length > 0) {
            const v = verifyPassword(password, pubCheck.rows[0].password_hash || '');
            if (v.ok) {
              authenticatedUser = {
                id: pubCheck.rows[0].id,
                email: pubCheck.rows[0].email,
                username: pubCheck.rows[0].username || targetUsername || targetEmail.split('@')[0],
              };
              if (v.needsRehash) {
                await pool.query('UPDATE public.users SET password_hash = $1 WHERE id = $2;', [hashPassword(password), pubCheck.rows[0].id]).catch(() => {});
              }
            }
          }
        } catch (pubErr) {
          console.warn('DB public.users check notice:', pubErr);
        }
      }

      if (!authenticatedUser) {
        return res.status(400).json({ error: 'ئیمەیڵ یان وشەی نهێنی هەڵەیە / Invalid email or password' });
      }

      if (pool) {
        const b = await pool.query('SELECT is_banned FROM public.users WHERE id = $1 LIMIT 1;', [authenticatedUser.id]).catch(() => null);
        if (b?.rows?.[0]?.is_banned === true) {
          return res.status(403).json({ error: 'This account has been banned.' });
        }
      }

      // Ensure stats exist in public.player_stats
      if (pool) {
        await pool.query(
          `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
           VALUES ($1, 5000, 50, 1200, 0, 0, 0, 0, 1)
           ON CONFLICT (id) DO NOTHING;`,
          [authenticatedUser.id]
        ).catch(() => {});
      }

      const token = jwt.sign(
        {
          sub: authenticatedUser.id,
          email: authenticatedUser.email,
          username: authenticatedUser.username,
          role: 'authenticated',
        },
        JWT_SECRET,
        { expiresIn: '30d' }
      );

      res.json({ success: true, token, user: authenticatedUser });
    } catch (e: any) {
      console.error('Login error:', e);
      res.status(500).json({ error: e.message || 'چوونەژوورەوە سەرکەوتوو نەبوو' });
    }
  });

  app.post('/api/auth/guest', authRateLimit(60 * 1000, 10), async (req, res) => {
    try {
      const { deviceId, username } = req.body;
      // The client-supplied deviceId is IGNORED: a guest id derived from it could be
      // re-created (taken over) by anyone who knew or guessed that value.
      const finalDeviceId = 'guest_' + crypto.randomBytes(16).toString('hex');
      const userId = 'gst_' + crypto.createHash('md5').update(finalDeviceId).digest('hex').substring(0, 16);
      let finalUsername = username || `Guest_${userId.substring(4, 8)}`;
      const guestEmail = `${userId}@guest.local`;

      if (pool) {
        let attempts = 0;
        while (attempts < 5) {
          const checkPub = await pool.query(
            'SELECT id FROM public.users WHERE LOWER(username) = LOWER($1) AND id <> $2 LIMIT 1;',
            [finalUsername, userId]
          );
          if (checkPub.rows.length === 0) break;
          finalUsername = `Guest_${Math.floor(1000 + Math.random() * 9000)}`;
          attempts++;
        }
      }

      // Provision user in Supabase Auth via admin to guarantee real auth user record
      let finalUserId = userId;
      try {
        const supaUid = await ensureSupabaseAuthUser(guestEmail, crypto.randomBytes(24).toString('hex'), finalUsername);
        if (supaUid) {
          finalUserId = supaUid;
        }
      } catch (authErr) {
        console.log('Guest Auth creation note:', authErr);
      }

      if (pool) {
        await pool.query(
          `INSERT INTO public.users (id, username, email, password_hash, is_guest, created_at)
           VALUES ($1, $2, $3, '', true, now())
           ON CONFLICT (id) DO UPDATE
           SET username = EXCLUDED.username,
               email = EXCLUDED.email,
               is_guest = true;`,
          [finalUserId, finalUsername, guestEmail]
        );

        await pool.query(
          `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
           VALUES ($1, 5000, 50, 1200, 0, 0, 0, 0, 1)
           ON CONFLICT (id) DO NOTHING;`,
          [finalUserId]
        );
      }

      try {
        await supabaseAdmin.from('users').upsert({
          id: finalUserId,
          username: finalUsername,
          email: guestEmail,
          is_guest: true,
        });
      } catch (e) {
        console.log('Guest insert notice:', e);
      }

      try {
        await supabaseAdmin.from('player_stats').upsert({
          id: finalUserId,
          coins: 5000,
          gems: 50,
          rating: 1200,
          wins: 0,
          losses: 0,
          draws: 0,
          xp: 0,
          level: 1,
        });
      } catch (e) {
        console.log('Guest stats notice:', e);
      }

      if (db) {
        await db.insert(schema.users).values({
          id: finalUserId,
          username: finalUsername,
          email: guestEmail,
          password_hash: '',
          is_guest: true,
        }).onConflictDoNothing().catch(() => {});

        await db.insert(schema.player_stats).values({
          id: finalUserId,
          coins: 5000,
          gems: 50,
          rating: 1200,
          wins: 0,
          losses: 0,
          draws: 0,
          xp: 0,
          level: 1,
        }).onConflictDoNothing().catch(() => {});
      }

      // A real signed token. Before, the 'token' was just the user id, so anyone
      // who saw a guest's id (leaderboard, match list) could act as that guest.
      const guestToken = jwt.sign(
        { sub: finalUserId, email: guestEmail, username: finalUsername, is_anonymous: true },
        JWT_SECRET,
        { expiresIn: '30d' }
      );
      res.json({ token: guestToken, user: { user_id: finalUserId, username: finalUsername, email: guestEmail, is_guest: true } });
    } catch (e: any) {
      console.error('Guest auth error:', e);
      res.status(500).json({ error: e.message || 'میوان سەرکەوتوو نەبوو' });
    }
  });

  app.post('/api/auth/sync-profile', async (req, res) => {
    try {
      // SECURITY: the identity used here must come from a VERIFIED token.
      // The old code fell back to the id/email in the request body when no
      // (valid) token was sent. Combined with the "migrate a legacy account
      // by email" step below, anyone could POST someone else's email with
      // their own id and steal that account's coins, items and matches.
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Authentication required' });
      }
      const token = (authHeader.split(' ')[1] || '').trim();
      let authenticatedUserId = '';
      let authenticatedEmail: string | undefined;
      let authenticatedUsername: string | undefined;
      let isGuest = false;
      let emailConfirmed = false;

      const { data: supaData } = await supabasePublic.auth.getUser(token);
      if (supaData?.user) {
        const u: any = supaData.user;
        authenticatedUserId = u.id;
        authenticatedEmail = u.email || undefined;
        authenticatedUsername =
          u.user_metadata?.username || u.user_metadata?.full_name || u.user_metadata?.name ||
          (typeof req.body?.username === 'string' ? req.body.username : undefined) ||
          authenticatedEmail?.split('@')[0];
        isGuest = !!u.is_anonymous || !!authenticatedEmail?.toLowerCase().includes('guest');
        emailConfirmed = !!(u.email_confirmed_at || u.confirmed_at);
      } else {
        // Server-signed JWT (issued by /api/auth/login or /register).
        try {
          const d: any = jwt.verify(token, JWT_SECRET);
          if (d?.sub) {
            authenticatedUserId = String(d.sub);
            authenticatedEmail = d.email;
            authenticatedUsername = d.username;
            isGuest = !!d.is_anonymous || !!String(d.email || '').toLowerCase().includes('guest');
            emailConfirmed = true; // server login already checked the password
          }
        } catch {}
      }

      if (!authenticatedUserId) {
        return res.status(401).json({ error: 'Invalid or expired authentication token' });
      }

      const finalUsername = (authenticatedUsername || 'Player').trim();
      const finalEmail = (authenticatedEmail || `${authenticatedUserId}@user.local`).toLowerCase().trim();

      let isNewUser = false;

      // Synchronize into PostgreSQL database with full collision handling and legacy account migration
      let resolvedUsername = finalUsername;
      if (pool) {
        try {
          // 1. Check if user already exists by ID
          const resById = await pool.query('SELECT * FROM public.users WHERE id = $1 LIMIT 1;', [authenticatedUserId]);
          if (resById.rows.length > 0) {
            resolvedUsername = resById.rows[0].username || finalUsername;
            // Update email, avatar, and is_guest if needed
            await pool.query(
              'UPDATE public.users SET email = $1, is_guest = $2 WHERE id = $3;',
              [finalEmail, isGuest, authenticatedUserId]
            );
          } else {
            // 2. Check if a user exists with this email under an older/custom ID (e.g. usr_...)
            const resByEmail = await pool.query('SELECT * FROM public.users WHERE email = $1 LIMIT 1;', [finalEmail]);
            if (resByEmail.rows.length > 0 && (isGuest || !emailConfirmed)) {
              // Never hand an existing account's data to an unconfirmed or guest identity.
              return res.status(403).json({ error: 'This email belongs to another account. Confirm your email first.' });
            }
            if (resByEmail.rows.length > 0) {
              const oldId = resByEmail.rows[0].id;
              resolvedUsername = resByEmail.rows[0].username || finalUsername;
              console.log(`[Account Migration] Migrating legacy user record from ${oldId} to Supabase Auth UUID ${authenticatedUserId}`);
              
              // Migrate stats if old record had stats
              const oldStatsRes = await pool.query('SELECT * FROM public.player_stats WHERE id = $1;', [oldId]);
              const newStatsRes = await pool.query('SELECT * FROM public.player_stats WHERE id = $1;', [authenticatedUserId]);
              
              if (oldStatsRes.rows.length > 0 && newStatsRes.rows.length === 0) {
                await pool.query('UPDATE public.player_stats SET id = $1 WHERE id = $2;', [authenticatedUserId, oldId]);
              } else if (oldStatsRes.rows.length > 0 && newStatsRes.rows.length > 0) {
                const maxCoins = Math.max(oldStatsRes.rows[0].coins || 5000, newStatsRes.rows[0].coins || 5000);
                const maxGems = Math.max(oldStatsRes.rows[0].gems || 50, newStatsRes.rows[0].gems || 50);
                const maxWins = Math.max(oldStatsRes.rows[0].wins || 0, newStatsRes.rows[0].wins || 0);
                await pool.query('UPDATE public.player_stats SET coins = $1, gems = $2, wins = $3 WHERE id = $4;', [maxCoins, maxGems, maxWins, authenticatedUserId]);
                await pool.query('DELETE FROM public.player_stats WHERE id = $1;', [oldId]);
              }

              // Update foreign/related records
              await pool.query('UPDATE public.royal_pass SET id = $1 WHERE id = $2;', [authenticatedUserId, oldId]).catch(() => {});
              await pool.query('UPDATE public.user_inventory SET user_id = $1 WHERE user_id = $2;', [authenticatedUserId, oldId]).catch(() => {});
              await pool.query('UPDATE public.user_challenges SET user_id = $1 WHERE user_id = $2;', [authenticatedUserId, oldId]).catch(() => {});
              await pool.query('UPDATE public.matches SET white_player_id = $1 WHERE white_player_id = $2;', [authenticatedUserId, oldId]).catch(() => {});
              await pool.query('UPDATE public.matches SET black_player_id = $1 WHERE black_player_id = $2;', [authenticatedUserId, oldId]).catch(() => {});

              // Update the user record's ID to real Supabase UUID
              await pool.query('UPDATE public.users SET id = $1, is_guest = $2 WHERE id = $3;', [authenticatedUserId, isGuest, oldId]);
            } else {
              // 3. New user: ensure username is unique
              let safeUsername = finalUsername;
              let attempts = 0;
              while (attempts < 5) {
                const resByUsername = await pool.query(
                  'SELECT id FROM public.users WHERE LOWER(username) = LOWER($1) AND id <> $2 LIMIT 1;',
                  [safeUsername, authenticatedUserId]
                );
                if (resByUsername.rows.length === 0) break;
                safeUsername = `${finalUsername.slice(0, 10)}_${Math.floor(1000 + Math.random() * 9000)}`;
                attempts++;
              }
              resolvedUsername = safeUsername;
              await pool.query(
                'INSERT INTO public.users (id, username, email, password_hash, is_guest) VALUES ($1, $2, $3, $4, $5) ON CONFLICT (id) DO UPDATE SET email = EXCLUDED.email, is_guest = EXCLUDED.is_guest, username = EXCLUDED.username;',
                [authenticatedUserId, safeUsername, finalEmail, '', isGuest]
              );
            }
          }

          // Ensure player_stats exists for authenticated user
          const statsCheck = await pool.query('SELECT id FROM public.player_stats WHERE id = $1 LIMIT 1;', [authenticatedUserId]);
          if (statsCheck.rows.length === 0) {
            isNewUser = true;
            await pool.query(
              'INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level) VALUES ($1, 5000, 50, 1200, 0, 0, 0, 0, 1) ON CONFLICT (id) DO NOTHING;',
              [authenticatedUserId]
            );
          }
        } catch (dbErr) {
          console.error('[Sync Profile DB error]:', dbErr);
        }
      }

      // Also attempt Supabase upsert if service role is available
      try {
        await supabaseAdmin.from('users').upsert(
          {
            id: authenticatedUserId,
            username: resolvedUsername,
            email: finalEmail,
            is_guest: isGuest,
          },
          { onConflict: 'id' }
        );
        if (isNewUser) {
          await supabaseAdmin.from('player_stats').upsert({
            id: authenticatedUserId,
            coins: 5000,
            gems: 50,
            rating: 1200,
            wins: 0,
            losses: 0,
            draws: 0,
            xp: 0,
            level: 1,
          });
        }
      } catch (supaErr) {}

      res.json({
        success: true,
        isNewUser: isNewUser,
        user: {
          id: authenticatedUserId,
          email: finalEmail,
          username: finalUsername,
          is_guest: isGuest,
        },
      });
    } catch (e: any) {
      console.error('Sync profile error:', e);
      res.status(500).json({ error: e.message || 'Sync profile failed' });
    }
  });

  // --- Real-time Match API ---

  // Initialize or join a match
  app.post('/api/match/:id/init', requireAuth, async (req: any, res) => {
    const { id } = req.params;
    const { assignedColor, tableId } = req.body;
    // SECURITY: the player is the authenticated token owner. The old code
    // trusted a `userId` from the request body, so anyone could join/act as
    // any other player.
    const userId: string = req.user.uid;

    if (!id || typeof id !== 'string' || id.length > 120) {
      return res.status(400).json({ error: 'Invalid match id' });
    }
    if (assignedColor !== undefined && assignedColor !== 'w' && assignedColor !== 'b') {
      return res.status(400).json({ error: 'assignedColor must be "w" or "b"' });
    }

    // SECURITY: stake/prize used to be taken from the client, so a player
    // could create a match with a 1-coin stake and a huge prize and print
    // coins. They now come ONLY from the server-side TABLE_STAKES table.
    let requestedStake = 0;
    let requestedPrize = 0;
    if (tableId && TABLE_STAKES[String(tableId)]) {
      requestedStake = TABLE_STAKES[String(tableId)].entryFee;
      requestedPrize = TABLE_STAKES[String(tableId)].prizePool;
    }
    // Enforce the table's minimum level here too (not only in queue_join), so a
    // hand-crafted /init for a high table can't bypass it.
    if (tableId && (TABLE_MIN_LEVEL[String(tableId)] ?? 1) > 1 && pool) {
      try {
        const lr = await pool.query('SELECT level FROM public.player_stats WHERE id = $1 LIMIT 1;', [userId]);
        if (Number(lr.rows[0]?.level || 1) < TABLE_MIN_LEVEL[String(tableId)]) {
          return res.status(403).json({ error: `This table requires level ${TABLE_MIN_LEVEL[String(tableId)]}` });
        }
      } catch {}
    }

    const result = await updateMatchAtomic(id, async (match) => {
      let m = match;
      if (!m) {
        m = {
          id,
          whiteId: assignedColor === 'w' ? userId : null,
          blackId: assignedColor === 'b' ? userId : null,
          fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          turn: 'w',
          whiteTimeMs: (TABLE_STAKES[String(tableId)]?.timeMin ?? 10) * 60000,
          blackTimeMs: (TABLE_STAKES[String(tableId)]?.timeMin ?? 10) * 60000,
          lastMoveAt: 0,
          status: 'waiting',
          winner: null,
          moveHistory: [],
          tableId: tableId ? String(tableId) : undefined,
          stake: requestedStake,
          prize: requestedPrize,
          stakesDeducted: false,
          prizeAwarded: false
        };
      } else {
        // A colour slot already held by someone else can never be taken over
        // (previously any caller could overwrite it and hijack a live match).
        if (assignedColor === 'w' && m.whiteId && m.whiteId !== userId) {
          return { error: 'That color slot is already taken', status: 409 };
        }
        if (assignedColor === 'b' && m.blackId && m.blackId !== userId) {
          return { error: 'That color slot is already taken', status: 409 };
        }
        if (assignedColor === 'w') {
          m.whiteId = userId;
        } else if (assignedColor === 'b') {
          m.blackId = userId;
        } else {
          if (!m.whiteId && m.blackId !== userId) m.whiteId = userId;
          else if (!m.blackId && m.whiteId !== userId) m.blackId = userId;
        }
        if (requestedStake > 0 && !m.stakesDeducted) {
          m.stake = requestedStake;
          m.prize = requestedPrize;
        }
      }

      // Check balance of joining player before proceeding
      if (m.stake > 0 && !m.stakesDeducted) {
        const userBal = await getPlayerCoinBalance(userId);
        if (userBal < m.stake) {
          return {
            error: `Insufficient coins: You have ${userBal} coins, but this match requires ${m.stake} coins.`,
            status: 400
          };
        }
      }

      // If both players are present and match was waiting, start match and deduct stakes atomically
      if (m.status === 'waiting' && m.whiteId && m.blackId) {
        const deductRes = await deductMatchStakes(m);
        if (!deductRes.success) {
          return {
            error: deductRes.error || 'Failed to deduct match stakes',
            status: 400
          };
        }
        m.status = 'active';
        m.lastMoveAt = Date.now();
      }

      return m;
    });

    if (result.error) return res.status(result.status || 500).json({ error: result.error });

    const wBal = result.match?.whiteId ? await getPlayerCoinBalance(result.match.whiteId) : 0;
    const bBal = result.match?.blackId ? await getPlayerCoinBalance(result.match.blackId) : 0;
    const userBal = userId === result.match?.whiteId ? wBal : bBal;

    res.json({
      match: result.match,
      userBalance: userBal,
      whiteBalance: wBal,
      blackBalance: bBal,
      stake: result.match?.stake,
      prize: result.match?.prize
    });
  });

  // Explicit match start endpoint
  // Not used by the game client. It let anyone start a match between ANY two
  // user ids with an arbitrary stake (deducting coins from strangers), so it is
  // now admin-only.
  app.post('/api/match/:id/start', adminMw, async (req, res) => {
    const { id } = req.params;
    const { whiteId, blackId, tableId, stake, prize } = req.body;

    let requestedStake = 0;
    let requestedPrize = 0;
    if (stake !== undefined && stake !== null && Number(stake) > 0) {
      requestedStake = Math.max(0, Math.floor(Number(stake) || 0));
      requestedPrize = prize !== undefined ? Math.max(0, Math.floor(Number(prize) || 0)) : (requestedStake * 2);
    } else if (tableId && TABLE_STAKES[String(tableId)]) {
      requestedStake = TABLE_STAKES[String(tableId)].entryFee;
      requestedPrize = TABLE_STAKES[String(tableId)].prizePool;
    }

    const result = await updateMatchAtomic(id, async (match) => {
      let m = match;
      if (!m) {
        m = {
          id,
          whiteId: whiteId || null,
          blackId: blackId || null,
          fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          turn: 'w',
          whiteTimeMs: (TABLE_STAKES[String(tableId)]?.timeMin ?? 10) * 60000,
          blackTimeMs: (TABLE_STAKES[String(tableId)]?.timeMin ?? 10) * 60000,
          lastMoveAt: 0,
          status: 'waiting',
          winner: null,
          moveHistory: [],
          tableId: tableId ? String(tableId) : undefined,
          stake: requestedStake,
          prize: requestedPrize,
          stakesDeducted: false,
          prizeAwarded: false
        };
      } else {
        if (whiteId) m.whiteId = whiteId;
        if (blackId) m.blackId = blackId;
        if (requestedStake > 0 && !m.stakesDeducted) {
          m.stake = requestedStake;
          m.prize = requestedPrize;
        }
      }

      if (!m.whiteId || !m.blackId) {
        return { error: 'Both whiteId and blackId are required to start match', status: 400 };
      }

      if (m.status === 'waiting' || (m.status === 'active' && !m.stakesDeducted)) {
        const deductRes = await deductMatchStakes(m);
        if (!deductRes.success) {
          return { error: deductRes.error || 'Failed to deduct match stakes', status: 400 };
        }
        m.status = 'active';
        m.lastMoveAt = Date.now();
      }

      return m;
    });

    if (result.error) return res.status(result.status || 500).json({ error: result.error });

    const wBal = result.match?.whiteId ? await getPlayerCoinBalance(result.match.whiteId) : 0;
    const bBal = result.match?.blackId ? await getPlayerCoinBalance(result.match.blackId) : 0;

    res.json({
      match: result.match,
      whiteBalance: wBal,
      blackBalance: bBal,
      stake: result.match?.stake,
      prize: result.match?.prize
    });
  });

  // Get current match state and dynamically calculate server-authoritative time
  app.get('/api/match/:id', requireAuth, async (req: any, res) => {
    const { id } = req.params;
    const match = await getServerMatch(id);
    if (!match) return res.status(404).json({ error: 'Match not found' });
    // Only the two players may read a match's live state (it used to be public).
    if (match.whiteId !== req.user.uid && match.blackId !== req.user.uid) {
      return res.status(403).json({ error: 'Not a participant in this match' });
    }

    let wTime = match.whiteTimeMs;
    let bTime = match.blackTimeMs;

    if (match.status === 'active' && match.lastMoveAt > 0) {
      const elapsed = Math.max(0, Date.now() - match.lastMoveAt);
      if (match.turn === 'w') wTime -= elapsed;
      else bTime -= elapsed;

      if (wTime <= 0 || bTime <= 0) {
        // Auto-timeout via atomic update
        const timeoutRes = await updateMatchAtomic(id, (m) => {
          if (!m || m.status !== 'active') return m;
          const el = Math.max(0, Date.now() - m.lastMoveAt);
          let currentW = m.whiteTimeMs - (m.turn === 'w' ? el : 0);
          let currentB = m.blackTimeMs - (m.turn === 'b' ? el : 0);
          if (currentW <= 0) {
            m.status = 'timeout';
            m.winner = 'b';
            m.whiteTimeMs = 0;
            return { match: m, shouldFinalize: true };
          } else if (currentB <= 0) {
            m.status = 'timeout';
            m.winner = 'w';
            m.blackTimeMs = 0;
            return { match: m, shouldFinalize: true };
          }
          return m;
        });
        if (timeoutRes.match) {
          if (timeoutRes.shouldFinalize) await finalizeMatch(timeoutRes.match);
          return res.json({ match: timeoutRes.match });
        }
      }
    }

    res.json({
      match: {
        ...match,
        whiteTimeMs: Math.max(0, wTime),
        blackTimeMs: Math.max(0, bTime),
        disconnectedUserId: match.disconnectedUserId || null,
        disconnectExpiresAt: match.disconnectExpiresAt || null,
        gracePeriodRemainingMs: match.disconnectExpiresAt ? Math.max(0, match.disconnectExpiresAt - Date.now()) : 0
      }
    });
  });

  // Submit a move securely with full server-side validation
  app.post('/api/match/:id/move', requireAuth, async (req: any, res) => {
    const { id } = req.params;
    const { move } = req.body;
    const userId: string = req.user.uid; // from the verified token, never the body
    if (!move) {
      return res.status(400).json({ error: 'Move is required' });
    }

    const result = await updateMatchAtomic(id, (match) => {
      if (!match) return { error: 'Invalid match', status: 404 };
      if (match.status !== 'active') {
        return { error: `Match is not active (current status: ${match.status})`, status: 400 };
      }

      // 1. Validate player identity
      const isWhite = match.whiteId === userId;
      const isBlack = match.blackId === userId;
      if (!isWhite && !isBlack) {
        return { error: 'Unauthorized: Player is not a participant in this match', status: 403 };
      }

      // 2. Validate whose turn it is
      if (match.turn === 'w' && !isWhite) {
        return { error: 'Not your turn: White to move', status: 403 };
      }
      if (match.turn === 'b' && !isBlack) {
        return { error: 'Not your turn: Black to move', status: 403 };
      }

      // 3. Deduct authoritative clock time
      const now = Date.now();
      const elapsed = match.lastMoveAt > 0 ? Math.max(0, now - match.lastMoveAt) : 0;
      if (match.turn === 'w') {
        match.whiteTimeMs -= elapsed;
        if (match.whiteTimeMs <= 0) {
          match.whiteTimeMs = 0;
          match.status = 'timeout';
          match.winner = 'b';
          return { match, shouldFinalize: true, error: 'White ran out of time', status: 400 };
        }
      } else {
        match.blackTimeMs -= elapsed;
        if (match.blackTimeMs <= 0) {
          match.blackTimeMs = 0;
          match.status = 'timeout';
          match.winner = 'w';
          return { match, shouldFinalize: true, error: 'Black ran out of time', status: 400 };
        }
      }

      // 4. Validate legal chess moves with Chess.js
      let chess: Chess;
      try {
        chess = new Chess(match.fen);
      } catch (fenErr: any) {
        return { error: 'Corrupt match FEN: ' + fenErr?.message, status: 500 };
      }

      if (chess.isGameOver()) {
        return { error: 'Game is already over', status: 400 };
      }

      let moveResult: any = null;
      try {
        if (typeof move === 'string') {
          moveResult = chess.move(move);
        } else if (typeof move === 'object' && move.from && move.to) {
          moveResult = chess.move({
            from: String(move.from).toLowerCase(),
            to: String(move.to).toLowerCase(),
            promotion: move.promotion ? String(move.promotion).toLowerCase() : 'q'
          });
        } else {
          return { error: 'Invalid move structure. Expected { from, to, promotion? } or SAN string', status: 400 };
        }
      } catch (moveErr: any) {
        return { error: 'Illegal move: ' + (moveErr?.message || 'Move not permitted by chess rules'), status: 400 };
      }

      if (!moveResult) {
        return { error: 'Illegal move', status: 400 };
      }

      // 5. Update state authoritatively
      match.fen = chess.fen();
      match.turn = chess.turn();
      match.lastMoveAt = now;

      // 6. Record move in history
      match.moveHistory = match.moveHistory || [];
      match.moveHistory.push({
        from: moveResult.from,
        to: moveResult.to,
        promotion: moveResult.promotion,
        san: moveResult.san,
        lan: moveResult.lan,
        fen: match.fen,
        by: userId,
        at: now,
        moveNumber: match.moveHistory.length + 1
      });

      // 7. Check game status
      let shouldFinalize = false;
      if (chess.isCheckmate()) {
        match.status = 'completed';
        match.winner = isWhite ? 'w' : 'b';
        shouldFinalize = true;
      } else if (chess.isDraw() || chess.isStalemate() || chess.isThreefoldRepetition() || chess.isInsufficientMaterial()) {
        match.status = 'draw';
        match.winner = null;
        shouldFinalize = true;
      }

      return { match, moveResult, shouldFinalize };
    });

    // A move that arrives after the clock ran out ends the match as a
    // timeout; make sure it is actually finalized before we report the error.
    if (result.error && result.shouldFinalize && result.match) await finalizeMatch(result.match);
    if (result.error) return res.status(result.status || 500).json({ error: result.error });
    if (result.shouldFinalize && result.match) await finalizeMatch(result.match);

    // Relay updated move state to opponent via WebSocket if connected
    if (broadcastToMatchRoom && result.match && result.moveResult) {
      try {
        const payloadStr = JSON.stringify({
          op_code: 1,
          move: {
            from: result.moveResult.from,
            to: result.moveResult.to,
            promotion: result.moveResult.promotion
          },
          fen: result.match.fen,
          turn: result.match.turn,
          whiteTimeMs: result.match.whiteTimeMs,
          blackTimeMs: result.match.blackTimeMs,
          status: result.match.status,
          winner: result.match.winner
        });
        const b64Data = Buffer.from(payloadStr).toString('base64');
        broadcastToMatchRoom(id, {
          type: 'match_data',
          matchId: id,
          opCode: 1,
          data: b64Data
        }, userId);
      } catch (wsErr) {
        console.warn('Failed to broadcast move via WebSocket:', wsErr);
      }
    }

    const wBal = result.match?.whiteId ? await getPlayerCoinBalance(result.match.whiteId) : 0;
    const bBal = result.match?.blackId ? await getPlayerCoinBalance(result.match.blackId) : 0;
    const userBal = userId === result.match?.whiteId ? wBal : bBal;

    res.json({
      match: result.match,
      moveResult: result.moveResult,
      userBalance: userBal,
      whiteBalance: wBal,
      blackBalance: bBal
    });
  });

  // End match manually (resign/draw)
  app.post('/api/match/:id/end', requireAuth, async (req: any, res) => {
    const { id } = req.params;
    const { reason } = req.body; // 'resign' | 'resigned' | 'timeout'
    const userId: string = req.user.uid; // from the verified token, never the body

    // SECURITY: this endpoint used to accept ANY caller and trust a
    // client-supplied `winner`/`reason`, so anyone could end any active match
    // and hand themselves the win (with real coins/XP/rating paid out). Now:
    // the caller must be a participant, a resignation always makes the
    // OPPONENT the winner, and a "timeout" is only accepted if the server's own
    // clock agrees. A one-sided "draw" is refused.
    const result = await updateMatchAtomic(id, (match) => {
      if (!match) return { error: 'Match not found', status: 404 };
      if (match.whiteId !== userId && match.blackId !== userId) {
        return { error: 'You are not a participant in this match', status: 403 };
      }
      if (match.status !== 'active') return match;

      if (reason === 'resign' || reason === 'resigned') {
        match.status = 'resigned';
        match.winner = match.whiteId === userId ? 'b' : 'w';
        return { match, shouldFinalize: true };
      }

      if (reason === 'timeout') {
        const el = match.lastMoveAt > 0 ? Math.max(0, Date.now() - match.lastMoveAt) : 0;
        const wLeft = match.whiteTimeMs - (match.turn === 'w' ? el : 0);
        const bLeft = match.blackTimeMs - (match.turn === 'b' ? el : 0);
        // The side to move loses only if the SERVER's clock for them has
        // (nearly) run out. 2s tolerance covers client/server clock skew and
        // network delay; a claim made while time clearly remains is ignored.
        if (match.turn === 'w' && wLeft <= 2000) {
          match.status = 'timeout'; match.winner = 'b'; match.whiteTimeMs = 0;
          return { match, shouldFinalize: true };
        }
        if (match.turn === 'b' && bLeft <= 2000) {
          match.status = 'timeout'; match.winner = 'w'; match.blackTimeMs = 0;
          return { match, shouldFinalize: true };
        }
        return match; // clock hasn't really expired: no state change
      }

      return { error: 'Unsupported end reason', status: 400 };
    });

    if (result.error) return res.status(result.status || 500).json({ error: result.error });
    if (result.shouldFinalize && result.match) await finalizeMatch(result.match);

    if (broadcastToMatchRoom && result.match) {
      try {
        const payloadStr = JSON.stringify({
          op_code: 2,
          reason,
          winner: result.match.winner,
          status: result.match.status
        });
        const b64Data = Buffer.from(payloadStr).toString('base64');
        broadcastToMatchRoom(id, {
          type: 'match_data',
          matchId: id,
          opCode: 2,
          data: b64Data
        });
      } catch {}
    }

    const wBal = result.match?.whiteId ? await getPlayerCoinBalance(result.match.whiteId) : 0;
    const bBal = result.match?.blackId ? await getPlayerCoinBalance(result.match.blackId) : 0;
    const userBal = userId === result.match?.whiteId ? wBal : bBal;

    res.json({
      match: result.match,
      userBalance: userBal,
      whiteBalance: wBal,
      blackBalance: bBal
    });
  });


  // Player Stats & Profile from PostgreSQL
  app.get('/api/player/:id/stats', requireAuth, async (req, res) => {
    try {
      if (!db || !pool) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const statsRes = await pool.query('SELECT * FROM public.player_stats WHERE id = $1 LIMIT 1', [req.params.id]);
      const userRes = await pool.query('SELECT username, avatar_url, bio, equipped_piece_skin, equipped_board_skin FROM public.users WHERE id = $1 LIMIT 1', [req.params.id]);
      const stats = statsRes.rows.length > 0 ? statsRes.rows[0] : { wins: 0, losses: 0, draws: 0, rating: 1200, coins: 5000, gems: 50, xp: 0, level: 1 };
      const user = userRes.rows.length > 0 ? userRes.rows[0] : null;
      res.json({ stats: { ...stats, username: user?.username, avatar_url: user?.avatar_url, bio: user?.bio ?? null, equipped_piece_skin: user?.equipped_piece_skin ?? null, equipped_board_skin: user?.equipped_board_skin ?? null } });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/profile', requireAuth, async (req, res) => {
    try {
      if (!db || !pool) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const { name, avatar, bio, equippedPieceSkin, equippedBoardSkin } = req.body || {};
      const skinOk = (v: any) => typeof v === 'string' && /^[a-z0-9_]{1,40}$/.test(v);
      const userId = req.params.id;
      let cleanBio: string | null = null;
      if (typeof bio === 'string') {
        cleanBio = bio.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 120);
      }

      // Validate input (previously anything at all was accepted).
      let cleanName: string | null = null;
      if (name !== undefined && name !== null && String(name).trim() !== '') {
        cleanName = String(name).trim().replace(/\s+/g, ' ');
        if (cleanName.length < 3 || cleanName.length > 20 || !/^[\p{L}\p{N}_\-. ]+$/u.test(cleanName)) {
          return res.status(400).json({ error: 'Name must be 3-20 characters (letters, numbers, _ - . and spaces)' });
        }
      }
      let cleanAvatar: string | null = null;
      if (avatar !== undefined && avatar !== null && String(avatar) !== '') {
        cleanAvatar = String(avatar);
        const okUrl = /^https:\/\//i.test(cleanAvatar) && cleanAvatar.length <= 600;
        const okData = /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(cleanAvatar) && cleanAvatar.length <= 400000;
        if (!okUrl && !okData) return res.status(400).json({ error: 'Invalid avatar' });
      }

      // SECURITY: the SERVER decides whether a rename is free (first time) or
      // costs 500 gems, using users.name_changes. It used to trust a
      // `deductGemsForNameChange` flag from the browser (so renaming could be
      // free forever), and it charged the gems BEFORE checking the name was
      // available (so a taken name still cost 500 gems). Everything now runs
      // in one transaction with the rows locked.
      const result = await db.transaction(async (tx: any) => {
        const urows = await tx.select().from(schema.users).where(eq(schema.users.id, userId)).for('update');
        const u = urows[0];
        if (!u) return { error: 'Account not found', status: 404 };

        const updates: any = {};
        if (cleanName && cleanName !== u.username) {
          const taken = await tx.select({ id: schema.users.id }).from(schema.users)
            .where(and(sql`LOWER(${schema.users.username}) = LOWER(${cleanName})`, not(eq(schema.users.id, userId))));
          if (taken.length > 0) {
            return { error: 'ئەم ناوی بەکارهێنەرە پێشتر بەکارهاتووە / This username is already taken', status: 400 };
          }
          const cost = (u.name_changes || 0) >= 1 ? 500 : 0;
          if (cost > 0) {
            const srows = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, userId)).for('update');
            if (srows.length === 0 || (srows[0].gems || 0) < cost) {
              return { error: 'Insufficient Gems! 500 Diamonds required 💎', status: 400 };
            }
            await tx.update(schema.player_stats).set({ gems: srows[0].gems - cost }).where(eq(schema.player_stats.id, userId));
          }
          updates.username = cleanName;
          updates.name_changes = (u.name_changes || 0) + 1;
        }
        if (cleanAvatar) updates.avatar_url = cleanAvatar;
        if (cleanBio !== null) updates.bio = cleanBio;
        if (skinOk(equippedPieceSkin)) updates.equipped_piece_skin = equippedPieceSkin;
        if (skinOk(equippedBoardSkin)) updates.equipped_board_skin = equippedBoardSkin;
        if (Object.keys(updates).length > 0) {
          await tx.update(schema.users).set(updates).where(eq(schema.users.id, userId));
        }
        return { ok: true };
      });
      if ((result as any).error) return res.status((result as any).status || 400).json({ error: (result as any).error });
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Royal Pass Endpoints
  app.get('/api/player/:id/royal-pass', requireAuth, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      let pass = await db.select().from(schema.royal_pass).where(eq(schema.royal_pass.id, req.params.id));
      if (pass.length === 0) {
        pass = await db.insert(schema.royal_pass).values({ id: req.params.id }).returning();
      }
      res.json({ pass: pass[0] });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/buy-premium', requireAuth, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const txResult = await db.transaction(async (tx: any) => {
        // Lock the pass + stats rows; refuse to charge again if already premium
        // (previously every request took another 500 gems, and two concurrent
        // requests could read the same balance).
        let pass = await tx.select().from(schema.royal_pass).where(eq(schema.royal_pass.id, req.params.id)).for('update');
        if (pass.length > 0 && pass[0].is_premium) throw new Error('Premium already unlocked');
        const stats = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, req.params.id)).for('update');
        if (stats.length === 0 || stats[0].gems < 500) { // 500 gems to buy premium
          throw new Error('Not enough gems');
        }
        await tx.update(schema.player_stats).set({ gems: stats[0].gems - 500 }).where(eq(schema.player_stats.id, req.params.id));
        
        if (pass.length === 0) {
          await tx.insert(schema.royal_pass).values({ id: req.params.id, is_premium: true });
        } else {
          await tx.update(schema.royal_pass).set({ is_premium: true }).where(eq(schema.royal_pass.id, req.params.id));
        }
      });
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.get('/api/shop/items', (req, res) => {
    res.json({ items: SHOP_CATALOG });
  });

  app.get('/api/player/:id/inventory', requireAuth, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const inv = await db.select().from(schema.user_inventory).where(eq(schema.user_inventory.user_id, req.params.id));
      res.json({ inventory: inv });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/shop/buy', requireAuth, async (req, res) => {
    try {
      const { itemId } = req.body;
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      
      const item = SHOP_CATALOG.find(i => i.id === itemId);
      if (!item) throw new Error('Item not found');

      const txResult = await db.transaction(async (tx: any) => {
        // Check if already owns
        const owned = await tx.select().from(schema.user_inventory).where(eq(schema.user_inventory.id, req.params.id + '_' + itemId));
        if (owned.length > 0) throw new Error('Already owned');

        // Check stats
        // Lock the stats row: without it two simultaneous purchases of two
        // different items both read the same balance and both succeed (e.g.
        // two 60-coin items on a 100-coin balance).
        let stats = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, req.params.id)).for('update');
        if (stats.length === 0) {
          stats = await tx.insert(schema.player_stats).values({ id: req.params.id }).returning();
        }
        
        const currentCoins = stats[0].coins || 0;
        const currentGems = stats[0].gems || 0;

        let costCoins = item.priceCoins || 0;
        let costGems = item.priceGems || 0;

        if (currentCoins < costCoins || currentGems < costGems) {
          throw new Error('Not enough currency');
        }

        // Deduct
        await tx.update(schema.player_stats)
          .set({ coins: currentCoins - costCoins, gems: currentGems - costGems })
          .where(eq(schema.player_stats.id, req.params.id));

        // Add to inventory
        await tx.insert(schema.user_inventory).values({
          id: req.params.id + '_' + itemId,
          user_id: req.params.id,
          item_id: itemId,
          item_type: item.type
        });

        // Add to purchases
        await tx.insert(schema.user_purchases).values({
          id: crypto.randomBytes(16).toString('hex'),
          user_id: req.params.id,
          item_id: itemId,
          price_coins: costCoins,
          price_gems: costGems
        });
        return { coins: currentCoins - costCoins, gems: currentGems - costGems };
      });

      res.json({ success: true, coins: txResult.coins, gems: txResult.gems });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/claim-reward', requireAuth, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      // Strict input: tier must be a real integer 1..20 and isPremium a real
      // boolean. Before, "5" (a string) and 5 were tracked as different tiers,
      // so the same tier could be claimed twice, and tiers above 20 paid
      // ever-growing rewards.
      const tier = req.body?.tier;
      const isPremium = req.body?.isPremium === true;
      if (typeof tier !== 'number' || !Number.isInteger(tier) || tier < 1 || tier > 20) {
        return res.status(400).json({ error: 'Invalid tier' });
      }

      const txResult = await db.transaction(async (tx: any) => {
        let pass = await tx.select().from(schema.royal_pass).where(eq(schema.royal_pass.id, req.params.id)).for('update');
        if (pass.length === 0) throw new Error('Pass not found');
        
        let p = pass[0];
        if (isPremium && !p.is_premium) throw new Error('Premium not unlocked');

        // Verify level (e.g. 100 XP per tier)
        const requiredXp = (tier - 1) * 100;
        if (p.season_xp < requiredXp) throw new Error('Not enough XP');

        const claimedList = isPremium ? p.claimed_premium_tiers : p.claimed_free_tiers;
        const claimedArr = Array.isArray(claimedList) ? claimedList : (typeof claimedList === 'string' ? JSON.parse(claimedList) : []);
        if (claimedArr.includes(tier)) throw new Error('Already claimed');
        
        claimedArr.push(tier);

        if (isPremium) {
          await tx.update(schema.royal_pass).set({ claimed_premium_tiers: claimedArr }).where(eq(schema.royal_pass.id, req.params.id));
        } else {
          await tx.update(schema.royal_pass).set({ claimed_free_tiers: claimedArr }).where(eq(schema.royal_pass.id, req.params.id));
        }

        // Calculate reward server-side
        let rewardCoins = 0;
        let rewardGems = 0;
        let itemToGrant = null;

        if (isPremium) {
          if (tier === 10) itemToGrant = 'board_goldencitadel';
          else if (tier === 20) itemToGrant = 'avatar_supremecrown';
          else if (tier >= 11 && tier <= 19) rewardCoins = tier * 10000;
          else if (tier < 10) rewardCoins = tier * 20000;
          else { rewardCoins = tier * 30000; rewardGems = 200; }
        } else {
          if (tier === 10) itemToGrant = 'board_redyellow';
          else if (tier === 20) itemToGrant = 'avatar_redcrown';
          else if (tier >= 11 && tier <= 19) rewardGems = 50;
          else if (tier < 10) { rewardCoins = tier * 1500; rewardGems = 10; }
          else if (tier % 5 === 0) itemToGrant = 'chest_ruby';
          else { rewardCoins = tier * 2000; rewardGems = 25; }
        }

        let stats = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, req.params.id)).for('update');
        if (stats.length === 0) {
          stats = await tx.insert(schema.player_stats).values({ id: req.params.id }).returning();
        }

        if (rewardCoins > 0 || rewardGems > 0) {
          await tx.update(schema.player_stats)
            .set({ 
              coins: (stats[0].coins || 0) + rewardCoins,
              gems: (stats[0].gems || 0) + rewardGems 
            })
            .where(eq(schema.player_stats.id, req.params.id));
        }

        if (itemToGrant) {
           const owned = await tx.select().from(schema.user_inventory).where(eq(schema.user_inventory.id, req.params.id + '_' + itemToGrant));
           if (owned.length === 0) {
              await tx.insert(schema.user_inventory).values({
                id: req.params.id + '_' + itemToGrant,
                user_id: req.params.id,
                item_id: itemToGrant,
                item_type: itemToGrant.split('_')[0]
              });
           }
        }
      });
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  app.get('/api/player/:id/challenges', requireAuth, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      // One transaction + per-user advisory lock: two simultaneous requests used
      // to both see "no challenges" and each insert a full set (duplicates).
      const chals: any[] = await db.transaction(async (tx: any) => {
        await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${'challenges:' + req.params.id}))`);
        // For now we just return active challenges if any exist, or generate defaults
        let chals: any[] = await tx.select().from(schema.user_challenges).where(eq(schema.user_challenges.user_id, req.params.id));
        // Daily renewal: once none of the challenges is still active, drop the
        // finished/expired ones (keeping completed-but-unclaimed rewards) and
        // issue a fresh pair. Before, challenges were created once and never
        // renewed, so the Royal Pass XP source dried up forever.
        const nowTs = Date.now();
        const stillActive = chals.some((c: any) => !c.expires_at || new Date(c.expires_at).getTime() > nowTs);
        if (!stillActive && chals.length > 0) {
          for (const c of chals) {
            if (c.is_claimed || !c.is_completed) {
              await tx.delete(schema.user_challenges).where(eq(schema.user_challenges.id, c.id));
            }
          }
          chals = await tx.select().from(schema.user_challenges).where(eq(schema.user_challenges.user_id, req.params.id));
        }
        if (chals.length === 0 || (!stillActive && !chals.some((c: any) => !c.is_completed))) {
          // Generate the daily set
          const newChals = [
            { id: crypto.randomUUID(), user_id: req.params.id, challenge_type: 'play_games', description: 'Play 3 Online Matches', target: 3, progress: 0, xp_reward: 100, expires_at: new Date(Date.now() + 86400000) },
            { id: crypto.randomUUID(), user_id: req.params.id, challenge_type: 'win_games', description: 'Win 1 Match', target: 1, progress: 0, xp_reward: 150, expires_at: new Date(Date.now() + 86400000) },
          ];
          await tx.insert(schema.user_challenges).values(newChals);
          chals = await tx.select().from(schema.user_challenges).where(eq(schema.user_challenges.user_id, req.params.id));
        }
        return chals;
      });
      res.json({ challenges: chals });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/claim-challenge', requireAuth, async (req, res) => {
    try {
      const { challengeId } = req.body;
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      if (typeof challengeId !== 'string' || !challengeId) return res.status(400).json({ error: 'Invalid challenge' });

      const txResult = await db.transaction(async (tx: any) => {
        // Row lock so a double-click / retry can't pay the reward twice.
        let chals = await tx.select().from(schema.user_challenges).where(eq(schema.user_challenges.id, challengeId)).for('update');
        if (chals.length === 0) throw new Error('Challenge not found');
        let chal = chals[0];
        
        if (chal.user_id !== req.params.id) throw new Error('Not your challenge');
        if (!chal.is_completed) throw new Error('Not completed');
        if (chal.is_claimed) throw new Error('Already claimed');

        await tx.update(schema.user_challenges).set({ is_claimed: true }).where(eq(schema.user_challenges.id, challengeId));

        let rp = await tx.select().from(schema.royal_pass).where(eq(schema.royal_pass.id, req.params.id)).for('update');
        if (rp.length === 0) {
          await tx.insert(schema.royal_pass).values({ id: req.params.id, season_xp: chal.xp_reward });
        } else {
          await tx.update(schema.royal_pass).set({ season_xp: (rp[0].season_xp || 0) + chal.xp_reward }).where(eq(schema.royal_pass.id, req.params.id));
        }

        // Add 500 Coins and 10 Gems for completing any challenge securely
        let stats = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, req.params.id)).for('update');
        if (stats.length === 0) {
          stats = await tx.insert(schema.player_stats).values({ id: req.params.id }).returning();
          stats = [stats[0]];
        }
        await tx.update(schema.player_stats).set({
          coins: (stats[0].coins || 0) + 500,
          gems: (stats[0].gems || 0) + 10
        }).where(eq(schema.player_stats.id, req.params.id));
      });
      res.json({ success: true });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  // -------------------------------------------------------------
  // --- Server-Authoritative Daily Rewards & Quests ---
  // -------------------------------------------------------------
  const DAILY_STREAK_CONFIG = [
    { day: 1, coins: 5000, gems: 5, chestType: 'red' },
    { day: 2, coins: 1000, gems: 10, chestType: 'red' },
    { day: 3, coins: 1500, gems: 15, chestType: 'gold' },
    { day: 4, coins: 2000, gems: 20, chestType: 'red' },
    { day: 5, coins: 3000, gems: 25, chestType: 'gold' },
    { day: 6, coins: 4500, gems: 30, chestType: 'gold' },
    { day: 7, coins: 10000, gems: 35, chestType: 'purple' },
  ];

  app.get('/api/player/:id/daily-reward/status', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const targetUserId = (req as any).user?.uid || req.params.id;
      const todayStr = new Date().toISOString().split('T')[0];
      const yesterdayStr = new Date(Date.now() - 86400000).toISOString().split('T')[0];

      // 1. Fetch all claims made today
      const todayClaimsRes = await pool.query(
        'SELECT reward_type, tier, streak_day, coins_awarded, claimed_at FROM public.user_daily_rewards WHERE user_id = $1 AND claim_date = $2;',
        [targetUserId, todayStr]
      );
      const todayClaims = todayClaimsRes.rows;

      // 2. Fetch latest daily streak claim
      const lastStreakRes = await pool.query(
        `SELECT streak_day, claim_date, claimed_at FROM public.user_daily_rewards 
         WHERE user_id = $1 AND reward_type = 'daily_streak' 
         ORDER BY claimed_at DESC LIMIT 1;`,
        [targetUserId]
      );

      let currentStreak = 1;
      let claimedToday = false;
      let canClaimStreak = true;

      if (lastStreakRes.rows.length > 0) {
        const last = lastStreakRes.rows[0];
        if (last.claim_date === todayStr) {
          currentStreak = last.streak_day;
          claimedToday = true;
          canClaimStreak = false;
        } else if (last.claim_date === yesterdayStr) {
          currentStreak = (last.streak_day % 7) + 1;
          claimedToday = false;
          canClaimStreak = true;
        } else {
          currentStreak = 1;
          claimedToday = false;
          canClaimStreak = true;
        }
      }

      // Build 7-day streak representation
      const streakDays = DAILY_STREAK_CONFIG.map((cfg) => {
        let claimed = false;
        let isCurrent = false;
        if (claimedToday) {
          claimed = cfg.day <= currentStreak;
          isCurrent = cfg.day === currentStreak;
        } else {
          claimed = cfg.day < currentStreak;
          isCurrent = cfg.day === currentStreak;
        }
        return {
          day: cfg.day,
          coins: cfg.coins,
          gems: cfg.gems,
          chestType: cfg.chestType,
          claimed,
          isCurrent,
        };
      });

      // 3. Count games played today & wins today
      const todayStart = new Date(todayStr + 'T00:00:00.000Z');
      const matchesPlayedRes = await pool.query(
        `SELECT COUNT(*) as cnt FROM public.matches 
         WHERE (white_player_id = $1 OR black_player_id = $1) AND created_at >= $2
           AND (status IN ('completed','draw') OR COALESCE(array_length(string_to_array(trim(moves_san), ' '), 1), 0) >= 6);`,
        [targetUserId, todayStart]
      );
      const playCount = parseInt(matchesPlayedRes.rows[0]?.cnt || '0', 10);

      const matchesWonRes = await pool.query(
        `SELECT COUNT(*) as cnt FROM public.matches 
         WHERE winner_id = $1 AND created_at >= $2
           AND (status IN ('completed','draw') OR COALESCE(array_length(string_to_array(trim(moves_san), ' '), 1), 0) >= 6);`,
        [targetUserId, todayStart]
      );
      const winCount = parseInt(matchesWonRes.rows[0]?.cnt || '0', 10);

      const play3Claimed = todayClaims.some((c: any) => c.reward_type === 'play_3_games');
      const win7Claimed = todayClaims.some((c: any) => c.reward_type === 'win_7_streak');
      // "Claimed" for the royal-event tab now means: no live event task is left
      // to claim (no live event, or every enabled task already claimed).
      const evLeft = await pool.query(
        `SELECT 1 FROM public.events e JOIN public.event_tasks t ON t.event_id = e.id AND t.is_enabled = TRUE
         WHERE e.status = 'published' AND e.start_at <= now() AND e.end_at >= now()
           AND NOT EXISTS (SELECT 1 FROM public.event_task_claims c WHERE c.task_id = t.id AND c.user_id = $1) LIMIT 1;`,
        [targetUserId]
      );
      const royalEventClaimed = evLeft.rows.length === 0;
      const claimedAdTiers = todayClaims.filter((c: any) => c.reward_type === 'ad_reward').map((c: any) => c.tier);

      // Countdown to next midnight UTC
      const now = new Date();
      const nextMidnightUtc = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
      const secondsUntilReset = Math.max(0, Math.floor((nextMidnightUtc.getTime() - now.getTime()) / 1000));

      res.json({
        success: true,
        canClaimStreak,
        claimedToday,
        currentStreak,
        streakDays,
        play3Count: playCount,
        play3Claimed,
        win7Count: winCount,
        win7Claimed,
        royalEventClaimed,
        claimedAdTiers,
        secondsUntilReset,
        serverDate: todayStr,
      });
    } catch (e: any) {
      console.error('daily-reward/status error:', e);
      res.status(500).json({ error: e.message });
    }
  });

  // Ad reward handshake. There is no real ad network wired in yet, so the
  // honest server-side guarantee is: the player must START an ad first, and
  // the reward can only be claimed after a minimum watch time measured by the
  // SERVER clock. Before, /claim paid out instantly for any tier on request.
  const adStartTimes = new Map<string, number>();
  const AD_MIN_WATCH_MS = 3000;
  app.post('/api/player/:id/ad-reward/start', requireAuth, async (req: any, res) => {
    const tier = Number(req.body?.tier);
    if (![1, 2, 3].includes(tier)) return res.status(400).json({ error: 'Invalid ad tier' });
    adStartTimes.set(`${req.user.uid}:${tier}`, Date.now());
    if (adStartTimes.size > 50000) adStartTimes.clear();
    res.json({ started: true, minWatchMs: AD_MIN_WATCH_MS });
  });

  app.post('/api/player/:id/daily-reward/claim', requireAuth, async (req, res) => {
    if (!pool) return res.status(503).json({ error: 'Database disconnected' });
    const targetUserId = (req as any).user?.uid || req.params.id;
    const type = req.body?.type || 'daily_streak';
    const tier = Number(req.body?.tier) || 1;
    const todayStr = new Date().toISOString().split('T')[0];
    const yesterdayStr = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      let coinsToAward = 0;
      let gemsToAward = 0;
      let streakDay = 1;
      let claimId = '';

      if (type === 'daily_streak') {
        // Check if already claimed today
        const existing = await client.query(
          `SELECT id FROM public.user_daily_rewards 
           WHERE user_id = $1 AND reward_type = 'daily_streak' AND claim_date = $2 FOR UPDATE;`,
          [targetUserId, todayStr]
        );
        if (existing.rows.length > 0) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'خەڵاتی ڕۆژانە ئەمڕۆ پێشتر وەرگیراوە / Daily reward already claimed today' });
        }

        // Calculate next streak day
        const lastStreakRes = await client.query(
          `SELECT streak_day, claim_date FROM public.user_daily_rewards 
           WHERE user_id = $1 AND reward_type = 'daily_streak' 
           ORDER BY claimed_at DESC LIMIT 1;`,
          [targetUserId]
        );

        if (lastStreakRes.rows.length > 0) {
          const last = lastStreakRes.rows[0];
          if (last.claim_date === yesterdayStr) {
            streakDay = (last.streak_day % 7) + 1;
          } else {
            streakDay = 1;
          }
        } else {
          streakDay = 1;
        }

        const config = DAILY_STREAK_CONFIG[streakDay - 1] || DAILY_STREAK_CONFIG[0];
        coinsToAward = config.coins;
        gemsToAward = config.gems;
        claimId = `${targetUserId}_daily_streak_${todayStr}`;

        await client.query(
          `INSERT INTO public.user_daily_rewards 
           (id, user_id, reward_type, claim_date, tier, streak_day, coins_awarded, gems_awarded, claimed_at)
           VALUES ($1, $2, 'daily_streak', $3, 1, $4, $5, $6, NOW());`,
          [claimId, targetUserId, todayStr, streakDay, coinsToAward, gemsToAward]
        );

        if (streakDay === 7) {
          await client.query(
            `INSERT INTO public.user_inventory (id, user_id, item_id, item_type)
             VALUES ($1, $2, 'board_obsidian', 'board')
             ON CONFLICT (id) DO NOTHING;`,
            [`${targetUserId}_board_obsidian`, targetUserId]
          );
        }
      } else if (type === 'play_3_games') {
        const existing = await client.query(
          `SELECT id FROM public.user_daily_rewards 
           WHERE user_id = $1 AND reward_type = 'play_3_games' AND claim_date = $2 FOR UPDATE;`,
          [targetUserId, todayStr]
        );
        if (existing.rows.length > 0) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'خەڵاتی یارییەکان پێشتر وەرگیراوە / Quest reward already claimed today' });
        }

        const todayStart = new Date(todayStr + 'T00:00:00.000Z');
        const countRes = await client.query(
          `SELECT COUNT(*) as cnt FROM public.matches 
           WHERE (white_player_id = $1 OR black_player_id = $1) AND created_at >= $2
             AND (status IN ('completed','draw') OR COALESCE(array_length(string_to_array(trim(moves_san), ' '), 1), 0) >= 6);`,
          [targetUserId, todayStart]
        );
        const playCount = parseInt(countRes.rows[0]?.cnt || '0', 10);
        if (playCount < 3) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'پێویستە لانی کەم ٣ یاری بکەیت / You must complete at least 3 games' });
        }

        coinsToAward = 1500;
        gemsToAward = 10;
        claimId = `${targetUserId}_play_3_games_${todayStr}`;
        await client.query(
          `INSERT INTO public.user_daily_rewards 
           (id, user_id, reward_type, claim_date, tier, streak_day, coins_awarded, gems_awarded, claimed_at)
           VALUES ($1, $2, 'play_3_games', $3, 1, 1, $4, $5, NOW());`,
          [claimId, targetUserId, todayStr, coinsToAward, gemsToAward]
        );
      } else if (type === 'win_7_streak') {
        const existing = await client.query(
          `SELECT id FROM public.user_daily_rewards 
           WHERE user_id = $1 AND reward_type = 'win_7_streak' AND claim_date = $2 FOR UPDATE;`,
          [targetUserId, todayStr]
        );
        if (existing.rows.length > 0) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'خەڵاتی بردنەوەکان پێشتر وەرگیراوە / 7-win reward already claimed today' });
        }

        const todayStart = new Date(todayStr + 'T00:00:00.000Z');
        const countRes = await client.query(
          `SELECT COUNT(*) as cnt FROM public.matches 
           WHERE winner_id = $1 AND created_at >= $2
             AND (status IN ('completed','draw') OR COALESCE(array_length(string_to_array(trim(moves_san), ' '), 1), 0) >= 6);`,
          [targetUserId, todayStart]
        );
        const winCount = parseInt(countRes.rows[0]?.cnt || '0', 10);
        if (winCount < 7) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'پێویستە ٧ یاری ببەیتەوە / You must win 7 games' });
        }

        coinsToAward = 4500;
        gemsToAward = 25;
        claimId = `${targetUserId}_win_7_streak_${todayStr}`;
        await client.query(
          `INSERT INTO public.user_daily_rewards 
           (id, user_id, reward_type, claim_date, tier, streak_day, coins_awarded, gems_awarded, claimed_at)
           VALUES ($1, $2, 'win_7_streak', $3, 1, 1, $4, $5, NOW());`,
          [claimId, targetUserId, todayStr, coinsToAward, gemsToAward]
        );
      } else if (type === 'royal_event') {
        // The "Royal Event" is now the admin-managed event system. Before, this
        // paid 8000 coins + 50 gems + a golden piece to EVERYONE, every day, with
        // no condition at all. Now it pays the next COMPLETED, unclaimed task of a
        // live event; progress comes only from real finished matches / puzzles.
        const rows = await client.query(
          `SELECT t.id AS task_id, t.event_id, t.target_amount, t.reward_coins, t.reward_gems, t.reward_xp, t.reward_item_id,
                  e.name AS event_name,
                  CASE e.event_type WHEN 'games_played' THEN p.games_played WHEN 'games_won' THEN p.games_won
                       WHEN 'win_streak' THEN p.best_win_streak WHEN 'puzzles_solved' THEN p.puzzles_solved ELSE 0 END AS score
           FROM public.events e
           JOIN public.event_tasks t ON t.event_id = e.id AND t.is_enabled = TRUE
           LEFT JOIN public.event_participants p ON p.event_id = e.id AND p.user_id = $1
           WHERE e.status = 'published' AND e.start_at <= now() AND e.end_at >= now()
             AND NOT EXISTS (SELECT 1 FROM public.event_task_claims c WHERE c.task_id = t.id AND c.user_id = $1)
           ORDER BY e.start_at, t.task_order, t.target_amount
           FOR UPDATE OF t;`,
          [targetUserId]
        );
        if (rows.rows.length === 0) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'ئێستا ئیڤێنتی چالاک یان خەڵاتی ماوە نییە / No active event reward available' });
        }
        const done = rows.rows.find((r: any) => Number(r.score || 0) >= Number(r.target_amount));
        if (!done) {
          await client.query('ROLLBACK');
          const nxt = rows.rows[0];
          return res.status(400).json({
            error: `ئیڤێنت «${nxt.event_name}»: ${Number(nxt.score || 0)}/${nxt.target_amount} / Task not completed yet`,
          });
        }
        await client.query(
          `INSERT INTO public.event_task_claims (id, event_id, task_id, user_id) VALUES ($1, $2, $3, $4);`,
          [crypto.randomUUID(), done.event_id, done.task_id, targetUserId]
        );
        coinsToAward = Number(done.reward_coins || 0);
        gemsToAward = Number(done.reward_gems || 0);
        const xpAward = Number(done.reward_xp || 0);
        claimId = `${targetUserId}_event_${done.task_id}`;
        if (xpAward > 0) {
          await client.query(
            `UPDATE public.player_stats SET xp = COALESCE(xp, 0) + $2, level = TRUNC((COALESCE(xp, 0) + $2) / 100) + 1 WHERE id = $1;`,
            [targetUserId, xpAward]
          );
        }
        if (done.reward_item_id) {
          const known = SHOP_CATALOG.find((i: any) => i.id === done.reward_item_id);
          await client.query(
            `INSERT INTO public.user_inventory (id, user_id, item_id, item_type) VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO NOTHING;`,
            [`${targetUserId}_${done.reward_item_id}`, targetUserId, done.reward_item_id, known?.type || String(done.reward_item_id).split('_')[0]]
          );
        }
      } else if (type === 'ad_reward') {
        const adTier = Number(tier) || 1;
        if (![1, 2, 3].includes(adTier)) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'Invalid ad tier' });
        }
        const adKey = `${targetUserId}:${adTier}`;
        const adStartedAt = adStartTimes.get(adKey);
        if (!adStartedAt) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'You must start watching the ad first' });
        }
        if (Date.now() - adStartedAt < AD_MIN_WATCH_MS) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'Please watch the full ad before claiming' });
        }
        adStartTimes.delete(adKey);
        const existing = await client.query(
          `SELECT id FROM public.user_daily_rewards 
           WHERE user_id = $1 AND reward_type = 'ad_reward' AND claim_date = $2 AND tier = $3 FOR UPDATE;`,
          [targetUserId, todayStr, adTier]
        );
        if (existing.rows.length > 0) {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: 'ئەم ڕیکلامە ئەمڕۆ بینراوە / Ad tier already claimed today' });
        }
        const adConfig: Record<number, { coins: number; gems: number }> = {
          1: { coins: 5000, gems: 5 },
          2: { coins: 1500, gems: 10 },
          3: { coins: 3000, gems: 15 },
        };
        coinsToAward = adConfig[adTier].coins;
        gemsToAward = adConfig[adTier].gems;
        claimId = `${targetUserId}_ad_reward_${todayStr}_${adTier}`;
        await client.query(
          `INSERT INTO public.user_daily_rewards 
           (id, user_id, reward_type, claim_date, tier, streak_day, coins_awarded, gems_awarded, claimed_at)
           VALUES ($1, $2, 'ad_reward', $3, $4, 1, $5, $6, NOW());`,
          [claimId, targetUserId, todayStr, adTier, coinsToAward, gemsToAward]
        );
      } else {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Unknown reward type' });
      }
      // Update player_stats with authoritative balance atomically
      const updateRes = await client.query(
        `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
         VALUES ($1, $2, $3, 1200, 0, 0, 0, 0, 1)
         ON CONFLICT (id) DO UPDATE 
         SET coins = public.player_stats.coins + $4,
             gems = public.player_stats.gems + $5
         RETURNING coins, gems;`,
        [targetUserId, 5000 + coinsToAward, 50 + gemsToAward, coinsToAward, gemsToAward]
      );
      
      const newCoins = updateRes.rows[0].coins;
      const newGems = updateRes.rows[0].gems;

      // The original handler never committed: every daily/quest/ad reward
      // written above was left in an open transaction and could be lost.
      await client.query('COMMIT');

      return res.json({
        success: true,
        rewardType: type,
        tier,
        streakDay,
        coinsAwarded: coinsToAward,
        gemsAwarded: gemsToAward,
        newBalance: newCoins,
        newGems,
      });
    } catch (err: any) {
      await client.query('ROLLBACK');
      console.error('daily-reward/claim error:', err);
      return res.status(500).json({ error: err.message });
    } finally {
      client.release();
    }
  });

  // -------------------------------------------------------------
  // --- vs-AI rewards (server-side, capped) ---
  // The AI game runs entirely in the browser, so the server cannot verify the
  // result. Before, the client simply added coins/XP to its own React state and
  // localStorage, so the reward was fake (it vanished on the next load). Now the
  // reward is stored in the database, but strictly capped so it can't be farmed:
  // at most 10 rewarded games per UTC day and at least 40 s between them.
  app.post('/api/player/:id/ai-game/complete', requireAuth, async (req: any, res) => {
    if (!pool) return res.status(503).json({ error: 'Database disconnected' });
    const uid = req.user.uid;
    const result = req.body?.result;
    if (!['win', 'draw', 'loss'].includes(result)) return res.status(400).json({ error: 'Invalid result' });
    const reward = result === 'win' ? { coins: 15, xp: 15 } : result === 'draw' ? { coins: 5, xp: 5 } : { coins: 0, xp: 2 };
    const today = new Date().toISOString().split('T')[0];
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(
        `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
         VALUES ($1, 5000, 50, 1200, 0, 0, 0, 0, 1) ON CONFLICT (id) DO NOTHING;`, [uid]);
      const st = await client.query('SELECT coins, xp, level FROM public.player_stats WHERE id = $1 FOR UPDATE;', [uid]);
      const used = await client.query(
        `SELECT COUNT(*)::int AS n, MAX(claimed_at) AS last FROM public.user_daily_rewards
         WHERE user_id = $1 AND reward_type = 'ai_game' AND claim_date = $2;`, [uid, today]);
      const n = used.rows[0]?.n || 0;
      const last = used.rows[0]?.last ? new Date(used.rows[0].last).getTime() : 0;
      if (n >= 10 || Date.now() - last < 40000) {
        await client.query('COMMIT');
        return res.json({ success: true, rewarded: false, coinsAwarded: 0, xpAwarded: 0,
          coins: st.rows[0].coins, xp: st.rows[0].xp, level: st.rows[0].level });
      }
      await client.query(
        `INSERT INTO public.user_daily_rewards (id, user_id, reward_type, claim_date, tier, streak_day, coins_awarded, gems_awarded, claimed_at)
         VALUES ($1, $2, 'ai_game', $3, $4, 1, $5, 0, NOW());`,
        [`${uid}_ai_game_${today}_${n + 1}`, uid, today, n + 1, reward.coins]);
      const up = await client.query(
        `UPDATE public.player_stats SET coins = coins + $2, xp = COALESCE(xp,0) + $3,
           level = TRUNC((COALESCE(xp,0) + $3) / 100) + 1
         WHERE id = $1 RETURNING coins, xp, level;`, [uid, reward.coins, reward.xp]);
      await client.query('COMMIT');
      return res.json({ success: true, rewarded: true, coinsAwarded: reward.coins, xpAwarded: reward.xp,
        coins: up.rows[0].coins, xp: up.rows[0].xp, level: up.rows[0].level });
    } catch (e: any) {
      await client.query('ROLLBACK').catch(() => {});
      console.error('ai-game/complete error:', e);
      return res.status(500).json({ error: e.message });
    } finally {
      client.release();
    }
  });

  // -------------------------------------------------------------
  // --- Server-Authoritative Puzzle Completion & Rewards ---
  // -------------------------------------------------------------
  app.get('/api/player/:id/puzzle/status', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const targetUserId = (req as any).user?.uid || req.params.id;

      const completions = await pool.query(
        `SELECT puzzle_id, level_number, coins_awarded, completed_at 
         FROM public.user_puzzle_completions 
         WHERE user_id = $1 
         ORDER BY level_number ASC;`,
        [targetUserId]
      );

      const completedPuzzles = completions.rows.map((r: any) => r.puzzle_id);
      const completedLevels = completions.rows.map((r: any) => r.level_number);
      const claimedRewards = completions.rows.map((r: any) => r.level_number);

      res.json({
        success: true,
        completedPuzzles,
        completedLevels,
        claimedRewards,
      });
    } catch (e: any) {
      console.error('puzzle/status error:', e);
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/puzzle/claim', requireAuth, async (req, res) => {
    if (!pool) return res.status(503).json({ error: 'Database disconnected' });
    const targetUserId = (req as any).user?.uid || req.params.id;
    const { puzzleId, levelNumber, move } = req.body;

    // Look up stage canonically
    // Resolve the stage unambiguously (before, "id OR level OR parsed id" let a
    // request mix fields from two different stages).
    const stage = (typeof puzzleId === 'string' && CHESS_40_STAGES.find((s) => s.id === puzzleId)) ||
      (puzzleId === undefined && levelNumber !== undefined ? CHESS_40_STAGES.find((s) => s.levelNumber === Number(levelNumber)) : undefined);

    if (!stage) {
      return res.status(400).json({ error: 'مەتەڵ نەدۆزرایەوە / Invalid puzzle stage' });
    }

    // The solution move is MANDATORY. It used to be checked only "if provided",
    // so a request that simply left `move` out claimed the reward without
    // solving anything.
    if (!move || typeof move !== 'string') {
      return res.status(400).json({ error: 'Solution move is required' });
    }
    {
      const cleanMove = move.trim().toLowerCase();
      const validSolutions = (stage.solutionMoves || []).map((m: string) => m.trim().toLowerCase());
      if (!validSolutions.includes(cleanMove)) {
        return res.status(400).json({ error: 'جووڵەی هەڵە بۆ ئەم مەتەڵە / Incorrect puzzle solution move' });
      }
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // Check if already completed/claimed
      const existing = await client.query(
        `SELECT id FROM public.user_puzzle_completions 
         WHERE user_id = $1 AND (puzzle_id = $2 OR level_number = $3) FOR UPDATE;`,
        [targetUserId, stage.id, stage.levelNumber]
      );

      if (existing.rows.length > 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ 
          error: 'ئەم مەتەڵە پێشتر وەرگیراوە / Puzzle reward has already been claimed',
          alreadyClaimed: true,
          puzzleId: stage.id,
          levelNumber: stage.levelNumber,
        });
      }

      // Puzzle answers ship inside the client bundle, so a script could claim all
      // 40 stages at once. A solve cannot realistically happen faster than a few
      // seconds after the previous one: enforce a server-side pacing floor.
      const lastDone = await client.query(
        `SELECT EXTRACT(EPOCH FROM (NOW() - MAX(completed_at))) AS ago FROM public.user_puzzle_completions WHERE user_id = $1;`, [targetUserId]);
      const agoSec = lastDone.rows[0]?.ago;
      if (agoSec !== null && agoSec !== undefined && Number(agoSec) >= 0 && Number(agoSec) < 6) {
        await client.query('ROLLBACK');
        return res.status(429).json({ error: 'زۆر خێرایە، کەمێک چاوەڕێ بە / Too fast, please wait a few seconds' });
      }

      // Record puzzle completion in DB
      const recordId = `${targetUserId}_${stage.id}`;
      await client.query(
        `INSERT INTO public.user_puzzle_completions 
         (id, user_id, puzzle_id, level_number, coins_awarded, completed_at)
         VALUES ($1, $2, $3, $4, $5, NOW());`,
        [recordId, targetUserId, stage.id, stage.levelNumber, stage.rewardCoins]
      );

      // Update player_stats with authoritative balance atomically
      const updateRes = await client.query(
        `INSERT INTO public.player_stats (id, coins, gems, rating, wins, losses, draws, xp, level)
         VALUES ($1, $2, 50, 1200, 0, 0, 0, 25, 1)
         ON CONFLICT (id) DO UPDATE 
         SET coins = public.player_stats.coins + $3,
             xp = public.player_stats.xp + 25,
             level = TRUNC((public.player_stats.xp + 25) / 100) + 1
         RETURNING coins, xp, level;`,
        [targetUserId, 5000 + stage.rewardCoins, stage.rewardCoins]
      );
      
      const newCoins = updateRes.rows[0].coins;
      const newXp = updateRes.rows[0].xp;
      const newLevel = updateRes.rows[0].level;

      // Events: a verified, first-time puzzle solve counts toward live
      // 'puzzles_solved' events (auto-enrol). Savepoint so a failure here can
      // never undo the puzzle reward itself.
      try {
        await client.query('SAVEPOINT ev_bump');
        await client.query(
          `INSERT INTO public.event_participants (id, event_id, user_id)
           SELECT md5(random()::text || clock_timestamp()::text || e.id), e.id, $1 FROM public.events e
           WHERE e.status = 'published' AND e.event_type = 'puzzles_solved' AND e.start_at <= now() AND e.end_at >= now()
             AND (e.max_participants IS NULL OR (SELECT COUNT(*) FROM public.event_participants p WHERE p.event_id = e.id) < e.max_participants)
           ON CONFLICT (event_id, user_id) DO NOTHING;`, [targetUserId]);
        await client.query(
          `UPDATE public.event_participants SET puzzles_solved = COALESCE(puzzles_solved, 0) + 1
           WHERE user_id = $1 AND event_id IN (SELECT id FROM public.events
             WHERE status = 'published' AND event_type = 'puzzles_solved' AND start_at <= now() AND end_at >= now());`, [targetUserId]);
        await client.query('RELEASE SAVEPOINT ev_bump');
      } catch (evErr) {
        await client.query('ROLLBACK TO SAVEPOINT ev_bump').catch(() => {});
        console.error('puzzle event bump failed:', evErr);
      }

      await client.query('COMMIT');

      return res.json({
        success: true,
        puzzleId: stage.id,
        levelNumber: stage.levelNumber,
        coinsAwarded: stage.rewardCoins,
        newBalance: newCoins,
        xpAwarded: 25,
        newXp,
        newLevel,
      });
    } catch (err: any) {
      await client.query('ROLLBACK');
      console.error('puzzle/claim error:', err);
      return res.status(500).json({ error: err.message });
    } finally {
      client.release();
    }
  });

  // --- Server-Authoritative Leaderboard Endpoints ---
  // Replaces all mock data with real PostgreSQL rankings.
  // Supports sorting by Rating, Wins, and Coins with deterministic tie-breaking.
  // Includes pagination, privacy protection (no passwords, emails or tokens),
  // and full-database ranking calculation for the current requesting user.
  app.get(['/api/leaderboard', '/api/leaderboard/:categoryParam'], optionalAuth, async (req, res) => {
    if (!pool) {
      return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
    }

    try {
      const rawCategory = (req.params.categoryParam || req.query.category || 'rating').toString().toLowerCase();
      const category = ['rating', 'wins', 'coins', 'friends'].includes(rawCategory) ? rawCategory : 'rating';

      const page = Math.max(1, parseInt(String(req.query.page || '1'), 10) || 1);
      const limit = Math.min(100, Math.max(1, parseInt(String(req.query.limit || '50'), 10) || 50));
      const offset = (page - 1) * limit;

      // Identify requesting user (via verified token in optionalAuth or explicit query param)
      const requestingUserId = (req as any).user?.uid || (typeof req.query.userId === 'string' ? req.query.userId.trim() : null);

      // Deterministic ranking order clauses
      let orderClause = '';
      if (category === 'wins') {
        orderClause = `ORDER BY COALESCE(ps.wins, 0) DESC, COALESCE(ps.rating, 1200) DESC, COALESCE(ps.coins, 5000) DESC, u.created_at ASC, u.id ASC`;
      } else if (category === 'coins') {
        orderClause = `ORDER BY COALESCE(ps.coins, 5000) DESC, COALESCE(ps.rating, 1200) DESC, COALESCE(ps.wins, 0) DESC, u.created_at ASC, u.id ASC`;
      } else {
        // default: rating
        orderClause = `ORDER BY COALESCE(ps.rating, 1200) DESC, COALESCE(ps.wins, 0) DESC, COALESCE(ps.coins, 5000) DESC, u.created_at ASC, u.id ASC`;
      }

      // Optional friends filter if category is 'friends'
      let friendsFilter = '';
      const queryParams: any[] = [];
      if (category === 'friends') {
        const rawFriendIds = req.query.friendIds ? String(req.query.friendIds).split(',').map(s => s.trim()).filter(Boolean) : [];
        const targetIds = requestingUserId ? Array.from(new Set([requestingUserId, ...rawFriendIds])) : rawFriendIds;
        if (targetIds.length > 0) {
          queryParams.push(targetIds);
          friendsFilter = `AND u.id = ANY($${queryParams.length}::text[])`;
        }
      }

      // Total count query
      const countSql = `
        SELECT COUNT(*) as count 
        FROM public.users u
        LEFT JOIN public.player_stats ps ON u.id = ps.id
        WHERE u.username IS NOT NULL AND TRIM(u.username) != '' ${friendsFilter};
      `;
      const countRes = await pool.query(countSql, queryParams);
      const total = parseInt(countRes.rows[0]?.count || '0', 10);

      // Paginated ranked entries query
      // Never expose private authentication data, passwords, emails, or tokens.
      const pageParams = [...queryParams, limit, offset];
      const entriesSql = `
        WITH ranked_users AS (
          SELECT 
            u.id,
            u.username,
            u.avatar_url,
            u.is_guest,
            COALESCE(ps.rating, 1200)::int AS rating,
            COALESCE(ps.wins, 0)::int AS wins,
            COALESCE(ps.losses, 0)::int AS losses,
            COALESCE(ps.draws, 0)::int AS draws,
            COALESCE(ps.coins, 5000)::int AS coins,
            COALESCE(ps.level, 1)::int AS level,
            ROW_NUMBER() OVER (${orderClause})::int AS rank
          FROM public.users u
          LEFT JOIN public.player_stats ps ON u.id = ps.id
          WHERE u.username IS NOT NULL AND TRIM(u.username) != '' ${friendsFilter}
        )
        SELECT rank, id, username, avatar_url, is_guest, rating, wins, losses, draws, coins, level
        FROM ranked_users
        ORDER BY rank ASC
        LIMIT $${queryParams.length + 1} OFFSET $${queryParams.length + 2};
      `;
      const entriesRes = await pool.query(entriesSql, pageParams);

      // Retrieve requesting user's full ranking across the entire database, even if outside Top 100
      let currentUserRankData: any = null;
      if (requestingUserId) {
        const userRankSql = `
          WITH ranked_users AS (
            SELECT 
              u.id,
              u.username,
              u.avatar_url,
              u.is_guest,
              COALESCE(ps.rating, 1200)::int AS rating,
              COALESCE(ps.wins, 0)::int AS wins,
              COALESCE(ps.losses, 0)::int AS losses,
              COALESCE(ps.draws, 0)::int AS draws,
              COALESCE(ps.coins, 5000)::int AS coins,
              COALESCE(ps.level, 1)::int AS level,
              ROW_NUMBER() OVER (${orderClause})::int AS rank
            FROM public.users u
            LEFT JOIN public.player_stats ps ON u.id = ps.id
            WHERE u.username IS NOT NULL AND TRIM(u.username) != ''
          )
          SELECT rank, id, username, avatar_url, is_guest, rating, wins, losses, draws, coins, level
          FROM ranked_users
          WHERE id = $1
          LIMIT 1;
        `;
        const userRankRes = await pool.query(userRankSql, [requestingUserId]);
        if (userRankRes.rows.length > 0) {
          currentUserRankData = userRankRes.rows[0];
        }
      }

      return res.json({
        success: true,
        category,
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
        entries: entriesRes.rows,
        currentUser: currentUserRankData,
      });
    } catch (err: any) {
      console.error('leaderboard error:', err);
      return res.status(500).json({ error: err.message || 'Failed to fetch leaderboard' });
    }
  });

  // Security: Reject client attempts to submit or tamper with leaderboard statistics directly
  app.post(['/api/leaderboard', '/api/leaderboard/*'], (_req, res) => {
    res.status(405).json({ error: 'Method Not Allowed. Leaderboard statistics cannot be submitted by clients.' });
  });

  app.put(['/api/leaderboard', '/api/leaderboard/*'], (_req, res) => {
    res.status(405).json({ error: 'Method Not Allowed. Leaderboard statistics cannot be modified by clients.' });
  });

  // ==========================================
  // AUTHORITATIVE CUSTOM PRIVATE ROOM ENDPOINTS
  // ==========================================

  // 1. Create a private custom room (Server generates unique 6-digit code)
  app.post('/api/custom-rooms/create', requireAuth, async (req: any, res: any) => {
    try {
      const hostId = req.user.uid;
      const hostUsername = req.user.username || 'Host';
      const timeMin = [3, 5, 10].includes(Number(req.body?.timeMin)) ? Number(req.body.timeMin) : 5;
      const requestedStake = Math.max(0, parseInt(req.body?.stake, 10) || 0);

      if (requestedStake > 0) {
        const hostBal = await getPlayerCoinBalance(hostId);
        if (hostBal < requestedStake) {
          return res.status(400).json({
            error: `Insufficient coins: You need ${requestedStake.toLocaleString()} coins for this stake, but only have ${hostBal.toLocaleString()}.`
          });
        }
      }

      const code = await generateUniqueRoomCode();
      console.log('MATCH CREATED!');
        const matchId = crypto.randomUUID();
      const timeMs = timeMin * 60 * 1000;

      const initialMatch: ServerMatch = {
        id: matchId,
        whiteId: hostId, // Provisional until guest joins
        blackId: null,
        fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
        turn: 'w',
        whiteTimeMs: timeMs,
        blackTimeMs: timeMs,
        lastMoveAt: 0,
        status: 'waiting',
        winner: null,
        moveHistory: [],
        tableId: 'custom',
        stake: requestedStake,
        prize: requestedStake * 2,
        stakesDeducted: false,
        prizeAwarded: false
      };

      inMemoryMatches.set(matchId, initialMatch);
      if (!matchRooms.has(matchId)) matchRooms.set(matchId, new Set());
      matchRooms.get(matchId)!.add(hostId);

      const room: CustomRoomRecord = {
        code,
        hostId,
        hostUsername,
        guestId: null,
        guestUsername: null,
        matchId,
        timeMin,
        stake: requestedStake,
        prize: requestedStake * 2,
        status: 'waiting',
        createdAt: Date.now()
      };

      customRooms.set(code, room);

      if (pool) {
        try {
          await pool.query(
            `INSERT INTO public.custom_rooms (code, host_id, guest_id, match_id, time_min, stake, prize, status, created_at, updated_at)
             VALUES ($1, $2, NULL, $3, $4, $5, $6, 'waiting', NOW(), NOW())
             ON CONFLICT (code) DO UPDATE SET host_id = EXCLUDED.host_id, match_id = EXCLUDED.match_id, status = 'waiting', updated_at = NOW();`,
            [code, hostId, matchId, timeMin, requestedStake, requestedStake * 2]
          );
        } catch (err: any) {
          console.warn('DB custom_rooms insert notice:', err.message);
        }
      }

      return res.json({
        success: true,
        room: {
          code,
          matchId,
          timeMin,
          stake: requestedStake,
          prize: requestedStake * 2,
          status: 'waiting'
        }
      });
    } catch (err: any) {
      console.error('Create custom room error:', err);
      return res.status(500).json({ error: err.message || 'Failed to create custom room' });
    }
  });

  // 2. Join a private custom room with 6-digit code
  app.post('/api/custom-rooms/join', requireAuth, async (req: any, res: any) => {
    try {
      const guestId = req.user.uid;
      const guestUsername = req.user.username || 'Guest';
      const code = String(req.body?.code || '').trim();

      if (!code || !/^\d{6}$/.test(code)) {
        return res.status(400).json({ error: 'Please enter a valid 6-digit room code' });
      }

      const rateKey = `${req.ip || 'ip'}:${guestId}`;
      if (!checkJoinRateLimit(rateKey)) {
        return res.status(429).json({ error: 'Too many failed join attempts. Please wait a minute before trying again.' });
      }

      let room = customRooms.get(code);

      // If not in memory, query from Postgres
      if (!room && pool) {
        try {
          const dbRes = await pool.query('SELECT * FROM public.custom_rooms WHERE code = $1 LIMIT 1;', [code]);
          if (dbRes.rows.length > 0) {
            const row = dbRes.rows[0];
            room = {
              code: row.code,
              hostId: row.host_id,
              hostUsername: 'Host',
              guestId: row.guest_id,
              guestUsername: null,
              matchId: row.match_id,
              timeMin: row.time_min || 5,
              stake: row.stake || 0,
              prize: row.prize || 0,
              status: row.status,
              createdAt: new Date(row.created_at).getTime()
            };
            customRooms.set(code, room);
          }
        } catch {}
      }

      if (!room) {
        return res.status(404).json({ error: 'Room not found. Please verify the 6-digit code.' });
      }

      if (room.status === 'active') {
        return res.status(409).json({ error: 'This room is already full and the match is in progress.' });
      }

      if (room.status === 'completed' || room.status === 'expired') {
        return res.status(410).json({ error: 'This custom room has already finished or expired.' });
      }

      // 30-minute expiration check
      if (Date.now() - room.createdAt > 30 * 60 * 1000) {
        room.status = 'expired';
        if (pool) {
          await pool.query("UPDATE public.custom_rooms SET status = 'expired', updated_at = NOW() WHERE code = $1;", [code]).catch(() => {});
        }
        return res.status(410).json({ error: 'This room code has expired.' });
      }

      // Prevent host from joining their own room
      if (room.hostId === guestId) {
        return res.status(400).json({ error: 'You cannot join your own private room as the opponent. Share the code with a friend!' });
      }

      // Prevent duplicate join
      if (room.guestId) {
        return res.status(409).json({ error: 'Room is already full.' });
      }

      // Check coin balances if stake > 0
      if (room.stake > 0) {
        const guestBal = await getPlayerCoinBalance(guestId);
        if (guestBal < room.stake) {
          return res.status(400).json({
            error: `Insufficient coins: You need ${room.stake.toLocaleString()} coins to join this room, but only have ${guestBal.toLocaleString()}.`
          });
        }
        const hostBal = await getPlayerCoinBalance(room.hostId);
        if (hostBal < room.stake) {
          return res.status(400).json({
            error: 'The room host no longer has sufficient coins for this match.'
          });
        }
      }

      // Re-check after the awaits above: two guests joining at the same moment
      // could both pass the earlier "room is empty" check.
      if (room.guestId || room.status !== 'waiting') {
        return res.status(409).json({ error: 'Room is already full.' });
      }

      // Fair 50/50 color assignment
      const hostColor: 'w' | 'b' = Math.random() < 0.5 ? 'w' : 'b';
      const guestColor: 'w' | 'b' = hostColor === 'w' ? 'b' : 'w';

      room.guestId = guestId;
      room.guestUsername = guestUsername;
      room.status = 'active';
      room.hostColor = hostColor;
      room.guestColor = guestColor;

      // Update in-memory match
      let match = inMemoryMatches.get(room.matchId);
      if (!match) {
        match = {
          id: room.matchId,
          whiteId: hostColor === 'w' ? room.hostId : guestId,
          blackId: hostColor === 'b' ? room.hostId : guestId,
          fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
          turn: 'w',
          whiteTimeMs: room.timeMin * 60 * 1000,
          blackTimeMs: room.timeMin * 60 * 1000,
          lastMoveAt: Date.now() + 4000,
          status: 'active',
          winner: null,
          moveHistory: [],
          tableId: 'custom',
          stake: room.stake,
          prize: room.prize,
          stakesDeducted: false,
          prizeAwarded: false
        };
        inMemoryMatches.set(room.matchId, match);
      } else {
        match.whiteId = hostColor === 'w' ? room.hostId : guestId;
        match.blackId = hostColor === 'b' ? room.hostId : guestId;
        match.status = 'active';
        match.lastMoveAt = Date.now();
      }

      if (room.stake > 0 && !match.stakesDeducted) {
        await deductMatchStakes(match);
      }

      // Add both players to WebSocket match room
      if (!matchRooms.has(room.matchId)) matchRooms.set(room.matchId, new Set());
      matchRooms.get(room.matchId)!.add(room.hostId);
      matchRooms.get(room.matchId)!.add(guestId);

      // Persist to Postgres
      if (pool) {
        try {
          await pool.query(
            "UPDATE public.custom_rooms SET guest_id = $1, status = 'active', updated_at = NOW() WHERE code = $2;",
            [guestId, code]
          );
          await pool.query(
            `INSERT INTO public.matches (id, white_player_id, black_player_id, fen, turn, white_time_ms, black_time_ms, status, stake, prize, created_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
             ON CONFLICT (id) DO UPDATE SET white_player_id = EXCLUDED.white_player_id, black_player_id = EXCLUDED.black_player_id, status = EXCLUDED.status;`,
            [match.id, match.whiteId, match.blackId, match.fen, match.turn, match.whiteTimeMs, match.blackTimeMs, match.status, match.stake, match.prize]
          );
        } catch (err: any) {
          console.warn('DB custom_rooms join update notice:', err.message);
        }
      }

      // Send WebSocket notification to host
      const hostSocket = socketsByUser.get(room.hostId);
      if (hostSocket) {
        sendJson(hostSocket, {
          type: 'custom_room_matched',
          code: room.code,
          matchId: room.matchId,
          assignedColor: hostColor,
          opponent: { userId: guestId, username: guestUsername },
          timeMin: room.timeMin,
          stake: room.stake,
          prize: room.prize
        });
        sendJson(hostSocket, {
          type: 'matched',
          matchId: room.matchId,
          assignedColor: hostColor,
          opponent: { userId: guestId, username: guestUsername },
          tableId: 'custom',
          entryFee: room.stake
        });
      }

      // Send WebSocket notification to guest
      const guestSocket = socketsByUser.get(guestId);
      if (guestSocket) {
        sendJson(guestSocket, {
          type: 'custom_room_matched',
          code: room.code,
          matchId: room.matchId,
          assignedColor: guestColor,
          opponent: { userId: room.hostId, username: room.hostUsername },
          timeMin: room.timeMin,
          stake: room.stake,
          prize: room.prize
        });
        sendJson(guestSocket, {
          type: 'matched',
          matchId: room.matchId,
          assignedColor: guestColor,
          opponent: { userId: room.hostId, username: room.hostUsername },
          tableId: 'custom',
          entryFee: room.stake
        });
      }

      return res.json({
        success: true,
        code: room.code,
        matchId: room.matchId,
        assignedColor: guestColor,
        opponent: { userId: room.hostId, username: room.hostUsername },
        timeMin: room.timeMin,
        stake: room.stake,
        prize: room.prize
      });
    } catch (err: any) {
      console.error('Join custom room error:', err);
      return res.status(500).json({ error: err.message || 'Failed to join custom room' });
    }
  });

  // 3. Check room status (Used for polling & host synchronization)
  app.get('/api/custom-rooms/:code/status', requireAuth, async (req: any, res: any) => {
    try {
      const code = String(req.params.code || '').trim();
      const userId = req.user.uid;

      let room = customRooms.get(code);

      if (pool) {
        try {
          const dbRes = await pool.query(`
            SELECT c.*, 
                   h.username as host_username,
                   g.username as guest_username,
                   m.white_player_id
            FROM public.custom_rooms c
            LEFT JOIN public.users h ON c.host_id = h.id
            LEFT JOIN public.users g ON c.guest_id = g.id
            LEFT JOIN public.matches m ON c.match_id = m.id
            WHERE c.code = $1 LIMIT 1;
          `, [code]);
          
          if (dbRes.rows.length > 0) {
            const row = dbRes.rows[0];
            
            // Determine host color from matches table if available
            let dbHostColor: 'w' | 'b' = 'w';
            let dbGuestColor: 'w' | 'b' = 'b';
            if (row.white_player_id && row.host_id) {
               if (row.white_player_id === row.host_id) {
                 dbHostColor = 'w';
                 dbGuestColor = 'b';
               } else {
                 dbHostColor = 'b';
                 dbGuestColor = 'w';
               }
            }
            
            room = {
              code: row.code,
              hostId: row.host_id,
              hostUsername: row.host_username || 'Host',
              guestId: row.guest_id,
              guestUsername: row.guest_username || 'Guest',
              matchId: row.match_id,
              timeMin: row.time_min || 5,
              stake: row.stake || 0,
              prize: row.prize || 0,
              status: row.status,
              hostColor: dbHostColor,
              guestColor: dbGuestColor,
              createdAt: new Date(row.created_at).getTime()
            };
            customRooms.set(code, room);
          }
        } catch {}
      }

      if (!room) {
        return res.status(404).json({ error: 'Room not found' });
      }

      if (room.status === 'waiting') {
        return res.json({
          status: 'waiting',
          code: room.code,
          timeMin: room.timeMin,
          stake: room.stake,
          prize: room.prize
        });
      }

      if (room.status === 'active') {
        const isHost = room.hostId === userId;
        const isGuest = room.guestId === userId;
        if (!isHost && !isGuest) {
          return res.status(403).json({ error: 'Unauthorized to access this room' });
        }

        const assignedColor = isHost ? (room.hostColor || 'w') : (room.guestColor || 'b');
        const opponent = isHost
          ? { userId: room.guestId, username: room.guestUsername || 'Guest' }
          : { userId: room.hostId, username: room.hostUsername || 'Host' };

        return res.json({
          status: 'active',
          matchId: room.matchId,
          assignedColor,
          opponent,
          timeMin: room.timeMin,
          stake: room.stake,
          prize: room.prize
        });
      }

      return res.json({
        status: room.status,
        code: room.code
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // 4. Cancel custom room
  app.post('/api/custom-rooms/:code/cancel', requireAuth, async (req: any, res: any) => {
    try {
      const code = String(req.params.code || '').trim();
      const userId = req.user.uid;
      const room = customRooms.get(code);
      if (room && room.hostId === userId && room.status === 'waiting') {
        room.status = 'expired';
        if (pool) {
          await pool.query("UPDATE public.custom_rooms SET status = 'expired', updated_at = NOW() WHERE code = $1;", [code]).catch(() => {});
        }
      }
      return res.json({ success: true });
    } catch (e: any) {
      return res.status(500).json({ error: e.message });
    }
  });

  // Example persistence endpoint for match history
    // API to fetch live matches for spectating
  // Real "players online" per table (replaces numbers that were hardcoded in the
  // client): players waiting in that table's queue + players in its live matches.
  // Cached for 5 s so many open lobbies cost one scan.
  let tableOnlineCache: { at: number; counts: Record<string, number> } = { at: 0, counts: {} };
  app.get('/api/tables/online', authRateLimit(60 * 1000, 30), (_req, res) => {
    if (Date.now() - tableOnlineCache.at > 5000) {
      const counts: Record<string, number> = {};
      for (const id of Object.keys(TABLE_STAKES)) counts[id] = 0;
      for (const m of inMemoryMatches.values()) {
        if (m.status === 'active' && m.tableId && counts[m.tableId] !== undefined) counts[m.tableId] += 2;
      }
      const q: Map<string, any[]> | undefined = (global as any).__mmQueues;
      if (q) for (const [tid, list] of q.entries()) if (counts[tid] !== undefined) counts[tid] += list.length;
      tableOnlineCache = { at: Date.now(), counts };
    }
    res.json({ counts: tableOnlineCache.counts });
  });

  // Real list of matches being played right now. Before: it queried the DB
  // `matches` table (rows only exist AFTER a match ends, so it was always empty)
  // and invented viewer counts with Math.random() and fixed rating 1200 / level 1.
  app.get('/api/matches/live', requireAuth, async (req: any, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database unavailable' });
      const live = (await listLiveMatches(50)).filter((m: any) => m.status === 'active' && m.whiteId && m.blackId).slice(0, 20);
      const ids = [...new Set(live.flatMap((m: any) => [m.whiteId, m.blackId]))];
      const info = new Map<string, any>();
      if (ids.length) {
        const r = await pool.query(
          `SELECT u.id, u.username, u.avatar_url, COALESCE(p.rating, 1200) AS rating, COALESCE(p.level, 1) AS level
           FROM public.users u LEFT JOIN public.player_stats p ON p.id = u.id WHERE u.id = ANY($1::text[]);`, [ids]);
        for (const row of r.rows) info.set(row.id, row);
      }
      const who = (id: string) => {
        const u = info.get(id);
        return { name: u?.username || 'Player', avatar: u?.avatar_url || '', rating: Number(u?.rating || 1200), level: Number(u?.level || 1) };
      };
      res.json({
        liveMatches: live.map((m: any) => ({
          id: m.id,
          viewers: 0, // live spectating is not implemented, so no viewers exist
          stake: m.stake || 0,
          turn: m.turn,
          player1: who(m.whiteId),
          player2: who(m.blackId),
        })),
      });
    } catch (e: any) {
      res.status(500).json({ error: 'Failed to load live matches' });
    }
  });

  // ================= GLOBAL CHAT (real, server-stored) =================
  // Before: the chat tab only appended your own message to local React state.
  // Now messages live in Postgres, are shown to everyone, rate-limited,
  // length-capped, and banned/suspended accounts cannot post.
  app.get('/api/chat/global', requireAuth, authRateLimit(60 * 1000, 60), async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const after = typeof req.query.after === 'string' ? req.query.after : '';
      const latest = async () =>
        (await db.select().from(schema.global_chat_messages).orderBy(desc(schema.global_chat_messages.created_at)).limit(50)).reverse();
      let rows: any[];
      if (after) {
        const ref = await db.select().from(schema.global_chat_messages).where(eq(schema.global_chat_messages.id, after));
        rows = ref[0]
          ? await db.select().from(schema.global_chat_messages).where(sql`${schema.global_chat_messages.created_at} > ${ref[0].created_at}`).orderBy(schema.global_chat_messages.created_at).limit(100)
          : await latest();
      } else {
        rows = await latest();
      }
      res.json({ messages: rows.map((m: any) => ({ id: m.id, userId: m.user_id, senderName: m.username, avatar: m.avatar, level: m.level, text: m.text, createdAt: m.created_at })) });
    } catch (e: any) {
      res.status(500).json({ error: 'Failed to load chat' });
    }
  });

  app.post('/api/chat/global', requireAuth, authRateLimit(10 * 1000, 6), async (req: any, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const text = typeof req.body?.text === 'string' ? req.body.text.replace(/\s+/g, ' ').trim() : '';
      if (!text) return res.status(400).json({ error: 'Message is empty' });
      if (text.length > 200) return res.status(400).json({ error: 'Message too long (max 200)' });
      const uid = req.user.uid;
      const u: any = (await db.select().from(schema.users).where(eq(schema.users.id, uid)))[0];
      if (!u) return res.status(404).json({ error: 'Account not found' });
      if (u.is_banned) return res.status(403).json({ error: 'Banned' });
      if (u.is_suspended && (!u.suspended_until || new Date(u.suspended_until) > new Date())) {
        return res.status(403).json({ error: 'Your account is suspended' });
      }
      const st: any = (await db.select().from(schema.player_stats).where(eq(schema.player_stats.id, uid)))[0];
      const row = { id: crypto.randomUUID(), user_id: uid, username: u.username, avatar: u.avatar_url || null, level: st?.level || 1, text };
      await db.insert(schema.global_chat_messages).values(row);
      res.json({ message: { id: row.id, userId: uid, senderName: row.username, avatar: row.avatar, level: row.level, text, createdAt: new Date().toISOString() } });
    } catch (e: any) {
      res.status(500).json({ error: 'Failed to send message' });
    }
  });

  // Keep the table small: drop messages older than 7 days.
  setInterval(() => {
    if (!db) return;
    db.delete(schema.global_chat_messages).where(sql`${schema.global_chat_messages.created_at} < now() - interval '7 days'`).catch(() => {});
  }, 6 * 60 * 60 * 1000).unref?.();

  app.get('/api/matches', adminMw, async (req, res) => {
    try {
      if (!db) return res.status(503).json({ error: 'Service temporarily unavailable. Database disconnected.' });
      const result = await db.select().from(schema.matches).limit(10);
      return res.json({ matches: result });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Project source files list endpoint for mobile / 1-click ZIP download

  // Tournament endpoints
  app.get('/api/tournaments/current', requireAuth, async (req: any, res: any) => {
    try {
      const [tournament] = await db.select().from(schema.tournaments).where(not(eq(schema.tournaments.status, 'completed'))).limit(1);
      
      if (!tournament) {
        return res.json({ tournament: null, participants: [], matches: [], isRegistered: false });
      }

      const userId = req.user.uid;
      
      const participants = await db.select({
        id: schema.users.id,
        name: schema.users.username,
        avatar: schema.users.avatar_url,
        level: schema.player_stats.level,
        rank: schema.tournament_participants.rank
      }).from(schema.tournament_participants)
        .innerJoin(schema.users, eq(schema.users.id, schema.tournament_participants.user_id))
        .innerJoin(schema.player_stats, eq(schema.player_stats.id, schema.users.id))
        .where(eq(schema.tournament_participants.tournament_id, tournament.id));

      const isRegistered = participants.some(p => p.id === userId);

      const matchesQuery = await db.select().from(schema.tournament_matches).where(eq(schema.tournament_matches.tournament_id, tournament.id));
      
      const matches = matchesQuery.map(m => {
         const p1 = participants.find(p => p.id === m.player1_id);
         const p2 = participants.find(p => p.id === m.player2_id);
         
         return {
            id: m.id,
            roundNameKu: `قۆناغی ${m.round}`,
            roundNameEn: `Round ${m.round}`,
            scheduledTime: 'TBD',
            p1: p1 ? { id: p1.id, name: p1.name, avatar: p1.avatar, score: m.winner_id === p1.id ? 1 : 0, isWinner: m.winner_id === p1.id } : null,
            p2: p2 ? { id: p2.id, name: p2.name, avatar: p2.avatar, score: m.winner_id === p2.id ? 1 : 0, isWinner: m.winner_id === p2.id } : null,
            status: m.status
         };
      });

      return res.json({ tournament, participants, matches, isRegistered });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  
  app.post('/api/tournaments/match/:id/start', requireAuth, async (req: any, res: any) => {
    try {
      const matchId = req.params.id; // tournament_match id
      const userId = req.user.uid;
      
      const [tMatch] = await db.select().from(schema.tournament_matches).where(eq(schema.tournament_matches.id, matchId));
      if (!tMatch) return res.status(404).json({ error: 'Match not found' });
      
      if (tMatch.player1_id !== userId && tMatch.player2_id !== userId) {
        return res.status(403).json({ error: 'Not your match' });
      }

      if (tMatch.status === 'completed') {
        return res.status(400).json({ error: 'Match already completed' });
      }

      if (!tMatch.player1_id || !tMatch.player2_id) {
         return res.status(400).json({ error: 'Waiting for opponent' });
      }

      if (tMatch.match_id) {
        return res.json({ success: true, matchId: tMatch.match_id });
      }

      // We need to create a real match using a mutex so both players don't create it
      const release = await acquireMatchMutex(`tmatch_${tMatch.id}`);
      try {
        const [current] = await db.select().from(schema.tournament_matches).where(eq(schema.tournament_matches.id, tMatch.id));
        if (current.match_id) {
           return res.json({ success: true, matchId: current.match_id });
        }

        const realMatchId = crypto.randomUUID();
        
        // Let's create an in-memory match (ServerMatch)
        const serverMatch: ServerMatch = { turn: 'w', whiteTimeMs: 600000, blackTimeMs: 600000, prize: 0, stakesDeducted: false, prizeAwarded: false,
           id: realMatchId,
           whiteId: current.player1_id,
           blackId: current.player2_id,
           status: 'active',
           // history: [],
           fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
           lastMoveAt: Date.now(),
           winner: null,
           // drawOffer: null,
           // timeControl: 10 * 60 * 1000,
           // whiteTimeLeft: 10 * 60 * 1000,
           // blackTimeLeft: 10 * 60 * 1000,
           stake: 0,
        };
        // activeMatches.set(realMatchId, serverMatch);

        await db.update(schema.tournament_matches)
          .set({ match_id: realMatchId, status: 'active' })
          .where(eq(schema.tournament_matches.id, tMatch.id));

        return res.json({ success: true, matchId: realMatchId });
      } finally {
        release();
      }

    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/tournaments/join', requireAuth, async (req: any, res: any) => {
    try {
      const userId = req.user.uid;
      let [tournament] = await db.select().from(schema.tournaments).where(eq(schema.tournaments.status, 'registration')).limit(1);
      
      if (!tournament) {
        // Create one for testing if it doesn't exist
        const tId = crypto.randomUUID();
        await db.insert(schema.tournaments).values({
          id: tId,
          name: '1-Month Grand Championship',
          type: 'monthly',
          status: 'registration',
          entry_fee: 1000,
          prize_pool: 50000,
          max_participants: 16
        });
        [tournament] = await db.select().from(schema.tournaments).where(eq(schema.tournaments.id, tId));
      }

      // Everything below runs in ONE transaction with the player's stats row
      // locked: previously the balance check happened outside the
      // transaction, so two simultaneous join requests could both pass it
      // and push coins negative, and a missing stats row crashed the route.
      const outcome = await db.transaction(async (tx: any) => {
        await tx.insert(schema.player_stats).values({ id: userId }).onConflictDoNothing();
        const [stats] = await tx.select().from(schema.player_stats).where(eq(schema.player_stats.id, userId)).for('update');
        if ((stats?.coins || 0) < tournament.entry_fee) return { error: 'Insufficient coins' };

        const [existing] = await tx.select().from(schema.tournament_participants)
          .where(and(eq(schema.tournament_participants.tournament_id, tournament.id), eq(schema.tournament_participants.user_id, userId)));
        if (existing) return { error: 'Already registered' };

        const countRes = await tx.select({ count: sql`count(*)` }).from(schema.tournament_participants).where(eq(schema.tournament_participants.tournament_id, tournament.id));
        if (Number(countRes[0].count) >= tournament.max_participants) return { error: 'Tournament is full' };

        await tx.insert(schema.tournament_participants).values({ tournament_id: tournament.id, user_id: userId });
        await tx.update(schema.player_stats)
          .set({ coins: sql`${schema.player_stats.coins} - ${tournament.entry_fee}` })
          .where(eq(schema.player_stats.id, userId));
        return { ok: true };
      });
      if ((outcome as any).error) return res.status(400).json({ error: (outcome as any).error });

      return res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Admin endpoint to start tournament
  app.post('/api/tournaments/admin/start', adminMw, async (req: any, res: any) => {
    try {
      const [tournament] = await db.select().from(schema.tournaments).where(eq(schema.tournaments.status, 'registration')).limit(1);
      if (!tournament) return res.status(400).json({ error: 'No tournament in registration' });

      const participants = await db.select().from(schema.tournament_participants).where(eq(schema.tournament_participants.tournament_id, tournament.id));
      if (participants.length < 2) return res.status(400).json({ error: 'Not enough participants' });

      // Shuffle and create round 1 matches
      const shuffled = [...participants].sort(() => 0.5 - Math.random());
      
      await db.transaction(async (tx) => {
        await tx.update(schema.tournaments).set({ status: 'active' }).where(eq(schema.tournaments.id, tournament.id));
        
        for (let i = 0; i < shuffled.length; i += 2) {
           const p1 = shuffled[i];
           const p2 = shuffled[i+1]; // might be undefined if odd
           
           await tx.insert(schema.tournament_matches).values({
              id: crypto.randomUUID(),
              tournament_id: tournament.id,
              round: 1,
              match_index: i/2,
              player1_id: p1.user_id,
              player2_id: p2 ? p2.user_id : null,
              status: p2 ? 'pending' : 'completed', // auto-win if bye
              winner_id: p2 ? null : p1.user_id
           });
        }
      });
      return res.json({ success: true });
    } catch(e: any) {
      res.status(500).json({ error: e.message });
    }
  });


  app.get('/api/project-files', adminMw, async (_req, res) => {
    try {
      const fs = await import('fs/promises');
      const rootDir = process.cwd();
      const files: { path: string; content?: string; isBinary?: boolean; url?: string }[] = [];

      async function scan(dir: string, base: string = '') {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        for (const entry of entries) {
          const fullPath = path.join(dir, entry.name);
          const relativePath = base ? `${base}/${entry.name}` : entry.name;

          // Skip node_modules, .git, dist, and tmp
          if (entry.isDirectory()) {
            if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === 'dist' || entry.name === '.cache') {
              continue;
            }
            await scan(fullPath, relativePath);
          } else {
            // Check if binary image
            if (/\.(jpg|jpeg|png|webp|gif|mp3|wav|ogg|ico|svg)$/i.test(entry.name)) {
              files.push({
                path: relativePath,
                isBinary: true,
                url: `/${relativePath}`,
              });
            } else {
              const textContent = await fs.readFile(fullPath, 'utf-8');
              files.push({
                path: relativePath,
                content: textContent,
                isBinary: false,
              });
            }
          }
        }
      }

      await scan(rootDir);
      res.json({ files });
    } catch (e: any) {
      console.error('Error scanning files:', e);
      res.status(500).json({ error: e.message });
    }
  });

  // Gemini AI Coach / Tactical Advice endpoint
  app.post('/api/gemini/advice', authRateLimit(60 * 1000, 8), async (req, res) => {
    try {
      const { fen, moves, language } = req.body;

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        // Fallback intelligent coaching response if key not yet set
        if (language === 'ku') {
          return res.json({
            analysisKu: 'تەختەکە ئاساییە. هەوڵبدە کۆنترۆڵی ناوەڕاست بکەیت بە بەکارھێنانی پیادە و ئەسپەکانت.',
            suggestedMoveSan: 'e4',
            tacticalTipKu: 'شای خۆت بە زوویی بخەرە شوێنێکی ئارام لەڕێگەی قەڵابەزێن (Castling).',
          });
        }
        return res.json({
          analysisEn: 'Solid board setup. Focus on controlling the center with your pawns and developing Knights.',
          suggestedMoveSan: 'e4',
          tacticalTipEn: 'Castle early to keep your King secure from central attacks.',
        });
      }

      const ai = new GoogleGenAI({ apiKey });

      const prompt = `You are a World Chess Grandmaster and AI Coach in "Onyx & Ivory 3D Chess".
Current Chess FEN: "${fen || 'start'}"
Recent Moves Log: "${moves?.join(' ') || 'None'}"
Target Language: ${language === 'ku' ? 'Central Kurdish (Sorani / کوردی)' : 'English'}

Provide a brief, insightful 2-sentence tactical commentary and 1 key tip for the player whose turn it is.
Return output in strictly valid JSON format with keys:
{
  "analysisKu": "کورتە شیکاری کایەکە بە کوردی سۆرانی",
  "analysisEn": "Brief tactical evaluation in English",
  "suggestedMoveSan": "e.g. Nf3 or e4",
  "tacticalTipKu": "ئامۆژگاری تاکتیکی بڕیاردەر بە کوردی سۆرانی",
  "tacticalTipEn": "One key strategic advice sentence in English"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      const responseText = response.text || '';
      const cleanJson = responseText.replace(/```json|```/g, '').trim();

      try {
        const parsed = JSON.parse(cleanJson);
        return res.json(parsed);
      } catch {
        return res.json({
          analysisKu: 'شیکاری شوێنی شاو و پارچەکانی ناوەڕاست نیشان دەدات کە یاریەکە هاوسەنگە.',
          analysisEn: 'Position analysis indicates a balanced game state. Develop your pieces.',
          tacticalTipKu: 'هەمیشە پێش جووڵە سەیری پارچە بێ پارێزگارەکانی دوژمن بکە.',
          tacticalTipEn: 'Always calculate undefended enemy pieces before moving.',
        });
      }
    } catch (err) {
      console.error('Gemini API Error:', err);
      res.status(500).json({ error: 'Failed to generate AI advice' });
    }
  });

  
  // =====================
  // FRIEND SYSTEM ENDPOINTS
  // =====================

  app.get('/api/users/search', authRateLimit(60 * 1000, 30), async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const q = String(req.query.q || '').trim().slice(0, 30).replace(/[\\%_]/g, (c) => '\\' + c);
      if (q.length < 2) return res.json({ users: [] });

      // Case-insensitive search on username
      const client = await pool.connect();
      try {
        const result = await client.query(
          `SELECT u.id, u.username as name, u.avatar_url as avatar, p.level 
           FROM public.users u
           LEFT JOIN public.player_stats p ON u.id = p.id
           WHERE u.username ILIKE $1
           LIMIT 10;`,
          [`%${q}%`]
        );
        res.json({ users: result.rows });
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Search users error:', e);
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/player/:id/friends', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const userId = (req as any).user?.uid || req.params.id;
      const client = await pool.connect();
      
      try {
        // Get accepted friends
        const result = await client.query(
          `SELECT 
            u.id, 
            u.username as name, 
            u.avatar_url as avatar, 
            p.level 
           FROM public.friendships f
           JOIN public.users u ON (u.id = f.friend_id OR u.id = f.user_id) AND u.id != $1
           LEFT JOIN public.player_stats p ON u.id = p.id
           WHERE (f.user_id = $1 OR f.friend_id = $1) AND f.status = 'accepted';`,
          [userId]
        );
        
        // Also check if they are online (simple mock for now, could be via Redis/sockets)
        const friends = result.rows.map(r => ({
          ...r,
          isOnline: socketsByUser && socketsByUser.has(r.id) ? true : false,
          statusText: socketsByUser && socketsByUser.has(r.id) ? 'Online 🟢' : 'Offline 🔴'
        }));
        
        res.json({ friends });
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Get friends error:', e);
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/player/:id/friend-requests', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const userId = (req as any).user?.uid || req.params.id;
      const client = await pool.connect();
      
      try {
        // Get pending requests where friend_id is the user (incoming)
        const result = await client.query(
          `SELECT 
            f.id as request_id,
            u.id, 
            u.username as name, 
            u.avatar_url as avatar, 
            p.level 
           FROM public.friendships f
           JOIN public.users u ON u.id = f.user_id
           LEFT JOIN public.player_stats p ON u.id = p.id
           WHERE f.friend_id = $1 AND f.status = 'pending';`,
          [userId]
        );
        
        res.json({ incomingRequests: result.rows });
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Get friend requests error:', e);
      res.status(500).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/friends/request', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const userId = (req as any).user?.uid || req.params.id;
      const { targetUsername, targetUserId } = req.body;
      
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        
        let targetId = targetUserId;
        if (!targetId && targetUsername) {
          const ures = await client.query(`SELECT id FROM public.users WHERE username = $1`, [targetUsername]);
          if (ures.rows.length === 0) throw new Error('User not found');
          targetId = ures.rows[0].id;
        }
        
        if (!targetId) throw new Error('Target required');
        if (targetId === userId) throw new Error('Cannot add yourself');
        
        // Check if relationship already exists
        const checkRes = await client.query(
          `SELECT status, user_id FROM public.friendships 
           WHERE (user_id = $1 AND friend_id = $2) OR (user_id = $2 AND friend_id = $1)
           FOR UPDATE`,
          [userId, targetId]
        );
        
        if (checkRes.rows.length > 0) {
          const f = checkRes.rows[0];
          if (f.status === 'accepted') throw new Error('Already friends');
          if (f.user_id === userId) throw new Error('Request already sent');
          throw new Error('You already have a pending request from this user');
        }
        
        const relId = userId < targetId ? `${userId}_${targetId}` : `${targetId}_${userId}`;
        
        await client.query(
          `INSERT INTO public.friendships (id, user_id, friend_id, status) VALUES ($1, $2, $3, 'pending')`,
          [relId, userId, targetId]
        );
        
        await client.query('COMMIT');
        res.json({ success: true });
      } catch (e: any) {
        await client.query('ROLLBACK');
        throw e;
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Send friend request error:', e);
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/friends/accept', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const userId = (req as any).user?.uid || req.params.id;
      const { friendId } = req.body;
      
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        
        const relId = userId < friendId ? `${userId}_${friendId}` : `${friendId}_${userId}`;
        
        const updateRes = await client.query(
          `UPDATE public.friendships 
           SET status = 'accepted' 
           WHERE id = $1 AND friend_id = $2 AND status = 'pending'
           RETURNING id`,
          [relId, userId]
        );
        
        if (updateRes.rows.length === 0) throw new Error('Request not found or already accepted');
        
        await client.query('COMMIT');
        res.json({ success: true });
      } catch (e: any) {
        await client.query('ROLLBACK');
        throw e;
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Accept friend request error:', e);
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/friends/reject', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const userId = (req as any).user?.uid || req.params.id;
      const { friendId, requestId } = req.body;
      
      const client = await pool.connect();
      try {
        let relId = requestId;
        if (!relId && friendId) {
           relId = userId < friendId ? `${userId}_${friendId}` : `${friendId}_${userId}`;
        }
        
        await client.query(
          `DELETE FROM public.friendships 
           WHERE id = $1 AND (friend_id = $2 OR user_id = $2)`,
          [relId, userId]
        );
        
        res.json({ success: true });
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Reject friend request error:', e);
      res.status(400).json({ error: e.message });
    }
  });

  app.post('/api/player/:id/friends/remove', requireAuth, async (req, res) => {
    try {
      if (!pool) return res.status(503).json({ error: 'Database disconnected' });
      const userId = (req as any).user?.uid || req.params.id;
      const { friendId } = req.body;
      
      const client = await pool.connect();
      try {
        const relId = userId < friendId ? `${userId}_${friendId}` : `${friendId}_${userId}`;
        
        await client.query(
          `DELETE FROM public.friendships 
           WHERE id = $1 AND (user_id = $2 OR friend_id = $2) AND status = 'accepted'`,
          [relId, userId]
        );
        
        res.json({ success: true });
      } finally {
        client.release();
      }
    } catch (e: any) {
      console.error('Remove friend error:', e);
      res.status(400).json({ error: e.message });
    }
  });

  // Vite middleware in development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const httpServer = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  setupRealtimeServer(httpServer);
}

// --- Realtime WebSocket server: online matchmaking + live match relay ---
// Replaces the previous third-party (Nakama) realtime service. Runs on the
// same HTTP server/port as the REST API, so no separate hosting is needed.
function setupRealtimeServer(httpServer: import('http').Server) {
  const wss = new SocketIOServer(httpServer, { path: '/ws', cors: { origin: (o: string | undefined, cb: (e: Error | null, ok?: boolean) => void) => cb(null, !o || isAllowedOrigin(o, undefined)), credentials: true }, transports: ['polling', 'websocket'] });

  const mmQueues = new Map<string, { userId: string; username: string }[]>(); // tableId -> waiting players
  (global as any).__mmQueues = mmQueues;

  const removeFromAllQueues = (userId: string) => {
    for (const list of mmQueues.values()) {
      const idx = list.findIndex((p) => p.userId === userId);
      if (idx !== -1) list.splice(idx, 1);
    }
  };

  const broadcastPresence = (matchId: string, userId: string, event: 'join' | 'leave' | 'disconnected' | 'reconnect' | 'abandoned', metadata?: any) => {
    const members = matchRooms.get(matchId);
    if (!members) return;
    for (const uid of members) {
      if (uid === userId) continue;
      const s = socketsByUser.get(uid);
      if (s) sendJson(s, { type: 'presence', matchId, userId, event, metadata });
    }
  };

  notifyUserBalance = (userId: string, coins: number, matchId?: string) => {
    const s = socketsByUser.get(userId);
    if (s) sendJson(s, { type: 'balance_update', userId, coins, matchId });
  };

  broadcastToMatchRoom = (matchId: string, payload: any, excludeUserId?: string) => {
    const members = matchRooms.get(matchId);
    if (!members) return;
    for (const uid of members) {
      if (excludeUserId && uid === excludeUserId) continue;
      const s = socketsByUser.get(uid);
      if (s) sendJson(s, payload);
    }
  };

  // High-frequency 1-second background clock ticker to detect timeouts authoritatively
  setInterval(async () => {
    const now = Date.now();
    for (const [matchId, match] of inMemoryMatches.entries()) {
      if (match.status === 'active' && match.lastMoveAt > 0) {
        const elapsed = Math.max(0, now - match.lastMoveAt);
        const curW = match.whiteTimeMs - (match.turn === 'w' ? elapsed : 0);
        const curB = match.blackTimeMs - (match.turn === 'b' ? elapsed : 0);

        if (curW <= 0 || curB <= 0) {
          const timeoutRes = await updateMatchAtomic(matchId, (m) => {
            if (!m || m.status !== 'active') return m;
            const el = Math.max(0, Date.now() - m.lastMoveAt);
            let remW = m.whiteTimeMs - (m.turn === 'w' ? el : 0);
            let remB = m.blackTimeMs - (m.turn === 'b' ? el : 0);
            if (remW <= 0) {
              m.status = 'timeout';
              m.winner = 'b';
              m.whiteTimeMs = 0;
              return { match: m, shouldFinalize: true };
            } else if (remB <= 0) {
              m.status = 'timeout';
              m.winner = 'w';
              m.blackTimeMs = 0;
              return { match: m, shouldFinalize: true };
            }
            return m;
          });

          if (timeoutRes.match && timeoutRes.shouldFinalize) {
            await finalizeMatch(timeoutRes.match);
            if (broadcastToMatchRoom) {
              try {
                const payloadStr = JSON.stringify({
                  op_code: 2,
                  reason: 'timeout',
                  winner: timeoutRes.match.winner,
                  status: 'timeout',
                  whiteTime: 0,
                  blackTime: 0
                });
                broadcastToMatchRoom(matchId, {
                  type: 'match_data',
                  matchId,
                  opCode: 2,
                  data: Buffer.from(payloadStr).toString('base64')
                });
              } catch {}
            }
          }
        }
      }
    }
  }, 1000);

  // 15-second heartbeat ping to detect dropouts immediately
  

  wss.on('connection', (ws: Socket) => {
    let currentUserId: string | null = null;
    

    

    // `identify` now verifies a token asynchronously; every other message waits
    // for it so e.g. an immediate `join_match` right after `identify` isn't lost.
    let identifyPromise: Promise<void> | null = null;

    ws.on('message', async (raw) => {
      let msg: any;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (msg.type !== 'identify' && identifyPromise) await identifyPromise;

      if (msg.type === 'identify') {
        // SECURITY: the identity comes from a verified token, never from the
        // `userId` the client claims. Before, anyone could identify as any
        // player: steal their matchmaking/match events, kick their socket,
        // and queue as them (spending THEIR entry-fee coins).
        let done!: () => void;
        identifyPromise = new Promise<void>((r) => { done = r; });
        const verifiedUid = await verifyTokenToUid(String(msg.token || ''));
        if (!verifiedUid || (msg.userId && String(msg.userId) !== verifiedUid)) {
          sendJson(ws, { type: 'identify_failed', error: 'Authentication failed' });
          done();
          return;
        }
        currentUserId = verifiedUid;
        done();
        if (currentUserId) {
          // Prevent duplicate connections from corrupting matches:
          // Close previous zombie or duplicate connection cleanly
          const existingWs = socketsByUser.get(currentUserId);
          if (existingWs && existingWs !== ws && existingWs.connected) {
            try {
              sendJson(existingWs, { type: 'superseded', message: 'Reconnected from another session' });
              existingWs.disconnect(true);
            } catch {}
          }
          socketsByUser.set(currentUserId, ws);

          // Check if this user had any active matches in grace period, and auto-reconnect
          for (const [matchId, match] of inMemoryMatches) {
            if (match.status === 'active' && (match.whiteId === currentUserId || match.blackId === currentUserId)) {
              if (!matchRooms.has(matchId)) matchRooms.set(matchId, new Set());
              matchRooms.get(matchId)!.add(currentUserId);
              handleUserReconnect(matchId, currentUserId);
            }
          }
        }
        sendJson(ws, { type: 'identify_ok' });
        return;
      }

      if (!currentUserId) return; // must identify before anything else

      if (msg.type === 'queue_join') {
        console.log('QUEUE JOIN: ' + JSON.stringify(msg)); console.log('QUEUE JOIN:', msg);
        console.log('[Queue] Join Request:', currentUserId, msg.username, msg.tableId);
        const tableId = String(msg.tableId || 'default');
        const entryFee = TABLE_STAKES[tableId]?.entryFee ?? 0;
        const needLevel = TABLE_MIN_LEVEL[tableId] ?? 1;
        if (needLevel > 1 && pool) {
          let lvl = 1;
          try {
            const lr = await pool.query('SELECT level FROM public.player_stats WHERE id = $1 LIMIT 1;', [currentUserId]);
            lvl = Number(lr.rows[0]?.level || 1);
          } catch {}
          if (lvl < needLevel) {
            sendJson(ws, { type: 'queue_error', error: `This table requires level ${needLevel} (you are level ${lvl}).` });
            return;
          }
        }
        if (entryFee > 0) {
          const userBalance = await getPlayerCoinBalance(currentUserId);
          if (userBalance < entryFee) {
            sendJson(ws, {
              type: 'queue_error',
              error: `Insufficient coins: You need ${entryFee.toLocaleString()} coins to join this table, but have ${userBalance.toLocaleString()}.`
            });
            return;
          }
        }

        removeFromAllQueues(currentUserId);
        if (!mmQueues.has(tableId)) mmQueues.set(tableId, []);
        const queue = mmQueues.get(tableId)!;
        // The display name comes from the database, not from the client message
        // (otherwise a player could impersonate anyone's name to their opponent).
        let queueName = 'Player';
        if (pool) {
          try {
            const un = await pool.query('SELECT username FROM public.users WHERE id = $1 LIMIT 1;', [currentUserId]);
            if (un.rows[0]?.username) queueName = un.rows[0].username;
          } catch {}
        }
        queue.push({ userId: currentUserId, username: queueName });
        console.log('Queue pushed: ' + queue.length); console.log('Queue pushed, length:', queue.length);

        let p1: { userId: string; username: string } | null = null;
        let p2: { userId: string; username: string } | null = null;
        let resolvedTableId = tableId;
        let resolvedEntryFee = entryFee;

        if (queue.length >= 2) {
          p1 = queue.shift()!;
          p2 = queue.shift()!;
        } else {
          // Fast matchmaking: if anyone is waiting in ANY queue (e.g. 30s or 2s), match immediately!
          for (const [otherTableId, otherQueue] of mmQueues.entries()) {
            if (otherTableId !== tableId && otherQueue.length > 0) {
              const waitingIdx = otherQueue.findIndex((p) => p.userId !== currentUserId);
              if (waitingIdx !== -1) {
                p2 = otherQueue.splice(waitingIdx, 1)[0];
                p1 = queue.shift()!;
                const otherFee = TABLE_STAKES[otherTableId]?.entryFee ?? 0;
                // Use lower fee so neither player encounters an insufficient balance error
                if (otherFee <= entryFee) {
                  resolvedTableId = otherTableId;
                  resolvedEntryFee = otherFee;
                }
                break;
              }
            }
          }
        }

        if (p1 && p2) {
          // Re-verify balances of both players before creating match
          const p1Bal = await getPlayerCoinBalance(p1.userId);
          const p2Bal = await getPlayerCoinBalance(p2.userId);

          if (resolvedEntryFee > 0 && (p1Bal < resolvedEntryFee || p2Bal < resolvedEntryFee)) {
            if (p1Bal < resolvedEntryFee) {
              const s1 = socketsByUser.get(p1.userId);
              if (s1) sendJson(s1, { type: 'queue_error', error: 'Insufficient coins for table entry' });
            } else {
              queue.unshift(p1);
            }
            if (p2Bal < resolvedEntryFee) {
              const s2 = socketsByUser.get(p2.userId);
              if (s2) sendJson(s2, { type: 'queue_error', error: 'Insufficient coins for table entry' });
            } else {
              queue.unshift(p2);
            }
            return;
          }

          console.log('MATCH CREATED!');
          const matchId = crypto.randomUUID();
          const p1Color: 'w' | 'b' = Math.random() < 0.5 ? 'w' : 'b';
          const p2Color: 'w' | 'b' = p1Color === 'w' ? 'b' : 'w';

          const whitePlayer = p1Color === 'w' ? p1 : p2;
          const blackPlayer = p1Color === 'b' ? p1 : p2;

          // Initialize match state with stakes immediately
          const initialMatch: ServerMatch = {
            id: matchId,
            whiteId: whitePlayer.userId,
            blackId: blackPlayer.userId,
            fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
            turn: 'w',
            whiteTimeMs: (TABLE_STAKES[resolvedTableId]?.timeMin ?? 10) * 60000,
            blackTimeMs: (TABLE_STAKES[resolvedTableId]?.timeMin ?? 10) * 60000,
            lastMoveAt: Date.now() + 6600,
            status: 'active',
            winner: null,
            moveHistory: [],
            tableId: resolvedTableId,
            stake: resolvedEntryFee,
            prize: TABLE_STAKES[resolvedTableId]?.prizePool ?? (resolvedEntryFee * 2),
            stakesDeducted: false,
            prizeAwarded: false
          };

          // Deduct stakes atomically
          const deductRes = await deductMatchStakes(initialMatch);
          if (!deductRes.success) {
            console.error('Stake deduction failed during matchmaking:', deductRes.error);
            const s1 = socketsByUser.get(p1.userId);
            const s2 = socketsByUser.get(p2.userId);
            if (s1) sendJson(s1, { type: 'queue_error', error: deductRes.error || 'Failed to deduct entry fee' });
            if (s2) sendJson(s2, { type: 'queue_error', error: deductRes.error || 'Failed to deduct entry fee' });
            return;
          }

          inMemoryMatches.set(matchId, initialMatch);

          matchRooms.set(matchId, new Set([p1.userId, p2.userId]));

          const s1 = socketsByUser.get(p1.userId);
          const s2 = socketsByUser.get(p2.userId);
          if (s1) sendJson(s1, { type: 'matched', matchId, assignedColor: p1Color, opponent: { userId: p2.userId, username: p2.username }, tableId: resolvedTableId, entryFee: resolvedEntryFee });
          if (s2) sendJson(s2, { type: 'matched', matchId, assignedColor: p2Color, opponent: { userId: p1.userId, username: p1.username }, tableId: resolvedTableId, entryFee: resolvedEntryFee });
        }
        return;
      }

      if (msg.type === 'queue_leave') {
        console.log('[Queue] Leave Request:', currentUserId);
        removeFromAllQueues(currentUserId);
        return;
      }

      if (msg.type === 'friend_invite') {
        const targetId = String(msg.targetId || '');
        const code = String(msg.code || '');
        if (!/^\d{6}$/.test(code) || !targetId || targetId === currentUserId) return;
        // The invite must carry a REAL, still-open room that this user hosts
        // (before, any 6-digit string could be pushed to a friend), and invites
        // are throttled so a friend can't be spammed.
        const invRoom = customRooms.get(code);
        if (!invRoom || invRoom.hostId !== currentUserId || invRoom.status !== 'waiting') {
          sendJson(ws, { type: 'friend_invite_ack', targetId, delivered: false, reason: 'room_not_open' });
          return;
        }
        {
          const k = `${currentUserId}>${targetId}`;
          const now = Date.now();
          const recent = (inviteThrottle.get(k) || []).filter((t) => now - t < 60_000);
          if (recent.length >= 3) {
            sendJson(ws, { type: 'friend_invite_ack', targetId, delivered: false, reason: 'rate_limited' });
            return;
          }
          recent.push(now);
          inviteThrottle.set(k, recent);
        }
        // Only accepted friends can be invited (previously any user id could
        // be spammed), and the inviter's name comes from the DB.
        let inviterName = 'Friend';
        if (pool) {
          try {
            const fr = await pool.query(
              "SELECT 1 FROM public.friendships WHERE status = 'accepted' AND ((user_id = $1 AND friend_id = $2) OR (user_id = $2 AND friend_id = $1)) LIMIT 1;",
              [currentUserId, targetId]
            );
            if (fr.rows.length === 0) return;
            const un = await pool.query('SELECT username FROM public.users WHERE id = $1 LIMIT 1;', [currentUserId]);
            if (un.rows[0]?.username) inviterName = un.rows[0].username;
          } catch { return; }
        }
        
        const targetWs = socketsByUser.get(targetId);
        if (targetWs && targetWs.connected) {
          sendJson(targetWs, {
            type: 'friend_invite_received',
            inviterId: currentUserId,
            inviterName,
            code
          });
          sendJson(ws, { type: 'friend_invite_ack', targetId, delivered: true });
        } else {
          sendJson(ws, { type: 'friend_invite_ack', targetId, delivered: false, reason: 'offline' });
        }
        return;
      }

      // In-game quick chat. Before, the chat box only drew a bubble on the SENDER's
      // own screen; the opponent never received anything. Now it is relayed by the
      // server to the other player of THIS match only (sender must be a player),
      // sanitised, length-limited and rate-limited.
      if (msg.type === 'match_chat') {
        const chatMatchId = String(msg.matchId || '');
        const chatText = String(msg.text || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, 60);
        if (!chatMatchId || !chatText) return;
        const cm = await getServerMatch(chatMatchId);
        if (!cm || (cm.whiteId !== currentUserId && cm.blackId !== currentUserId)) return;
        const ck = `${currentUserId}:${chatMatchId}`;
        const nowT = Date.now();
        const hist = (matchChatThrottle.get(ck) || []).filter((t) => nowT - t < 60_000);
        if (hist.length >= 12 || (hist.length && nowT - hist[hist.length - 1] < 1000)) return;
        hist.push(nowT);
        matchChatThrottle.set(ck, hist);
        const otherId = cm.whiteId === currentUserId ? cm.blackId : cm.whiteId;
        const otherWs = otherId ? socketsByUser.get(otherId) : null;
        if (otherWs && otherWs.connected) {
          sendJson(otherWs, { type: 'match_chat', matchId: chatMatchId, text: chatText, from: currentUserId });
        }
        return;
      }

      if (msg.type === 'join_custom_room') {
        const code = String(msg.code || '').trim();
        let room = customRooms.get(code);
        if (!room && pool) {
          try {
            const dbRes = await pool.query("SELECT * FROM public.custom_rooms WHERE code = $1 LIMIT 1;", [code]);
            if (dbRes.rows.length > 0) {
              const row = dbRes.rows[0];
              room = {
                code: row.code,
                hostId: row.host_id,
                hostUsername: 'Host',
                guestId: row.guest_id,
                guestUsername: 'Guest',
                matchId: row.match_id,
                timeMin: row.time_min || 5,
                stake: row.stake || 0,
                prize: row.prize || 0,
                status: row.status,
                createdAt: new Date(row.created_at).getTime()
              };
              customRooms.set(code, room);
            }
          } catch {}
        }
        // Only the host or the guest who actually joined via the REST API may
        // enter the room's realtime channel.
        if (room && (room.hostId === currentUserId || room.guestId === currentUserId)) {
          if (!matchRooms.has(room.matchId)) matchRooms.set(room.matchId, new Set());
          matchRooms.get(room.matchId)!.add(currentUserId);
          sendJson(ws, {
            type: 'join_custom_room_ok',
            code,
            matchId: room.matchId,
            status: room.status
          });
        }
        return;
      }

      if (msg.type === 'join_match') {
        const matchId = String(msg.matchId || '');
        if (!matchId) return;
        // Only the two players can enter a match room (before, anyone who knew
        // a match id received its live state and presence).
        const joinTarget = await getServerMatch(matchId);
        if (!joinTarget || (joinTarget.whiteId !== currentUserId && joinTarget.blackId !== currentUserId)) {
          sendJson(ws, { type: 'join_match_failed', matchId, reason: joinTarget ? 'unauthorized' : 'not_found' });
          return;
        }
        if (!matchRooms.has(matchId)) matchRooms.set(matchId, new Set());
        matchRooms.get(matchId)!.add(currentUserId);
        const restoredMatch = handleUserReconnect(matchId, currentUserId);
        sendJson(ws, {
          type: 'join_match_ok',
          matchId,
          match: restoredMatch || inMemoryMatches.get(matchId) || null
        });
        broadcastPresence(matchId, currentUserId, 'join');
        return;
      }

      if (msg.type === 'leave_match') {
        const matchId = String(msg.matchId || '');
        matchRooms.get(matchId)?.delete(currentUserId);
        broadcastPresence(matchId, currentUserId, 'leave');
        return;
      }

      if (msg.type === 'match_data') {
        // Disabling direct client-to-client match data relay to enforce server authority
        // All match updates now flow through the REST API which validates state first
        return;
      }
    });

    ws.on('disconnect', () => {
      if (!currentUserId) return;
      // Safeguard against duplicate connections:
      // If socketsByUser currently maps to a different socket, this was an old/superseded socket.
      // Do NOT tear down the user's active session or matches!
      if (socketsByUser.get(currentUserId) !== ws) {
        return;
      }
      socketsByUser.delete(currentUserId);
      removeFromAllQueues(currentUserId);

      for (const [matchId, members] of matchRooms) {
        if (members.has(currentUserId)) {
          members.delete(currentUserId);
          broadcastPresence(matchId, currentUserId, 'leave');
        }
      }

      // Check if user was in an active match and start authoritative reconnect grace period
      handleUserDisconnect(currentUserId);
    });
  });

  console.log('Realtime WebSocket server ready at /ws');
}

startServer().catch((err) => {
  console.error('[STARTUP] Server initialization failed:', err?.message || err);
  process.exit(1);
});
