import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Check, Users, Key, Play, Swords, ShieldAlert, Sparkles, Loader2, Share2 } from 'lucide-react';
import { Language } from '../types';
import { soundManager } from '../lib/soundManager';
import { createCustomRoom, joinCustomRoom, getCustomRoomStatus, cancelCustomRoom } from '../lib/customRoomService';
import { useRealtimeStore } from '../lib/realtime';

interface CustomRoomModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onMatchFound: (
    matchId: string,
    opponentProfile: any,
    assignedColor: 'w' | 'b',
    timeMin: number,
    stake?: number,
    prize?: number
  ) => void;
  initialCode?: string;
  initialMatchId?: string;
  initialIsHost?: boolean;
}

export const CustomRoomModal: React.FC<CustomRoomModalProps> = ({
  isOpen,
  onClose,
  language,
  onMatchFound,
  initialCode,
  initialMatchId,
  initialIsHost,
}) => {
  const isRtl = language === 'ku';
  const [tab, setTab] = useState<'create' | 'join'>('create');

  // Create Room State
  const [selectedTime, setSelectedTime] = useState<number>(5);
  const [isCreating, setIsCreating] = useState<boolean>(false);
  const [createdRoomCode, setCreatedRoomCode] = useState<string | null>(null);
  const [createdMatchId, setCreatedMatchId] = useState<string | null>(null);
  const [isWaitingForOpponent, setIsWaitingForOpponent] = useState<boolean>(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  // Join Room State
  const [joinCode, setJoinCode] = useState<string>('');
  const [isJoining, setIsJoining] = useState<boolean>(false);
  const [joinError, setJoinError] = useState<string | null>(null);

  // Realtime Socket
  const { socket: realtimeSocket, connectSocket } = useRealtimeStore();
  const pollIntervalRef = useRef<any>(null);
  const matchedHandledRef = useRef<boolean>(false);
  const onCloseRef = useRef(onClose);
  const onMatchFoundRef = useRef(onMatchFound);
  const languageRef = useRef(language);

  useEffect(() => {
    onCloseRef.current = onClose;
    onMatchFoundRef.current = onMatchFound;
    languageRef.current = language;
  }, [onClose, onMatchFound, language]);

  // Ensure socket is connected
  useEffect(() => {
    if (isOpen && (!realtimeSocket || !realtimeSocket.isOpen)) {
      connectSocket().catch(() => {});
    }
  }, [isOpen, realtimeSocket, connectSocket]);

  // Reset or initialize on open/close
  useEffect(() => {
    if (!isOpen) {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
      // ONLY cancel room if match was NOT handled/started
      if (createdRoomCode && isWaitingForOpponent && !matchedHandledRef.current) {
        cancelCustomRoom(createdRoomCode).catch(() => {});
      }
      setCreatedRoomCode(null);
      setCreatedMatchId(null);
      setIsWaitingForOpponent(false);
      setCreateError(null);
      setJoinError(null);
      setJoinCode('');
      setIsCreating(false);
      setIsJoining(false);
      matchedHandledRef.current = false;
    } else {
      if (initialCode && initialIsHost) {
        setCreatedRoomCode(initialCode);
        setCreatedMatchId(initialMatchId || null);
        setIsWaitingForOpponent(true);
        setTab('create');
      } else if (initialCode && !initialIsHost) {
        setJoinCode(initialCode);
        setTab('join');
      } else {
        setCreatedRoomCode(null);
        setCreatedMatchId(null);
        setIsWaitingForOpponent(false);
      }
      matchedHandledRef.current = false;
    }
  }, [isOpen, initialCode, initialMatchId, initialIsHost]);

  // Listen for socket events and polling when waiting in a room
  useEffect(() => {
    if (!isOpen || !createdRoomCode || !isWaitingForOpponent) return;

    let isMounted = true;

    const setupListeners = async () => {
      let activeSocket = realtimeSocket;
      if (!activeSocket || !activeSocket.isOpen) {
        activeSocket = await connectSocket();
      }

      if (!activeSocket || !activeSocket.isOpen) {
        alert(language === 'ku' ? 'نەتوانرا پەیوەندی بە سێرڤەرەوە بکرێت.' : 'Could not connect to server.');
        onClose();
        return;
      }
      
      if (activeSocket && activeSocket.isOpen && createdRoomCode) {
        activeSocket.joinCustomRoom(createdRoomCode);
        if (createdMatchId) {
          activeSocket.joinMatch(createdMatchId);
        }

        activeSocket.oncustomroommatched = (evt: any) => {
          if (!isMounted) return;
          if (evt.code === createdRoomCode && !matchedHandledRef.current) {
            matchedHandledRef.current = true;
            if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
            soundManager.playVictory();
            onMatchFoundRef.current(
              evt.matchId,
              evt.opponent,
              evt.assignedColor,
              evt.timeMin || selectedTime || 5,
              evt.stake,
              evt.prize
            );
            onCloseRef.current();
          }
        };
      }
    };

    setupListeners();

    // Polling fallback to guarantee detection
    pollIntervalRef.current = setInterval(async () => {
      if (matchedHandledRef.current || !createdRoomCode || !isMounted) return;
      try {
        const res = await getCustomRoomStatus(createdRoomCode);
        if (res.success && res.data?.status === 'active' && !matchedHandledRef.current && isMounted) {
          matchedHandledRef.current = true;
          if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
          soundManager.playVictory();
          onMatchFoundRef.current(
            res.data.matchId,
            res.data.opponent,
            res.data.assignedColor || 'w',
            res.data.timeMin || selectedTime || 5,
            res.data.stake,
            res.data.prize
          );
          onCloseRef.current();
        }
      } catch (err) {
        console.warn('Room status polling notice:', err);
      }
    }, 1000);

    return () => {
      isMounted = false;
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
      if (realtimeSocket) {
        realtimeSocket.oncustomroommatched = undefined;
      }
    };
  }, [isOpen, createdRoomCode, createdMatchId, isWaitingForOpponent, realtimeSocket, connectSocket, selectedTime, onMatchFound, onClose]);

  

  // Handle Create Room Button Click
  const handleCreateRoom = async () => {
    soundManager.playClick();
    setIsCreating(true);
    setCreateError(null);
    matchedHandledRef.current = false;

    const res = await createCustomRoom(selectedTime, 0);
    setIsCreating(false);

    if (!res.success || !res.room) {
      setCreateError(res.error || (isRtl ? 'دروستکردنی ژوور سەرکەوتوو نەبوو' : 'Failed to create room'));
      return;
    }

    setCreatedRoomCode(res.room.code);
    setCreatedMatchId(res.room.matchId);
    setIsWaitingForOpponent(true);

    const s = realtimeSocket || await connectSocket();
    if (s && s.isOpen) {
      s.joinCustomRoom(res.room.code);
      if (res.room.matchId) s.joinMatch(res.room.matchId);
    }
  };

  const handleCopyCode = () => {
    if (!createdRoomCode) return;
    soundManager.playClick();
    navigator.clipboard.writeText(createdRoomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareCode = () => {
    if (!createdRoomCode) return;
    soundManager.playClick();
    const shareText = isRtl
      ? `وەرە لەگەڵم شەتڕەنج بکە لە ژووری تایبەت! کۆدی ژوور: ${createdRoomCode}`
      : `Play chess with me in a private room! Room code: ${createdRoomCode}`;

    if (navigator.share) {
      navigator.share({
        title: isRtl ? 'کۆدی ژووری شەتڕەنج' : 'Chess Room Code',
        text: shareText,
      }).catch(() => {
        handleCopyCode();
      });
    } else {
      handleCopyCode();
    }
  };

  const handleCancelRoom = async () => {
    soundManager.playClick();
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    if (createdRoomCode) {
      await cancelCustomRoom(createdRoomCode).catch(() => {});
    }
    setCreatedRoomCode(null);
    setCreatedMatchId(null);
    setIsWaitingForOpponent(false);
  };

  // Handle Join Room Submit
  const handleJoinSubmit = async () => {
    soundManager.playClick();
    const clean = joinCode.trim();
    if (!/^\d{6}$/.test(clean)) {
      setJoinError(isRtl ? 'تکایە کۆدی ٦ ژمارەیی بەڕاستی بنووسە' : 'Please enter a valid 6-digit room code');
      return;
    }

    setJoinError(null);
    setIsJoining(true);

    const res = await joinCustomRoom(clean);
    setIsJoining(false);

    if (!res.success || !res.room) {
      setJoinError(res.error || (isRtl ? 'چوونە ژوورەوە سەرکەوتوو نەبوو' : 'Failed to join room'));
      return;
    }

    matchedHandledRef.current = true;
    const s = realtimeSocket || await connectSocket();
    if (s && s.isOpen && res.room.matchId) {
      s.joinMatch(res.room.matchId);
    }

    soundManager.playVictory();
    onMatchFoundRef.current(
      res.room.matchId,
      res.room.opponent,
      res.room.assignedColor || 'b',
      res.room.timeMin || 5,
      res.room.stake,
      res.room.prize
    );
    onCloseRef.current();
  };

  // Auto-join if initial code was provided for a guest
  useEffect(() => {
    if (isOpen && initialCode && !initialIsHost && joinCode === initialCode && !isJoining && !matchedHandledRef.current) {
      handleJoinSubmit();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, initialCode, initialIsHost, joinCode]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md font-sans">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 15 }}
          className={`relative w-full max-w-md bg-gradient-to-b from-[#2e170b] via-[#1c0d06] to-[#0f0703] border-2 border-amber-500/80 rounded-3xl p-5 shadow-[0_0_50px_rgba(245,158,11,0.3)] text-amber-100 flex flex-col overflow-hidden ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-amber-800/60 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-b from-amber-400 via-yellow-500 to-amber-700 p-0.5 shadow-md flex items-center justify-center shrink-0">
                <Users className="w-6 h-6 text-amber-950" />
              </div>
              <div>
                <h2 className="text-xl font-black text-amber-100 tracking-wide">
                  {isRtl ? 'ژووری تایبەت' : 'Private Custom Room'}
                </h2>
                <p className="text-xs text-amber-300/70 font-medium">
                  {isRtl ? 'یاری کردن لەگەڵ هاوڕێیان بە کۆد' : 'Play online matches with friends'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                soundManager.playClick();
                onCloseRef.current();
              }}
              className="w-9 h-9 rounded-2xl bg-gradient-to-b from-amber-800 to-amber-950 border border-amber-500/80 text-amber-200 flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-md cursor-pointer"
            >
              <X className="w-5 h-5 text-amber-300" />
            </button>
          </div>

          {/* Mode Tabs */}
          {!isWaitingForOpponent && (
            <div className="grid grid-cols-2 gap-2 bg-[#120804] p-1.5 rounded-2xl border border-amber-900/60 mb-5">
              <button
                onClick={() => {
                  soundManager.playClick();
                  setTab('create');
                }}
                className={`py-2.5 rounded-xl font-black text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
                  tab === 'create'
                    ? 'bg-gradient-to-r from-yellow-500 to-amber-600 text-amber-950 shadow-md border border-yellow-300'
                    : 'text-amber-200/60 hover:text-amber-100'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>{isRtl ? 'دروستکردنی ژوور' : 'Create Room'}</span>
              </button>

              <button
                onClick={() => {
                  soundManager.playClick();
                  setTab('join');
                }}
                className={`py-2.5 rounded-xl font-black text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
                  tab === 'join'
                    ? 'bg-gradient-to-r from-yellow-500 to-amber-600 text-amber-950 shadow-md border border-yellow-300'
                    : 'text-amber-200/60 hover:text-amber-100'
                }`}
              >
                <Key className="w-4 h-4" />
                <span>{isRtl ? 'چوونە ژوورەوە' : 'Join Room'}</span>
              </button>
            </div>
          )}

          {/* Tab Content */}
          {tab === 'create' ? (
            <div className="flex flex-col gap-4">
              {!isWaitingForOpponent ? (
                <>
                  {/* Time Format Selector */}
                  <div>
                    <label className="text-xs font-black text-amber-200 block mb-2">
                      {isRtl ? 'کاتی یاری' : 'Match Time'}
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { min: 3, labelKu: '٣ خولەک', labelEn: '3 Min' },
                        { min: 5, labelKu: '٥ خولەک', labelEn: '5 Min' },
                        { min: 10, labelKu: '١٠ خولەک', labelEn: '10 Min' },
                      ].map((item) => (
                        <button
                          key={item.min}
                          onClick={() => {
                            soundManager.playClick();
                            setSelectedTime(item.min);
                          }}
                          className={`py-2.5 rounded-xl font-extrabold text-xs border transition cursor-pointer ${
                            selectedTime === item.min
                              ? 'bg-amber-500 text-amber-950 border-yellow-200 shadow-md font-black'
                              : 'bg-[#180b05] text-amber-200/70 border-amber-900/60 hover:border-amber-700'
                          }`}
                        >
                          {isRtl ? item.labelKu : item.labelEn}
                        </button>
                      ))}
                    </div>
                  </div>

                  {createError && (
                    <div className="p-3 rounded-xl bg-red-950/70 border border-red-500/70 text-red-300 text-xs font-bold flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
                      <span>{createError}</span>
                    </div>
                  )}

                  {/* Create Room Button */}
                  <button
                    onClick={handleCreateRoom}
                    disabled={isCreating}
                    className="w-full mt-2 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:brightness-110 text-emerald-950 font-black text-base border border-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.4)] transition cursor-pointer flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                  >
                    {isCreating ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>{isRtl ? 'دروست دەکرێت...' : 'Generating Code...'}</span>
                      </>
                    ) : (
                      <>
                        <Swords className="w-5 h-5 fill-emerald-950" />
                        <span>{isRtl ? 'دروستکردنی کۆدی ژوور' : 'Create Private Room'}</span>
                      </>
                    )}
                  </button>
                </>
              ) : (
                /* Waiting for Opponent Screen */
                <div className="flex flex-col gap-4">
                  <div className="bg-gradient-to-r from-[#221006] via-[#3a1d0a] to-[#221006] border-2 border-amber-500/80 rounded-2xl p-5 flex flex-col items-center gap-3 text-center shadow-inner">
                    <span className="text-xs font-black text-amber-300/90 uppercase tracking-widest">
                      {isRtl ? 'کۆدی ژووری تایبەت' : 'ROOM CODE'}
                    </span>
                    <div className="font-mono text-4xl sm:text-5xl font-black text-yellow-300 tracking-[0.3em] drop-shadow-md select-all py-1">
                      {createdRoomCode}
                    </div>

                    <div className="flex items-center gap-2 mt-1 w-full max-w-xs">
                      <button
                        onClick={handleCopyCode}
                        className="flex-1 py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                      >
                        {copied ? (
                          <>
                            <Check className="w-4 h-4 text-emerald-400" />
                            <span className="text-emerald-400">{isRtl ? 'کۆپی کرا!' : 'Copied!'}</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            <span>{isRtl ? 'کۆپیکردن' : 'Copy Code'}</span>
                          </>
                        )}
                      </button>

                      <button
                        onClick={handleShareCode}
                        className="py-2 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                        <span>{isRtl ? 'ناردن' : 'Share'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Pulsing Waiting Indicator */}
                  <div className="p-4 rounded-2xl bg-[#140803] border border-amber-900/60 flex flex-col items-center gap-2 text-center">
                    <div className="relative flex items-center justify-center w-12 h-12">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-30"></span>
                      <Loader2 className="w-6 h-6 animate-spin text-yellow-400 relative" />
                    </div>
                    <p className="text-sm font-black text-amber-100">
                      {isRtl ? 'چاوەڕوانی هاتنی بەرامبەر...' : 'Waiting for opponent to join...'}
                    </p>
                    <p className="text-xs text-amber-400/70 max-w-xs">
                      {isRtl
                        ? 'ئەم کۆدە ٦ ژمارەییە بدە بە هاوڕێکەت بۆ ئەوەی بە ئۆنلاین پەیوەست بێت.'
                        : 'Give this 6-digit code to your friend so they can join this match on their device.'}
                    </p>
                  </div>

                  {/* Cancel Room Button */}
                  <button
                    onClick={handleCancelRoom}
                    className="w-full py-2.5 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 border border-amber-800 text-amber-300/80 hover:text-amber-200 text-xs font-bold transition cursor-pointer"
                  >
                    {isRtl ? 'هەڵوەشاندنەوەی ژوور' : 'Cancel Room'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Join Room Tab */
            <div className="flex flex-col gap-4">
              <div>
                <label className="text-xs font-black text-amber-200 block mb-2">
                  {isRtl ? 'کۆدی ژوور بنووسە' : 'Enter 6-Digit Room Code'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    maxLength={6}
                    value={joinCode}
                    onChange={(e) => {
                      setJoinCode(e.target.value.replace(/\D/g, ''));
                      setJoinError(null);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && joinCode.length === 6 && !isJoining) {
                        handleJoinSubmit();
                      }
                    }}
                    placeholder="123456"
                    className="w-full bg-[#120804] border-2 border-amber-600/80 focus:border-yellow-400 rounded-2xl py-3.5 px-4 font-mono font-black text-center text-3xl text-yellow-300 placeholder-amber-800/40 outline-none transition tracking-[0.25em]"
                    autoFocus
                  />
                </div>
                {joinError && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 rounded-xl bg-red-950/70 border border-red-500/70 text-red-300 text-xs font-bold mt-2 flex items-center gap-2"
                  >
                    <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{joinError}</span>
                  </motion.div>
                )}
              </div>

              {/* Submit Join */}
              <button
                onClick={handleJoinSubmit}
                disabled={joinCode.length !== 6 || isJoining}
                className={`w-full mt-2 py-3.5 rounded-2xl font-black text-base border transition flex items-center justify-center gap-2 active:scale-95 ${
                  joinCode.length === 6 && !isJoining
                    ? 'bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600 text-amber-950 border-yellow-200 shadow-[0_0_20px_rgba(234,179,8,0.5)] cursor-pointer'
                    : 'bg-[#180c05] text-amber-700/50 border-amber-900/40 opacity-60 cursor-not-allowed'
                }`}
              >
                {isJoining ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin text-amber-950" />
                    <span>{isRtl ? 'پەیوەندی دەبەسترێت...' : 'Joining Room...'}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-amber-950" />
                    <span>{isRtl ? 'چوونە ژوورەوە' : 'Join Room'}</span>
                  </>
                )}
              </button>
            </div>
          )}
        </motion.div>
      </div>
          )}
    </AnimatePresence>
  );
};
