import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Coins, Zap, Trophy, X, Shield, Crown } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../lib/soundManager';

export type ChestType = 'red' | 'gold' | 'purple';

interface ChestGraphicProps {
  type: ChestType;
  size?: number; // e.g. 64, 80, 120
  isOpen?: boolean;
  className?: string;
  onClick?: () => void;
}

// 1. RED CHEST (سندوقی سوور - Rare Ruby Chest)
export const RedChestGraphic: React.FC<ChestGraphicProps> = ({
  size = 80,
  isOpen = false,
  className = '',
  onClick,
}) => (
  <div
    onClick={onClick}
    style={{ width: size, height: size }}
    className={`relative flex items-center justify-center cursor-pointer group shrink-0 select-none ${className}`}
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_8px_16px_rgba(225,29,72,0.6)]">
      <defs>
        <radialGradient id="redChestBg" cx="40%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#fda4af" />
          <stop offset="30%" stopColor="#e11d48" />
          <stop offset="70%" stopColor="#be123c" />
          <stop offset="100%" stopColor="#4c0519" />
        </radialGradient>
        <linearGradient id="redGoldTrim" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="40%" stopColor="#f59e0b" />
          <stop offset="80%" stopColor="#b45309" />
          <stop offset="100%" stopColor="#451a03" />
        </linearGradient>
      </defs>

      {/* Red Glowing Background Pulse */}
      <circle cx="50" cy="50" r="45" fill="#f43f5e" opacity="0.15" className="animate-pulse" />

      {/* Chest Base Box */}
      <rect x="18" y="44" width="64" height="38" rx="6" fill="url(#redChestBg)" stroke="url(#redGoldTrim)" strokeWidth="3" />

      {/* Vertical & Horizontal Gold Bands */}
      <rect x="30" y="44" width="8" height="38" fill="url(#redGoldTrim)" />
      <rect x="62" y="44" width="8" height="38" fill="url(#redGoldTrim)" />
      <rect x="18" y="60" width="64" height="6" fill="url(#redGoldTrim)" opacity="0.9" />

      {/* Animated Chest Lid */}
      <g
        className={`transition-transform duration-500 origin-bottom ${
          isOpen ? '-translate-y-6 rotate-[-25deg]' : ''
        }`}
      >
        <path
          d="M 16 44 C 16 26 84 26 84 44 Z"
          fill="url(#redChestBg)"
          stroke="url(#redGoldTrim)"
          strokeWidth="3.5"
        />
        <rect x="30" y="28" width="8" height="16" fill="url(#redGoldTrim)" />
        <rect x="62" y="28" width="8" height="16" fill="url(#redGoldTrim)" />
      </g>

      {/* Gold Brass Lock Plate with Chess Knight Symbol */}
      <rect x="42" y="42" width="16" height="18" rx="3" fill="url(#redGoldTrim)" stroke="#fef08a" strokeWidth="1.5" />
      <circle cx="50" cy="49" r="3.5" fill="#1c050b" />
      <path d="M 50 51 L 50 56" stroke="#1c050b" strokeWidth="2" strokeLinecap="round" />

      {/* Top Sparkle */}
      <polygon points="50,14 52,20 58,20 53,23 55,29 50,25 45,29 47,23 42,20 48,20" fill="#ffffff" className="animate-pulse" />
    </svg>
  </div>
);

// 2. GOLD CHEST (سندوقی زەرد - Epic Golden Chest)
export const GoldChestGraphic: React.FC<ChestGraphicProps> = ({
  size = 80,
  isOpen = false,
  className = '',
  onClick,
}) => (
  <div
    onClick={onClick}
    style={{ width: size, height: size }}
    className={`relative flex items-center justify-center cursor-pointer group shrink-0 select-none ${className}`}
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_8px_18px_rgba(245,158,11,0.8)]">
      <defs>
        <radialGradient id="goldChestBg" cx="40%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#fff7ed" />
          <stop offset="30%" stopColor="#fde047" />
          <stop offset="65%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#78350f" />
        </radialGradient>
        <linearGradient id="goldMetalTrim" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#fef08a" />
          <stop offset="70%" stopColor="#d97706" />
          <stop offset="100%" stopColor="#451a03" />
        </linearGradient>
      </defs>

      {/* Gold Aura Pulse */}
      <circle cx="50" cy="50" r="46" fill="#fbbf24" opacity="0.25" className="animate-pulse" />

      {/* Chest Base Box */}
      <rect x="18" y="44" width="64" height="38" rx="6" fill="url(#goldChestBg)" stroke="url(#goldMetalTrim)" strokeWidth="3.5" />

      {/* Vertical Gold Straps */}
      <rect x="28" y="44" width="10" height="38" fill="url(#goldMetalTrim)" />
      <rect x="62" y="44" width="10" height="38" fill="url(#goldMetalTrim)" />
      <rect x="18" y="58" width="64" height="7" fill="url(#goldMetalTrim)" />

      {/* Animated Chest Lid */}
      <g
        className={`transition-transform duration-500 origin-bottom ${
          isOpen ? '-translate-y-6 rotate-[-25deg]' : ''
        }`}
      >
        <path
          d="M 15 44 C 15 24 85 24 85 44 Z"
          fill="url(#goldChestBg)"
          stroke="url(#goldMetalTrim)"
          strokeWidth="4"
        />
        <rect x="28" y="26" width="10" height="18" fill="url(#goldMetalTrim)" />
        <rect x="62" y="26" width="10" height="18" fill="url(#goldMetalTrim)" />

        {/* Crown Icon on Lid */}
        <path d="M 42 34 L 45 28 L 50 32 L 55 28 L 58 34 Z" fill="#78350f" />
      </g>

      {/* Lock Plate with Glowing Crown Gem */}
      <rect x="41" y="41" width="18" height="20" rx="4" fill="url(#goldMetalTrim)" stroke="#ffffff" strokeWidth="1.5" />
      <circle cx="50" cy="51" r="4" fill="#3b82f6" className="animate-ping" />
      <circle cx="50" cy="51" r="4" fill="#60a5fa" />

      {/* Starburst Rays */}
      <polygon points="50,10 53,18 60,18 54,22 56,29 50,24 44,29 46,22 40,18 47,18" fill="#fef08a" />
    </svg>
  </div>
);

// 3. PURPLE CHEST (سندوقی بنەوشەیی / شاهانە - Master Purple Chest)
export const PurpleChestGraphic: React.FC<ChestGraphicProps> = ({
  size = 80,
  isOpen = false,
  className = '',
  onClick,
}) => (
  <div
    onClick={onClick}
    style={{ width: size, height: size }}
    className={`relative flex items-center justify-center cursor-pointer group shrink-0 select-none ${className}`}
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_8px_22px_rgba(168,85,247,0.85)]">
      <defs>
        <radialGradient id="purpleChestBg" cx="40%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#f5d0fe" />
          <stop offset="30%" stopColor="#c084fc" />
          <stop offset="65%" stopColor="#7e22ce" />
          <stop offset="100%" stopColor="#3b0764" />
        </radialGradient>
        <linearGradient id="purplePlatinumTrim" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#fef08a" />
          <stop offset="70%" stopColor="#a855f7" />
          <stop offset="100%" stopColor="#2e1065" />
        </linearGradient>
      </defs>

      {/* Purple Aura Pulse */}
      <circle cx="50" cy="50" r="46" fill="#a855f7" opacity="0.3" className="animate-pulse" />

      {/* Chest Base Box */}
      <rect x="18" y="44" width="64" height="38" rx="6" fill="url(#purpleChestBg)" stroke="url(#purplePlatinumTrim)" strokeWidth="3.5" />

      {/* Platinum Vertical Bands */}
      <rect x="28" y="44" width="10" height="38" fill="url(#purplePlatinumTrim)" />
      <rect x="62" y="44" width="10" height="38" fill="url(#purplePlatinumTrim)" />
      <rect x="18" y="58" width="64" height="7" fill="url(#purplePlatinumTrim)" />

      {/* Animated Chest Lid */}
      <g
        className={`transition-transform duration-500 origin-bottom ${
          isOpen ? '-translate-y-6 rotate-[-25deg]' : ''
        }`}
      >
        <path
          d="M 15 44 C 15 22 85 22 85 44 Z"
          fill="url(#purpleChestBg)"
          stroke="url(#purplePlatinumTrim)"
          strokeWidth="4"
        />
        <rect x="28" y="24" width="10" height="20" fill="url(#purplePlatinumTrim)" />
        <rect x="62" y="24" width="10" height="20" fill="url(#purplePlatinumTrim)" />
      </g>

      {/* Diamond Center Emblem */}
      <polygon points="50,42 60,51 50,60 40,51" fill="#fef08a" stroke="#ffffff" strokeWidth="1.5" />
      <circle cx="50" cy="51" r="3" fill="#a855f7" className="animate-ping" />

      {/* Floating Magic Stars */}
      <polygon points="50,8 53,16 61,16 55,21 57,28 50,23 43,28 45,21 39,16 47,16" fill="#ffffff" />
    </svg>
  </div>
);

// 4. ANIMATED REALISTIC 3D CHEST OPENING OVERLAY MODAL
interface ChestOpeningModalProps {
  isOpen: boolean;
  chestType: ChestType;
  title: string;
  coins: number;
  gems?: number;
  unlockedSkinName?: string;
  onClose: () => void;
}

export const ChestOpeningModal: React.FC<ChestOpeningModalProps> = ({
  isOpen,
  chestType,
  title,
  coins,
  gems = 10,
  unlockedSkinName,
  onClose,
}) => {
  const [animState, setAnimState] = React.useState<'idle' | 'opening' | 'opened'>('idle');

  React.useEffect(() => {
    if (isOpen) {
      setAnimState('idle');
      soundManager.playClick();

      // Trigger shake and opening after 400ms
      const timer1 = setTimeout(() => {
        setAnimState('opening');
        soundManager.playVictory();
      }, 500);

      const timer2 = setTimeout(() => {
        setAnimState('opened');
        confetti({
          particleCount: 120,
          spread: 90,
          origin: { y: 0.5 },
        });
      }, 1200);

      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[120] bg-black/90 backdrop-blur-lg flex items-center justify-center p-4 text-center select-none font-sans overflow-hidden"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.8, y: 30 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.8, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="relative w-full max-w-sm rounded-[36px] border-2 border-yellow-400 bg-gradient-to-b from-[#3a1504] via-[#240c02] to-[#120401] p-6 shadow-[0_0_80px_rgba(245,158,11,0.7)] flex flex-col items-center text-center overflow-hidden"
        >
          {/* Top Close Button */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-red-600 border border-white text-white flex items-center justify-center hover:scale-105 transition cursor-pointer z-30 shadow"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>

          {/* Background Radial Light Rays Effect */}
          <div className="absolute -top-16 inset-x-0 h-48 bg-gradient-to-b from-yellow-500/40 via-amber-500/10 to-transparent rounded-full blur-3xl pointer-events-none animate-pulse" />

          {/* ANIMATED CHEST CONTAINER */}
          <div className="relative my-4 flex items-center justify-center">
            {/* Glowing Backdrop Circle */}
            <div
              className={`absolute w-36 h-36 rounded-full blur-2xl transition-opacity duration-700 ${
                chestType === 'red'
                  ? 'bg-red-500/50'
                  : chestType === 'purple'
                  ? 'bg-purple-500/60'
                  : 'bg-yellow-400/60'
              }`}
            />

            <motion.div
              animate={
                animState === 'opening'
                  ? {
                      rotate: [-12, 12, -12, 12, 0],
                      scale: [1, 1.25, 1.1],
                      y: [-5, -15, 0],
                    }
                  : animState === 'opened'
                  ? { scale: [1.1, 1.05], y: 0 }
                  : { y: [-4, 4, -4] }
              }
              transition={{ duration: 0.6, repeat: animState === 'idle' ? Infinity : 0 }}
            >
              {chestType === 'red' && <RedChestGraphic size={120} isOpen={animState === 'opened'} />}
              {chestType === 'gold' && <GoldChestGraphic size={120} isOpen={animState === 'opened'} />}
              {chestType === 'purple' && <PurpleChestGraphic size={120} isOpen={animState === 'opened'} />}
            </motion.div>
          </div>

          {/* REWARD TITLE */}
          <h3 className="text-xl sm:text-2xl font-black text-yellow-300 drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)] tracking-wide">
            {title}
          </h3>

          {/* FLOATING REWARD ITEMS WHEN OPENED */}
          {animState === 'opened' && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="w-full my-4 space-y-2"
            >
              {/* Coins & Gems Bar */}
              <div className="w-full bg-gradient-to-r from-amber-950/90 via-amber-900/90 to-amber-950/90 border-2 border-yellow-400/80 rounded-2xl py-2.5 px-4 shadow-[0_0_20px_rgba(245,158,11,0.5)] flex items-center justify-center gap-4">
                <div className="flex items-center gap-1.5 font-mono font-black text-yellow-300 text-xl sm:text-2xl">
                  <Coins className="w-6 h-6 text-yellow-400" />
                  <span>+{coins} $</span>
                </div>

                {gems > 0 && (
                  <div className="flex items-center gap-1.5 font-mono font-black text-cyan-300 text-xl sm:text-2xl">
                    <span className="text-xl">💎</span>
                    <span>+{gems}</span>
                  </div>
                )}
              </div>

              {/* Unlocked Chess Skin Card if any */}
              {unlockedSkinName && (
                <div className="bg-gradient-to-r from-purple-900/90 to-indigo-900/90 border-2 border-purple-400 rounded-2xl p-2.5 text-center shadow-lg">
                  <span className="text-[10px] font-black text-purple-300 uppercase tracking-widest block">
                    NEW SKIN UNLOCKED!
                  </span>
                  <span className="text-sm font-black text-white flex items-center justify-center gap-1.5 mt-0.5">
                    <span>👑</span>
                    <span>{unlockedSkinName}</span>
                  </span>
                </div>
              )}
            </motion.div>
          )}

          {/* CLAIM BUTTON */}
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="w-full mt-2 py-3.5 rounded-2xl bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 border-b-4 border-amber-800 text-amber-950 font-black text-base tracking-wider shadow-[0_8px_25px_rgba(245,158,11,0.6)] hover:brightness-110 active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5 text-amber-950 fill-current" />
            <span>وەربگرە (Claim)</span>
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
