import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  UserPlus,
  Users,
  Check,
  Swords,
  Search,
  CheckCircle2,
  Clock,
  Zap,
  Sparkles,
  Ban,
  ShieldAlert,
  Copy,
  Trophy,
  Loader2,
} from 'lucide-react';
import { Language, UserProfile, Friend } from '../types';
import { LevelCrown } from './LevelCrown';
import { soundManager } from '../lib/soundManager';
import { useRealtimeStore } from '../lib/realtime';
import { buildApiUrl } from '../lib/api';
import { createCustomRoom } from '../lib/customRoomService';

interface FriendsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile: UserProfile;
  onUpdateProfile: (updated: UserProfile) => void;
  onChallengeFriend?: (friend: Friend, code?: string) => void;
}

export const FriendsModal: React.FC<FriendsModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
  onUpdateProfile,
  onChallengeFriend,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'online' | 'add' | 'requests' | 'blocked'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [addInput, setAddInput] = useState<string>('');
  const [copiedMyId, setCopiedMyId] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [friendsList, setFriendsList] = useState<Friend[]>([]);
  const [incomingRequests, setIncomingRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);

  const { session } = useRealtimeStore();
  const isRtl = language === 'ku';

  useEffect(() => {
    if (isOpen && session?.user_id) {
      fetchFriends();
      fetchRequests();
    }
  }, [isOpen, session]);

  const getHeaders = () => {
    const cleanToken = (session?.token || '').trim().replace(/[\r\n]/g, '');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;
    return headers;
  };

  const fetchFriends = async () => {
    if (!session?.user_id) return;
    setLoading(true);
    try {
      const cleanUserId = encodeURIComponent(session.user_id);
      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/friends`), { headers: getHeaders() });
      if (res.ok) {
        const data = await res.json();
        setFriendsList(data.friends || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const fetchRequests = async () => {
    if (!session?.user_id) return;
    try {
      const cleanUserId = encodeURIComponent(session.user_id);
      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/friend-requests`), { headers: getHeaders() });
      if (res.ok) {
        const data = await res.json();
        setIncomingRequests(data.incomingRequests || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const handleCopyMyId = () => {
    soundManager.playClick();
    navigator.clipboard.writeText(userProfile.id || '');
    setCopiedMyId(true);
    showToast(isRtl ? 'ئایدیەکەت کۆپی کرا! 📋' : 'Player ID copied! 📋');
    setTimeout(() => setCopiedMyId(false), 2000);
  };

  const handleSearchUsers = async () => {
    if (!addInput.trim()) return;
    soundManager.playClick();
    setSearchLoading(true);
    try {
      const res = await fetch(buildApiUrl(`/api/users/search?q=${encodeURIComponent(addInput)}`));
      if (res.ok) {
        const data = await res.json();
        setSearchResults(data.users || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleSendAddRequest = async (e?: React.FormEvent, targetId?: string, targetUsername?: string) => {
    if (e) e.preventDefault();
    const tId = targetId || addInput;
    const tName = targetUsername || addInput;
    if (!tId.trim()) return;
    
    soundManager.playClick();
    try {
      const cleanUserId = encodeURIComponent(session!.user_id);
      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/friends/request`), {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ targetUserId: tId, targetUsername: tName })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast(
          isRtl
            ? `داواکاری هاوڕێیەتی سەرکەوتووانە نێردرا! 📩`
            : `Friend request sent! 📩`
        );
        setAddInput('');
        setSearchResults([]);
      } else {
        showToast(data.error || 'Failed to send request');
      }
    } catch (e: any) {
      showToast(e.message || 'Error sending request');
    }
  };

  const handleAcceptRequest = async (req: any) => {
    soundManager.playClick();
    try {
      const cleanUserId = encodeURIComponent(session!.user_id);
      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/friends/accept`), {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ friendId: req.id })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast(
          isRtl
            ? `داواکارییەکە قبولکرا! (${req.name}) زیادرایە هاوڕێیان ✅`
            : `${req.name} accepted as friend! ✅`
        );
        fetchFriends();
        fetchRequests();
      } else {
        showToast(data.error || 'Error accepting request');
      }
    } catch (e: any) {
      showToast(e.message || 'Error');
    }
  };

  const handleDeclineRequest = async (req: any) => {
    soundManager.playClick();
    try {
      const cleanUserId = encodeURIComponent(session!.user_id);
      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/friends/reject`), {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ friendId: req.id, requestId: req.request_id })
      });
      if (res.ok) {
        fetchRequests();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleRemoveFriend = async (friendId: string) => {
    if (!confirm(isRtl ? 'ئایا دڵنیایت لە سڕینەوەی ئەم هاوڕێیە؟' : 'Are you sure you want to remove this friend?')) return;
    soundManager.playClick();
    try {
      const cleanUserId = encodeURIComponent(session!.user_id);
      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/friends/remove`), {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ friendId })
      });
      if (res.ok) {
        showToast(isRtl ? 'هاوڕێیەکە سڕایەوە' : 'Friend removed');
        fetchFriends();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDirectInvite = async (friend: Friend) => {
    soundManager.playClick();
    showToast(isRtl ? `چاوەڕوان بە، ئینڤایت دروست دەکرێت...` : `Creating match invite...`);
    
    // Create a custom room
    const res = await createCustomRoom(5, 0); // 5 min, 0 stake
    if (res.success && res.room) {
      const s = useRealtimeStore.getState().socket;
      const myUsername = session?.username || 'Friend';
      
      if (s) {
        // The server now acknowledges whether the invite was really delivered.
        (s as any).onfriendinviteack = (ack: any) => {
          (s as any).onfriendinviteack = undefined;
          if (ack && ack.delivered === false) {
            showToast(
              ack.reason === 'rate_limited'
                ? (isRtl ? 'زۆر ئینڤایتت ناردووە، کەمێک چاوەڕێ بە' : 'Too many invites, please wait')
                : (isRtl ? `${friend.name} ئۆنلاین نییە، ئینڤایت نەگەیشت` : `${friend.name} is offline, invite not delivered`)
            );
          }
        };
        s.sendFriendInvite(friend.id, res.room.code, myUsername);
      }

      soundManager.playVictory();
      showToast(
        isRtl
          ? `ئینڤایت نێردرا بۆ (${friend.name})! ♟️`
          : `Match invitation sent to ${friend.name}! ♟️`
      );
      setTimeout(() => {
        onClose();
        if (onChallengeFriend) onChallengeFriend(friend, res.room!.code);
      }, 1500);
    } else {
      showToast(res.error || 'Failed to create room for invite');
    }
  };

  if (!isOpen) return null;

  const filteredFriends = friendsList.filter((f) => {
    if (activeTab === 'online' && !f.isOnline) return false;
    if (searchQuery) return f.name.toLowerCase().includes(searchQuery.toLowerCase());
    return true;
  });

  return (
    <AnimatePresence>
      <div className={`fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md ${isRtl ? 'rtl' : 'ltr'}`}>
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-4xl max-h-[90vh] bg-gradient-to-b from-[#2a1309] to-[#1a0b05] rounded-3xl sm:rounded-[2.5rem] border-2 border-yellow-500/30 shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col md:flex-row"
        >
          {/* TOAST NOTIFICATION */}
          <AnimatePresence>
            {toastMessage && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="absolute top-4 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white px-4 py-2 rounded-full font-bold text-xs shadow-lg flex items-center gap-2 whitespace-nowrap"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{toastMessage}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* LEFT SIDEBAR (Tabs & Header) */}
          <div className="w-full md:w-72 bg-black/40 p-4 sm:p-6 flex flex-col border-b md:border-b-0 md:border-r border-yellow-500/20 md:border-r-yellow-500/20 shrink-0">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-amber-500 flex items-center gap-2">
                <Users className="w-6 h-6 text-yellow-400" />
                {isRtl ? 'لیستی هاوڕێیان' : 'Friends List'}
              </h2>
              <button
                onClick={() => {
                  soundManager.playClick();
                  onClose();
                }}
                className="md:hidden p-2 rounded-full bg-red-900/40 text-red-400 hover:bg-red-500 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* My ID Card */}
            <div className="mb-6 p-4 rounded-2xl bg-gradient-to-br from-amber-900/40 to-[#1a0b05] border border-amber-600/40 relative overflow-hidden group">
              <div className="absolute inset-0 bg-amber-500/5 group-hover:bg-amber-500/10 transition" />
              <div className="relative z-10 flex items-center gap-3 mb-2">
                <img
                  src={userProfile.avatar}
                  className="w-10 h-10 rounded-full border-2 border-amber-500 object-cover"
                  alt="My Avatar"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0 flex-1 text-left rtl:text-right">
                  <div className="text-[10px] text-amber-200/60 uppercase font-black tracking-wider">
                    {isRtl ? 'ئایدی یاریزان (ID)' : 'Player ID'}
                  </div>
                  <div className="text-sm font-black text-amber-100 truncate">{userProfile.id}</div>
                </div>
              </div>
              <button
                onClick={handleCopyMyId}
                className={`w-full py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-2 ${
                  copiedMyId
                    ? 'bg-emerald-600 text-white border border-emerald-400 shadow-[0_0_15px_#10b981]'
                    : 'bg-[#2a1309] text-amber-400 border border-amber-600/50 hover:bg-amber-900/60 hover:text-amber-300'
                }`}
              >
                {copiedMyId ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedMyId ? (isRtl ? 'کۆپی کرا!' : 'Copied!') : (isRtl ? 'کۆپیکردنی ئایدی' : 'Copy ID')}</span>
              </button>
            </div>

            {/* Navigation Tabs */}
            <nav className="flex flex-row overflow-x-auto md:flex-col gap-2 pb-2 md:pb-0 custom-scrollbar">
              {[
                { id: 'all', labelEn: 'All Friends', labelKu: 'هەموو هاوڕێیان', icon: <Users className="w-4 h-4" />, count: friendsList.length },
                { id: 'online', labelEn: 'Online Now', labelKu: 'ئۆنلاینەکان', icon: <Zap className="w-4 h-4" />, count: friendsList.filter(f => f.isOnline).length },
                { id: 'add', labelEn: 'Add Friend', labelKu: 'زیادکردنی هاوڕێ', icon: <UserPlus className="w-4 h-4" /> },
                { id: 'requests', labelEn: 'Requests', labelKu: 'داواکارییەکان', icon: <Clock className="w-4 h-4" />, count: incomingRequests.length, highlight: incomingRequests.length > 0 },
                { id: 'blocked', labelEn: 'Blocked', labelKu: 'بلۆککراوەکان', icon: <Ban className="w-4 h-4" /> },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    soundManager.playClick();
                    setActiveTab(tab.id as any);
                  }}
                  className={`flex items-center justify-between p-3 rounded-xl transition text-sm font-bold shrink-0 md:shrink-auto min-w-[140px] md:min-w-0 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-amber-600 to-yellow-600 text-white shadow-md'
                      : 'bg-black/20 text-amber-200/70 hover:bg-amber-900/40 hover:text-amber-100'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {tab.icon}
                    <span>{isRtl ? tab.labelKu : tab.labelEn}</span>
                  </div>
                  {tab.count !== undefined && (
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-black ${
                        tab.highlight
                          ? 'bg-red-500 text-white animate-pulse'
                          : activeTab === tab.id
                          ? 'bg-black/30 text-white'
                          : 'bg-black/40 text-amber-400'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* RIGHT CONTENT AREA */}
          <div className="flex-1 p-4 sm:p-6 bg-[#1a0b05] flex flex-col min-h-[500px]">
            {/* Header & Close for Desktop */}
            <div className="hidden md:flex justify-end mb-4">
              <button
                onClick={() => {
                  soundManager.playClick();
                  onClose();
                }}
                className="p-2 rounded-full bg-red-900/20 text-red-400 hover:bg-red-500 hover:text-white transition border border-red-900/30"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* TAB 1 & 2: ALL FRIENDS / ONLINE FRIENDS */}
            {(activeTab === 'all' || activeTab === 'online') && (
              <div className="w-full h-full flex flex-col">
                {/* Search Bar */}
                <div className="relative mb-4 shrink-0">
                  <div className="absolute inset-y-0 left-3 rtl:left-auto rtl:right-3 flex items-center pointer-events-none">
                    <Search className="w-5 h-5 text-amber-500/50" />
                  </div>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={isRtl ? 'گەڕان بۆ هاوڕێ...' : 'Search friends...'}
                    className="w-full bg-black/40 border border-amber-900/50 rounded-xl py-3 pl-10 pr-4 rtl:pl-4 rtl:pr-10 text-sm font-bold text-amber-100 placeholder-amber-500/30 focus:border-amber-500 focus:outline-none"
                  />
                </div>

                {/* Friends List Container */}
                {loading ? (
                   <div className="flex-1 flex justify-center items-center"><Loader2 className="w-8 h-8 animate-spin text-amber-500" /></div>
                ) : filteredFriends.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-amber-300/60 font-bold gap-3">
                    <Users className="w-12 h-12 text-amber-900/50" />
                    <span>{isRtl ? 'هیچ هاوڕێیەک نەدۆزرایەوە!' : 'No friends found!'}</span>
                  </div>
                ) : (
                  <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-2 pb-16 md:pb-0">
                    {filteredFriends.map((friend) => (
                      <div
                        key={friend.id}
                        className="group flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-[#2a1309] to-[#1a0b05] border border-amber-900/40 hover:border-amber-500/50 transition cursor-default shadow"
                      >
                        <div className="flex items-center gap-3 overflow-hidden">
                          <div className="relative shrink-0">
                            <img
                              src={friend.avatar}
                              className="w-10 h-10 sm:w-11 sm:h-11 rounded-full border-2 border-yellow-400/90 object-cover shadow group-hover:scale-105 transition"
                              alt={friend.name}
                              referrerPolicy="no-referrer"
                            />
                            {/* Online / Offline Dot */}
                            <span
                              className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-black ${
                                friend.isOnline
                                  ? 'bg-emerald-400 shadow-[0_0_8px_#10b981] animate-pulse'
                                  : 'bg-rose-500'
                              }`}
                            />
                          </div>
                          <div className="text-left rtl:text-right min-w-0 flex-1">
                            <div className="flex items-center gap-1 truncate">
                              <span className="text-xs font-black text-amber-100 truncate">{friend.name}</span>
                              <LevelCrown level={friend.level} size="sm" />
                            </div>
                            <div className="text-[10px] text-amber-300/80 truncate font-semibold">
                              {friend.statusText || (friend.isOnline ? 'ئۆنلاین 🟢' : 'ئۆفلاین 🔴')}
                            </div>
                          </div>
                        </div>
                        {/* Match Invitation Button */}
                        <div className="flex items-center gap-2 shrink-0">
                          {friend.isOnline ? (
                            <button
                              onClick={() => handleDirectInvite(friend)}
                              className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-amber-950 font-black text-[11px] shadow hover:scale-105 active:scale-95 transition cursor-pointer flex items-center gap-1"
                            >
                              <Swords className="w-3.5 h-3.5 fill-amber-950" />
                              <span>{isRtl ? 'انڤایت ♟️' : 'Invite ♟️'}</span>
                            </button>
                          ) : (
                            <button
                              disabled
                              className="px-2.5 py-1 rounded-xl bg-slate-900/80 text-amber-400/50 font-bold text-[10px] border border-amber-900/40 cursor-not-allowed"
                            >
                              {isRtl ? 'ئۆفلاین' : 'Offline'}
                            </button>
                          )}
                          <button
                            onClick={() => handleRemoveFriend(friend.id)}
                            className="p-1.5 rounded-xl bg-red-900/80 text-red-300 hover:bg-red-700 transition"
                            title={isRtl ? 'سڕینەوە' : 'Remove'}
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: ADD FRIEND FORM */}
            {activeTab === 'add' && (
              <div className="w-full h-full flex flex-col gap-4 p-3 max-w-md mx-auto">
                <div className="text-center space-y-1">
                  <UserPlus className="w-10 h-10 text-yellow-400 mx-auto" />
                  <h3 className="text-sm font-black text-yellow-300">
                    {isRtl ? 'زیادکردنی هاوڕێی نوێ بە ناو' : 'Add New Chess Friend'}
                  </h3>
                  <p className="text-xs text-amber-200/80">
                    {isRtl
                      ? 'ناوی یاریزان بنووسە بۆ ناردنی داواکاری هاوڕێیەتی ڕاستەوخۆ'
                      : 'Enter Username to send an instant friend request'}
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={addInput}
                    onChange={(e) => setAddInput(e.target.value)}
                    placeholder={isRtl ? 'نموونە: Hawler_Grandmaster' : 'e.g. Hawler_Grandmaster'}
                    className="w-full bg-slate-950/90 border-2 border-amber-500/80 rounded-2xl py-3 px-4 text-xs font-mono text-yellow-300 placeholder-amber-400/50 focus:border-yellow-300 focus:outline-none shadow-inner"
                  />
                  <button
                    onClick={handleSearchUsers}
                    className="py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-600 to-amber-800 text-white font-black text-xs shadow-lg hover:brightness-110 active:scale-95 transition flex items-center justify-center"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                </div>

                <div className="mt-4 flex flex-col gap-2">
                  {searchLoading ? (
                    <div className="flex justify-center py-4"><Loader2 className="w-6 h-6 animate-spin text-amber-500" /></div>
                  ) : searchResults.length > 0 ? (
                    searchResults.map(u => (
                      <div key={u.id} className="bg-black/40 border border-amber-600/60 rounded-2xl p-3 flex items-center justify-between shadow">
                        <div className="flex items-center gap-3">
                          <img src={u.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d'} className="w-10 h-10 rounded-full border border-yellow-400 object-cover" />
                          <div className="flex flex-col text-left rtl:text-right">
                             <span className="text-xs font-bold text-amber-100">{u.name}</span>
                             <span className="text-[10px] text-amber-400/60">Level {u.level || 1}</span>
                          </div>
                        </div>
                        <button onClick={() => handleSendAddRequest(undefined, u.id, u.name)} className="px-3 py-1.5 rounded-xl bg-yellow-500 text-yellow-950 font-bold text-xs">
                          {isRtl ? 'زیادکردن +' : 'Add +'}
                        </button>
                      </div>
                    ))
                  ) : addInput.length > 2 && !searchLoading ? (
                    <div className="text-center text-amber-500/60 text-xs py-4">No users found.</div>
                  ) : null}
                </div>
              </div>
            )}

            {/* TAB 4: INCOMING REQUESTS */}
            {activeTab === 'requests' && (
              <div className="w-full h-full flex flex-col gap-2">
                {incomingRequests.length === 0 ? (
                  <div className="w-full py-16 text-center text-amber-300/60 text-xs font-bold space-y-2">
                    <Clock className="w-8 h-8 text-amber-500/50 mx-auto" />
                    <div>{isRtl ? 'هیچ داواکارییەکی نوێ نییە!' : 'No pending friend requests at the moment.'}</div>
                  </div>
                ) : (
                  incomingRequests.map((req) => (
                    <div
                      key={req.request_id}
                      className="bg-gradient-to-r from-[#4d2105] to-[#210901] border border-amber-600/60 rounded-2xl p-3 flex items-center justify-between shadow"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={req.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d'}
                          className="w-11 h-11 rounded-full border-2 border-yellow-400 object-cover shadow"
                          alt={req.name}
                          referrerPolicy="no-referrer"
                        />
                        <div className="text-left rtl:text-right">
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-black text-amber-100">{req.name}</span>
                            <LevelCrown level={req.level} size="sm" />
                          </div>
                          <span className="text-[10px] text-amber-300/80 font-bold">{isRtl ? 'داواکاری ناردووە' : 'Sent you a request'}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleAcceptRequest(req)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs transition cursor-pointer shadow flex items-center gap-1"
                        >
                          <Check className="w-4 h-4 stroke-[3]" />
                          <span>{isRtl ? 'وەربگرە' : 'Accept'}</span>
                        </button>
                        <button
                          onClick={() => handleDeclineRequest(req)}
                          className="p-1.5 rounded-xl bg-red-900 hover:bg-red-700 text-white transition cursor-pointer shadow"
                        >
                          <X className="w-4 h-4 stroke-[3]" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 5: BLOCKED USERS */}
            {activeTab === 'blocked' && (
              <div className="w-full h-full flex flex-col gap-2">
                <div className="w-full py-16 text-center text-amber-300/60 text-xs font-bold space-y-2">
                  <ShieldAlert className="w-8 h-8 text-amber-500/50 mx-auto" />
                  <div>{isRtl ? 'هیچ یاریزانێکی بلوککراو لە لیستەکەتدا نییە!' : 'No blocked players in your list.'}</div>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
