import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Check,
  Sparkles,
  Coins,
  Clock,
  Video,
  Zap,
  Gift,
  Trophy,
  Crown,
  Gamepad2,
  Swords,
  Flame,
  Shield,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language } from '../types';
import { soundManager } from '../lib/soundManager';
import {
  RedChestGraphic,
  GoldChestGraphic,
  PurpleChestGraphic,
  ChestOpeningModal,
  ChestType,
} from './ChestGraphics';
import { startAdReward,
  fetchDailyRewardStatus,
  claimDailyReward,
  DailyRewardStatus,
} from '../lib/rewardsService';

interface DailyRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userCoins?: number;
  onUpdateCoins?: (newBalance: number) => void;
  onAddCoins: (amount: number) => void;
  onAddGems?: (amount: number) => void;
  userProfile?: any;
  onUpdateProfile?: (updated: any) => void;
}

interface DailyDayItem {
  day: number;
  coins: number;
  chestType: ChestType;
  claimed: boolean;
  isCurrent: boolean;
}

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isOpen,
  onClose,
  language,
  userCoins,
  onUpdateCoins,
  onAddCoins,
  onAddGems,
  userProfile,
  onUpdateProfile,
}) => {
  // 4 Event Sub-Sections / Tabs:
  // 'daily_streak' | 'play_3_games' | 'win_7_streak' | 'royal_event'
  const [activeTab, setActiveTab] = useState<
    'daily_streak' | 'play_3_games' | 'win_7_streak' | 'royal_event'
  >('daily_streak');

  // Live Timer Countdown to Midnight Reset
  const [timeLeftStr, setTimeLeftStr] = useState<string>('00:00:00');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isClaiming, setIsClaiming] = useState<boolean>(false);

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date();
      const midnight = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
      const diffMs = midnight.getTime() - now.getTime();

      const hours = Math.floor(diffMs / (1000 * 60 * 60));
      const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diffMs % (1000 * 60)) / 1000);

      const pad = (n: number) => n.toString().padStart(2, '0');
      setTimeLeftStr(`${pad(hours)}:${pad(mins)}:${pad(secs)}`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, []);

  // 7-Day Streak Items with 3 Chest Styles
  const [dailyDays, setDailyDays] = useState<DailyDayItem[]>([
    { day: 1, coins: 500, chestType: 'red', claimed: false, isCurrent: true },
    { day: 2, coins: 1000, chestType: 'red', claimed: false, isCurrent: false },
    { day: 3, coins: 1500, chestType: 'gold', claimed: false, isCurrent: false },
    { day: 4, coins: 2000, chestType: 'red', claimed: false, isCurrent: false },
    { day: 5, coins: 3000, chestType: 'gold', claimed: false, isCurrent: false },
    { day: 6, coins: 4500, chestType: 'gold', claimed: false, isCurrent: false },
    { day: 7, coins: 10000, chestType: 'purple', claimed: false, isCurrent: false },
  ]);

  // Quests & Challenges Progress State
  const [play3Count, setPlay3Count] = useState<number>(0);
  const [play3Claimed, setPlay3Claimed] = useState<boolean>(false);
  const [win7Count, setWin7Count] = useState<number>(0);
  const [win7Claimed, setWin7Claimed] = useState<boolean>(false);
  const [royalEventClaimed, setRoyalEventClaimed] = useState<boolean>(false);

  // Video Ad Tiers
  const [adTiers, setAdTiers] = useState([
    { id: 1, amount: 500, chestType: 'red' as ChestType, claimed: false },
    { id: 2, amount: 1500, chestType: 'gold' as ChestType, claimed: false },
    { id: 3, amount: 3000, chestType: 'purple' as ChestType, claimed: false },
  ]);

  // Fetch Server-Authoritative Status
  const loadServerStatus = useCallback(async () => {
    try {
      const status = await fetchDailyRewardStatus();
      if (!status) return;

      if (status.streakDays && status.streakDays.length > 0) {
        setDailyDays(status.streakDays as DailyDayItem[]);
      }
      setPlay3Count(status.play3Count ?? 0);
      setPlay3Claimed(Boolean(status.play3Claimed));
      setWin7Count(status.win7Count ?? 0);
      setWin7Claimed(Boolean(status.win7Claimed));
      setRoyalEventClaimed(Boolean(status.royalEventClaimed));

      const claimedAds = status.claimedAdTiers || [];
      setAdTiers([
        { id: 1, amount: 500, chestType: 'red', claimed: claimedAds.includes(1) },
        { id: 2, amount: 1500, chestType: 'gold', claimed: claimedAds.includes(2) },
        { id: 3, amount: 3000, chestType: 'purple', claimed: claimedAds.includes(3) },
      ]);
    } catch (e) {
      console.warn('Failed to load daily reward status from server:', e);
    }
  }, []);

  // Reload status from server whenever modal opens
  useEffect(() => {
    if (isOpen) {
      setErrorMessage(null);
      loadServerStatus();
    }
  }, [isOpen, loadServerStatus]);

  // Interactive 3D Chest Opening Modal State
  const [activeChestModal, setActiveChestModal] = useState<{
    isOpen: boolean;
    chestType: ChestType;
    title: string;
    coins: number;
    gems?: number;
    unlockedSkinName?: string;
  }>({
    isOpen: false,
    chestType: 'gold',
    title: '',
    coins: 0,
  });

  // Video Ad Simulation state
  const [watchingAdId, setWatchingAdId] = useState<number | null>(null);
  const [adProgress, setAdProgress] = useState<number>(0);

  const isRtl = language === 'ku';

  // Reward items (e.g. the day-7 board) are granted by the SERVER in
  // user_inventory when the claim succeeds; the shop reads them from there.
  // Nothing is written to localStorage any more (it was a fake local-only unlock).
  const unlockSkinItem = (_itemId: string) => {};

  // Trigger Opening 3D Chest Modal (Visual celebration only - coins already updated from server)
  const triggerChestOpen = (
    type: ChestType,
    title: string,
    coins: number,
    gems = 10,
    unlockedSkinName?: string,
    unlockedItemId?: string
  ) => {
    if (unlockedItemId) {
      unlockSkinItem(unlockedItemId);
    }

    setActiveChestModal({
      isOpen: true,
      chestType: type,
      title,
      coins,
      gems,
      unlockedSkinName,
    });
  };

  // Claim Daily Day Streak Reward (Server-Authoritative)
  const handleClaimDailyDay = async (dayNum: number, coins: number, chestType: ChestType) => {
    if (isClaiming) return;
    soundManager.playClick();
    setIsClaiming(true);
    setErrorMessage(null);

    try {
      const res = await claimDailyReward('daily_streak');
      if (!res.success) {
        setErrorMessage(res.error || (isRtl ? 'خەڵاتی ئەمڕۆ پێشتر وەرگیراوە' : 'Daily reward already claimed today'));
        await loadServerStatus();
        return;
      }

      // Update client coins and profile strictly from server-authoritative balance
      if (onUpdateCoins) {
        onUpdateCoins(res.newBalance);
      } else {
        onAddCoins(res.coinsAwarded);
      }

      if (onAddGems && res.gemsAwarded > 0) {
        onAddGems(res.gemsAwarded);
      }

      if (onUpdateProfile) {
        onUpdateProfile({ coins: res.newBalance, gems: res.newGems });
      }

      const title =
        dayNum === 7
          ? isRtl
            ? 'خەڵاتی گەورەی ڕۆژی ٧ەم - سندوقی شاهانە!'
            : 'Day 7 Grand Royal Master Chest!'
          : isRtl
          ? `خەڵاتی ڕۆژی ${dayNum}ەم!`
          : `Day ${dayNum} Reward Chest!`;

      const skinName = dayNum === 7 ? (isRtl ? 'تەختەی ئەژدیها (Dragon Arena)' : 'Dragon Arena Board') : undefined;
      const skinId = dayNum === 7 ? 'board_obsidian' : undefined;

      triggerChestOpen(chestType, title, res.coinsAwarded, res.gemsAwarded, skinName, skinId);
      await loadServerStatus();
    } catch (e: any) {
      setErrorMessage(e.message || (isRtl ? 'هەڵەیەک ڕوویدا' : 'An error occurred'));
    } finally {
      setIsClaiming(false);
    }
  };

  // Claim Quest 1: Play 3 Games (Server-Authoritative)
  const handleClaimPlay3 = async () => {
    if (play3Count < 3 || play3Claimed || isClaiming) return;
    soundManager.playClick();
    setIsClaiming(true);
    setErrorMessage(null);

    try {
      const res = await claimDailyReward('play_3_games');
      if (!res.success) {
        setErrorMessage(res.error || (isRtl ? 'خەڵاتی یارییەکان پێشتر وەرگیراوە' : 'Quest reward already claimed'));
        await loadServerStatus();
        return;
      }

      if (onUpdateCoins) onUpdateCoins(res.newBalance);
      else onAddCoins(res.coinsAwarded);
      if (onAddGems && res.gemsAwarded > 0) onAddGems(res.gemsAwarded);
      if (onUpdateProfile) onUpdateProfile({ coins: res.newBalance, gems: res.newGems });

      triggerChestOpen('red', isRtl ? 'خەڵاتی ۳ یاری ئەنجامدان!' : '3 Games Completion Reward!', res.coinsAwarded, res.gemsAwarded);
      await loadServerStatus();
    } catch (e: any) {
      setErrorMessage(e.message || (isRtl ? 'هەڵەیەک ڕوویدا' : 'An error occurred'));
    } finally {
      setIsClaiming(false);
    }
  };

  // Claim Quest 2: Win 7 Games (Server-Authoritative)
  const handleClaimWin7 = async () => {
    if (win7Count < 7 || win7Claimed || isClaiming) return;
    soundManager.playClick();
    setIsClaiming(true);
    setErrorMessage(null);

    try {
      const res = await claimDailyReward('win_7_streak');
      if (!res.success) {
        setErrorMessage(res.error || (isRtl ? 'خەڵاتی بردنەوەکان پێشتر وەرگیراوە' : '7-win reward already claimed'));
        await loadServerStatus();
        return;
      }

      if (onUpdateCoins) onUpdateCoins(res.newBalance);
      else onAddCoins(res.coinsAwarded);
      if (onAddGems && res.gemsAwarded > 0) onAddGems(res.gemsAwarded);
      if (onUpdateProfile) onUpdateProfile({ coins: res.newBalance, gems: res.newGems });

      triggerChestOpen('gold', isRtl ? 'خەڵاتی ٧ بردنەوەی یەکبەدوایەک!' : '7-Win Streak Master Trophy!', res.coinsAwarded, res.gemsAwarded);
      await loadServerStatus();
    } catch (e: any) {
      setErrorMessage(e.message || (isRtl ? 'هەڵەیەک ڕوویدا' : 'An error occurred'));
    } finally {
      setIsClaiming(false);
    }
  };

  // Claim Quest 3: Royal Event (Server-Authoritative)
  const handleClaimRoyalEvent = async () => {
    if (royalEventClaimed || isClaiming) return;
    soundManager.playClick();
    setIsClaiming(true);
    setErrorMessage(null);

    try {
      const res = await claimDailyReward('royal_event');
      if (!res.success) {
        setErrorMessage(res.error || (isRtl ? 'ئیڤێنتی شاهانە پێشتر وەرگیراوە' : 'Royal event already claimed'));
        await loadServerStatus();
        return;
      }

      if (onUpdateCoins) onUpdateCoins(res.newBalance);
      else onAddCoins(res.coinsAwarded);
      if (onAddGems && res.gemsAwarded > 0) onAddGems(res.gemsAwarded);
      if (onUpdateProfile) onUpdateProfile({ coins: res.newBalance, gems: res.newGems });

      triggerChestOpen(
        'purple',
        isRtl ? 'خەڵاتی ئیڤێنتی شاهانەی ئاگر!' : 'Royal Fire Temple Event Chest!',
        res.coinsAwarded,
        res.gemsAwarded,
        isRtl ? 'پێگەی قەڵای ئاگر (Fire Castle Skin)' : 'Fire Castle Piece Skin',
        'piece_gold'
      );
      await loadServerStatus();
    } catch (e: any) {
      setErrorMessage(e.message || (isRtl ? 'هەڵەیەک ڕوویدا' : 'An error occurred'));
    } finally {
      setIsClaiming(false);
    }
  };

  // Watch Video Ad Simulation (Server-Authoritative)
  const handleWatchAd = (id: number, amount: number, type: ChestType) => {
    if (watchingAdId !== null || isClaiming) return;
    soundManager.playClick();
    startAdReward(id); // server starts its own watch timer
    setWatchingAdId(id);
    setAdProgress(0);
    setErrorMessage(null);

    let curr = 0;
    const interval = setInterval(() => {
      curr += 25;
      setAdProgress(curr);

      if (curr >= 100) {
        clearInterval(interval);
        setTimeout(async () => {
          setWatchingAdId(null);
          try {
            const res = await claimDailyReward('ad_reward', id);
            if (res.success) {
              if (onUpdateCoins) onUpdateCoins(res.newBalance);
              else onAddCoins(res.coinsAwarded);
              if (onAddGems && res.gemsAwarded > 0) onAddGems(res.gemsAwarded);
              if (onUpdateProfile) onUpdateProfile({ coins: res.newBalance, gems: res.newGems });

              triggerChestOpen(
                type,
                isRtl ? 'خەڵاتی سەیرکردنی ریکلامی ڤیدیۆیی!' : 'Video Sponsor Reward Chest!',
                res.coinsAwarded,
                res.gemsAwarded
              );
              await loadServerStatus();
            } else {
              setErrorMessage(res.error || (isRtl ? 'ئەم ڕیکلامە ئەمڕۆ پێشتر بینراوە' : 'Ad reward already claimed today'));
              await loadServerStatus();
            }
          } catch (err: any) {
            setErrorMessage(err.message || 'Error claiming ad reward');
          }
        }, 300);
      }
    }, 1000); // 4 steps = ~4s; the server enforces a 3s minimum watch time
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md select-none font-sans overflow-hidden">
        
        {/* 3D CHEST OPENING MODAL */}
        <ChestOpeningModal
          isOpen={activeChestModal.isOpen}
          chestType={activeChestModal.chestType}
          title={activeChestModal.title}
          coins={activeChestModal.coins}
          gems={activeChestModal.gems}
          unlockedSkinName={activeChestModal.unlockedSkinName}
          onClose={() => setActiveChestModal((prev) => ({ ...prev, isOpen: false }))}
        />

        {/* VIDEO AD SIMULATION OVERLAY */}
        {watchingAdId !== null && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-6 text-center"
          >
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 flex items-center justify-center text-amber-950 shadow-[0_0_40px_rgba(245,158,11,0.8)] mb-4 animate-pulse">
              <Video className="w-10 h-10" />
            </div>
            <h3 className="text-lg font-black text-white tracking-wide">
              {isRtl ? 'سەیرکردنی ریکلامی ڤیدیۆیی...' : 'Watching Sponsor Video...'}
            </h3>
            <p className="text-xs text-amber-200/80 mt-1 mb-6">
              {isRtl ? 'تکایە چاوەڕێ بکە تا ریکلامەکە تەواو دەبێت' : 'Please wait for the video to complete'}
            </p>

            <div className="w-full max-w-xs h-4 bg-amber-950 rounded-full border border-amber-600/60 overflow-hidden shadow-inner p-0.5">
              <motion.div
                className="h-full bg-gradient-to-r from-yellow-400 via-amber-400 to-amber-200 rounded-full"
                style={{ width: `${adProgress}%` }}
              />
            </div>
            <span className="text-xs font-mono font-bold text-yellow-300 mt-2">
              {adProgress}%
            </span>
          </motion.div>
        )}

        {/* MAIN CONTAINER (ROYAL WOOD & GOLD ORNATE FRAME) */}
        <motion.div
          initial={{ scale: 0.92, opacity: 0, y: 15 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.92, opacity: 0, y: 15 }}
          className={`relative w-full max-w-md h-[92vh] max-h-[730px] rounded-[36px] p-3.5 sm:p-4 shadow-[0_25px_90px_rgba(0,0,0,0.98)] flex flex-col border-2 border-[#d6982a] bg-gradient-to-b from-[#3d1806] via-[#240c02] to-[#120501] text-amber-50 ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* FLOATING RED CLOSE BUTTON */}
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="absolute -top-3 -right-3 w-9 h-9 rounded-full bg-red-600 border-2 border-white text-white flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer shadow-[0_4px_12px_rgba(0,0,0,0.6)] z-50"
          >
            <X className="w-5 h-5 stroke-[2.5]" />
          </button>

          {/* HEADER TITLE */}
          <div className="text-center pt-1 pb-1 shrink-0">
            <h2 className="text-lg sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-300 to-amber-500 tracking-wide uppercase drop-shadow">
              {isRtl ? 'ئیڤێنتەکانی ڕۆژانە و سندوقەکان' : 'Daily Events & Treasure Chests'}
            </h2>
            <div className="mt-1 inline-flex items-center gap-1.5 px-3 py-1 bg-amber-950/80 border border-amber-600/50 rounded-full text-[11px] font-mono text-yellow-300 shadow">
              <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>{isRtl ? 'نوێبوونەوەی ڕۆژانە:' : 'Next Daily Reset:'}</span>
              <span className="font-black text-white">{timeLeftStr}</span>
            </div>
          </div>

          {/* ERROR NOTIFICATION BANNER */}
          {errorMessage && (
            <div className="mx-2 mb-1 p-2 bg-red-950/90 border border-red-500/80 rounded-xl text-center text-xs text-red-200 shadow-md animate-fade-in">
              {errorMessage}
            </div>
          )}

          {/* ========================================================= */}
          {/* 4 SUB-SECTION EVENT PILL TABS */}
          {/* ========================================================= */}
          <div className="grid grid-cols-4 gap-1.5 my-1.5 shrink-0">
            
            {/* TAB 1: Daily Login Streak */}
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('daily_streak');
              }}
              className={`relative rounded-2xl py-2 px-1 text-center transition cursor-pointer flex flex-col items-center justify-center border-2 ${
                activeTab === 'daily_streak'
                  ? 'bg-gradient-to-b from-[#6e330d] via-[#4d2106] to-[#2e1202] border-yellow-400 text-yellow-300 shadow-[0_0_15px_rgba(245,158,11,0.5)]'
                  : 'bg-[#421b06]/90 border-[#8a4b18] text-amber-200/90 hover:border-amber-400'
              }`}
            >
              <Gift className="w-3.5 h-3.5 text-yellow-400 mb-0.5" />
              <span className="text-[10px] font-black tracking-tight leading-tight">
                {isRtl ? 'خەڵاتی ڕۆژانە' : 'Daily Streak'}
              </span>
            </button>

            {/* TAB 2: Play 3 Games */}
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('play_3_games');
              }}
              className={`relative rounded-2xl py-2 px-1 text-center transition cursor-pointer flex flex-col items-center justify-center border-2 ${
                activeTab === 'play_3_games'
                  ? 'bg-gradient-to-b from-[#6e330d] via-[#4d2106] to-[#2e1202] border-yellow-400 text-yellow-300 shadow-[0_0_15px_rgba(245,158,11,0.5)]'
                  : 'bg-[#421b06]/90 border-[#8a4b18] text-amber-200/90 hover:border-amber-400'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5 text-blue-400 mb-0.5" />
              <span className="text-[10px] font-black tracking-tight leading-tight">
                {isRtl ? '۳ یاری بکە' : 'Play 3 Games'}
              </span>
            </button>

            {/* TAB 3: Win 7 Streak */}
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('win_7_streak');
              }}
              className={`relative rounded-2xl py-2 px-1 text-center transition cursor-pointer flex flex-col items-center justify-center border-2 ${
                activeTab === 'win_7_streak'
                  ? 'bg-gradient-to-b from-[#6e330d] via-[#4d2106] to-[#2e1202] border-yellow-400 text-yellow-300 shadow-[0_0_15px_rgba(245,158,11,0.5)]'
                  : 'bg-[#421b06]/90 border-[#8a4b18] text-amber-200/90 hover:border-amber-400'
              }`}
            >
              <Trophy className="w-3.5 h-3.5 text-amber-400 mb-0.5" />
              <span className="text-[10px] font-black tracking-tight leading-tight">
                {isRtl ? '۷ بردنەوە' : 'Win 7 Streak'}
              </span>
            </button>

            {/* TAB 4: Royal Event */}
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('royal_event');
              }}
              className={`relative rounded-2xl py-2 px-1 text-center transition cursor-pointer flex flex-col items-center justify-center border-2 ${
                activeTab === 'royal_event'
                  ? 'bg-gradient-to-b from-[#7a3b11] via-[#522407] to-[#331402] border-yellow-400 text-yellow-300 shadow-[0_0_15px_rgba(245,158,11,0.6)]'
                  : 'bg-[#421b06]/90 border-[#8a4b18] text-amber-200/90 hover:border-amber-400'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-rose-400 mb-0.5 animate-pulse" />
              <span className="text-[10px] font-black tracking-tight leading-tight">
                {isRtl ? 'ئیڤێنتی شاهانە' : 'Royal Event'}
              </span>
            </button>

          </div>

          {/* ========================================================= */}
          {/* SCROLLABLE EVENT CONTENT BODY */}
          {/* ========================================================= */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-1 my-1 space-y-3">
            
            {/* ------------------------------------------------------- */}
            {/* SUB-SECTION 1: DAILY LOGIN STREAK */}
            {/* ------------------------------------------------------- */}
            {activeTab === 'daily_streak' && (
              <div className="space-y-3">
                
                {/* 7-DAY STREAK CAROUSEL / GRID */}
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {dailyDays.slice(0, 6).map((item) => (
                    <div
                      key={item.day}
                      className={`relative rounded-2xl p-2 border-2 flex flex-col items-center justify-between min-h-[120px] text-center shadow-lg transition ${
                        item.claimed
                          ? 'bg-[#183321]/90 border-emerald-500/60 text-slate-300'
                          : item.isCurrent
                          ? 'bg-gradient-to-b from-[#5c2709] via-[#3d1805] to-[#240c02] border-yellow-400 shadow-[0_0_15px_rgba(245,158,11,0.5)]'
                          : 'bg-[#3b1706]/80 border-[#6b2e0c] opacity-85'
                      }`}
                    >
                      <span className="text-[10px] font-black text-amber-200/90 uppercase">
                        Day {item.day}
                      </span>

                      {/* 3D Chest Graphic Preview */}
                      <div className="my-1 flex flex-col items-center">
                        {item.chestType === 'red' && <RedChestGraphic size={48} isOpen={item.claimed} />}
                        {item.chestType === 'gold' && <GoldChestGraphic size={48} isOpen={item.claimed} />}
                        {item.chestType === 'purple' && <PurpleChestGraphic size={48} isOpen={item.claimed} />}

                        <span className="text-xs font-black text-yellow-300 font-mono mt-0.5">
                          +{item.coins} $
                        </span>
                      </div>

                      {item.claimed ? (
                        <div className="w-full py-0.5 rounded-xl bg-emerald-950/90 text-emerald-400 font-black text-[9px] flex items-center justify-center gap-0.5">
                          <Check className="w-3 h-3 stroke-[3]" />
                          <span>{isRtl ? 'وەردگیرا' : 'Claimed'}</span>
                        </div>
                      ) : (
                        <button
                          disabled={!item.isCurrent}
                          onClick={() => handleClaimDailyDay(item.day, item.coins, item.chestType)}
                          className={`w-full py-1 rounded-xl font-black text-[10px] shadow cursor-pointer border-b-2 ${
                            item.isCurrent
                              ? 'bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 border-amber-800 text-amber-950 hover:brightness-110 active:scale-95'
                              : 'bg-amber-950/60 border-amber-900 text-amber-500 cursor-not-allowed'
                          }`}
                        >
                          {isRtl ? 'کەرەوە' : 'Open'}
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                {/* DAY 7 MASTER PURPLE CHEST CARD */}
                <div className="relative w-full rounded-2xl border-2 border-yellow-400 bg-gradient-to-r from-[#592608] via-[#3b1705] to-[#220c02] p-3 shadow-xl flex items-center justify-between">
                  <div className="flex flex-col text-left rtl:text-right">
                    <span className="text-[10px] font-black text-yellow-400 uppercase tracking-widest">
                      Day 7 Grand Reward
                    </span>
                    <span className="text-sm font-black text-white my-0.5">
                      {isRtl ? 'سندوقی شاهانەی بنەوشەیی' : 'Royal Master Purple Chest'}
                    </span>
                    <span className="text-xs font-mono font-black text-yellow-300 flex items-center gap-1">
                      <Coins className="w-3.5 h-3.5 text-yellow-400" />
                      <span>+10,000 $</span>
                    </span>
                  </div>

                  <div className="flex flex-col items-center shrink-0">
                    <PurpleChestGraphic size={64} isOpen={dailyDays[6].claimed} />
                    <button
                      disabled={dailyDays[6].claimed || !dailyDays[6].isCurrent}
                      onClick={() => handleClaimDailyDay(7, 10000, 'purple')}
                      className={`mt-1.5 px-4 py-1.5 rounded-xl font-black text-xs shadow border-b-2 transition cursor-pointer ${
                        dailyDays[6].claimed
                          ? 'bg-slate-800 text-slate-400 border-slate-900 cursor-not-allowed'
                          : dailyDays[6].isCurrent
                          ? 'bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 border-amber-800 text-amber-950 hover:brightness-110 active:scale-95'
                          : 'bg-amber-950/80 text-amber-500 border-amber-900 cursor-not-allowed'
                      }`}
                    >
                      {dailyDays[6].claimed ? (isRtl ? 'وەردگیرا' : 'Claimed') : isRtl ? 'کەرەوە' : 'Claim'}
                    </button>
                  </div>
                </div>

                {/* VIDEO ADS SPONSOR CHESTS */}
                <div className="bg-[#481e09]/90 border border-[#8a4a17] rounded-2xl p-2.5 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-black text-amber-200">
                    <Video className="w-4 h-4 text-emerald-400" />
                    <span>{isRtl ? 'سندوقی بێبەرامبەر بە سەیرکردنی ریکلام' : 'Free Chests via Video Ads'}</span>
                  </div>

                  {adTiers.map((tier) => (
                    <div
                      key={tier.id}
                      className="bg-[#321203] border border-[#6b2e0c] rounded-xl p-2 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        {tier.chestType === 'red' && <RedChestGraphic size={36} />}
                        {tier.chestType === 'gold' && <GoldChestGraphic size={36} />}
                        {tier.chestType === 'purple' && <PurpleChestGraphic size={36} />}

                        <div className="flex flex-col text-left rtl:text-right">
                          <span className="font-bold text-white text-[11px]">
                            {tier.chestType === 'red'
                              ? isRtl ? 'سندوقی ڕوبی' : 'Ruby Chest'
                              : tier.chestType === 'gold'
                              ? isRtl ? 'سندوقی زێڕین' : 'Gold Chest'
                              : isRtl ? 'سندوقی شاهانە' : 'Master Chest'}
                          </span>
                          <span className="font-mono font-black text-yellow-300 text-[10px]">
                            +{tier.amount} $
                          </span>
                        </div>
                      </div>

                      <button
                        disabled={tier.claimed}
                        onClick={() => handleWatchAd(tier.id, tier.amount, tier.chestType)}
                        className={`px-3 py-1.5 rounded-xl text-[11px] font-black border-b-2 cursor-pointer ${
                          tier.claimed
                            ? 'bg-slate-800 border-slate-900 text-slate-400 cursor-not-allowed'
                            : 'bg-gradient-to-b from-yellow-400 to-amber-500 border-amber-800 text-amber-950 hover:brightness-110 active:scale-95'
                        }`}
                      >
                        {tier.claimed ? (isRtl ? 'وەردگیرا' : 'Claimed') : isRtl ? 'سەیرکردن' : 'Watch AD'}
                      </button>
                    </div>
                  ))}
                </div>

              </div>
            )}

            {/* ------------------------------------------------------- */}
            {/* SUB-SECTION 2: PLAY 3 GAMES QUEST */}
            {/* ------------------------------------------------------- */}
            {activeTab === 'play_3_games' && (
              <div className="space-y-3">
                <div className="bg-[#481e09]/90 border border-[#8a4a17] rounded-3xl p-4 shadow-xl text-center space-y-3">
                  <div className="flex items-center justify-center gap-2">
                    <Gamepad2 className="w-5 h-5 text-blue-400" />
                    <h3 className="text-base font-black text-amber-200">
                      {isRtl ? 'ئەرکی ڕۆژانە: ۳ یاری ئەنجام بدە' : 'Daily Quest: Play 3 Matches'}
                    </h3>
                  </div>

                  <p className="text-xs text-amber-200/80">
                    {isRtl
                      ? '۳ یاری ڕاستەقینە یان بەڕامبەر AI بکه بۆ بردنەوەی سندوقی زێڕین!'
                      : 'Play 3 matches in any game mode to earn the Ruby Chest!'}
                  </p>

                  {/* Progress Bar (2/3 done) */}
                  <div className="w-full bg-amber-950/80 border border-amber-600/60 rounded-full p-1">
                    <div className="flex items-center justify-between text-[10px] font-bold text-amber-200 px-2 mb-1">
                      <span>{isRtl ? 'پێشکەوتن' : 'Progress'}</span>
                      <span className="font-mono text-yellow-300 font-black">{play3Count} / 3</span>
                    </div>
                    <div className="w-full h-3 bg-amber-900/80 rounded-full overflow-hidden p-0.5">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-500"
                        style={{ width: `${(play3Count / 3) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Reward Chest Box */}
                  <div className="my-3 flex items-center justify-center gap-4 bg-[#321203] border border-[#6b2e0c] rounded-2xl p-3">
                    <RedChestGraphic size={70} />
                    <div className="text-left rtl:text-right">
                      <span className="text-xs font-black text-yellow-300 block">
                        {isRtl ? 'خەڵاتی سندوقی ڕوبی' : 'Ruby Chest Rewards'}
                      </span>
                      <span className="text-sm font-mono font-black text-white block">
                        +1,500 $ & +10 💎
                      </span>
                    </div>
                  </div>

                  <button
                    disabled={play3Claimed}
                    onClick={() => {
                      if (play3Count >= 3) {
                        handleClaimPlay3();
                      }
                    }}
                    className={`w-full py-3 rounded-2xl font-black text-sm shadow-xl border-b-4 transition cursor-pointer flex items-center justify-center gap-2 ${
                      play3Claimed
                        ? 'bg-slate-800 border-slate-900 text-slate-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-yellow-400 via-amber-500 to-amber-600 border-amber-800 text-amber-950 hover:brightness-110 active:scale-95'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 fill-current" />
                    <span>
                      {play3Claimed
                        ? isRtl ? 'وەردگیرا' : 'Claimed'
                        : play3Count < 3
                        ? isRtl ? 'تەواوکردنی ئەرک (یاری بکە)' : 'Complete Quest (Play Now)'
                        : isRtl ? 'وەربگرە' : 'Claim Rewards'}
                    </span>
                  </button>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------- */}
            {/* SUB-SECTION 3: WIN 7 STREAK */}
            {/* ------------------------------------------------------- */}
            {activeTab === 'win_7_streak' && (
              <div className="space-y-3">
                <div className="bg-[#481e09]/90 border border-[#8a4a17] rounded-3xl p-4 shadow-xl text-center space-y-3">
                  <div className="flex items-center justify-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-400" />
                    <h3 className="text-base font-black text-amber-200">
                      {isRtl ? 'تەحەددی: ۷ یاری ببنەوە' : 'Streak Challenge: Win 7 Matches'}
                    </h3>
                  </div>

                  <p className="text-xs text-amber-200/80">
                    {isRtl
                      ? '۷ یاری بە سەرکەوتوویی ببنەوە بۆ وەرگرتنی سندوقی زێڕینی گەورە!'
                      : 'Win 7 matches to unlock the Master Gold Treasure Chest!'}
                  </p>

                  {/* Progress Bar (5/7 wins) */}
                  <div className="w-full bg-amber-950/80 border border-amber-600/60 rounded-full p-1">
                    <div className="flex items-center justify-between text-[10px] font-bold text-amber-200 px-2 mb-1">
                      <span>{isRtl ? 'بردنەوەکان' : 'Wins'}</span>
                      <span className="font-mono text-yellow-300 font-black">{win7Count} / 7</span>
                    </div>
                    <div className="w-full h-3 bg-amber-900/80 rounded-full overflow-hidden p-0.5">
                      <div
                        className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full transition-all duration-500"
                        style={{ width: `${(win7Count / 7) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Reward Chest Box */}
                  <div className="my-3 flex items-center justify-center gap-4 bg-[#321203] border border-[#6b2e0c] rounded-2xl p-3">
                    <GoldChestGraphic size={70} />
                    <div className="text-left rtl:text-right">
                      <span className="text-xs font-black text-yellow-300 block">
                        {isRtl ? 'خەڵاتی سندوقی زێڕین' : 'Epic Gold Chest Rewards'}
                      </span>
                      <span className="text-sm font-mono font-black text-white block">
                        +4,500 $ & +25 💎
                      </span>
                    </div>
                  </div>

                  <button
                    disabled={win7Claimed}
                    onClick={() => {
                      if (win7Count >= 7) {
                        handleClaimWin7();
                      }
                    }}
                    className={`w-full py-3 rounded-2xl font-black text-sm shadow-xl border-b-4 transition cursor-pointer flex items-center justify-center gap-2 ${
                      win7Claimed
                        ? 'bg-slate-800 border-slate-900 text-slate-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-yellow-400 via-amber-500 to-amber-600 border-amber-800 text-amber-950 hover:brightness-110 active:scale-95'
                    }`}
                  >
                    <Trophy className="w-4 h-4 fill-current" />
                    <span>
                      {win7Claimed
                        ? isRtl ? 'وەردگیرا' : 'Claimed'
                        : win7Count < 7
                        ? isRtl ? 'تەواوکردنی ۷ بردنەوە' : 'Complete 7 Wins'
                        : isRtl ? 'وەربگرە' : 'Claim Gold Chest'}
                    </span>
                  </button>
                </div>
              </div>
            )}

            {/* ------------------------------------------------------- */}
            {/* SUB-SECTION 4: ROYAL SPECIAL EVENT */}
            {/* ------------------------------------------------------- */}
            {activeTab === 'royal_event' && (
              <div className="space-y-3">
                <div className="relative rounded-3xl border-2 border-yellow-400 bg-gradient-to-b from-[#6b1e0c] via-[#451104] to-[#220701] p-4 shadow-2xl text-center space-y-3 overflow-hidden">
                  <div className="flex items-center justify-center gap-2">
                    <Flame className="w-6 h-6 text-rose-500 animate-pulse" />
                    <h3 className="text-base font-black text-yellow-300 uppercase tracking-widest">
                      {isRtl ? 'ئیڤێنتی تایبەتی کۆشکی ئاگر' : 'Royal Fire Temple Arena Event'}
                    </h3>
                  </div>

                  <p className="text-xs text-amber-100/90 leading-relaxed">
                    {isRtl
                      ? 'بەشداری لە ئیڤێنتی تایبەتی شەترەنجی شاهانە بکه بۆ بەدەستهێنانی سندوقی بنەوشەیی شاهانە و پێگەی تایبەتی قەڵای ئاگر!'
                      : 'Join the Royal Fire Temple Chess Arena to unlock the Master Purple Chest & Fire Castle piece skin!'}
                  </p>

                  {/* Chest & Skin Drops Preview */}
                  <div className="my-3 flex items-center justify-center gap-4 bg-[#2b0a02] border border-rose-900/80 rounded-2xl p-3 shadow-inner">
                    <PurpleChestGraphic size={80} />
                    <div className="text-left rtl:text-right space-y-1">
                      <span className="text-xs font-black text-purple-300 block">
                        {isRtl ? 'سندوقی بنەوشەیی شاهانە' : 'Master Purple Chest'}
                      </span>
                      <span className="text-sm font-mono font-black text-yellow-300 block">
                        +8,000 $ & +50 💎
                      </span>
                      <span className="text-[10px] font-black text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/50 inline-block">
                        {isRtl ? 'پێگەی قەڵای ئاگر (Fire Castle Skin)' : 'Fire Castle Piece Skin'}
                      </span>
                    </div>
                  </div>

                  <button
                    disabled={royalEventClaimed}
                    onClick={handleClaimRoyalEvent}
                    className={`w-full py-3.5 rounded-2xl font-black text-sm shadow-2xl border-b-4 transition cursor-pointer flex items-center justify-center gap-2 ${
                      royalEventClaimed
                        ? 'bg-slate-800 border-slate-900 text-slate-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-yellow-400 via-amber-500 to-amber-600 border-amber-800 text-amber-950 hover:brightness-110 active:scale-95'
                    }`}
                  >
                    <Crown className="w-5 h-5 fill-current" />
                    <span>
                      {royalEventClaimed
                        ? isRtl ? 'وەردگیرا' : 'Claimed'
                        : isRtl ? 'وەربگرە (سندوقی بنەوشەیی)' : 'Claim Master Purple Chest'}
                    </span>
                  </button>
                </div>
              </div>
            )}

          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
