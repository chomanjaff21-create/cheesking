import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Move, Square } from 'chess.js';
import { RotateCcw } from 'lucide-react';
import { soundManager } from '../lib/soundManager';
import { ThemeStyle, PieceSkinId, BoardSkinId } from '../types';
import { getMaterialsForTheme, getMaterialsForCustomSkins, create3DPieceGroup } from '../lib/3dPieceGenerator';
import { Chess2DBoard } from './Chess2DBoard';
import castleBgImg from '../assets/images/royal_castle_bg_1786446261388.jpg';
import kurdistanBgImg from '../assets/images/kurdistan_game_bg_1786463095756.jpg';
import dragonBgImg from '../assets/images/kurdish_dragon_bg_1786463324168.jpg';
import knightsCastleBgImg from '../assets/images/knights_castle_bg_1786551605299.jpg';
import crispRoyalHallBgImg from '../assets/images/crisp_royal_hall_bg_1786551901778.jpg';
import fullFantasyBgImg from '../assets/images/full_fantasy_bg_1786552287636.jpg';
import epicCastleTerraceBgImg from '../assets/images/royal_chess_kurd_castle_bg_1788296185378.jpg';
import mountainRiverBgImg from '../assets/images/mountain_river_bg_1786666267261.jpg';
import desertPyramidsBgImg from '../assets/images/egyptian_sahara_pyramids_grand_1786721974267.jpg';
import royalWinterCastleBgImg from '../assets/images/royal_winter_castle_1788782659066.jpg';
import darkGlassHallBgImg from '../assets/images/dark_glass_hall_bg_1788783496148.jpg';

// Module-level persistent texture cache & preloader to eliminate black flash when entering chess game
const globalBgTexturesCache: { [key: string]: THREE.Texture } = {};
const sharedTextureLoader = new THREE.TextureLoader();

let studioDarkTexInstance: THREE.CanvasTexture | null = null;
const getStudioDarkTexture = (): THREE.CanvasTexture => {
  if (studioDarkTexInstance) return studioDarkTexInstance;
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    const grad = ctx.createRadialGradient(512, 460, 40, 512, 512, 720);
    grad.addColorStop(0, '#161a26'); // Subtle ambient studio glow centered behind board
    grad.addColorStop(0.3, '#0d1017');
    grad.addColorStop(0.65, '#06070a');
    grad.addColorStop(1.0, '#030406'); // Pitch dark luxury studio vignette matching IMG_4754.jpeg
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1024, 1024);
  }
  studioDarkTexInstance = new THREE.CanvasTexture(canvas);
  studioDarkTexInstance.colorSpace = THREE.SRGBColorSpace;
  return studioDarkTexInstance;
};

const getBgUrlForBoardSkin = (skin: string): string => {
  if (skin === 'ocean_azure' || skin === 'azure') return mountainRiverBgImg;
  if (skin === 'dragon_arena' || skin === 'dragon_glass_castle') return dragonBgImg;
  if (skin === 'egyptian_pyramids') return desertPyramidsBgImg;
  return darkGlassHallBgImg;
};

const getOrPreloadBgTexture = (url: string, onReady?: (tex: THREE.Texture) => void): THREE.Texture => {
  if (globalBgTexturesCache[url]) {
    if (onReady) onReady(globalBgTexturesCache[url]);
    return globalBgTexturesCache[url];
  }
  const tex = sharedTextureLoader.load(url, (loadedTex) => {
    loadedTex.colorSpace = THREE.SRGBColorSpace;
    globalBgTexturesCache[url] = loadedTex;
    if (onReady) onReady(loadedTex);
  });
  tex.colorSpace = THREE.SRGBColorSpace;
  globalBgTexturesCache[url] = tex;
  return tex;
};

// Immediately kick off background texture preloading when module imports
if (typeof window !== 'undefined') {
  [darkGlassHallBgImg, royalWinterCastleBgImg, mountainRiverBgImg, epicCastleTerraceBgImg, dragonBgImg, desertPyramidsBgImg].forEach((url) => {
    getOrPreloadBgTexture(url);
  });
}

// Helper to generate a high-definition 2D texture for the Kurdistan Flag (☀️ 21-ray sunburst)
const createKurdistanFlagTexture = (): THREE.CanvasTexture => {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 640;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    const w = canvas.width;
    const h = canvas.height;
    const stripeH = h / 3;

    // Top Stripe - Red
    ctx.fillStyle = '#dc2626';
    ctx.fillRect(0, 0, w, stripeH);

    // Middle Stripe - White
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, stripeH, w, stripeH);

    // Bottom Stripe - Green
    ctx.fillStyle = '#16a34a';
    ctx.fillRect(0, stripeH * 2, w, stripeH);

    // Center Sun ☀️ (21 Rays - Official Emblem of Kurdistan)
    const cx = w / 2;
    const cy = h / 2;
    const outerRadius = 145;
    const innerRadius = 75;
    const coreRadius = 65;
    const raysCount = 21;

    // Soft outer golden halo glow
    const radialGlow = ctx.createRadialGradient(cx, cy, 30, cx, cy, 180);
    radialGlow.addColorStop(0, 'rgba(254, 240, 138, 0.95)');
    radialGlow.addColorStop(0.5, 'rgba(234, 179, 8, 0.6)');
    radialGlow.addColorStop(1, 'rgba(234, 179, 8, 0)');
    ctx.fillStyle = radialGlow;
    ctx.beginPath();
    ctx.arc(cx, cy, 180, 0, Math.PI * 2);
    ctx.fill();

    // Draw 21 Sharp Golden Rays
    ctx.fillStyle = '#eab308';
    ctx.strokeStyle = '#ca8a04';
    ctx.lineWidth = 2;

    for (let i = 0; i < raysCount; i++) {
      const angle = (i * Math.PI * 2) / raysCount - Math.PI / 2;
      const angleLeft = angle - (Math.PI / raysCount) * 0.45;
      const angleRight = angle + (Math.PI / raysCount) * 0.45;

      const xTip = cx + Math.cos(angle) * outerRadius;
      const yTip = cy + Math.sin(angle) * outerRadius;

      const xLeft = cx + Math.cos(angleLeft) * innerRadius;
      const yLeft = cy + Math.sin(angleLeft) * innerRadius;

      const xRight = cx + Math.cos(angleRight) * innerRadius;
      const yRight = cy + Math.sin(angleRight) * innerRadius;

      ctx.beginPath();
      ctx.moveTo(xLeft, yLeft);
      ctx.lineTo(xTip, yTip);
      ctx.lineTo(xRight, yRight);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    // Inner Solid Golden Core Circle
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(cx, cy, coreRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ca8a04';
    ctx.lineWidth = 3;
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
};

// Data Structures for Water Splash & Sinking Capture System
interface WaterRippleData {
  ringMesh: THREE.Mesh;
  splashParticles: THREE.Points;
  splashPositions: Float32Array;
  splashVelocities: { vx: number; vy: number; vz: number }[];
  vortexMesh?: THREE.Mesh;
  bubbleParticles?: THREE.Points;
  bubblePositions?: Float32Array;
  bubbleVelocities?: { vx: number; vy: number; vz: number }[];
  age: number;
  maxAge: number;
}

interface SinkingCapturePiece {
  group: THREE.Group;
  vortexRings: THREE.Mesh[];
  bubblesParticles: THREE.Points;
  bubblePositions: Float32Array;
  bubbleVelocities: { vx: number; vy: number; vz: number }[];
  age: number;
  maxAge: number;
  x: number;
  z: number;
}

// AAA Realistic Small Brown Wooden Boat Builder (بەلەمێکی جوان و بچووک و قاوەیی دارین)
const create3DWoodenBoat = () => {
  const boatGroup = new THREE.Group();
  boatGroup.name = 'floating_wooden_boat';

  // 1. Rich Warm Varnished Mahogany / Walnut Wood Planks Textures
  const boatWoodCanvas = document.createElement('canvas');
  boatWoodCanvas.width = 256;
  boatWoodCanvas.height = 256;
  const wCtx = boatWoodCanvas.getContext('2d');
  if (wCtx) {
    wCtx.fillStyle = '#452613';
    wCtx.fillRect(0, 0, 256, 256);
    // Wood grain lines
    for (let i = 0; i < 256; i += 4) {
      wCtx.strokeStyle = i % 8 === 0 ? 'rgba(28, 14, 6, 0.65)' : 'rgba(92, 53, 26, 0.45)';
      wCtx.lineWidth = 1.6;
      wCtx.beginPath();
      wCtx.moveTo(0, i);
      wCtx.lineTo(256, i + (Math.random() - 0.5) * 4);
      wCtx.stroke();
    }
  }
  const woodTexture = new THREE.CanvasTexture(boatWoodCanvas);
  woodTexture.wrapS = THREE.RepeatWrapping;
  woodTexture.wrapT = THREE.RepeatWrapping;

  const darkWoodMat = new THREE.MeshStandardMaterial({
    map: woodTexture,
    color: 0x543015,
    roughness: 0.42,
    metalness: 0.15,
  });

  const lightWoodMat = new THREE.MeshStandardMaterial({
    map: woodTexture,
    color: 0x7c4922,
    roughness: 0.38,
    metalness: 0.12,
  });

  const darkTrimWoodMat = new THREE.MeshStandardMaterial({
    color: 0x2b170a,
    roughness: 0.55,
    metalness: 0.1,
  });

  const brassMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    metalness: 0.92,
    roughness: 0.18,
  });

  // 2. Realistic Boat Hull (Sculpted Wooden Rowboat)
  // Outer Main Hull Shell
  const hullShape = new THREE.Shape();
  hullShape.moveTo(0, 1.25); // Pointed Upswept Bow (سەری بەلەم)
  hullShape.quadraticCurveTo(0.52, 0.45, 0.48, -0.65); // Right side curve
  hullShape.lineTo(0.38, -1.05); // Right stern corner
  hullShape.lineTo(-0.38, -1.05); // Flat Transom Stern
  hullShape.lineTo(-0.48, -0.65); // Left stern corner
  hullShape.quadraticCurveTo(-0.52, 0.45, 0, 1.25); // Left side curve to bow

  const hullExtrudeSettings = {
    depth: 0.36,
    bevelEnabled: true,
    bevelSegments: 4,
    steps: 1,
    bevelSize: 0.04,
    bevelThickness: 0.05,
  };

  const hullGeom = new THREE.ExtrudeGeometry(hullShape, hullExtrudeSettings);
  hullGeom.rotateX(-Math.PI / 2);
  const hullOuter = new THREE.Mesh(hullGeom, darkWoodMat);
  hullOuter.position.y = -0.18;
  hullOuter.castShadow = true;
  hullOuter.receiveShadow = true;
  boatGroup.add(hullOuter);

  // Inner Hollowed Hull Floor Planks
  const innerFloorShape = new THREE.Shape();
  innerFloorShape.moveTo(0, 1.12);
  innerFloorShape.quadraticCurveTo(0.42, 0.42, 0.38, -0.60);
  innerFloorShape.lineTo(0.30, -0.95);
  innerFloorShape.lineTo(-0.30, -0.95);
  innerFloorShape.lineTo(-0.38, -0.60);
  innerFloorShape.quadraticCurveTo(-0.42, 0.42, 0, 1.12);

  const innerFloorGeom = new THREE.ExtrudeGeometry(innerFloorShape, { depth: 0.06, bevelEnabled: false });
  innerFloorGeom.rotateX(-Math.PI / 2);
  const innerFloor = new THREE.Mesh(innerFloorGeom, lightWoodMat);
  innerFloor.position.y = 0.02;
  boatGroup.add(innerFloor);

  // Gunwales (Top Wooden Trim Rails along the boat sides)
  const gunwaleLeft = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 2.25, 12), darkTrimWoodMat);
  gunwaleLeft.position.set(-0.46, 0.18, 0.08);
  gunwaleLeft.rotation.z = -0.05;
  boatGroup.add(gunwaleLeft);

  const gunwaleRight = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 2.25, 12), darkTrimWoodMat);
  gunwaleRight.position.set(0.46, 0.18, 0.08);
  gunwaleRight.rotation.z = 0.05;
  boatGroup.add(gunwaleRight);

  // Center Bottom Keel Beam
  const keelGeom = new THREE.BoxGeometry(0.07, 0.11, 2.35);
  const keel = new THREE.Mesh(keelGeom, darkTrimWoodMat);
  keel.position.set(0, -0.21, 0.08);
  boatGroup.add(keel);

  // 3. Wooden Rib Frames across the floor
  for (let r = -0.7; r <= 0.7; r += 0.32) {
    const ribW = 0.72 - Math.abs(r) * 0.20;
    const ribGeom = new THREE.BoxGeometry(ribW, 0.04, 0.045);
    const rib = new THREE.Mesh(ribGeom, darkTrimWoodMat);
    rib.position.set(0, 0.045, r);
    boatGroup.add(rib);
  }

  // 4. Wooden Thwarts / Bench Seats (تەختەی دانیشتنی دارین)
  // Bow Seat (Front Triangle Bench)
  const bowBenchGeom = new THREE.BoxGeometry(0.42, 0.045, 0.26);
  const bowBench = new THREE.Mesh(bowBenchGeom, lightWoodMat);
  bowBench.position.set(0, 0.15, 0.75);
  boatGroup.add(bowBench);

  // Center Rowing Seat (تەختەی ناوەڕاست)
  const centerBenchGeom = new THREE.BoxGeometry(0.78, 0.045, 0.26);
  const centerBench = new THREE.Mesh(centerBenchGeom, lightWoodMat);
  centerBench.position.set(0, 0.15, 0.02);
  centerBench.castShadow = true;
  boatGroup.add(centerBench);

  // Stern Seat (تەختەی پشتەوە)
  const sternBenchGeom = new THREE.BoxGeometry(0.62, 0.045, 0.26);
  const sternBench = new THREE.Mesh(sternBenchGeom, lightWoodMat);
  sternBench.position.set(0, 0.15, -0.75);
  boatGroup.add(sternBench);

  // 5. Pair of Beautiful Wooden Oars (دوو مەشارەی دارین / پاروو)
  const createOar = (side: number) => {
    const oarGroup = new THREE.Group();
    // Loom (Shaft)
    const shaftGeom = new THREE.CylinderGeometry(0.018, 0.018, 1.55, 12);
    const shaft = new THREE.Mesh(shaftGeom, lightWoodMat);
    shaft.position.y = 0.55;
    shaft.castShadow = true;
    oarGroup.add(shaft);

    // Oar Blade (دەمی پەڕەی مەشارە)
    const bladeShape = new THREE.Shape();
    bladeShape.moveTo(0, 0);
    bladeShape.quadraticCurveTo(0.07, 0.18, 0.06, 0.46);
    bladeShape.lineTo(-0.06, 0.46);
    bladeShape.quadraticCurveTo(-0.07, 0.18, 0, 0);
    const bladeGeom = new THREE.ExtrudeGeometry(bladeShape, { depth: 0.014, bevelEnabled: false });
    const blade = new THREE.Mesh(bladeGeom, darkWoodMat);
    blade.position.set(0, 1.30, -0.007);
    blade.rotation.x = Math.PI;
    blade.castShadow = true;
    oarGroup.add(blade);

    // Brass Oarlock Swivel (قولاپی مەشارە)
    const oarlock = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.011, 8, 16, Math.PI * 1.5), brassMat);
    oarlock.position.set(0, 0.38, 0);
    oarGroup.add(oarlock);

    oarGroup.position.set(side * 0.46, 0.18, 0.02);
    oarGroup.rotation.set(0.12, side * -0.35, side * 0.85);
    return oarGroup;
  };

  boatGroup.add(createOar(-1));
  boatGroup.add(createOar(1));

  // 6. Warm Amber Glowing Brass Lantern on Bow Post (فانۆسی زێڕینی شەوانەی بەلەم)
  const lanternGroup = new THREE.Group();
  lanternGroup.position.set(0, 0.34, 1.16);

  // Lantern Wooden Bow Mount Post
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.30, 10), darkTrimWoodMat);
  post.position.y = -0.06;
  lanternGroup.add(post);

  // Brass Cap & Base
  const lCap = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.08, 8), brassMat);
  lCap.position.y = 0.16;
  lanternGroup.add(lCap);

  const lBase = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.065, 0.035, 8), brassMat);
  lBase.position.y = 0.02;
  lanternGroup.add(lBase);

  // Glowing Crystal Amber Flame/Glass (شوشەی فانۆسی ڕۆشن)
  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0xfbbf24,
    emissive: 0xf59e0b,
    emissiveIntensity: 1.4,
    transparent: true,
    opacity: 0.88,
    roughness: 0.08,
    transmission: 0.75,
  });
  const glassGeom = new THREE.CylinderGeometry(0.052, 0.052, 0.10, 8);
  const lanternGlass = new THREE.Mesh(glassGeom, glassMat);
  lanternGlass.position.y = 0.09;
  lanternGroup.add(lanternGlass);

  // Soft Ambient Golden Light cast from Lantern onto Water & Boat
  const boatLight = new THREE.PointLight(0xf59e0b, 2.2, 7.5);
  boatLight.position.set(0, 0.12, 0);
  lanternGroup.add(boatLight);

  boatGroup.add(lanternGroup);

  // Scale boat to be elegant and perfectly proportioned
  boatGroup.scale.set(1.4, 1.4, 1.4);

  return { boatGroup, boatLight };
};

// ============================================================================
// AAA 3D PROCEDURAL REALISTIC DATE PALM TREE BUILDER (دارخورمای بەرز و واحی بیابان)
// ============================================================================
const create3DPalmTree = (heightScale = 1.0) => {
  const palmGroup = new THREE.Group();
  palmGroup.name = 'oasis_palm_tree';

  // Rich textured sandstone and palm husk materials
  const trunkBarkMat = new THREE.MeshStandardMaterial({
    color: 0x4a2810, // Deep organic fibrous date palm trunk
    roughness: 0.9,
    metalness: 0.05,
    bumpScale: 0.08,
  });

  const goldBarkRingMat = new THREE.MeshStandardMaterial({
    color: 0xd97706, // Amber golden fiber ring
    roughness: 0.45,
    metalness: 0.4,
  });

  const frondMatPrimary = new THREE.MeshStandardMaterial({
    color: 0x15803d, // Vibrant emerald palm frond
    roughness: 0.35,
    metalness: 0.12,
    side: THREE.DoubleSide,
  });

  const frondMatSecondary = new THREE.MeshStandardMaterial({
    color: 0x4ade80, // Sunlit golden green palm tip
    roughness: 0.3,
    metalness: 0.15,
    side: THREE.DoubleSide,
  });

  const dateClusterMat = new THREE.MeshStandardMaterial({
    color: 0xb45309, // Ripe sweet golden/amber Giza dates
    roughness: 0.38,
    metalness: 0.25,
  });

  // 1. Natural S-curved Segmented Trunk with Overlapping Fibrous Rings
  const numSegments = 9;
  let currentY = 0;
  let currentX = 0;
  let currentZ = 0;
  const curveDirX = 0.035 * (Math.random() > 0.5 ? 1 : -1);
  const curveDirZ = 0.025 * (Math.random() > 0.5 ? 1 : -1);

  for (let i = 0; i < numSegments; i++) {
    const radiusBottom = (0.24 - i * 0.012) * heightScale;
    const radiusTop = (0.22 - i * 0.012) * heightScale;
    const segHeight = 0.45 * heightScale;

    // Segment cylinder
    const segGeom = new THREE.CylinderGeometry(radiusTop, radiusBottom, segHeight, 12);
    const segMesh = new THREE.Mesh(segGeom, trunkBarkMat);
    segMesh.position.set(currentX, currentY + segHeight / 2, currentZ);
    segMesh.rotation.z = curveDirX * (i + 1);
    segMesh.rotation.x = curveDirZ * (i + 1);
    segMesh.castShadow = true;
    segMesh.receiveShadow = true;
    palmGroup.add(segMesh);

    // Decorative stepped husk collar
    const collarGeom = new THREE.TorusGeometry(radiusBottom * 1.08, 0.024 * heightScale, 6, 12);
    const collarMesh = new THREE.Mesh(collarGeom, goldBarkRingMat);
    collarMesh.position.set(currentX, currentY + 0.02, currentZ);
    collarMesh.rotation.x = Math.PI / 2;
    palmGroup.add(collarMesh);

    currentY += segHeight * 0.93;
    currentX += curveDirX * segHeight;
    currentZ += curveDirZ * segHeight;
  }

  // 2. Majestic Arching 2-Tier Crown of 16 Feathered Date Palm Fronds
  const numFronds = 8;
  for (let f = 0; f < numFronds; f++) {
    const isUpperTier = f % 2 === 0;
    const angle = (f / numFronds) * Math.PI * 2 + (f * 0.1);
    const frondGroup = new THREE.Group();
    frondGroup.position.set(currentX, currentY, currentZ);

    const frondReach = isUpperTier ? 1.85 * heightScale : 2.25 * heightScale;
    const archHeight = isUpperTier ? 0.65 * heightScale : 0.45 * heightScale;
    const droopDepth = isUpperTier ? -0.35 * heightScale : -0.75 * heightScale;

    // Curved Spine Rib
    const ribCurve = new THREE.CubicBezierCurve3(
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, archHeight * 0.8, frondReach * 0.35),
      new THREE.Vector3(0, archHeight, frondReach * 0.7),
      new THREE.Vector3(0, droopDepth, frondReach)
    );
    const ribGeom = new THREE.TubeGeometry(ribCurve, 14, 0.022 * heightScale, 6, false);
    const ribMesh = new THREE.Mesh(ribGeom, trunkBarkMat);
    frondGroup.add(ribMesh);

    // Individual Feather Leaflets along the spine
    const numLeaflets = 14;
    for (let b = 0; b < numLeaflets; b++) {
      const t = (b + 1) / (numLeaflets + 1);
      const pt = ribCurve.getPoint(t);
      const leafletLength = Math.sin(t * Math.PI) * (0.48 * heightScale);
      const leafletGeom = new THREE.ConeGeometry(0.045 * heightScale, leafletLength, 4);

      const leafMat = b % 3 === 0 ? frondMatSecondary : frondMatPrimary;

      // Left leaflet
      const leftLeaf = new THREE.Mesh(leafletGeom, leafMat);
      leftLeaf.position.set(pt.x - 0.04 * heightScale, pt.y, pt.z);
      leftLeaf.rotation.set(0.15, 0, Math.PI / 2.7);
      leftLeaf.castShadow = true;
      frondGroup.add(leftLeaf);

      // Right leaflet
      const rightLeaf = new THREE.Mesh(leafletGeom, leafMat);
      rightLeaf.position.set(pt.x + 0.04 * heightScale, pt.y, pt.z);
      rightLeaf.rotation.set(0.15, 0, -Math.PI / 2.7);
      rightLeaf.castShadow = true;
      frondGroup.add(rightLeaf);
    }

    frondGroup.rotation.y = angle;
    frondGroup.rotation.x = isUpperTier ? 0.22 : 0.38;
    palmGroup.add(frondGroup);
  }

  // 3. Four Hanging Clusters of Rich Golden Dates (هێشووە خورمای واحی بیابان)
  for (let c = 0; c < 4; c++) {
    const cAngle = (c / 4) * Math.PI * 2 + 0.35;
    const cluster = new THREE.Group();
    cluster.position.set(
      currentX + Math.cos(cAngle) * 0.16 * heightScale,
      currentY - 0.12 * heightScale,
      currentZ + Math.sin(cAngle) * 0.16 * heightScale
    );

    // Stem string
    const stringMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015 * heightScale, 0.015 * heightScale, 0.25 * heightScale, 4),
      goldBarkRingMat
    );
    stringMesh.position.y = -0.1 * heightScale;
    cluster.add(stringMesh);

    for (let d = 0; d < 3; d++) {
      const date = new THREE.Mesh(
        new THREE.SphereGeometry(0.042 * heightScale, 6, 6),
        dateClusterMat
      );
      date.scale.set(1, 1.6, 1);
      date.position.set(
        (Math.random() - 0.5) * 0.1 * heightScale,
        -0.08 * heightScale - d * 0.035 * heightScale,
        (Math.random() - 0.5) * 0.1 * heightScale
      );
      date.castShadow = true;
      cluster.add(date);
    }
    palmGroup.add(cluster);
  }

  return palmGroup;
};

// ============================================================================
// AAA 3D PROCEDURAL REALISTIC STEPPED MASONRY PYRAMID (هەرەمی خشتی بەردین)
// ============================================================================
const create3DGrandMasonryPyramid = (baseSize: number, tiers = 7, rotY = 0) => {
  const pGroup = new THREE.Group();
  pGroup.name = 'grand_masonry_pyramid';
  pGroup.rotation.y = rotY;

  // Authentic Egyptian Sandstone Block Materials (خشتی بەردینی جیزە)
  const stoneMat1 = new THREE.MeshStandardMaterial({
    color: 0xd97706, // Warm Golden Desert Sandstone
    roughness: 0.68,
    metalness: 0.12,
  });

  const stoneMat2 = new THREE.MeshStandardMaterial({
    color: 0xb45309, // Baked Ochre Terracotta Sandstone
    roughness: 0.72,
    metalness: 0.15,
  });

  const stoneMat3 = new THREE.MeshStandardMaterial({
    color: 0x92400e, // Dark Weathered Ancient Basalt Stone
    roughness: 0.78,
    metalness: 0.18,
  });

  const goldCapMat = new THREE.MeshStandardMaterial({
    color: 0xffd700, // Electrum & Pure Gold Benben Stone Capstone
    emissive: 0xd97706,
    emissiveIntensity: 0.85,
    roughness: 0.12,
    metalness: 0.98,
  });

  let currentY = 0;
  const totalHeight = baseSize * 0.85;
  const tierHeight = totalHeight / tiers;

  for (let t = 0; t < tiers; t++) {
    const tierFrac = t / tiers;
    const tierSize = baseSize * (1 - tierFrac * 0.88);
    const nextTierSize = baseSize * (1 - ((t + 1) / tiers) * 0.88);

    // 1. Solid Inner Stepped Tier Core
    const tierCoreGeom = new THREE.BoxGeometry(tierSize, tierHeight, tierSize);
    const tierCore = new THREE.Mesh(tierCoreGeom, t % 2 === 0 ? stoneMat1 : stoneMat2);
    tierCore.position.y = currentY + tierHeight / 2;
    tierCore.castShadow = true;
    tierCore.receiveShadow = true;
    pGroup.add(tierCore);

    // 2. Individual Masonry Stone Bricks around the Perimeter (وەک خشت لەسەر یەک)
    const blocksPerSide = Math.max(3, Math.floor(6 - t * 0.6));
    const blockSize = tierSize / blocksPerSide;
    const blockH = tierHeight * 0.96;

    for (let side = 0; side < 4; side++) {
      const angle = (side * Math.PI) / 2;
      for (let b = 0; b < blocksPerSide; b++) {
        const offset = -tierSize / 2 + blockSize / 2 + b * blockSize;
        const bGeom = new THREE.BoxGeometry(blockSize * 0.94, blockH, blockSize * 0.28);
        const bMat = (t + side + b) % 3 === 0 ? stoneMat1 : (t + b) % 2 === 0 ? stoneMat2 : stoneMat3;
        const brick = new THREE.Mesh(bGeom, bMat);

        if (side === 0) {
          brick.position.set(offset, currentY + tierHeight / 2, tierSize / 2);
        } else if (side === 1) {
          brick.position.set(tierSize / 2, currentY + tierHeight / 2, offset);
          brick.rotation.y = Math.PI / 2;
        } else if (side === 2) {
          brick.position.set(offset, currentY + tierHeight / 2, -tierSize / 2);
        } else {
          brick.position.set(-tierSize / 2, currentY + tierHeight / 2, offset);
          brick.rotation.y = Math.PI / 2;
        }

        brick.castShadow = true;
        pGroup.add(brick);
      }
    }

    currentY += tierHeight;
  }

  // 3. Radiant Glowing Golden Benben Pyramidion Capstone (لووتکەی زێڕینی هەرەم)
  const capstoneSize = baseSize * 0.16;
  const capstoneHeight = baseSize * 0.18;
  const capGeom = new THREE.ConeGeometry(capstoneSize * 0.72, capstoneHeight, 4);
  const capMesh = new THREE.Mesh(capGeom, goldCapMat);
  capMesh.position.y = currentY + capstoneHeight / 2;
  capMesh.rotation.y = Math.PI / 4;
  capMesh.castShadow = true;
  pGroup.add(capMesh);

  // Soft radiant sun aura light from the Golden Capstone
  const capLight = new THREE.PointLight(0xf59e0b, 2.5, 18.0);
  capLight.position.y = currentY + capstoneHeight;
  pGroup.add(capLight);

  return pGroup;
};

// ============================================================================
// AAA 3D PROCEDURAL MINI STEPPED PYRAMID WITH GLOWING GOLDEN CAPSTONE (هەرەم)
// ============================================================================
const create3DMiniPyramid = (baseSize = 1.6, tiers = 4) => {
  const pyramidGroup = new THREE.Group();
  pyramidGroup.name = 'mini_stepped_pyramid';

  const sandstoneMat1 = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    roughness: 0.55,
    metalness: 0.15,
  });
  const sandstoneMat2 = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    roughness: 0.6,
    metalness: 0.2,
  });

  const goldTrimMat = new THREE.MeshStandardMaterial({
    color: 0xffd700,
    roughness: 0.15,
    metalness: 0.95,
  });

  const glowingGoldMat = new THREE.MeshStandardMaterial({
    color: 0xffe066,
    emissive: 0xd97706,
    emissiveIntensity: 0.8,
    roughness: 0.1,
    metalness: 0.98,
  });

  let currentY = 0;
  const tierHeight = 0.25;

  for (let i = 0; i < tiers; i++) {
    const tierSize = baseSize * (1 - (i / tiers) * 0.65);

    // Stepped Masonry Box
    const boxGeom = new THREE.BoxGeometry(tierSize, tierHeight, tierSize);
    const tierMesh = new THREE.Mesh(boxGeom, i % 2 === 0 ? sandstoneMat1 : sandstoneMat2);
    tierMesh.position.y = currentY + tierHeight / 2;
    tierMesh.castShadow = true;
    tierMesh.receiveShadow = true;
    pyramidGroup.add(tierMesh);

    // Masonry brick relief grooving around the tier edges
    const numBricks = 1;
    const bW = tierSize / numBricks;
    for (let b = 0; b < numBricks; b++) {
      const brickBevel = new THREE.Mesh(
        new THREE.BoxGeometry(bW * 0.92, tierHeight * 0.88, 0.04),
        sandstoneMat2
      );
      brickBevel.position.set(-tierSize / 2 + bW / 2 + b * bW, currentY + tierHeight / 2, tierSize / 2 + 0.01);
      pyramidGroup.add(brickBevel);
    }

    // Inset golden edge trim
    const rimGeom = new THREE.BoxGeometry(tierSize * 1.02, 0.035, tierSize * 1.02);
    const rimMesh = new THREE.Mesh(rimGeom, goldTrimMat);
    rimMesh.position.y = currentY + tierHeight;
    pyramidGroup.add(rimMesh);

    currentY += tierHeight;
  }

  // Golden Pyramidion (Benben Stone / لووتکەی زێڕینی هەرەم)
  const capstoneSize = baseSize * 0.36;
  const capstoneHeight = 0.52;
  const capstoneGeom = new THREE.ConeGeometry(capstoneSize * 0.72, capstoneHeight, 4);
  const capstoneMesh = new THREE.Mesh(capstoneGeom, glowingGoldMat);
  capstoneMesh.position.y = currentY + capstoneHeight / 2;
  capstoneMesh.rotation.y = Math.PI / 4;
  capstoneMesh.castShadow = true;
  pyramidGroup.add(capstoneMesh);

  // Soft radiant golden light from the pyramidion
  const capLight = new THREE.PointLight(0xf59e0b, 1.8, 6.0);
  capLight.position.y = currentY + capstoneHeight;
  pyramidGroup.add(capLight);

  return { pyramidGroup, capLight };
};

// ============================================================================
// AAA 3D PHARAONIC GOLDEN FIRE BRAZIER (مەشخەڵی فیرعەونی)
// ============================================================================
const create3DPharaonicBrazier = () => {
  const brazierGroup = new THREE.Group();
  brazierGroup.name = 'pharaonic_fire_brazier';

  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xffd700,
    metalness: 0.9,
    roughness: 0.2,
  });

  const stoneBaseMat = new THREE.MeshStandardMaterial({
    color: 0x92400e,
    roughness: 0.5,
    metalness: 0.2,
  });

  const flameMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    emissive: 0xef4444,
    emissiveIntensity: 1.8,
    roughness: 0.1,
    metalness: 0.2,
  });

  // Base Plinth
  const baseMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.4, 0.18, 8), stoneBaseMat);
  baseMesh.position.y = 0.09;
  brazierGroup.add(baseMesh);

  // Pillar Stem
  const stemMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 0.4, 8), stoneBaseMat);
  stemMesh.position.y = 0.38;
  brazierGroup.add(stemMesh);

  // Golden Fire Bowl
  const bowlMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.44, 0.2, 0.2, 12), goldMat);
  bowlMesh.position.y = 0.65;
  brazierGroup.add(bowlMesh);

  // Flame
  const flameMesh = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.4, 8), flameMat);
  flameMesh.position.y = 0.88;
  flameMesh.name = 'brazier_flame';
  brazierGroup.add(flameMesh);

  // Torch Light
  const flameLight = new THREE.PointLight(0xf97316, 2.2, 8.0);
  flameLight.position.y = 0.95;
  brazierGroup.add(flameLight);

  return { brazierGroup, flameLight };
};

// ============================================================================
// 3D GLOWING GAMEPLAY EFFECT TEXTURES (نەخشی درەوشانەوەی زێڕینی جوڵە و دیاریکردن)
// ============================================================================
const createGoldenDestinationGlowTexture = () => {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 256, 256);
    // Soft radial golden glow that completely fades before the edge (stays ONLY inside square)
    const grad = ctx.createRadialGradient(128, 128, 12, 128, 128, 118);
    grad.addColorStop(0, 'rgba(255, 245, 160, 0.95)'); // Warm bright golden core
    grad.addColorStop(0.25, 'rgba(250, 204, 21, 0.85)'); // Rich vibrant gold
    grad.addColorStop(0.55, 'rgba(234, 179, 8, 0.55)');  // Warm amber aura
    grad.addColorStop(0.85, 'rgba(202, 138, 4, 0.20)');  // Soft outer fade
    grad.addColorStop(1.0, 'rgba(0, 0, 0, 0)');          // Transparent square edge boundary

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    // Subtle inner rounded golden boundary line
    ctx.strokeStyle = 'rgba(254, 240, 138, 0.9)';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.roundRect(10, 10, 236, 236, 12);
    ctx.stroke();

    // Corner accent pips
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.fillRect(18, 18, 12, 12);
    ctx.fillRect(226, 18, 12, 12);
    ctx.fillRect(18, 226, 12, 12);
    ctx.fillRect(226, 226, 12, 12);
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
};

const createGoldenOriginGlowTexture = () => {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 256, 256);
    // Subtle golden trail for starting square
    const grad = ctx.createRadialGradient(128, 128, 10, 128, 128, 118);
    grad.addColorStop(0, 'rgba(250, 204, 21, 0.45)');
    grad.addColorStop(0.6, 'rgba(234, 179, 8, 0.25)');
    grad.addColorStop(1.0, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    ctx.strokeStyle = 'rgba(250, 204, 21, 0.6)';
    ctx.lineWidth = 4;
    ctx.setLineDash([12, 8]);
    ctx.beginPath();
    ctx.roundRect(12, 12, 232, 232, 10);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
};

const createSelectedSquareGlowTexture = () => {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 256, 256);
    // Soft golden glowing pulse area
    const grad = ctx.createRadialGradient(128, 128, 8, 128, 128, 118);
    grad.addColorStop(0, 'rgba(254, 240, 138, 0.9)');
    grad.addColorStop(0.35, 'rgba(245, 158, 11, 0.65)');
    grad.addColorStop(0.75, 'rgba(217, 119, 6, 0.3)');
    grad.addColorStop(1.0, 'rgba(0, 0, 0, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    // Glowing inner frame
    ctx.strokeStyle = 'rgba(254, 240, 138, 0.95)';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.roundRect(10, 10, 236, 236, 12);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.needsUpdate = true;
  return tex;
};

interface Chess3DCanvasProps {
  board: ({ type: string; color: 'w' | 'b' } | null)[][];
  selectedSquare: string | null;
  validMoves: Move[];
  lastMove: Move | null;
  isCheck: boolean;
  turn: 'w' | 'b';
  theme: ThemeStyle;
  equippedPieceSkin?: PieceSkinId;
  equippedBoardSkin?: BoardSkinId;
  previewPieceSkin?: PieceSkinId | null;
  previewBoardSkin?: BoardSkinId | null;
  onSquareClick: (square: string) => void;
  cameraPreset: 'perspective' | 'top' | 'black';
  tableThemeStyle?: 'classic' | 'purple' | 'red' | 'blue' | 'green' | 'gold' | 'dark';
  capturedWhite?: string[];
  capturedBlack?: string[];
  playerColor?: 'w' | 'b';
}

const Chess3DCanvasComponent: React.FC<Chess3DCanvasProps> = ({
  board,
  selectedSquare,
  validMoves,
  lastMove,
  isCheck,
  turn,
  theme,
  equippedPieceSkin = 'basalt' as PieceSkinId,
  equippedBoardSkin = 'classic_wood' as BoardSkinId,
  previewPieceSkin = null,
  previewBoardSkin = null,
  onSquareClick,
  cameraPreset,
  tableThemeStyle = 'classic',
  capturedWhite = [],
  capturedBlack = [],
  playerColor = 'w',
}) => {
  const activePieceSkin = previewPieceSkin || equippedPieceSkin;
  const activeBoardSkin = previewBoardSkin || equippedBoardSkin;
  const [sceneReady, setSceneReady] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const piecesGroupRef = useRef<THREE.Group | null>(null);
  const highlightsGroupRef = useRef<THREE.Group | null>(null);
  const dustGroupRef = useRef<THREE.Group | null>(null);
  const boatGroupRef = useRef<THREE.Group | null>(null);
  const boatLightRef = useRef<THREE.PointLight | null>(null);
  const riverGroupRef = useRef<THREE.Group | null>(null);
  const waterPillarsGroupRef = useRef<THREE.Group | null>(null);
  const towerLightsRef = useRef<THREE.PointLight[]>([]);
  const desertGroupRef = useRef<THREE.Group | null>(null);
  const desertPillarsGroupRef = useRef<THREE.Group | null>(null);
  const desertTorchLightsRef = useRef<THREE.PointLight[]>([]);
  const bgTexturesRef = useRef<{ [key: string]: THREE.Texture }>({});
  const waterRipplesRef = useRef<WaterRippleData[]>([]);
  const sinkingPiecesRef = useRef<SinkingCapturePiece[]>([]);
  const tilesMapRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const brazierFlamesRef = useRef<THREE.Mesh[]>([]);
  const piecePoolRef = useRef<Array<{
    group: THREE.Group;
    type: string;
    color: 'w' | 'b';
    square: string | null;
    isCapturedTray?: boolean;
    visible: boolean;
  }>>([]);
  const piecePoolSkinRef = useRef<string>('');
  const highlightPoolRef = useRef<{
    selectedRing: THREE.Mesh;
    selectedPlane: THREE.Mesh;
    validMoveRings: THREE.Mesh[];
    lastMovePlanes: THREE.Mesh[];
    lastMoveLight: THREE.PointLight;
    checkRing: THREE.Mesh;
    normalMoveMat: THREE.MeshBasicMaterial;
    captureMoveMat: THREE.MeshBasicMaterial;
    selectedPlaneMat: THREE.MeshBasicMaterial;
    selectedRingMat: THREE.MeshBasicMaterial;
    destGlowMat: THREE.MeshBasicMaterial;
    originGlowMat: THREE.MeshBasicMaterial;
  } | null>(null);
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const pointerVecRef = useRef<THREE.Vector2>(new THREE.Vector2());
  const targetCamPosRef = useRef<THREE.Vector3>(new THREE.Vector3());
  const targetControlsPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));
  const flagTexRef = useRef<THREE.CanvasTexture | null>(null);
  if (!flagTexRef.current) {
    flagTexRef.current = createKurdistanFlagTexture();
  }

  // Real-Time FPS & Performance Monitor Refs
  const fpsDomRef = useRef<HTMLDivElement>(null);
  const frameCountRef = useRef<number>(0);
  const lastPerfUpdateRef = useRef<number>(performance.now());
  const [showPerfMonitor, setShowPerfMonitor] = useState<boolean>(true);

  // Helper convert algebraic file/rank (e.g., "e4") to 3D world coordinates (X, Z)
  // Board center is (0,0,0). File a-h maps to X = -3.5 to +3.5. Rank 1-8 maps to Z = +3.5 to -3.5 (from white view)
  const squareToWorld = (sq: string) => {
    const fileIndex = sq.charCodeAt(0) - 97; // 'a' -> 0, 'h' -> 7
    const rankIndex = parseInt(sq[1], 10) - 1; // '1' -> 0, '8' -> 7

    const x = fileIndex - 3.5;
    const z = 3.5 - rankIndex;
    return { x, z };
  };

  const worldToSquare = (x: number, z: number): string | null => {
    const fileIndex = Math.round(x + 3.5);
    const rankIndex = Math.round(3.5 - z);

    if (fileIndex < 0 || fileIndex > 7 || rankIndex < 0 || rankIndex > 7) {
      return null;
    }
    const fileChar = String.fromCharCode(97 + fileIndex);
    const rankChar = (rankIndex + 1).toString();
    return `${fileChar}${rankChar}`;
  };

  // Initialize Three.js Scene, Camera, Lights, OrbitControls
  useEffect(() => {
    if (!containerRef.current) return;

    const container = containerRef.current;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    // Scene - Set default background to Royal Winter Ice Castle Aurora or Studio Dark for classic
    const scene = new THREE.Scene();
    if (tableThemeStyle === 'classic') {
      scene.background = getStudioDarkTexture();
    } else {
      const initialBgUrl = getBgUrlForBoardSkin(activeBoardSkin);
      scene.background = getOrPreloadBgTexture(initialBgUrl, (loadedTex) => {
        scene.background = loadedTex;
      });
    }
    sceneRef.current = scene;

    // Camera - lower table on screen with wide cinematic depth
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 10.2, 10.0);
    cameraRef.current = camera;

    // Renderer - Ultra-smooth 60 FPS performance optimization
    const isMobile = typeof window !== 'undefined' && (/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || window.innerWidth < 768);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 1.0 : 1.25));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    // Clear previous canvas if any
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Reset all caches and pools for the new scene
    piecePoolRef.current = [];
    piecePoolSkinRef.current = '';
    tilesMapRef.current.clear();
    waterRipplesRef.current = [];
    sinkingPiecesRef.current = [];

    // Orbit Controls - AAA Mobile 3D Perspective with 360° Orbit & Free Pitch
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minPolarAngle = 0.22; // Comfortable high tilt, avoiding top-pole gimbal lock flip
    controls.maxPolarAngle = Math.PI / 2.25; // Tilt down to table horizon (never dips below table)
    controls.minAzimuthAngle = -Infinity; // Full 360° horizontal rotation
    controls.maxAzimuthAngle = Infinity;  // Full 360° horizontal rotation
    controls.minDistance = 6.8;
    controls.maxDistance = 21.0;
    controls.enablePan = false; // Lock target centered on board to avoid wobble
    controls.target.set(0, 0.05, 0);
    controlsRef.current = controls;

    // Track user drag state
    let isUserDragging = false;
    let autoSnapActive = false;

    controls.addEventListener('start', () => {
      isUserDragging = true;
      autoSnapActive = false;
    });

    controls.addEventListener('end', () => {
      isUserDragging = false;
      autoSnapActive = false;
    });

    // High-Clarity Studio & Mountain Sunlit Lighting setup
    const ambientLight = new THREE.AmbientLight(0xffedd5, 1.4);
    scene.add(ambientLight);

    // Key Light: Warm Sunlit Directional Light with anti-flicker shadow bias
    const dirLight1 = new THREE.DirectionalLight(0xffd7aa, 2.5);
    dirLight1.position.set(8, 18, 12);
    dirLight1.castShadow = true;
    dirLight1.shadow.mapSize.width = isMobile ? 1024 : 2048;
    dirLight1.shadow.mapSize.height = isMobile ? 1024 : 2048;
    dirLight1.shadow.bias = -0.0015;
    dirLight1.shadow.normalBias = 0.05;
    dirLight1.shadow.camera.left = -12;
    dirLight1.shadow.camera.right = 12;
    dirLight1.shadow.camera.top = 12;
    dirLight1.shadow.camera.bottom = -12;
    dirLight1.shadow.camera.near = 0.5;
    dirLight1.shadow.camera.far = 50;
    scene.add(dirLight1);

    // Fill Light: Soft Sky Accent
    const dirLight2 = new THREE.DirectionalLight(0xbae6fd, 1.5);
    dirLight2.position.set(-12, 14, -8);
    scene.add(dirLight2);

    // Rim Light: Gold Back Light for Piece Outlines
    const rimLight = new THREE.DirectionalLight(0xfef08a, 2.0);
    rimLight.position.set(0, 12, -16);
    scene.add(rimLight);

    // Elegant Overhead Downward Spotlight highlighting the glass table's polished facets and crystal reflections
    const tableSpotLight = new THREE.SpotLight(0xffffff, 2.4, 30, Math.PI / 3.8, 0.45, 1.2);
    tableSpotLight.position.set(0, 15, 0);
    tableSpotLight.target.position.set(0, 0, 0);
    scene.add(tableSpotLight);
    scene.add(tableSpotLight.target);

    // Soft Studio Rim Accent for Glass Table Beveled Edges
    const glassEdgeLight = new THREE.PointLight(0xf1f5f9, 1.5, 22);
    glassEdgeLight.position.set(0, 5.0, -8.5);
    scene.add(glassEdgeLight);

    // Cache Ultra-HD Textures for Dynamic Arena Switching
    bgTexturesRef.current.river = getOrPreloadBgTexture(mountainRiverBgImg);
    bgTexturesRef.current.castle = getOrPreloadBgTexture(epicCastleTerraceBgImg);
    bgTexturesRef.current.dragon = getOrPreloadBgTexture(dragonBgImg);
    bgTexturesRef.current.desert = getOrPreloadBgTexture(desertPyramidsBgImg);

    scene.fog = new THREE.FogExp2(0x06070a, 0.002);

    // BUILD 3D ROYAL KURDISTAN CITADEL ENVIRONMENT
    const envGroup = new THREE.Group();
    envGroup.name = 'royal_castle_env';

    // Sleek Dark Luxury Stage Platform matching the background image
    const stageRadius = 8.5;
    const stageGeom = new THREE.CylinderGeometry(stageRadius, stageRadius + 0.8, 0.5, 64);
    const stageMat = new THREE.MeshStandardMaterial({
      color: 0x140e0a,
      roughness: 0.25,
      metalness: 0.6,
    });
    const stagePlatform = new THREE.Mesh(stageGeom, stageMat);
    stagePlatform.position.y = -1.85;
    stagePlatform.receiveShadow = true;
    // envGroup.add(stagePlatform); // Removed to prevent the big black circle glitch when zooming out

    // =========================================================
    // AAA LIQUID CRYSTAL WATER PEDESTAL PILLARS (پایەی ئاو)
    // =========================================================
    const towerLights: THREE.PointLight[] = [];
    const waterOrbs: THREE.Mesh[] = [];
    const waterDropletRings: THREE.Mesh[] = [];
    const waterPillarsGroup = new THREE.Group();
    waterPillarsGroup.name = 'water_pillars_group';

    const waterPillarMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Deep turquoise crystal water
      emissive: 0x0369a1,
      emissiveIntensity: 0.5,
      roughness: 0.1,
      metalness: 0.35,
      transparent: true,
      opacity: 0.88,
    });

    const waterGlowGoldMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 0.95,
      roughness: 0.15,
    });

    const createWaterPillar = (x: number, z: number, pillarIdx: number) => {
      const pillarGroup = new THREE.Group();
      pillarGroup.position.set(x, 0.45, z);

      // 1. Crystal Water Fluted Column (ستوونی ئاوی کریستاڵی)
      const column = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.48, 1.45, 24), waterPillarMat);
      column.position.y = 0.725;
      column.castShadow = true;
      column.receiveShadow = true;
      pillarGroup.add(column);

      // Inner Bioluminescent Core Tube
      const innerCoreGeom = new THREE.CylinderGeometry(0.18, 0.24, 1.35, 16);
      const innerCoreMat = new THREE.MeshBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.65,
      });
      const innerCore = new THREE.Mesh(innerCoreGeom, innerCoreMat);
      innerCore.position.y = 0.725;
      pillarGroup.add(innerCore);

      // 2. Ornate Golden Filigree Trim Rings on Water Column
      const topRing = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.038, 12, 24), waterGlowGoldMat);
      topRing.rotation.x = Math.PI / 2;
      topRing.position.y = 1.38;
      pillarGroup.add(topRing);

      const midRing = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.032, 12, 24), waterGlowGoldMat);
      midRing.rotation.x = Math.PI / 2;
      midRing.position.y = 0.75;
      pillarGroup.add(midRing);

      const bottomRing = new THREE.Mesh(new THREE.TorusGeometry(0.50, 0.042, 12, 24), waterGlowGoldMat);
      bottomRing.rotation.x = Math.PI / 2;
      bottomRing.position.y = 0.15;
      pillarGroup.add(bottomRing);

      // 3. Water Fountain Capital Basin (حەوزی سەری پایەی ئاو)
      const basinGeom = new THREE.CylinderGeometry(0.54, 0.38, 0.35, 20);
      const basin = new THREE.Mesh(basinGeom, waterPillarMat);
      basin.position.y = 1.52;
      basin.castShadow = true;
      pillarGroup.add(basin);

      const basinGoldRim = new THREE.Mesh(new THREE.TorusGeometry(0.54, 0.035, 10, 24), waterGlowGoldMat);
      basinGoldRim.rotation.x = Math.PI / 2;
      basinGoldRim.position.y = 1.68;
      pillarGroup.add(basinGoldRim);

      // 4. Floating & Rotating Royal Water Crystal Sphere / Orb (گۆی ئاوی کریستاڵی درەوشاوە)
      const orbMat = new THREE.MeshStandardMaterial({
        color: 0x38bdf8,
        emissive: 0x0284c7,
        emissiveIntensity: 0.9,
        roughness: 0.08,
        metalness: 0.4,
      });
      const waterOrb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.24, 2), orbMat);
      waterOrb.position.y = 2.05;
      waterOrb.userData = { pillarIdx, baseY: 2.05 };
      pillarGroup.add(waterOrb);
      waterOrbs.push(waterOrb);

      // 5. Orbiting Golden Water Ring / Fountain Droplets
      const ringDropletGeom = new THREE.TorusGeometry(0.38, 0.022, 8, 24);
      const ringDroplet = new THREE.Mesh(ringDropletGeom, waterGlowGoldMat);
      ringDroplet.position.y = 2.05;
      ringDroplet.rotation.x = Math.PI / 3;
      pillarGroup.add(ringDroplet);
      waterDropletRings.push(ringDroplet);

      // 6. Aqua Bioluminescent Radiant Light
      const pLight = new THREE.PointLight(0x38bdf8, 3.2, 14);
      pLight.position.set(x, 2.2, z);
      scene.add(pLight);
      towerLights.push(pLight);

      return pillarGroup;
    };

    // Place 4 AAA Liquid Crystal Water Pillars directly on the 4 Corners (پایەکانی ئاو)
    waterPillarsGroup.add(createWaterPillar(-5.4, -5.4, 0));
    waterPillarsGroup.add(createWaterPillar(5.4, -5.4, 1));
    waterPillarsGroup.add(createWaterPillar(-5.4, 5.4, 2));
    waterPillarsGroup.add(createWaterPillar(5.4, 5.4, 3));

    envGroup.add(waterPillarsGroup);
    waterPillarsGroupRef.current = waterPillarsGroup;
    towerLightsRef.current = towerLights;

    // Set initial visibility of water pillars
    const initIsWater = activeBoardSkin === 'ocean_azure' || activeBoardSkin === 'azure';
    waterPillarsGroup.visible = initIsWater;
    towerLights.forEach((light) => {
      light.visible = initIsWater;
    });

    scene.add(envGroup);

    // Group for Move Dust Particle Effects
    const dustGroup = new THREE.Group();
    scene.add(dustGroup);
    dustGroupRef.current = dustGroup;

    // =========================================================
    // AAA REALISTIC FLOATING BROWN WOODEN BOAT ON RIVER WATER (بەلەمێکی جوان و بچووکی دارین)
    // =========================================================
    const { boatGroup, boatLight } = create3DWoodenBoat();
    boatGroup.position.set(6.8, -3.72, 5.2);
    boatGroup.rotation.y = -0.45;
    boatGroup.visible = initIsWater;
    boatLight.visible = initIsWater;
    scene.add(boatGroup);
    boatGroupRef.current = boatGroup;
    boatLightRef.current = boatLight;

    // =========================================================
    // REALISTIC FLOWING FULL CRYSTAL WATER EXPANSE & RIPPLES (ساحەی فوول ئاو)
    // =========================================================
    const riverGroup = new THREE.Group();
    riverGroup.name = 'flowing_river_system';
    riverGroup.visible = initIsWater;

    // 1. GPU-Accelerated Wave & Caustic Shader Water Expanse (Solid 60 FPS)
    const riverGeom = new THREE.PlaneGeometry(160, 160, 48, 48);
    riverGeom.rotateX(-Math.PI / 2); // Lay flat on XZ plane

    const waterUniforms = {
      uTime: { value: 0 },
      uColorDeep: { value: new THREE.Color(0x0284c7) },
      uColorPeak: { value: new THREE.Color(0x38bdf8) },
      uSunDir: { value: new THREE.Vector3(0.5, 0.8, 0.4).normalize() },
    };

    const riverMat = new THREE.ShaderMaterial({
      uniforms: waterUniforms,
      vertexShader: `
        uniform float uTime;
        varying vec3 vWorldPos;
        varying vec3 vNormal;
        varying vec2 vUv;
        void main() {
          vUv = uv;
          vec3 pos = position;
          // Smooth realistic multi-octave GPU wave displacement
          float w1 = sin(pos.x * 0.28 + uTime * 2.4) * 0.14;
          float w2 = cos(pos.z * 0.38 + uTime * 1.8) * 0.11;
          float w3 = sin((pos.x + pos.z) * 0.22 + uTime * 3.0) * 0.06;
          pos.y += w1 + w2 + w3;

          // Compute analytical normal on GPU
          float dx = cos(pos.x * 0.28 + uTime * 2.4) * 0.28 * 0.14 + cos((pos.x + pos.z) * 0.22 + uTime * 3.0) * 0.22 * 0.06;
          float dz = -sin(pos.z * 0.38 + uTime * 1.8) * 0.38 * 0.11 + cos((pos.x + pos.z) * 0.22 + uTime * 3.0) * 0.22 * 0.06;
          vec3 n = normalize(vec3(-dx, 1.0, -dz));

          vNormal = normalize(normalMatrix * n);
          vec4 worldP = modelMatrix * vec4(pos, 1.0);
          vWorldPos = worldP.xyz;
          gl_Position = projectionMatrix * viewMatrix * worldP;
        }
      `,
      fragmentShader: `
        uniform float uTime;
        uniform vec3 uColorDeep;
        uniform vec3 uColorPeak;
        uniform vec3 uSunDir;
        varying vec3 vWorldPos;
        varying vec3 vNormal;
        varying vec2 vUv;
        void main() {
          vec3 viewDir = normalize(cameraPosition - vWorldPos);
          vec3 normal = normalize(vNormal);

          // Fresnel rim reflection
          float fresnel = pow(1.0 - max(dot(viewDir, normal), 0.0), 2.2);

          // Specular sun highlight
          vec3 halfVec = normalize(uSunDir + viewDir);
          float spec = pow(max(dot(normal, halfVec), 0.0), 32.0);

          // Flowing caustic ripple pattern on GPU
          float ripple = sin(vWorldPos.x * 0.8 + uTime * 3.0) * cos(vWorldPos.z * 0.8 - uTime * 2.5) * 0.5 + 0.5;

          vec3 waterColor = mix(uColorDeep, uColorPeak, fresnel * 0.65 + ripple * 0.2);
          waterColor += vec3(1.0, 0.95, 0.8) * spec * 0.85;

          gl_FragColor = vec4(waterColor, 0.94);
        }
      `,
      transparent: true,
      side: THREE.DoubleSide,
    });

    const riverMesh = new THREE.Mesh(riverGeom, riverMat);
    riverMesh.position.set(0, -3.85, 0);
    riverMesh.receiveShadow = true;
    riverGroup.add(riverMesh);

    // 2. Animated River Water Foam Texture Overlay
    const foamCanvas = document.createElement('canvas');
    foamCanvas.width = 256;
    foamCanvas.height = 256;
    const foamCtx = foamCanvas.getContext('2d');
    if (foamCtx) {
      foamCtx.fillStyle = 'rgba(0,0,0,0)';
      foamCtx.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 32; i++) {
        const x = Math.random() * 256;
        const y = Math.random() * 256;
        const rad = 15 + Math.random() * 35;
        const grad = foamCtx.createRadialGradient(x, y, 0, x, y, rad);
        grad.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
        grad.addColorStop(0.5, 'rgba(186, 230, 253, 0.35)');
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        foamCtx.fillStyle = grad;
        foamCtx.beginPath();
        foamCtx.arc(x, y, rad, 0, Math.PI * 2);
        foamCtx.fill();
      }
    }
    const foamTexture = new THREE.CanvasTexture(foamCanvas);
    foamTexture.wrapS = THREE.RepeatWrapping;
    foamTexture.wrapT = THREE.RepeatWrapping;
    foamTexture.repeat.set(8, 8);

    const foamMat = new THREE.MeshBasicMaterial({
      map: foamTexture,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const foamMesh = new THREE.Mesh(new THREE.PlaneGeometry(160, 160), foamMat);
    foamMesh.rotation.x = -Math.PI / 2;
    foamMesh.position.set(0, -3.82, 0);
    riverGroup.add(foamMesh);

    // 3. AAA Water Splashes & Jumping Droplets (Optimized 40 count)
    const splashCount = 40;
    const splashGeom = new THREE.BufferGeometry();
    const splashPositions = new Float32Array(splashCount * 3);
    const splashVelocities: { vx: number; vy: number; vz: number; baseVy: number }[] = [];

    for (let i = 0; i < splashCount; i++) {
      const rx = (Math.random() - 0.5) * 52;
      const rz = (Math.random() - 0.5) * 52;
      const ry = -3.8 + Math.random() * 0.9;
      splashPositions[i * 3 + 0] = rx;
      splashPositions[i * 3 + 1] = ry;
      splashPositions[i * 3 + 2] = rz;

      const baseVy = 0.05 + Math.random() * 0.16;
      splashVelocities.push({
        vx: (Math.random() - 0.5) * 0.025,
        vy: baseVy,
        vz: (Math.random() - 0.5) * 0.025,
        baseVy,
      });
    }

    splashGeom.setAttribute('position', new THREE.BufferAttribute(splashPositions, 3));

    const splashCanvas = document.createElement('canvas');
    splashCanvas.width = 64;
    splashCanvas.height = 64;
    const sCtx = splashCanvas.getContext('2d');
    if (sCtx) {
      const g = sCtx.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(255, 255, 255, 1.0)');
      g.addColorStop(0.35, 'rgba(186, 230, 253, 0.85)');
      g.addColorStop(0.75, 'rgba(56, 189, 248, 0.35)');
      g.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sCtx.fillStyle = g;
      sCtx.fillRect(0, 0, 64, 64);
    }
    const splashTexture = new THREE.CanvasTexture(splashCanvas);

    const splashMat = new THREE.PointsMaterial({
      size: 0.42,
      map: splashTexture,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const splashParticles = new THREE.Points(splashGeom, splashMat);
    riverGroup.add(splashParticles);

    // 4. Cyan River Water Reflection Light on Citadel Table
    const riverLight = new THREE.PointLight(0x38bdf8, 2.2, 22);
    riverLight.position.set(0, -2.5, 0);
    riverLight.visible = initIsWater;
    scene.add(riverLight);

    scene.add(riverGroup);
    riverGroupRef.current = riverGroup;

    // =========================================================
    // AAA REALISTIC EGYPTIAN SAHARA DESERT & GIZA PYRAMIDS ARENA (ساحەی بیابانی میسر و هەرەمەکان)
    // =========================================================
    const initIsDesert = activeBoardSkin === 'egyptian_pyramids';
    const desertGroup = new THREE.Group();
    desertGroup.name = 'egyptian_desert_pyramids_system';
    desertGroup.visible = initIsDesert;

    // 1. Vast Rippled Golden Sand Dune Floor Expanse
    const duneGeom = new THREE.PlaneGeometry(160, 160, 64, 64);
    duneGeom.rotateX(-Math.PI / 2);
    const posAttr = duneGeom.attributes.position;
    for (let i = 0; i < posAttr.count; i++) {
      const vx = posAttr.getX(i);
      const vz = posAttr.getZ(i);
      // Gentle natural desert sand dune undulations
      const distFromCenter = Math.sqrt(vx * vx + vz * vz);
      if (distFromCenter > 8.5) {
        const duneHeight = Math.sin(vx * 0.08) * Math.cos(vz * 0.06) * 1.8 + Math.sin(vz * 0.12) * 0.9;
        posAttr.setY(i, duneHeight);
      }
    }
    duneGeom.computeVertexNormals();

    const sandMat = new THREE.MeshStandardMaterial({
      color: 0xd97706, // Warm Golden Desert Sand
      roughness: 0.88,
      metalness: 0.08,
      flatShading: false,
    });

    const duneMesh = new THREE.Mesh(duneGeom, sandMat);
    duneMesh.position.set(0, -3.88, 0);
    duneMesh.receiveShadow = true;
    desertGroup.add(duneMesh);

    // 2. Majestic Distant 3D Masonry Giza Pyramids (هەرەمە گەورەکانی جیزە بە خشتی بەردین)
    // Great Pyramid of Giza (Khufu - 8 Tiers of Stacked Masonry Stone Blocks)
    const khufuPyramid = create3DGrandMasonryPyramid(28, 8, 0.25);
    khufuPyramid.position.set(-30, -3.8, -38);
    desertGroup.add(khufuPyramid);

    // Pyramid of Khafre (7 Tiers with glowing Benben Capstone)
    const khafrePyramid = create3DGrandMasonryPyramid(24, 7, -0.3);
    khafrePyramid.position.set(28, -3.8, -44);
    desertGroup.add(khafrePyramid);

    // Pyramid of Menkaure (6 Tiers)
    const menkaurePyramid = create3DGrandMasonryPyramid(18, 6, 0.45);
    menkaurePyramid.position.set(-8, -3.8, -50);
    desertGroup.add(menkaurePyramid);

    // Side Pyramid of Queens
    const queenPyramid = create3DGrandMasonryPyramid(12, 5, -0.15);
    queenPyramid.position.set(-48, -3.8, -25);
    desertGroup.add(queenPyramid);

    // 3. Oasis Clusters of 3D Royal Date Palm Trees (دارخورماکانی دەوروبەری بیابان)
    const palmPositions = [
      { x: -9.5, z: 6.8, s: 1.1 },
      { x: -11.8, z: 4.5, s: 0.9 },
      { x: 9.2, z: -6.5, s: 1.15 },
      { x: 11.5, z: -8.0, s: 0.85 },
      { x: -12.0, z: -8.5, s: 1.05 },
      { x: 10.5, z: 7.2, s: 1.0 },
    ];
    palmPositions.forEach((pos) => {
      const palm = create3DPalmTree(pos.s);
      palm.position.set(pos.x, -3.88, pos.z);
      desertGroup.add(palm);
    });

    // 4. Drifting Golden Sand Dust Particles in Desert Breeze (خۆڵی بیابان)
    const sandDustCount = 200;
    const sandDustGeom = new THREE.BufferGeometry();
    const sandDustPositions = new Float32Array(sandDustCount * 3);
    const sandDustVelocities: { vx: number; vy: number; vz: number }[] = [];

    for (let i = 0; i < sandDustCount; i++) {
      sandDustPositions[i * 3 + 0] = (Math.random() - 0.5) * 50;
      sandDustPositions[i * 3 + 1] = -3.5 + Math.random() * 8.0;
      sandDustPositions[i * 3 + 2] = (Math.random() - 0.5) * 50;

      sandDustVelocities.push({
        vx: 0.02 + Math.random() * 0.05,
        vy: (Math.random() - 0.5) * 0.015,
        vz: 0.01 + Math.random() * 0.03,
      });
    }

    sandDustGeom.setAttribute('position', new THREE.BufferAttribute(sandDustPositions, 3));

    const sandDustCanvas = document.createElement('canvas');
    sandDustCanvas.width = 64;
    sandDustCanvas.height = 64;
    const sdCtx = sandDustCanvas.getContext('2d');
    if (sdCtx) {
      const g = sdCtx.createRadialGradient(32, 32, 0, 32, 32, 32);
      g.addColorStop(0, 'rgba(254, 240, 138, 0.95)');
      g.addColorStop(0.4, 'rgba(245, 158, 11, 0.65)');
      g.addColorStop(1, 'rgba(0, 0, 0, 0)');
      sdCtx.fillStyle = g;
      sdCtx.fillRect(0, 0, 64, 64);
    }
    const sandDustTexture = new THREE.CanvasTexture(sandDustCanvas);

    const sandDustMat = new THREE.PointsMaterial({
      size: 0.35,
      map: sandDustTexture,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const sandDustParticles = new THREE.Points(sandDustGeom, sandDustMat);
    desertGroup.add(sandDustParticles);

    // Warm Sun Amber Ambient Lighting for Desert
    const desertSunLight = new THREE.PointLight(0xf59e0b, 2.5, 25);
    desertSunLight.position.set(0, 8, -6);
    desertSunLight.visible = initIsDesert;
    desertGroup.add(desertSunLight);

    scene.add(desertGroup);
    desertGroupRef.current = desertGroup;

    // 5. Desert Pillars Group for 4 Board Corner Bastions with Pharaonic Braziers & Torches
    const desertPillarsGroup = new THREE.Group();
    desertPillarsGroup.name = 'desert_pillars_group';
    desertPillarsGroup.visible = initIsDesert;
    const desertTorchLights: THREE.PointLight[] = [];

    const brazierFlames: THREE.Mesh[] = [];
    const createEgyptianCornerBastionGroup = (cx: number, cz: number) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(cx, -0.05, cz);

      // Mini Stepped Pyramid Base
      const { pyramidGroup, capLight } = create3DMiniPyramid(1.6, 4);
      pyramidGroup.scale.set(0.9, 0.9, 0.9);
      bGroup.add(pyramidGroup);
      desertTorchLights.push(capLight);

      // Mini Royal Oasis Palm Tree on outer corner
      const miniPalm = create3DPalmTree(0.55);
      miniPalm.position.set(Math.sign(cx) * 0.45, 0.2, Math.sign(cz) * 0.45);
      bGroup.add(miniPalm);

      // Pharaonic Fire Brazier on inner step
      const { brazierGroup, flameLight } = create3DPharaonicBrazier();
      brazierGroup.position.set(0, 1.25, 0);
      brazierGroup.scale.set(0.7, 0.7, 0.7);
      bGroup.add(brazierGroup);
      desertTorchLights.push(flameLight);

      const flame = brazierGroup.getObjectByName('brazier_flame') as THREE.Mesh | null;
      if (flame) brazierFlames.push(flame);

      return bGroup;
    };

    desertPillarsGroup.add(createEgyptianCornerBastionGroup(-5.4, -5.4));
    desertPillarsGroup.add(createEgyptianCornerBastionGroup(5.4, -5.4));
    desertPillarsGroup.add(createEgyptianCornerBastionGroup(-5.4, 5.4));
    desertPillarsGroup.add(createEgyptianCornerBastionGroup(5.4, 5.4));

    envGroup.add(desertPillarsGroup);
    desertPillarsGroupRef.current = desertPillarsGroup;
    desertTorchLightsRef.current = desertTorchLights;
    desertTorchLights.forEach((l) => { l.visible = initIsDesert; });
    brazierFlamesRef.current = brazierFlames;

    // Groups for board objects, pieces, and 3D highlights
    const piecesGroup = new THREE.Group();
    scene.add(piecesGroup);
    piecesGroupRef.current = piecesGroup;

    const highlightsGroup = new THREE.Group();
    scene.add(highlightsGroup);
    highlightsGroupRef.current = highlightsGroup;

    // Pre-create persistent Highlight Mesh Pool with Golden Glow Game Effects
    const destGlowTex = createGoldenDestinationGlowTexture();
    const originGlowTex = createGoldenOriginGlowTexture();
    const selectedGlowTex = createSelectedSquareGlowTexture();

    const selectedRingGeom = new THREE.RingGeometry(0.30, 0.44, 32);
    const selectedRingMat = new THREE.MeshBasicMaterial({ color: 0xffe066, side: THREE.DoubleSide, transparent: true, opacity: 0.9, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const selectedRing = new THREE.Mesh(selectedRingGeom, selectedRingMat);
    selectedRing.rotation.x = -Math.PI / 2;
    selectedRing.visible = false;
    highlightsGroup.add(selectedRing);

    const selectedPlaneGeom = new THREE.PlaneGeometry(0.96, 0.96);
    const selectedPlaneMat = new THREE.MeshBasicMaterial({ map: selectedGlowTex, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const selectedPlane = new THREE.Mesh(selectedPlaneGeom, selectedPlaneMat);
    selectedPlane.rotation.x = -Math.PI / 2;
    selectedPlane.visible = false;
    highlightsGroup.add(selectedPlane);

    const validMoveRingGeom = new THREE.RingGeometry(0.12, 0.38, 32);
    const normalMoveMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, side: THREE.DoubleSide, transparent: true, opacity: 0.85, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const captureMoveMat = new THREE.MeshBasicMaterial({ color: 0xff3355, side: THREE.DoubleSide, transparent: true, opacity: 0.85, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const validMoveRings: THREE.Mesh[] = [];
    for (let i = 0; i < 36; i++) {
      const ring = new THREE.Mesh(validMoveRingGeom, normalMoveMat);
      ring.name = 'valid_move_ring';
      ring.rotation.x = -Math.PI / 2;
      ring.visible = false;
      highlightsGroup.add(ring);
      validMoveRings.push(ring);
    }

    const lastMovePlaneGeom = new THREE.PlaneGeometry(0.96, 0.96);
    const originGlowMat = new THREE.MeshBasicMaterial({ map: originGlowTex, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const destGlowMat = new THREE.MeshBasicMaterial({ map: destGlowTex, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });

    const originPlane = new THREE.Mesh(lastMovePlaneGeom, originGlowMat);
    originPlane.rotation.x = -Math.PI / 2;
    originPlane.visible = false;
    highlightsGroup.add(originPlane);

    const destPlane = new THREE.Mesh(lastMovePlaneGeom, destGlowMat);
    destPlane.rotation.x = -Math.PI / 2;
    destPlane.visible = false;
    highlightsGroup.add(destPlane);

    const lastMovePlanes: THREE.Mesh[] = [originPlane, destPlane];

    // Soft 3D Golden Light for destination square
    const lastMoveLight = new THREE.PointLight(0xfacc15, 1.8, 1.6);
    lastMoveLight.position.set(0, 0.22, 0);
    lastMoveLight.visible = false;
    highlightsGroup.add(lastMoveLight);

    const checkRingGeom = new THREE.RingGeometry(0.2, 0.48, 32);
    const checkRingMat = new THREE.MeshBasicMaterial({ color: 0xff0000, side: THREE.DoubleSide, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const checkRing = new THREE.Mesh(checkRingGeom, checkRingMat);
    checkRing.rotation.x = -Math.PI / 2;
    checkRing.visible = false;
    highlightsGroup.add(checkRing);

    highlightPoolRef.current = {
      selectedRing,
      selectedPlane,
      validMoveRings,
      lastMovePlanes,
      lastMoveLight,
      checkRing,
      normalMoveMat,
      captureMoveMat,
      selectedPlaneMat,
      selectedRingMat,
      destGlowMat,
      originGlowMat,
    };

    // Animation Loop
    let animId: number;
    let clock = new THREE.Clock();
    let governorStart = performance.now();
    let governorLowStreak = 0;
    let governorLevel = 0;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      controls.update();

      // Real-Time Lightweight FPS & Performance Telemetry (Zero React Re-render)
      const perfNow = performance.now();
      frameCountRef.current++;
      if (perfNow - lastPerfUpdateRef.current >= 250) {
        const elapsedSec = (perfNow - lastPerfUpdateRef.current) / 1000;
        const currentFps = Math.round(frameCountRef.current / elapsedSec);
        const frameTimeMs = (1000 / Math.max(1, currentFps)).toFixed(1);
        frameCountRef.current = 0;
        lastPerfUpdateRef.current = perfNow;

        // Adaptive quality governor (no visual change on devices that hold 60 FPS):
        // if a device stays well below 60 FPS for ~2 s, lower the render
        // resolution one step at a time so moves and animations stay smooth.
        // Skipped for the first 5 s (scene warm-up) and after the tab was hidden.
        if (elapsedSec <= 1 && perfNow - governorStart > 5000) {
          if (currentFps < 45) governorLowStreak++; else governorLowStreak = 0;
          if (governorLowStreak >= 8 && governorLevel < 2) {
            governorLevel++;
            governorLowStreak = 0;
            const target = governorLevel === 1 ? Math.min(renderer.getPixelRatio(), 1.0) : 0.75;
            renderer.setPixelRatio(target);
          }
        }

        if (fpsDomRef.current && renderer) {
          const info = renderer.info;
          const calls = info.render.calls;
          const triangles = info.render.triangles;
          const geometries = info.memory.geometries;
          const textures = info.memory.textures;

          const perfMem = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
          const memMB = perfMem ? (perfMem.usedJSHeapSize / (1024 * 1024)).toFixed(0) + ' MB' : null;

          let colorClass = 'text-emerald-400';
          let statusDot = '🟢';
          let statusText = 'Excellent';
          if (currentFps >= 55) {
            colorClass = 'text-emerald-400';
            statusDot = '🟢';
            statusText = 'Excellent';
          } else if (currentFps >= 40) {
            colorClass = 'text-yellow-400';
            statusDot = '🟡';
            statusText = 'Medium';
          } else if (currentFps >= 30) {
            colorClass = 'text-orange-400';
            statusDot = '🟠';
            statusText = 'Low';
          } else {
            colorClass = 'text-red-400';
            statusDot = '🔴';
            statusText = 'Very Low';
          }

          const triStr = triangles > 1000 ? `${(triangles / 1000).toFixed(1)}k` : `${triangles}`;

          fpsDomRef.current.innerHTML = `
            <div class="flex items-center justify-between gap-3 pb-1 border-b border-white/10">
              <div class="flex items-center gap-1.5">
                <span class="text-xs">${statusDot}</span>
                <span class="text-xs font-mono font-black ${colorClass}">${currentFps} FPS</span>
                <span class="text-[9px] font-sans px-1 py-0.2 rounded bg-white/10 text-slate-300 font-semibold">${statusText}</span>
              </div>
              <span class="text-[10px] font-mono text-slate-400">${frameTimeMs} ms</span>
            </div>
            <div class="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[9px] font-mono pt-1 text-slate-300">
              <div>Draw Calls: <span class="text-white font-bold">${calls}</span></div>
              <div>Triangles: <span class="text-white font-bold">${triStr}</span></div>
              <div>Geometries: <span class="text-white font-bold">${geometries}</span></div>
              <div>Textures: <span class="text-white font-bold">${textures}</span></div>
              ${memMB ? `<div class="col-span-2 text-slate-400">Memory: <span class="text-sky-300 font-bold">${memMB}</span></div>` : ''}
            </div>
          `;
        }
      }

      const time = clock.getElapsedTime();
      const isWaterThemeNow = riverGroupRef.current?.visible || false;
      const isDesertThemeNow = desertGroupRef.current?.visible || false;

      // 0. Auto-Snap Camera Back to Standard Straight Alignment when drag is released (zero-allocation vector math)
      if (!isUserDragging && autoSnapActive) {
        const container = containerRef.current;
        if (container && cameraRef.current) {
          const w = container.clientWidth || window.innerWidth;
          const h = container.clientHeight || window.innerHeight;
          const aspect = w / h;
          const distScale = aspect < 0.65 ? 1.24 : aspect < 1.0 ? 1.10 : 1.0;

          const isBlackSide = cameraPreset === 'black' || (cameraPreset === 'perspective' && playerColor === 'b');
          let targetX = 0;
          let targetY = 9.8 * distScale;
          let targetZ = isBlackSide ? -10.5 * distScale : 10.5 * distScale;
          if (cameraPreset === 'top') {
            targetY = 18.5 * distScale;
            targetZ = 0.0001;
          }

          targetCamPosRef.current.set(targetX, targetY, targetZ);
          targetControlsPosRef.current.set(0, 0.05, 0);

          camera.position.lerp(targetCamPosRef.current, 0.18);
          controls.target.lerp(targetControlsPosRef.current, 0.18);

          // Once extremely close, finalize snap
          if (camera.position.distanceTo(targetCamPosRef.current) < 0.02) {
            camera.position.copy(targetCamPosRef.current);
            controls.target.set(0, 0.05, 0);
            autoSnapActive = false;
          }
        }
      }

      // 1. Animate Liquid Crystal Water Pillars & Orbs (پایەی ئاو)
      if (isWaterThemeNow) {
        towerLights.forEach((light, idx) => {
          light.intensity = 3.0 + Math.sin(time * 3.5 + idx * 1.5) * 0.5;
        });
        waterOrbs.forEach((orb) => {
          orb.rotation.y = time * 1.6;
          orb.rotation.x = Math.sin(time * 2.2) * 0.25;
          const pIdx = orb.userData.pillarIdx || 0;
          const bY = orb.userData.baseY || 2.05;
          orb.position.y = bY + Math.sin(time * 3.2 + pIdx * 1.57) * 0.07;
        });
        waterDropletRings.forEach((ring, rIdx) => {
          ring.rotation.z = time * 2.4 + rIdx * 0.8;
          ring.rotation.y = time * 1.4 + rIdx * 0.5;
        });

        // 2. Animate Flowing River Water Waves & Caustics on GPU (Zero CPU Overhead - Solid 60 FPS)
        waterUniforms.uTime.value = time;

        // Animate Jumping Water Splash Droplets ("ماپسی خوی هەلبدات")
        if (splashGeom && splashPositions) {
          const sArr = splashGeom.attributes.position.array as Float32Array;
          for (let i = 0; i < splashCount; i++) {
            const vel = splashVelocities[i];
            sArr[i * 3 + 0] += vel.vx;
            sArr[i * 3 + 1] += vel.vy;
            sArr[i * 3 + 2] += vel.vz;

            vel.vy -= 0.0055; // Gravity pulling droplet down

            if (sArr[i * 3 + 1] < -3.85) {
              sArr[i * 3 + 1] = -3.82;
              vel.vy = vel.baseVy * (0.8 + Math.random() * 0.5); // Splash jump!
              sArr[i * 3 + 0] = (Math.random() - 0.5) * 52;
              sArr[i * 3 + 2] = (Math.random() - 0.5) * 52;
            }
          }
          splashGeom.attributes.position.needsUpdate = true;
        }

        if (foamTexture) {
          foamTexture.offset.x += 0.0012;
          foamTexture.offset.y += 0.0022;
        }

        if (riverLight) {
          riverLight.intensity = 1.8 + Math.sin(time * 3.0) * 0.4;
        }

        // Animate Realistic Gentle Water Bobbing & Floating Dynamics for Wooden Boat (بەلەمێکی قاوەیی سەر ئاو)
        if (boatGroupRef.current) {
          const boat = boatGroupRef.current;
          boat.position.y = -3.72 + Math.sin(time * 1.6) * 0.045 + Math.cos(time * 0.9) * 0.02;
          boat.rotation.x = Math.sin(time * 1.3) * 0.035;
          boat.rotation.z = Math.cos(time * 1.5) * 0.04;
          boat.rotation.y = -0.45 + Math.sin(time * 0.4) * 0.03;

          if (boatLightRef.current) {
            boatLightRef.current.intensity = 2.0 + Math.sin(time * 4.0) * 0.35 + Math.cos(time * 7.0) * 0.15;
          }
        }
      }

      // 3. Animate Move Dust Puff Particles
      if (dustGroupRef.current && dustGroupRef.current.children.length > 0) {
        for (let i = dustGroupRef.current.children.length - 1; i >= 0; i--) {
          const p = dustGroupRef.current.children[i] as THREE.Mesh;
          if (p.userData && p.userData.vx !== undefined) {
            p.position.x += p.userData.vx;
            p.position.y += p.userData.vy;
            p.position.z += p.userData.vz;
            p.userData.vy -= 0.0012; // gravity
            p.userData.life -= 0.035;
            p.scale.multiplyScalar(0.97);

            if (p.material instanceof THREE.Material) {
              p.material.opacity = Math.max(0, p.userData.life);
            }

            if (p.userData.life <= 0) {
              dustGroupRef.current.remove(p);
              if (p.geometry) p.geometry.dispose();
            }
          }
        }
      }

      // 4. Animate Water Move Ripples & Splash Droplets on Board
      if (waterRipplesRef.current.length > 0) {
        for (let i = waterRipplesRef.current.length - 1; i >= 0; i--) {
          const ripple = waterRipplesRef.current[i];
          ripple.age += 1;
          const progress = ripple.age / ripple.maxAge;

          // Expand ring & fade out
          const scale = 1.0 + progress * 3.8;
          ripple.ringMesh.scale.set(scale, scale, scale);
          (ripple.ringMesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, (1 - progress) * 0.9);

          // Animate splash droplets
          const posArr = ripple.splashPositions;
          for (let p = 0; p < ripple.splashVelocities.length; p++) {
            const vel = ripple.splashVelocities[p];
            posArr[p * 3 + 0] += vel.vx;
            posArr[p * 3 + 1] += vel.vy;
            posArr[p * 3 + 2] += vel.vz;

            vel.vy -= 0.009; // Gravity
          }
          ripple.splashParticles.geometry.attributes.position.needsUpdate = true;
          (ripple.splashParticles.material as THREE.PointsMaterial).opacity = Math.max(0, 1 - progress);

          if (ripple.age >= ripple.maxAge) {
            if (sceneRef.current) {
              sceneRef.current.remove(ripple.ringMesh);
              sceneRef.current.remove(ripple.splashParticles);
              ripple.ringMesh.geometry.dispose();
              (ripple.ringMesh.material as THREE.Material).dispose();
              ripple.splashParticles.geometry.dispose();
              (ripple.splashParticles.material as THREE.Material).dispose();
            }
            waterRipplesRef.current.splice(i, 1);
          }
        }
      }

      // 4b. Animate Swallowing Water Vortex Piece Captures ("ئاو بیخوات")
      if (sinkingPiecesRef.current.length > 0) {
        for (let i = sinkingPiecesRef.current.length - 1; i >= 0; i--) {
          const sinking = sinkingPiecesRef.current[i];
          sinking.age += 1;
          const progress = sinking.age / sinking.maxAge;

          // Sinking Piece: Spin rapidly around Y-axis, tilt on X/Z, plunge into water, shrink & dissolve
          sinking.group.rotation.y += 0.16 + progress * 0.12;
          sinking.group.rotation.x = Math.sin(progress * Math.PI) * 0.55;
          sinking.group.rotation.z = Math.cos(progress * Math.PI) * 0.42;
          sinking.group.position.y = 0.04 - Math.pow(progress, 1.4) * 1.1; // Plunges down into water depth

          const scale = Math.max(0.01, 1.0 - Math.pow(progress, 1.15) * 0.88);
          sinking.group.scale.set(scale, scale, scale);

          // Fade piece materials
          sinking.group.traverse((child) => {
            if (child instanceof THREE.Mesh && child.material) {
              if (Array.isArray(child.material)) {
                child.material.forEach((m) => {
                  m.transparent = true;
                  m.opacity = Math.max(0, (1 - progress * 1.15));
                });
              } else {
                child.material.transparent = true;
                child.material.opacity = Math.max(0, (1 - progress * 1.15));
              }
            }
          });

          // Whirlpool Vortex Rings: Spin oppositely and pulse scale
          if (sinking.vortexRings.length >= 3) {
            sinking.vortexRings[0].rotation.z += 0.14;
            sinking.vortexRings[1].rotation.z -= 0.20;
            sinking.vortexRings[2].rotation.z += 0.16;

            const ringScale = progress < 0.35 ? 1.0 + (progress / 0.35) * 0.45 : 1.45 * (1 - (progress - 0.35) / 0.65);
            sinking.vortexRings.forEach((ring) => {
              ring.scale.set(ringScale, ringScale, ringScale);
              (ring.material as THREE.MeshBasicMaterial).opacity = Math.max(0, (1 - progress) * 0.95);
            });
          }

          // Bubbles Particles: Swirl tangentially around vortex center while rising
          const bPos = sinking.bubblePositions;
          for (let p = 0; p < sinking.bubbleVelocities.length; p++) {
            const v = sinking.bubbleVelocities[p];
            // Tangential vortex suction drift
            const dx = bPos[p * 3 + 0] - sinking.x;
            const dz = bPos[p * 3 + 2] - sinking.z;
            bPos[p * 3 + 0] += v.vx - dz * 0.045;
            bPos[p * 3 + 1] += v.vy;
            bPos[p * 3 + 2] += v.vz + dx * 0.045;

            v.vy -= 0.0035; // Gravity
          }
          sinking.bubblesParticles.geometry.attributes.position.needsUpdate = true;
          (sinking.bubblesParticles.material as THREE.PointsMaterial).opacity = Math.max(0, 1 - progress);

          // Cleanup when complete
          if (sinking.age >= sinking.maxAge) {
            if (sceneRef.current) {
              sceneRef.current.remove(sinking.group);
              sinking.vortexRings.forEach((r) => {
                sceneRef.current?.remove(r);
                r.geometry.dispose();
                (r.material as THREE.Material).dispose();
              });
              sceneRef.current.remove(sinking.bubblesParticles);
              sinking.bubblesParticles.geometry.dispose();
              (sinking.bubblesParticles.material as THREE.Material).dispose();

              // Dispose piece meshes
              sinking.group.traverse((c) => {
                if (c instanceof THREE.Mesh) {
                  if (c.geometry) c.geometry.dispose();
                  if (c.material) {
                    if (Array.isArray(c.material)) c.material.forEach((m) => m.dispose());
                    else c.material.dispose();
                  }
                }
              });
            }
            sinkingPiecesRef.current.splice(i, 1);
          }
        }
      }

      // Subtle float glow for legal move indicators
      highlightsGroup.children.forEach((child) => {
        if (child.name === 'valid_move_ring' && child.visible) {
          child.rotation.z += 0.01;
        }
      });

      // 3D Golden Pulse for Selected Square & Destination Glow Modulation
      if (highlightPoolRef.current) {
        if (highlightPoolRef.current.selectedPlane.visible) {
          const pulse = 0.55 + 0.35 * Math.sin(time * 4.2);
          highlightPoolRef.current.selectedPlaneMat.opacity = pulse;
          highlightPoolRef.current.selectedRingMat.opacity = 0.6 + 0.3 * Math.sin(time * 4.2);
        }
        if (highlightPoolRef.current.lastMoveLight.visible) {
          highlightPoolRef.current.lastMoveLight.intensity = 1.6 + 0.3 * Math.sin(time * 3.0);
        }
      }

      // 4c. Animate Desert Arena: Direct Brazier Flame Flickering (O(1) direct list) & Drifting Sand Dust
      if (isDesertThemeNow && desertGroupRef.current) {
        // Animate drifting sand dust particles
        const sandPoints = desertGroupRef.current.children.find(c => c instanceof THREE.Points) as THREE.Points | undefined;
        if (sandPoints) {
          const sPos = sandPoints.geometry.attributes.position.array as Float32Array;
          for (let pIdx = 0; pIdx < sPos.length / 3; pIdx++) {
            sPos[pIdx * 3 + 0] += 0.035; // Gentle horizontal breeze drift
            sPos[pIdx * 3 + 1] += Math.sin(time * 2.0 + pIdx) * 0.008;
            sPos[pIdx * 3 + 2] += 0.015;

            // Wrap around
            if (sPos[pIdx * 3 + 0] > 25) sPos[pIdx * 3 + 0] = -25;
            if (sPos[pIdx * 3 + 2] > 25) sPos[pIdx * 3 + 2] = -25;
          }
          sandPoints.geometry.attributes.position.needsUpdate = true;
        }

        // Animate Pharaonic Brazier flame flickering directly without scene traversal
        brazierFlamesRef.current.forEach((obj) => {
          const flicker = Math.sin(time * 14.0 + obj.id * 0.7) * 0.12 + Math.cos(time * 21.0) * 0.08;
          obj.scale.set(1.0 + flicker * 0.6, 1.0 + flicker * 1.3, 1.0 + flicker * 0.6);
          obj.rotation.y += 0.04;
        });
      }

      // 5. Gentle Aquatic Buoyancy Floating Oscillation for Chess Pieces on Water Board
      if (isWaterThemeNow && piecesGroupRef.current) {
        piecesGroupRef.current.children.forEach((child) => {
          if (child.userData && child.userData.square) {
            const sq = child.userData.square;
            const fileCode = sq.charCodeAt(0) - 97;
            const rankNum = parseInt(sq[1], 10) - 1;
            const floatY =
              0.04 +
              Math.sin(time * 2.2 + fileCode * 0.65 + rankNum * 0.55) * 0.024 +
              Math.cos(time * 1.6 + fileCode * 0.8) * 0.012;
            const floatRotZ = Math.sin(time * 1.8 + fileCode) * 0.016;
            const floatRotX = Math.cos(time * 1.5 + rankNum) * 0.014;
            child.position.y = floatY;
            child.rotation.z = floatRotZ;
            child.rotation.x = floatRotX;
          }
        });
      }

      renderer.render(scene, camera);
    };
    animate();

    // ResizeObserver for clean responsiveness and auto mobile re-framing
    const resizeObserver = new ResizeObserver(() => {
      if (!containerRef.current || !renderer || !camera) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
        updateCameraPosition();
      }
    });
    resizeObserver.observe(container);
    setSceneReady(true);

    return () => {
      soundManager.stopAllAmbience();
      cancelAnimationFrame(animId);
      resizeObserver.disconnect();
      piecePoolRef.current = [];
      piecePoolSkinRef.current = '';
      tilesMapRef.current.clear();
      waterRipplesRef.current = [];
      sinkingPiecesRef.current = [];
      renderer.dispose();
      setSceneReady(false);
    };
  }, []);

  // Dynamically update 3D Arena Environment (Water Realm vs Desert Pyramids vs Dragon Castle vs Standard Classic Royal Arena)
  useEffect(() => {
    if (!sceneRef.current) return;
    const isWaterTheme = activeBoardSkin === 'ocean_azure' || activeBoardSkin === 'azure';
    const isDesertTheme = activeBoardSkin === 'egyptian_pyramids';
    const isDragonTheme = activeBoardSkin === 'dragon_arena' || activeBoardSkin === 'dragon_glass_castle';

    if (riverGroupRef.current) riverGroupRef.current.visible = isWaterTheme;
    if (boatGroupRef.current) boatGroupRef.current.visible = isWaterTheme;
    if (boatLightRef.current) boatLightRef.current.visible = isWaterTheme;
    if (waterPillarsGroupRef.current) waterPillarsGroupRef.current.visible = isWaterTheme;
    towerLightsRef.current.forEach((light) => {
      light.visible = isWaterTheme;
    });

    if (desertGroupRef.current) {
      desertGroupRef.current.visible = isDesertTheme;
    }
    if (desertPillarsGroupRef.current) desertPillarsGroupRef.current.visible = isDesertTheme;
    desertTorchLightsRef.current.forEach((light) => {
      light.visible = isDesertTheme;
    });

    if (isWaterTheme) {
      if (bgTexturesRef.current.river) {
        sceneRef.current.background = bgTexturesRef.current.river;
      }
      soundManager.startRiverAmbience();
      soundManager.stopDesertAmbience();
    } else if (isDesertTheme) {
      if (bgTexturesRef.current.desert) {
        sceneRef.current.background = bgTexturesRef.current.desert;
      }
      soundManager.stopRiverAmbience();
      soundManager.startDesertAmbience();
    } else if (isDragonTheme) {
      if (bgTexturesRef.current.dragon) {
        sceneRef.current.background = bgTexturesRef.current.dragon;
      }
      soundManager.stopRiverAmbience();
      soundManager.stopDesertAmbience();
    } else {
      // Default: Clean, dark luxury studio vignette environment matching IMG_4754.jpeg
      sceneRef.current.background = getStudioDarkTexture();
      soundManager.stopRiverAmbience();
      soundManager.stopDesertAmbience();
    }
  }, [activeBoardSkin, sceneReady]);

  // Update camera position when cameraPreset or playerColor changes
  useEffect(() => {
    updateCameraPosition();
  }, [cameraPreset, playerColor]);

  // Update Camera position according to preset and screen aspect ratio
  const updateCameraPosition = () => {
    if (!cameraRef.current || !containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    const aspect = width / height;

    const camera = cameraRef.current;
    const controls = controlsRef.current;

    // Dynamically scale FOV and distance so board fits cleanly on both mobile portrait and desktop screens
    if (aspect < 0.65) {
      camera.fov = 52;
    } else if (aspect < 1.0) {
      camera.fov = 44;
    } else {
      camera.fov = 38;
    }
    camera.updateProjectionMatrix();

    const distScale = aspect < 0.65 ? 1.24 : aspect < 1.0 ? 1.10 : 1.0;
    const isBlackView = cameraPreset === 'black' || (cameraPreset === 'perspective' && playerColor === 'b');

    if (cameraPreset === 'top') {
      // Clean 2D Flat Top View - High altitude spacious overhead view
      camera.position.set(0, 18.5 * distScale, 0.0001);
      if (controls) {
        controls.target.set(0, 0.05, 0);
        controls.enableRotate = false;
        controls.enableZoom = false;
        controls.enablePan = false;
        controls.update();
      }
    } else if (isBlackView) {
      // 3D perspective from Black side (Consistent centered pivot)
      camera.position.set(0, 9.8 * distScale, -10.5 * distScale);
      if (controls) {
        controls.target.set(0, 0.05, 0);
        controls.enableRotate = true;
        controls.enableZoom = true;
        controls.enablePan = false;
        controls.minPolarAngle = 0.22;
        controls.maxPolarAngle = Math.PI / 2.25;
        controls.minAzimuthAngle = -Infinity;
        controls.maxAzimuthAngle = Infinity;
        controls.minDistance = 6.8;
        controls.maxDistance = 21.0;
        controls.update();
      }
    } else {
      // AAA 3D perspective default from White side
      camera.position.set(0, 9.8 * distScale, 10.5 * distScale);
      if (controls) {
        controls.target.set(0, 0.05, 0);
        controls.enableRotate = true;
        controls.enableZoom = true;
        controls.enablePan = false;
        controls.minPolarAngle = 0.22;
        controls.maxPolarAngle = Math.PI / 2.25;
        controls.minAzimuthAngle = -Infinity;
        controls.maxAzimuthAngle = Infinity;
        controls.minDistance = 6.8;
        controls.maxDistance = 21.0;
        controls.update();
      }
    }
  };

  // Helper to create 2D text texture for rank/file board notation
  const createTextTexture = (text: string, color = '#f5e6be') => {
    const canvas = document.createElement('canvas');
    canvas.width = 128;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, 128, 128);
      ctx.font = 'bold 72px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = color;
      ctx.fillText(text, 64, 64);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.needsUpdate = true;
    return texture;
  };

  // Re-build 3D Chess Board tiles and border when theme changes
  useEffect(() => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;

    // Remove existing board mesh if present
    const existingBoard = scene.getObjectByName('chess_board_wrapper');
    if (existingBoard) {
      existingBoard.traverse((child) => {
        if (child.isMesh) {
          child.geometry.dispose();
          if (child.material) {
            if (Array.isArray(child.material)) {
              child.material.forEach(m => m.dispose());
            } else {
              child.material.dispose();
            }
          }
        }
      });
      scene.remove(existingBoard);
    }

    const boardWrapper = new THREE.Group();
    boardWrapper.name = 'chess_board_wrapper';

    const materials = getMaterialsForCustomSkins(activePieceSkin, activeBoardSkin);
    tilesMapRef.current.clear();

    const isWaterTheme = activeBoardSkin === 'ocean_azure' || activeBoardSkin === 'azure';
    const isDesertTheme = activeBoardSkin === 'egyptian_pyramids';
    const isPurpleTheme = tableThemeStyle === 'purple' || activeBoardSkin === 'lavender' || activeBoardSkin === 'galaxy_star';
    const isClassicBWTheme = tableThemeStyle === 'classic';

    // Override board & piece materials for Classic Luxury Arena (Exact clone of IMG_4754.jpeg)
    if (isClassicBWTheme) {
      materials.boardLight = new THREE.MeshStandardMaterial({
        color: 0xffffff, // Crisp Porcelain White Tile (Exact match IMG_4754.jpeg)
        roughness: 0.12,
        metalness: 0.05,
      });
      materials.boardDark = new THREE.MeshStandardMaterial({
        color: 0x8291a0, // Sleek Modern Silver-Grey Tile (Exact match IMG_4754.jpeg)
        roughness: 0.14,
        metalness: 0.22,
      });
      materials.border = new THREE.MeshStandardMaterial({
        color: 0xf8fafc, // Porcelain White matching the outer unibody frame (Exact match IMG_4754.jpeg)
        roughness: 0.12,
        metalness: 0.05,
      });

      // Pure 24K Radiant Polished Gold for White, Polished Mirror Chrome Silver for Black
      materials.whitePiece = new THREE.MeshPhysicalMaterial({
        color: 0xfacc15, // Radiant 24K Polished Gold (Exact match IMG_4754.jpeg)
        emissive: 0x854d0e,
        emissiveIntensity: 0.08,
        roughness: 0.12,
        metalness: 0.96,
        clearcoat: 0.95,
        clearcoatRoughness: 0.08,
        reflectivity: 1.0,
      });
      materials.blackPiece = new THREE.MeshPhysicalMaterial({
        color: 0xf1f5f9, // Polished Mirror Chrome Silver (Exact match IMG_4754.jpeg)
        emissive: 0x334155,
        emissiveIntensity: 0.04,
        roughness: 0.08,
        metalness: 0.98,
        clearcoat: 1.0,
        clearcoatRoughness: 0.06,
        reflectivity: 1.0,
        userData: { isSilver: true },
      });
    }

    // Override board & piece materials for Purple Amethyst Glass Realm
    if (isPurpleTheme) {
      materials.boardLight = new THREE.MeshStandardMaterial({
        color: 0xc084fc, // Translucent Lavender Glass Tile
        emissive: 0x7e22ce,
        emissiveIntensity: 0.2,
        roughness: 0.05,
        metalness: 0.85,
        transparent: true,
        opacity: 0.92,
      });
      materials.boardDark = new THREE.MeshStandardMaterial({
        color: 0x6b21a8, // Glowing Amethyst Glass Tile
        emissive: 0x3b0764,
        emissiveIntensity: 0.25,
        roughness: 0.08,
        metalness: 0.9,
        transparent: true,
        opacity: 0.95,
      });
      materials.border = new THREE.MeshStandardMaterial({
        color: 0x1f0940, // Elegant deep night-purple
        roughness: 0.35,
        metalness: 0.15,
      });

      // 3D Glass Pieces in Purple Arena (Translucent Lavender Crystal & Deep Obsidian Purple Glass)
      if (activePieceSkin === 'basalt' || activePieceSkin === 'amethyst' || activePieceSkin === 'marble') {
        materials.whitePiece = new THREE.MeshStandardMaterial({
          color: 0xe9d5ff, // Translucent Lavender Crystal Glass
          emissive: 0xa855f7,
          emissiveIntensity: 0.4,
          roughness: 0.05,
          metalness: 0.92,
          transparent: true,
          opacity: 0.92,
        });
        materials.blackPiece = new THREE.MeshStandardMaterial({
          color: 0x581c87, // Deep Royal Obsidian Purple Glass
          emissive: 0x3b0764,
          emissiveIntensity: 0.35,
          roughness: 0.08,
          metalness: 0.95,
          transparent: true,
          opacity: 0.95,
        });
      }
    }

    // =========================================================
    // THEMED PEDESTAL TABLE & SIDE TRAYS (Purple Amethyst vs Water Realm vs Desert Pyramids vs Classic)
    // =========================================================
    const crystalWaterMat = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Deep turquoise crystal water
      emissive: 0x0369a1,
      emissiveIntensity: 0.35,
      roughness: 0.15,
      metalness: 0.3,
      transparent: true,
      opacity: 0.88,
    });

    const desertSandstoneMat = new THREE.MeshStandardMaterial({
      color: 0xb45309, // Baked Giza Pyramid Sandstone
      roughness: 0.65,
      metalness: 0.2,
    });

    const purpleCrystalMat = new THREE.MeshStandardMaterial({
      color: 0x6b21a8, // Vibrant Amethyst Royal Purple Glass
      emissive: 0x3b0764,
      emissiveIntensity: 0.45,
      roughness: 0.12,
      metalness: 0.7,
      transparent: true,
      opacity: 0.92,
    });

    const classicWoodPedestalMat = new THREE.MeshStandardMaterial({
      color: 0x14110e, // Rich Kurdish Dark Walnut & Obsidian Slate
      roughness: 0.25,
      metalness: 0.35,
    });

    // Extended Luxury Theming for Table Styles
    const isRedTheme = tableThemeStyle === 'red';
    const isBlueTheme = tableThemeStyle === 'blue';
    const isGreenTheme = tableThemeStyle === 'green';
    const isGoldTheme = tableThemeStyle === 'gold';
    const isDarkTheme = tableThemeStyle === 'dark';

    // 1. Theme-Specific Pedestal Table Surface Materials
    const tablePedestalMat = isPurpleTheme
      ? new THREE.MeshStandardMaterial({ color: 0x1a0b2e, roughness: 0.22, metalness: 0.25 })
      : isRedTheme
      ? new THREE.MeshStandardMaterial({ color: 0x24070a, roughness: 0.25, metalness: 0.28 })
      : isBlueTheme
      ? new THREE.MeshStandardMaterial({ color: 0x06182a, roughness: 0.20, metalness: 0.32 })
      : isGreenTheme
      ? new THREE.MeshStandardMaterial({ color: 0x051d18, roughness: 0.24, metalness: 0.26 })
      : isGoldTheme
      ? new THREE.MeshStandardMaterial({ color: 0x1f1608, roughness: 0.18, metalness: 0.45 })
      : isDarkTheme
      ? new THREE.MeshStandardMaterial({ color: 0x0a0c10, roughness: 0.30, metalness: 0.20 })
      : isWaterTheme
      ? crystalWaterMat
      : isDesertTheme
      ? desertSandstoneMat
      : (materials.border || classicWoodPedestalMat);

    // 2. Theme-Specific Velvet Tray Felt Materials
    const trayFeltMat = isPurpleTheme
      ? new THREE.MeshStandardMaterial({ color: 0x3b0764, roughness: 0.70, metalness: 0.08 })
      : isRedTheme
      ? new THREE.MeshStandardMaterial({ color: 0x4c0519, roughness: 0.68, metalness: 0.08 })
      : isBlueTheme
      ? new THREE.MeshStandardMaterial({ color: 0x0c4a6e, roughness: 0.65, metalness: 0.10 })
      : isGreenTheme
      ? new THREE.MeshStandardMaterial({ color: 0x064e3b, roughness: 0.68, metalness: 0.08 })
      : isGoldTheme
      ? new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.62, metalness: 0.12 })
      : isDarkTheme
      ? new THREE.MeshStandardMaterial({ color: 0x09090b, roughness: 0.85, metalness: 0.05 })
      : isWaterTheme
      ? new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.25, metalness: 0.15 })
      : isDesertTheme
      ? new THREE.MeshStandardMaterial({ color: 0x92400e, roughness: 0.75, metalness: 0.10 })
      : new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.80, metalness: 0.05 });

    // 3. Ornate Polished Gold & Accents
    const goldAccentMat = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      metalness: 0.92,
      roughness: 0.18,
    });

    const borderWoodMat = new THREE.MeshStandardMaterial({
      color: isPurpleTheme
        ? 0x170729
        : isRedTheme
        ? 0x1f0609
        : isBlueTheme
        ? 0x051322
        : isGreenTheme
        ? 0x041814
        : isGoldTheme
        ? 0x1c1306
        : isDarkTheme
        ? 0x0e1117
        : isWaterTheme
        ? 0x072d42
        : isDesertTheme
        ? 0x92400e
        : 0x14110e,
      roughness: 0.28,
      metalness: 0.25,
    });

    // =========================================================
    // AAA MODERN FLOATING ROUNDED CHESSBOARD SLAB (Exact clone of IMG_4754.jpeg)
    // =========================================================
    const createRoundedRectShape = (w: number, h: number, r: number) => {
      const shape = new THREE.Shape();
      const x = -w / 2;
      const y = -h / 2;
      shape.moveTo(x + r, y);
      shape.lineTo(x + w - r, y);
      shape.quadraticCurveTo(x + w, y, x + w, y + r);
      shape.lineTo(x + w, y + h - r);
      shape.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
      shape.lineTo(x + r, y + h);
      shape.quadraticCurveTo(x, y + h, x, y + h - r);
      shape.lineTo(x, y + r);
      shape.quadraticCurveTo(x, y, x + r, y);
      return shape;
    };

    // 1. Master Floating Rounded Slab Frame with Inner Cutout (No geometry under 8x8 tiles = 0% Z-fighting)
    const slabShape = createRoundedRectShape(
      isClassicBWTheme ? 9.4 : 9.2,
      isClassicBWTheme ? 9.4 : 9.2,
      isClassicBWTheme ? 0.88 : 0.72
    );
    const innerHole = new THREE.Path();
    const hSize = 4.02;
    innerHole.moveTo(-hSize, -hSize);
    innerHole.lineTo(hSize, -hSize);
    innerHole.lineTo(hSize, hSize);
    innerHole.lineTo(-hSize, hSize);
    innerHole.closePath();
    slabShape.holes.push(innerHole);

    const slabGeom = new THREE.ExtrudeGeometry(slabShape, {
      depth: isClassicBWTheme ? 0.18 : 0.22,
      bevelEnabled: true,
      bevelSegments: 4,
      steps: 1,
      bevelSize: isClassicBWTheme ? 0.05 : 0.04,
      bevelThickness: 0.04,
    });
    slabGeom.rotateX(Math.PI / 2); // Lay flat on XZ plane

    // Theme-specific Pure Crystal-Glass Table Slab Material (مێزە شووشەییە تەواوەکە)
    const glassSlabMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(
        isPurpleTheme ? 0xd8b4fe :
        isRedTheme ? 0xfecdd3 :
        isBlueTheme ? 0xbae6fd :
        isGreenTheme ? 0xa7f3d0 :
        isGoldTheme ? 0xfef08a :
        0xffffff // Pure Diamond Crystal Glass Table Slab
      ),
      transmission: 0.95,              // Pure optical transparency
      opacity: 0.92,
      transparent: true,
      roughness: 0.02,                 // Diamond-polished glassy surface
      metalness: 0.02,
      ior: 1.52,                       // True crown glass refractive index
      thickness: 2.2,                  // Volumetric light absorption through depth
      attenuationColor: new THREE.Color(
        isPurpleTheme ? 0xa855f7 :
        isRedTheme ? 0xf43f5e :
        isBlueTheme ? 0x0284c7 :
        isGreenTheme ? 0x10b981 :
        isGoldTheme ? 0xf59e0b :
        0xe2e8f0 // Pristine crystal refraction inside glass
      ),
      attenuationDistance: 3.5,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02,
      reflectivity: 0.98,
    });

    const slabMat = glassSlabMat; // User strictly requested the table under the board to be glass always

    const slabMesh = new THREE.Mesh(slabGeom, slabMat);
    slabMesh.position.y = -0.01;
    slabMesh.receiveShadow = true;
    slabMesh.castShadow = true;
    boardWrapper.add(slabMesh);

    // Polished Platinum Bevel Trim running around the perimeter (for glass themes)
    if (!isClassicBWTheme) {
      const glassRimShape = createRoundedRectShape(9.28, 9.28, 0.76);
      const rimHole = new THREE.Path();
      rimHole.moveTo(-4.55, -4.55);
      rimHole.lineTo(4.55, -4.55);
      rimHole.lineTo(4.55, 4.55);
      rimHole.lineTo(-4.55, 4.55);
      rimHole.closePath();
      glassRimShape.holes.push(rimHole);
      const glassRimGeom = new THREE.ExtrudeGeometry(glassRimShape, {
        depth: 0.06,
        bevelEnabled: false,
      });
      glassRimGeom.rotateX(Math.PI / 2);
      const glassRimMat = new THREE.MeshStandardMaterial({
        color: 0xf1f5f9,
        roughness: 0.12,
        metalness: 0.85,
      });
      const glassRimMesh = new THREE.Mesh(glassRimGeom, glassRimMat);
      glassRimMesh.position.y = 0.005;
      boardWrapper.add(glassRimMesh);
    }

    // 2. Solid Luxury Bedding Plate directly under the 8x8 tiles (keeps tiles 100% solid, non-transparent & clear)
    const bedGeom = new THREE.BoxGeometry(8.05, 0.05, 8.05);
    const bedMat = new THREE.MeshStandardMaterial({
      color: isClassicBWTheme ? 0xf8fafc : 0x111827,
      roughness: 0.25,
      metalness: 0.10,
    });
    const bedMesh = new THREE.Mesh(bedGeom, bedMat);
    bedMesh.position.y = -0.015;
    boardWrapper.add(bedMesh);

    // 3. Recessed Floating Crystal Under-Plinth
    const subBaseShape = createRoundedRectShape(8.70, 8.70, 0.65);
    const subBaseGeom = new THREE.ExtrudeGeometry(subBaseShape, {
      depth: 0.14,
      bevelEnabled: true,
      bevelSegments: 3,
      bevelSize: 0.03,
      bevelThickness: 0.03,
    });
    subBaseGeom.rotateX(Math.PI / 2);
    const subBaseMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(0xffffff),
      transmission: 0.92,
      roughness: 0.04,
      metalness: 0.04,
      transparent: true,
      opacity: 0.88,
      thickness: 2.0,
      ior: 1.52,
      clearcoat: 1.0,
    });
    const subBaseMesh = new THREE.Mesh(subBaseGeom, subBaseMat);
    subBaseMesh.position.y = -0.28;
    boardWrapper.add(subBaseMesh);

    // 4. Sculpted Crystal-Glass Column Supports under the table corners
    if (!isClassicBWTheme) {
      const glassPillarMat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(0xffffff),
        transmission: 0.94,
        roughness: 0.03,
        metalness: 0.04,
        transparent: true,
        opacity: 0.90,
        ior: 1.52,
        thickness: 1.8,
        clearcoat: 1.0,
      });

      const pillarGeom = new THREE.CylinderGeometry(0.32, 0.42, 0.36, 12);
      const cornerCoords = [
        [-3.85, -0.32, -3.85],
        [3.85, -0.32, -3.85],
        [-3.85, -0.32, 3.85],
        [3.85, -0.32, 3.85],
      ];
      cornerCoords.forEach(([cx, cy, cz]) => {
        const pMesh = new THREE.Mesh(pillarGeom, glassPillarMat);
        pMesh.position.set(cx, cy, cz);
        boardWrapper.add(pMesh);

        const torusGeom = new THREE.TorusGeometry(0.40, 0.04, 8, 24);
        torusGeom.rotateX(Math.PI / 2);
        const ringMesh = new THREE.Mesh(torusGeom, goldAccentMat);
        ringMesh.position.set(cx, cy + 0.16, cz);
        boardWrapper.add(ringMesh);
      });

      // Central Glass Fluted Table Plinth
      const centerPedestalGeom = new THREE.CylinderGeometry(1.8, 2.5, 0.26, 24);
      const centerPedestalMesh = new THREE.Mesh(centerPedestalGeom, glassPillarMat);
      centerPedestalMesh.position.set(0, -0.35, 0);
      boardWrapper.add(centerPedestalMesh);
    }

    // 5. Beautiful Dark Glass / Frost Scene Background Floor
    const studioFloorGeom = new THREE.CircleGeometry(40, 64);
    studioFloorGeom.rotateX(-Math.PI / 2);
    const studioFloorMat = new THREE.MeshPhysicalMaterial({
      color: 0x05070c,
      transmission: 0.90,
      opacity: 0.85,
      transparent: true,
      roughness: 0.15,
      metalness: 0.15,
      ior: 1.50,
      thickness: 1.5,
      clearcoat: 0.5,
    });
    const studioFloor = new THREE.Mesh(studioFloorGeom, studioFloorMat);
    studioFloor.position.y = -0.40;
    studioFloor.receiveShadow = true;
    boardWrapper.add(studioFloor);

    // 6. Smoked Translucent Glass Side Resting Pads for Captured Pieces (only on decorative glass themes)
    if (!isClassicBWTheme) {
      const createSideRestPad = (padX: number) => {
        const padShape = createRoundedRectShape(1.8, 7.6, 0.4);
        const padGeom = new THREE.ExtrudeGeometry(padShape, {
          depth: 0.05,
          bevelEnabled: true,
          bevelSegments: 3,
          bevelSize: 0.02,
          bevelThickness: 0.02,
        });
        padGeom.rotateX(Math.PI / 2);
        const padMat = new THREE.MeshPhysicalMaterial({
          color: new THREE.Color(0x1e293b),
          transmission: 0.85,
          roughness: 0.08,
          metalness: 0.12,
          transparent: true,
          opacity: 0.86,
          ior: 1.50,
          thickness: 0.9,
          clearcoat: 0.9,
        });
        const padMesh = new THREE.Mesh(padGeom, padMat);
        padMesh.position.set(padX, -0.01, 0);
        padMesh.receiveShadow = true;
        boardWrapper.add(padMesh);
      };
      createSideRestPad(-6.2);
      createSideRestPad(6.2);
    }

    // =========================================================
    // ETCHED BOARD COORDINATES (A-H, 1-8) ON FLOATING SLAB BORDER
    // =========================================================
    // High-contrast, crystal-clear rank & file notation on all 4 board edges
    const labelColor = isClassicBWTheme ? '#0f172a' : '#cbd5e1'; // Bold slate/black on white border, platinum on dark glass
    const labelGeom = new THREE.PlaneGeometry(0.42, 0.42);
    labelGeom.rotateX(-Math.PI / 2);

    // File letters (a-h) along South & North borders
    const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    files.forEach((fileChar, c) => {
      const x = c - 3.5;
      const fileTex = createTextTexture(fileChar.toUpperCase(), labelColor);
      const fileMat = new THREE.MeshBasicMaterial({
        map: fileTex,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
      });

      // South border label
      const southMesh = new THREE.Mesh(labelGeom, fileMat);
      southMesh.position.set(x, 0.046, 4.30);
      boardWrapper.add(southMesh);

      // North border label
      const northMesh = new THREE.Mesh(labelGeom, fileMat);
      northMesh.rotation.y = Math.PI;
      northMesh.position.set(x, 0.046, -4.30);
      boardWrapper.add(northMesh);
    });

    // Rank numbers (1-8) along West & East borders
    for (let r = 0; r < 8; r++) {
      const z = 3.5 - r;
      const rankChar = (r + 1).toString();
      const rankTex = createTextTexture(rankChar, labelColor);
      const rankMat = new THREE.MeshBasicMaterial({
        map: rankTex,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
      });

      // West border label
      const westMesh = new THREE.Mesh(labelGeom, rankMat);
      westMesh.position.set(-4.30, 0.046, z);
      boardWrapper.add(westMesh);

      // East border label
      const eastMesh = new THREE.Mesh(labelGeom, rankMat);
      eastMesh.rotation.y = Math.PI;
      eastMesh.position.set(4.30, 0.046, z);
      boardWrapper.add(eastMesh);
    }

    // =========================================================
    // 8x8 BOARD SQUARES (InstancedMesh with Razor-Sharp Grooves)
    // =========================================================
    const tileGeom = new THREE.BoxGeometry(0.985, 0.04, 0.985);
    const lightTiles = new THREE.InstancedMesh(tileGeom, materials.boardLight, 32);
    const darkTiles = new THREE.InstancedMesh(tileGeom, materials.boardDark, 32);
    lightTiles.receiveShadow = true;
    lightTiles.castShadow = true;
    darkTiles.receiveShadow = true;
    darkTiles.castShadow = true;
    
    // Hit plane for raycasting (O(1) intersection instead of O(64))
    const hitPlaneGeom = new THREE.PlaneGeometry(8, 8);
    const hitPlaneMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false });
    const hitPlane = new THREE.Mesh(hitPlaneGeom, hitPlaneMat);
    hitPlane.rotation.x = -Math.PI / 2;
    hitPlane.position.y = 0.042;
    hitPlane.name = 'chess_hit_plane';
    boardWrapper.add(hitPlane);

    let lightIdx = 0;
    let darkIdx = 0;
    const dummy = new THREE.Object3D();

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const isLight = (r + c) % 2 !== 0; 
        const x = c - 3.5;
        const z = 3.5 - r;
        
        dummy.position.set(x, 0.02, z);
        dummy.updateMatrix();

        if (isLight) {
          lightTiles.setMatrixAt(lightIdx++, dummy.matrix);
        } else {
          darkTiles.setMatrixAt(darkIdx++, dummy.matrix);
        }
      }
    }
    boardWrapper.add(lightTiles);
    boardWrapper.add(darkTiles);

    scene.add(boardWrapper);
  }, [theme, activePieceSkin, activeBoardSkin, sceneReady, tableThemeStyle, playerColor]);

  // Re-render 3D Pieces with High-Performance Object Reconciliation Pool
  useEffect(() => {
    if (!sceneRef.current || !piecesGroupRef.current) return;
    const scene = sceneRef.current;
    const piecesGroup = piecesGroupRef.current;

    // Guarantee piecesGroup is attached to scene and visible
    if (!scene.children.includes(piecesGroup)) {
      scene.add(piecesGroup);
    }
    piecesGroup.visible = true;

    if (!board || !Array.isArray(board) || board.length !== 8) return;

    // If skins changed or pool empty, rebuild/reset pool cleanly
    const skinKey = `${activePieceSkin}_${activeBoardSkin}_${equippedPieceSkin}`;
    if (piecePoolSkinRef.current !== skinKey) {
      piecesGroup.traverse((child) => {
        if (child.isMesh) {
          child.geometry.dispose();
          if (child.material) {
            if (Array.isArray(child.material)) child.material.forEach(m => m.dispose());
            else child.material.dispose();
          }
        }
      });
      while (piecesGroup.children.length > 0) {
        piecesGroup.remove(piecesGroup.children[0]);
      }
      piecePoolRef.current = [];
      piecePoolSkinRef.current = skinKey;
    }

    const materials = getMaterialsForCustomSkins(activePieceSkin, activeBoardSkin);

    // Reset usage flag on all pooled items
    piecePoolRef.current.forEach((item) => {
      item.visible = false;
      item.square = null;
    });

    // 1. Place active board pieces
    const activeWhiteTypes: string[] = [];
    const activeBlackTypes: string[] = [];

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece) {
          const rank = 8 - r;
          const fileChar = String.fromCharCode(97 + c);
          const sq = `${fileChar}${rank}`;
          const { x, z } = squareToWorld(sq);

          if (piece.color === 'w') activeWhiteTypes.push(piece.type);
          else activeBlackTypes.push(piece.type);

          // Find available matching piece in pool
          let pooled = piecePoolRef.current.find(
            (p) => !p.visible && !p.isCapturedTray && p.type === piece.type && p.color === piece.color
          );

          if (!pooled) {
            const mat = piece.color === 'w' ? materials.whitePiece : materials.blackPiece;
            const pieceMeshGroup = create3DPieceGroup(
              piece.type,
              mat,
              piece.color === 'w' ? equippedPieceSkin : activePieceSkin,
              flagTexRef.current
            );
            piecesGroup.add(pieceMeshGroup);
            pooled = {
              group: pieceMeshGroup,
              type: piece.type,
              color: piece.color,
              square: sq,
              isCapturedTray: false,
              visible: true,
            };
            piecePoolRef.current.push(pooled);
          } else if (pooled.group.parent !== piecesGroup) {
            piecesGroup.add(pooled.group);
          }

          pooled.visible = true;
          pooled.square = sq;
          pooled.group.visible = true;
          pooled.group.traverse((c) => {
            c.visible = true;
            if (c instanceof THREE.Mesh) {
              c.castShadow = true;
              c.receiveShadow = true;
            }
          });
          pooled.group.scale.set(1, 1, 1);
          pooled.group.rotation.y = piece.color === 'b' ? Math.PI : 0;
          pooled.group.rotation.x = 0;
          pooled.group.rotation.z = 0;
          pooled.group.position.set(x, 0.06, z);
          pooled.group.userData = { square: sq, piece };
        }
      }
    }

    // 2. Place captured pieces on side trays
    // Using props capturedWhite and capturedBlack

    // Captured White
    capturedWhite.forEach((type, idx) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      const xPos = -6.2 + (col === 0 ? -0.45 : 0.45);
      const zPos = -2.8 + row * 0.80;

      let pooled = piecePoolRef.current.find(
        (p) => !p.visible && p.isCapturedTray && p.type === type && p.color === 'w'
      );

      if (!pooled) {
        const mesh = create3DPieceGroup(
          type,
          materials.whitePiece,
          equippedPieceSkin,
          flagTexRef.current
        );
        piecesGroup.add(mesh);
        pooled = {
          group: mesh,
          type,
          color: 'w',
          square: null,
          isCapturedTray: true,
          visible: true,
        };
        piecePoolRef.current.push(pooled);
      } else if (pooled.group.parent !== piecesGroup) {
        piecesGroup.add(pooled.group);
      }

      pooled.visible = true;
      pooled.group.visible = true;
      pooled.group.traverse((c) => {
        c.visible = true;
      });
      pooled.group.scale.set(0.58, 0.58, 0.58);
      pooled.group.rotation.set(0, 0, 0);
      pooled.group.position.set(xPos, 0.065, zPos);
      pooled.group.userData = {};
    });

    // Captured Black
    capturedBlack.forEach((type, idx) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      const xPos = 6.2 + (col === 0 ? -0.45 : 0.45);
      const zPos = -2.8 + row * 0.80;

      let pooled = piecePoolRef.current.find(
        (p) => !p.visible && p.isCapturedTray && p.type === type && p.color === 'b'
      );

      if (!pooled) {
        const mesh = create3DPieceGroup(
          type,
          materials.blackPiece,
          activePieceSkin,
          flagTexRef.current
        );
        piecesGroup.add(mesh);
        pooled = {
          group: mesh,
          type,
          color: 'b',
          square: null,
          isCapturedTray: true,
          visible: true,
        };
        piecePoolRef.current.push(pooled);
      } else if (pooled.group.parent !== piecesGroup) {
        piecesGroup.add(pooled.group);
      }

      pooled.visible = true;
      pooled.group.visible = true;
      pooled.group.traverse((c) => {
        c.visible = true;
      });
      pooled.group.scale.set(0.58, 0.58, 0.58);
      pooled.group.rotation.set(0, Math.PI, 0);
      pooled.group.position.set(xPos, 0.065, zPos);
      pooled.group.userData = {};
    });

    // Hide any unused piece meshes in pool and move out of view
    piecePoolRef.current.forEach((item) => {
      if (!item.visible) {
        item.group.visible = false;
        item.group.position.set(0, -50, 0);
      }
    });
  }, [board, theme, activePieceSkin, activeBoardSkin, equippedPieceSkin, sceneReady]);

  // Re-render 3D Move Highlights (Zero-Allocation Pool Update)
  useEffect(() => {
    const pool = highlightPoolRef.current;
    if (!pool) return;

    // 1. Highlight Selected Square
    if (selectedSquare) {
      const { x, z } = squareToWorld(selectedSquare);
      pool.selectedRing.position.set(x, 0.066, z);
      pool.selectedRing.visible = true;

      pool.selectedPlane.position.set(x, 0.063, z);
      pool.selectedPlane.visible = true;
    } else {
      pool.selectedRing.visible = false;
      pool.selectedPlane.visible = false;
    }

    // 2. Highlight Valid Destination Moves
    for (let i = 0; i < pool.validMoveRings.length; i++) {
      const ring = pool.validMoveRings[i];
      if (i < validMoves.length) {
        const move = validMoves[i];
        const { x, z } = squareToWorld(move.to);
        const isCapture = Boolean(move.captured);
        ring.material = isCapture ? pool.captureMoveMat : pool.normalMoveMat;
        ring.position.set(x, 0.064, z);
        ring.visible = true;
      } else {
        ring.visible = false;
      }
    }

    // 3. Highlight Last Move with Soft Gold/Yellow Glow on Destination Square (staying strictly inside square)
    if (lastMove) {
      // Origin square (from)
      if (pool.lastMovePlanes[0]) {
        const fromPos = squareToWorld(lastMove.from);
        pool.lastMovePlanes[0].position.set(fromPos.x, 0.062, fromPos.z);
        pool.lastMovePlanes[0].visible = true;
      }
      // Destination square (to) - with soft gold/yellow glow
      if (pool.lastMovePlanes[1]) {
        const toPos = squareToWorld(lastMove.to);
        pool.lastMovePlanes[1].position.set(toPos.x, 0.0625, toPos.z);
        pool.lastMovePlanes[1].visible = true;
        pool.lastMoveLight.position.set(toPos.x, 0.22, toPos.z);
        pool.lastMoveLight.visible = true;
      }
    } else {
      pool.lastMovePlanes.forEach((p) => { p.visible = false; });
      pool.lastMoveLight.visible = false;
    }

    // 4. Highlight King under Check
    if (isCheck) {
      let kingSq: string | null = null;
      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          const piece = board[r][c];
          if (piece && piece.type === 'k' && piece.color === turn) {
            const rank = 8 - r;
            const fileChar = String.fromCharCode(97 + c);
            kingSq = `${fileChar}${rank}`;
            break;
          }
        }
        if (kingSq) break;
      }

      if (kingSq) {
        const { x, z } = squareToWorld(kingSq);
        pool.checkRing.position.set(x, 0.066, z);
        pool.checkRing.visible = true;
      } else {
        pool.checkRing.visible = false;
      }
    } else {
      pool.checkRing.visible = false;
    }
  }, [selectedSquare, validMoves, lastMove, isCheck, turn, board, sceneReady]);

  // Aquatic Water Whirlpool & Swallowed Piece Capture Animation Trigger ("ئاو بیخوات")
  const spawnWaterVortexCaptureAnimation = (sq: string, pieceType: string, pieceColor: 'w' | 'b') => {
    if (!sceneRef.current) return;
    const { x, z } = squareToWorld(sq);
    const materials = getMaterialsForCustomSkins(activePieceSkin, activeBoardSkin);

    // 1. Create a clone group of the captured piece for the sinking animation
    const pieceBaseMat = pieceColor === 'w' ? materials.whitePiece : materials.blackPiece;
    const sinkingPieceMat = pieceBaseMat.clone();
    sinkingPieceMat.transparent = true;
    sinkingPieceMat.opacity = 0.95;

    const pieceCloneGroup = create3DPieceGroup(
      pieceType,
      sinkingPieceMat,
      activePieceSkin,
      flagTexRef.current
    );
    pieceCloneGroup.position.set(x, 0.04, z);
    if (pieceColor === 'b') {
      pieceCloneGroup.rotation.y = Math.PI;
    }
    sceneRef.current.add(pieceCloneGroup);

    // 2. Multi-layer Concentric Swirling Water Whirlpool Vortex Rings on Water Surface
    const vortexRings: THREE.Mesh[] = [];

    // Outer Cyan Whirlpool Swirl Ring
    const outerRingGeom = new THREE.RingGeometry(0.18, 0.58, 36);
    const outerRingMat = new THREE.MeshBasicMaterial({
      color: 0x00f3ff,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
    });
    const outerRing = new THREE.Mesh(outerRingGeom, outerRingMat);
    outerRing.rotation.x = -Math.PI / 2;
    outerRing.position.set(x, 0.052, z);
    sceneRef.current.add(outerRing);
    vortexRings.push(outerRing);

    // Middle Frothing White Seafoam Swirl Ring
    const foamRingGeom = new THREE.RingGeometry(0.28, 0.44, 36);
    const foamRingMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    });
    const foamRing = new THREE.Mesh(foamRingGeom, foamRingMat);
    foamRing.rotation.x = -Math.PI / 2;
    foamRing.position.set(x, 0.054, z);
    sceneRef.current.add(foamRing);
    vortexRings.push(foamRing);

    // Inner Deep Abyss Core Ring (Deep Sapphire / Abyss Blue)
    const innerRingGeom = new THREE.RingGeometry(0.02, 0.22, 36);
    const innerRingMat = new THREE.MeshBasicMaterial({
      color: 0x03254c,
      transparent: true,
      opacity: 0.95,
      side: THREE.DoubleSide,
    });
    const innerRing = new THREE.Mesh(innerRingGeom, innerRingMat);
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.set(x, 0.056, z);
    sceneRef.current.add(innerRing);
    vortexRings.push(innerRing);

    // 3. Upward Frothing Bubble Spurt Particles around Whirlpool
    const bubbleCount = 36;
    const bubbleGeom = new THREE.BufferGeometry();
    const bubblePositions = new Float32Array(bubbleCount * 3);
    const bubbleVelocities: { vx: number; vy: number; vz: number }[] = [];

    for (let i = 0; i < bubbleCount; i++) {
      const angle = (i / bubbleCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
      const rad = 0.15 + Math.random() * 0.25;
      bubblePositions[i * 3 + 0] = x + Math.cos(angle) * rad;
      bubblePositions[i * 3 + 1] = 0.05 + Math.random() * 0.06;
      bubblePositions[i * 3 + 2] = z + Math.sin(angle) * rad;

      const radialSpeed = 0.015 + Math.random() * 0.035;
      bubbleVelocities.push({
        vx: Math.cos(angle) * radialSpeed,
        vy: 0.05 + Math.random() * 0.12,
        vz: Math.sin(angle) * radialSpeed,
      });
    }

    bubbleGeom.setAttribute('position', new THREE.BufferAttribute(bubblePositions, 3));

    const bubbleMat = new THREE.PointsMaterial({
      size: 0.36,
      color: 0x7dd3fc,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const bubblesParticles = new THREE.Points(bubbleGeom, bubbleMat);
    sceneRef.current.add(bubblesParticles);

    // 4. Register to sinking pieces collection
    sinkingPiecesRef.current.push({
      group: pieceCloneGroup,
      vortexRings,
      bubblesParticles,
      bubblePositions,
      bubbleVelocities,
      age: 0,
      maxAge: 48,
      x,
      z,
    });

    // 5. Play watery whirlpool plunge & bubble sound
    soundManager.playWaterVortexCapture();
  };

  // Water Splash Ripple Effect Trigger
  const spawnWaterSplashEffect = (sq: string, intensity = 1.0) => {
    if (!sceneRef.current) return;
    const { x, z } = squareToWorld(sq);

    // 1. Expanding Glowing Water Ring Mesh
    const ringGeom = new THREE.RingGeometry(0.12, 0.28, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.9 * intensity,
      side: THREE.DoubleSide,
    });
    const ringMesh = new THREE.Mesh(ringGeom, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(x, 0.055, z);
    sceneRef.current.add(ringMesh);

    // 2. Water Droplets Particle Burst
    const count = Math.floor(24 * intensity);
    const splashGeom = new THREE.BufferGeometry();
    const splashPositions = new Float32Array(count * 3);
    const splashVelocities: { vx: number; vy: number; vz: number }[] = [];

    for (let i = 0; i < count; i++) {
      splashPositions[i * 3 + 0] = x;
      splashPositions[i * 3 + 1] = 0.06;
      splashPositions[i * 3 + 2] = z;

      const angle = Math.random() * Math.PI * 2;
      const speed = 0.025 + Math.random() * 0.065;
      splashVelocities.push({
        vx: Math.cos(angle) * speed,
        vy: 0.1 + Math.random() * 0.15,
        vz: Math.sin(angle) * speed,
      });
    }

    splashGeom.setAttribute('position', new THREE.BufferAttribute(splashPositions, 3));

    const splashMat = new THREE.PointsMaterial({
      size: 0.32,
      color: 0xbae6fd,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const splashParticles = new THREE.Points(splashGeom, splashMat);
    sceneRef.current.add(splashParticles);

    waterRipplesRef.current.push({
      ringMesh,
      splashParticles,
      splashPositions,
      splashVelocities,
      age: 0,
      maxAge: 40,
    });

    soundManager.playWaterSplash();
  };

  // Spawn Dust Impact Puff on lastMove (Clean animations, no water bubbles)
  useEffect(() => {
    if (!lastMove) return;

    if (!dustGroupRef.current) return;
    const { x, z } = squareToWorld(lastMove.to);
    const dustGroup = dustGroupRef.current;

    // Spawn subtle gold impact puff particles
    const particleCount = 4;
    const dustGeom = new THREE.SphereGeometry(0.04, 6, 6);

    for (let i = 0; i < particleCount; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xf59e0b,
        transparent: true,
        opacity: 0.8,
      });
      const p = new THREE.Mesh(dustGeom, mat);
      const angle = (i / particleCount) * Math.PI * 2 + (Math.random() - 0.5) * 0.4;
      const speed = 0.02 + Math.random() * 0.035;
      p.position.set(x, 0.08, z);
      p.userData = {
        vx: Math.cos(angle) * speed,
        vy: 0.035 + Math.random() * 0.04,
        vz: Math.sin(angle) * speed,
        age: 0,
        maxAge: 20 + Math.floor(Math.random() * 10),
      };
      dustGroup.add(p);
    }
  }, [lastMove]);

  // Pointer Down & Up event handling to distinguish clean taps vs camera drags
  const pointerDownInfoRef = useRef<{ x: number; y: number; time: number } | null>(null);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    pointerDownInfoRef.current = {
      x: e.clientX,
      y: e.clientY,
      time: Date.now(),
    };
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const downInfo = pointerDownInfoRef.current;
    pointerDownInfoRef.current = null;
    if (!downInfo) return;

    const dist = Math.hypot(e.clientX - downInfo.x, e.clientY - downInfo.y);
    const elapsed = Date.now() - downInfo.time;

    // Ignore intentional camera rotation drags / long swipes (> 18px movement or > 750ms hold)
    if (dist > 18 || elapsed > 750) {
      return;
    }

    if (!rendererRef.current || !cameraRef.current || !sceneRef.current) return;

    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const mouseX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const mouseY = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    pointerVecRef.current.set(mouseX, mouseY);
    const raycaster = raycasterRef.current;
    raycaster.setFromCamera(pointerVecRef.current, cameraRef.current);

    // 1. First priority: Check if user tapped directly on a 3D chess piece
    let clickedSquare: string | null = null;
    if (piecesGroupRef.current) {
      const pieceIntersects = raycaster.intersectObjects(piecesGroupRef.current.children, true);
      for (const hit of pieceIntersects) {
        let obj: THREE.Object3D | null = hit.object;
        while (obj && !obj.userData?.square && obj.parent) {
          obj = obj.parent;
        }
        if (obj && obj.userData?.square) {
          clickedSquare = obj.userData.square;
          break;
        }
      }
    }

    // If a piece was tapped, immediately trigger click on that square!
    if (clickedSquare) {
      onSquareClick(clickedSquare);
      return;
    }

    // 2. Second priority: Raycast against the board hit plane for destination moves or empty squares
    const hitPlane = sceneRef.current.getObjectByName('chess_hit_plane');
    const intersects = hitPlane ? raycaster.intersectObject(hitPlane) : [];

    if (intersects.length > 0) {
      const p = intersects[0].point;
      const sq = worldToSquare(p.x, p.z);
      if (sq) onSquareClick(sq);
    }
  };

  return (
    <div className="w-full h-full relative overflow-hidden rounded-2xl shadow-2xl border border-sky-600/40">
      {/* Full-Screen Outdoor Moving Aquatic River Background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div
          className="absolute -inset-4 bg-cover bg-center filter brightness-110 contrast-105 scale-105 transition-all duration-1000"
          style={{
            backgroundImage: `url(${mountainRiverBgImg})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-cyan-950/20 to-sky-950/50 backdrop-blur-[0.5px]" />
        
      </div>

      {/* Interactive 3D Canvas */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        className={`w-full h-full relative z-10 cursor-pointer touch-none select-none ${
          cameraPreset === 'top' ? 'hidden' : 'block'
        }`}
      />

      {/* 2D Board Overlay Mode (Matching IMG_3880.jpeg) */}
      {cameraPreset === 'top' && (
        <div
          className={`absolute inset-0 z-20 flex items-center justify-center p-2 sm:p-4 backdrop-blur-md transition-all duration-300 ${
            tableThemeStyle === 'purple'
              ? 'bg-gradient-to-b from-[#1e0b2b] via-[#10002b] to-[#070014]'
              : tableThemeStyle === 'classic'
              ? 'bg-gradient-to-b from-[#0f172a] via-[#020617] to-[#000000]'
              : tableThemeStyle === 'red'
              ? 'bg-gradient-to-b from-[#3b0707] via-[#1c0303] to-[#0a0000]'
              : tableThemeStyle === 'blue'
              ? 'bg-gradient-to-b from-[#0a192f] via-[#020c1b] to-[#01060f]'
              : tableThemeStyle === 'green'
              ? 'bg-gradient-to-b from-[#042f2e] via-[#021f1e] to-[#011211]'
              : tableThemeStyle === 'gold'
              ? 'bg-gradient-to-b from-[#3a2203] via-[#1f1201] to-[#0d0700]'
              : 'bg-gradient-to-b from-[#18181b] via-[#0f0f11] to-[#050505]'
          }`}
        >
          <Chess2DBoard
            board={board}
            selectedSquare={selectedSquare}
            validMoves={validMoves}
            lastMove={lastMove}
            isCheck={isCheck}
            turn={turn}
            onSquareClick={onSquareClick}
            themeStyle={tableThemeStyle}
            isFlipped={playerColor === 'b' || cameraPreset === 'black'}
            capturedWhite={capturedWhite}
            capturedBlack={capturedBlack}
          />
        </div>
      )}

      {/* Real-Time Developer FPS & Performance Monitor Overlay */}
      {showPerfMonitor && (
        <div
          id="realtime-fps-monitor"
          className="absolute top-3 left-3 z-30 bg-slate-950/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-2.5 shadow-2xl min-w-[180px] pointer-events-auto select-none transition-all"
        >
          <div className="flex items-center justify-between gap-2 pb-1 border-b border-slate-700/50 mb-1">
            <span className="text-[10px] font-bold tracking-wider uppercase text-slate-400">Perf Monitor</span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowPerfMonitor(false);
              }}
              className="text-[10px] text-slate-400 hover:text-white px-1 rounded bg-slate-800/80 hover:bg-slate-700 cursor-pointer"
              title="Close FPS Monitor"
            >
              ✕
            </button>
          </div>
          <div ref={fpsDomRef} className="space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
              <span>🟢</span>
              <span className="text-emerald-400 font-bold">60 FPS</span>
              <span className="text-[9px] text-slate-500">16.6 ms</span>
            </div>
          </div>
        </div>
      )}

      {/* Floating 3D Camera Scenery Reset Controls */}
      <div className="absolute bottom-3 right-3 z-20 flex items-center gap-2">
        {!showPerfMonitor && (
          <button
            onClick={() => setShowPerfMonitor(true)}
            className="bg-slate-950/90 hover:bg-slate-900 border border-slate-700 text-slate-300 text-[11px] font-bold px-2.5 py-1.5 rounded-xl shadow-lg backdrop-blur-md cursor-pointer transition active:scale-95"
            title="Show FPS Monitor"
          >
            📊 FPS
          </button>
        )}
      </div>
    </div>
  );
};

export const Chess3DCanvas = React.memo(Chess3DCanvasComponent);
