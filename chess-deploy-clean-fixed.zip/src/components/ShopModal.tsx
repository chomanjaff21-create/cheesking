import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Lock, CheckCircle2, Crown } from 'lucide-react';
import { useRealtimeStore } from '../lib/realtime';
import { buildApiUrl } from '../lib/api';
import { ShopItem } from '../lib/shopCatalog';
import { soundManager } from '../lib/soundManager';
import { getPlayerProfile } from '../lib/profileService';
import { UserProfile, PieceSkinId, BoardSkinId } from '../types';
import { CurrencyBadge, GoldCoinIcon, GemIcon } from './CurrencyIcons';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'ku';
  userProfile: UserProfile;
  equippedPieceSkin: PieceSkinId;
  equippedBoardSkin: BoardSkinId;
  previewPieceSkin: PieceSkinId | null;
  previewBoardSkin: BoardSkinId | null;
  onSelectPieceSkin: (skin: PieceSkinId) => void;
  onSelectBoardSkin: (board: BoardSkinId) => void;
  onPreviewPieceSkin: (skin: PieceSkinId | null) => void;
  onPreviewBoardSkin: (board: BoardSkinId | null) => void;
  onUpdateProfile?: (updated: Partial<UserProfile>) => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({ 
  isOpen, onClose, language, userProfile,
  equippedPieceSkin, equippedBoardSkin,
  previewPieceSkin, previewBoardSkin,
  onSelectPieceSkin, onSelectBoardSkin,
  onPreviewPieceSkin, onPreviewBoardSkin, onUpdateProfile
}) => {
  const isRtl = language === 'ku';
  const { session } = useRealtimeStore();
  
  const [activeTab, setActiveTab] = useState<'board' | 'piece' | 'avatar' | 'cosmetic'>('board');
  const [items, setItems] = useState<ShopItem[]>([]);
  const [inventory, setInventory] = useState<string[]>([]);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [serviceError, setServiceError] = useState(false);
  
  // Local state to reflect immediate updates before profile re-fetch
  const [localCoins, setLocalCoins] = useState(userProfile?.coins ?? 5000);
  const [localGems, setLocalGems] = useState(userProfile?.gems ?? 50);

  useEffect(() => {
    setLocalCoins(userProfile?.coins ?? 5000);
    setLocalGems(userProfile?.gems ?? 50);
  }, [userProfile?.coins, userProfile?.gems]);

  useEffect(() => {
    if (!isOpen) return;

    // Fetch latest balance from server authoritative state
    getPlayerProfile().then(profile => {
      if (profile) {
        if (typeof profile.coins === 'number') setLocalCoins(profile.coins);
        if (typeof profile.gems === 'number') setLocalGems(profile.gems);
        if (onUpdateProfile) onUpdateProfile({ coins: profile.coins, gems: profile.gems });
      }
    });
    
    // Fetch catalog independently of session
    fetch(buildApiUrl('/api/shop/items'))
      .then(res => {
        if (res.status === 503) setServiceError(true);
        return res.json();
      })
      .then(data => {
        if (data.items) setItems(data.items);
      })
      .catch(e => console.error("Failed to load catalog", e));
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || !session?.user_id) return;
    
    const cleanToken = (session.token || '').trim().replace(/[\r\n]/g, '');
    const cleanUserId = encodeURIComponent(session.user_id);
    const headers: Record<string, string> = {};
    if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

    fetch(buildApiUrl(`/api/player/${cleanUserId}/inventory`), { headers })
      .then(async res => {
        if (!res.ok) return null;
        return await res.json();
      })
      .then(data => {
        if (data?.inventory) {
          const itemIds = data.inventory.map((i: any) => i.item_id);
          setInventory(itemIds);
          localStorage.setItem(`user_inventory_${session.user_id}`, JSON.stringify(itemIds));
        }
      })
      .catch(() => {
        const localInv = localStorage.getItem(`user_inventory_${session.user_id}`);
        if (localInv) {
          try { setInventory(JSON.parse(localInv)); } catch {}
        }
      });
  }, [isOpen, session]);

  const handleBuy = async (item: ShopItem) => {
    if (!session?.user_id) return;
    
    const priceCoins = item.priceCoins || 0;
    const priceGems = item.priceGems || 0;
    
    if (localCoins < priceCoins || localGems < priceGems) {
      soundManager.playMove(); // Error sound
      return;
    }

    soundManager.playClick();
    setLoadingId(item.id);

    try {
      const cleanToken = (session.token || '').trim().replace(/[\r\n]/g, '');
      const cleanUserId = encodeURIComponent(session.user_id);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/shop/buy`), {
        method: 'POST',
        headers,
        body: JSON.stringify({ itemId: item.id })
      });
      
      const data = await res.json().catch(() => ({}));

      if (res.ok && data.success) {
        soundManager.playVictory();
        
        // Trust the server's authoritative response for coins and gems
        if (typeof data.coins === 'number') setLocalCoins(data.coins);
        if (typeof data.gems === 'number') setLocalGems(data.gems);
        if (onUpdateProfile) {
           onUpdateProfile({ coins: data.coins, gems: data.gems });
        }
        
        // Strictly fetch full profile to ensure total sync after purchase
        getPlayerProfile().then(profile => {
          if (profile) {
            if (typeof profile.coins === 'number') setLocalCoins(profile.coins);
            if (typeof profile.gems === 'number') setLocalGems(profile.gems);
            if (onUpdateProfile) onUpdateProfile({ coins: profile.coins, gems: profile.gems });
          }
        });
        
        setInventory(prev => {
          const updated = [...prev, item.id];
          localStorage.setItem(`user_inventory_${session.user_id}`, JSON.stringify(updated));
          return updated;
        });

        // Equip automatically on purchase
        if (item.type === 'piece') onSelectPieceSkin(item.id as PieceSkinId);
        if (item.type === 'board') onSelectBoardSkin(item.id as BoardSkinId);
      } else {
        // Purchase failed on server (e.g., insufficient funds, already owned, or offline)
        // DO NOT update local inventory or deduct local balance.
        soundManager.playMove(); // Error sound
        console.error("Purchase failed:", data.error || "Unknown error");
      }
    } catch (e) {
      // Network error
      soundManager.playMove(); // Error sound
      console.error("Network error during purchase", e);
    } finally {
      setLoadingId(null);
    }
  };

  const handleEquip = (item: ShopItem) => {
    soundManager.playClick();
    if (item.type === 'piece') onSelectPieceSkin(item.id as PieceSkinId);
    if (item.type === 'board') onSelectBoardSkin(item.id as BoardSkinId);
  };

  if (!isOpen) return null;

  const currentItems = items.filter(i => i.type === activeTab);

  return (
    <AnimatePresence>
      <div className={`fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md ${isRtl ? 'rtl' : 'ltr'}`}>
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-5xl h-[88vh] bg-gradient-to-b from-[#2a170b] via-[#1a0e07] to-[#0d0703] border-2 border-amber-500/70 rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden text-amber-100 font-sans"
        >
          {/* Header */}
          {serviceError && (
            <div className="bg-red-950/80 border-b border-red-500/50 px-4 py-2 text-center shrink-0">
              <span className="text-red-300 text-xs sm:text-sm font-bold">
                {isRtl ? 'سیستمی بازاڕ لەسەر هێڵ نییە (داتابەیس بەردەست نییە)' : 'Shop service unavailable. Database is offline.'}
              </span>
            </div>
          )}

          <div className="relative px-3 sm:px-6 py-3 bg-gradient-to-r from-[#3e2311] via-[#2d180b] to-[#1e0f07] border-b border-amber-500/50 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 z-10 shrink-0 shadow-lg">
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-b from-yellow-300 via-amber-500 to-amber-700 flex items-center justify-center shadow-[0_0_15px_rgba(234,179,8,0.4)] border border-yellow-200 shrink-0">
                <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-amber-950 fill-amber-950" />
              </div>
              <div className="flex flex-col">
                <h2 className="text-base sm:text-2xl font-black text-amber-100 tracking-wide leading-tight">
                  {isRtl ? 'فرووشگای شاهانە' : 'Royal Shop'}
                </h2>
                <p className="text-[10px] sm:text-xs text-amber-300/80 font-semibold hidden sm:block">
                  {isRtl ? 'جوانکاری و مێز و پارچەکانی شەتڕەنج' : 'Skins, Boards & Custom Pieces'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 shrink-0">
              {/* Currency Badges - Unified 3D Metallic Badges */}
              <div className="flex items-center gap-1.5 sm:gap-2">
                <CurrencyBadge type="coins" amount={localCoins} />
                <CurrencyBadge type="gems" amount={localGems} />
              </div>

              <button
                onClick={() => { soundManager.playClick(); onClose(); }}
                className="w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-b from-amber-800 to-amber-950 border border-amber-500/80 text-amber-200 flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-md cursor-pointer shrink-0"
              >
                <X className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Sidebar Tabs (Desktop) */}
            <div className="md:w-56 bg-gradient-to-b from-[#1c0d06] to-[#120703] border-r border-amber-900/60 p-3 shrink-0 overflow-y-auto hidden md:block">
              <div className="space-y-2">
                {[
                  { id: 'board', labelEn: 'Chess Boards', labelKu: 'مێزەکانی یاری', icon: '🔲' },
                  { id: 'piece', labelEn: 'Piece Skins', labelKu: 'پارچەکانی شەتڕەنج', icon: '♟️' },
                  { id: 'avatar', labelEn: 'Avatars', labelKu: 'ئەڤاتارەکان', icon: '👤' },
                  { id: 'cosmetic', labelEn: 'Cosmetics', labelKu: 'جوانکارییەکان', icon: '✨' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => { soundManager.playClick(); setActiveTab(tab.id as any); }}
                    className={`w-full text-left px-4 py-3 rounded-2xl font-black text-xs sm:text-sm flex items-center gap-3 transition-all cursor-pointer ${
                      activeTab === tab.id 
                        ? 'bg-gradient-to-r from-yellow-500 via-amber-500 to-amber-600 text-amber-950 shadow-lg border border-yellow-300' 
                        : 'text-amber-200/70 hover:bg-amber-900/30 hover:text-amber-100 border border-transparent'
                    }`}
                  >
                    <span className="text-lg">{tab.icon}</span>
                    <span>{isRtl ? tab.labelKu : tab.labelEn}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile Horizontal Tabs */}
            <div className="md:hidden flex overflow-x-auto p-3 bg-[#180b05] border-b border-amber-900/60 gap-2 shrink-0 custom-scrollbar">
              {[
                { id: 'board', labelEn: 'Boards', labelKu: 'مێزەکان', icon: '🔲' },
                { id: 'piece', labelEn: 'Pieces', labelKu: 'پارچەکان', icon: '♟️' },
                { id: 'avatar', labelEn: 'Avatars', labelKu: 'ئەڤاتارەکان', icon: '👤' },
                { id: 'cosmetic', labelEn: 'Cosmetics', labelKu: 'جوانکاری', icon: '✨' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => { soundManager.playClick(); setActiveTab(tab.id as any); }}
                  className={`px-4 py-2 rounded-xl font-black text-xs whitespace-nowrap transition-all flex items-center gap-2 cursor-pointer ${
                    activeTab === tab.id 
                      ? 'bg-gradient-to-r from-yellow-500 to-amber-600 text-amber-950 shadow-md' 
                      : 'bg-[#2a150a] text-amber-200/70 border border-amber-900/50'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{isRtl ? tab.labelKu : tab.labelEn}</span>
                </button>
              ))}
            </div>

            {/* Content Cards Grid */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#110703] custom-scrollbar">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
                {currentItems.length === 0 ? (
                  <div className="col-span-full flex flex-col items-center justify-center p-12 text-amber-400/50 font-bold gap-2">
                    <span className="text-4xl">🛍️</span>
                    <span>{isRtl ? 'هیچ کاڵایەک لەم بەشەدا نییە.' : 'No items found in this section.'}</span>
                  </div>
                ) : null}

                {currentItems.map(item => {
                  const isDefaultOwned = item.priceCoins === 0 && item.priceGems === 0;
                  const isOwned = isDefaultOwned || inventory.includes(item.id);
                  const isEquipped = (item.type === 'piece' && equippedPieceSkin === item.id) || (item.type === 'board' && equippedBoardSkin === item.id);
                  const canAffordCoins = !item.priceCoins || localCoins >= item.priceCoins;
                  const canAffordGems = !item.priceGems || localGems >= item.priceGems;
                  const canAfford = canAffordCoins && canAffordGems;
                  const isProcessing = loadingId === item.id;

                  return (
                    <motion.div
                      key={item.id}
                      whileHover={{ scale: 1.02 }}
                      onMouseEnter={() => {
                        if (item.type === 'piece') onPreviewPieceSkin(item.id as PieceSkinId);
                        if (item.type === 'board') onPreviewBoardSkin(item.id as BoardSkinId);
                      }}
                      onMouseLeave={() => {
                        if (item.type === 'piece') onPreviewPieceSkin(null);
                        if (item.type === 'board') onPreviewBoardSkin(null);
                      }}
                      className={`relative bg-gradient-to-b from-[#221107] to-[#160a04] rounded-2xl border ${
                        isEquipped 
                          ? 'border-yellow-400/90 shadow-[0_0_20px_rgba(250,204,21,0.25)]' 
                          : isOwned 
                            ? 'border-emerald-500/50' 
                            : 'border-amber-900/60 hover:border-amber-600/80'
                      } overflow-hidden flex flex-col transition-all`}
                    >
                      {/* Image / Color Preview Area */}
                      <div 
                        className="h-36 w-full bg-[#0a0402] flex items-center justify-center relative p-3 overflow-hidden border-b border-amber-900/40"
                        style={{ backgroundColor: item.colorHex || undefined }}
                      >
                        {item.imageUrl ? (
                          <img src={item.imageUrl} alt={item.name} className="max-h-full max-w-full object-contain filter drop-shadow-md" />
                        ) : (
                          <div className="flex flex-col items-center gap-1">
                            <span className="text-5xl filter drop-shadow-lg">
                              {item.type === 'board' ? '🔲' : item.type === 'piece' ? '♟️' : item.type === 'avatar' ? '👤' : '✨'}
                            </span>
                          </div>
                        )}

                        {/* Top Badges */}
                        {isEquipped && (
                          <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-amber-500 text-amber-950 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-md border border-yellow-200">
                            {isRtl ? 'بەکارهێنراوە' : 'EQUIPPED'}
                          </div>
                        )}
                        {!isEquipped && isOwned && (
                          <div className="absolute top-2 right-2 bg-emerald-600/90 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-md flex items-center gap-1 border border-emerald-400">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{isRtl ? 'هەتە' : 'OWNED'}</span>
                          </div>
                        )}
                      </div>

                      {/* Card Info */}
                      <div className="p-4 flex-1 flex flex-col justify-between">
                        <div>
                          <h3 className="font-black text-amber-100 text-base leading-snug">{item.name}</h3>
                          <p className="text-amber-200/60 text-xs mt-1 mb-3 line-clamp-2">{item.description}</p>
                        </div>

                        {/* Action Buttons */}
                        <div className="mt-2">
                          {isEquipped ? (
                            <button disabled className="w-full py-2.5 rounded-xl bg-amber-500/15 text-amber-400 font-black text-xs border border-amber-500/30 cursor-default flex items-center justify-center gap-1.5">
                              <CheckCircle2 className="w-4 h-4 text-amber-400" />
                              <span>{isRtl ? 'بەکارهێنراوە' : 'Equipped'}</span>
                            </button>
                          ) : isOwned ? (
                            <button 
                              onClick={() => handleEquip(item)}
                              className="w-full py-2.5 rounded-xl bg-gradient-to-b from-amber-700 to-amber-900 hover:from-amber-600 hover:to-amber-800 text-amber-100 font-black text-xs border border-amber-500/60 transition shadow-md cursor-pointer active:scale-95"
                            >
                              {isRtl ? 'بەکارهێنان' : 'Equip Skin'}
                            </button>
                          ) : (
                            <button
                              onClick={() => handleBuy(item)}
                              disabled={!canAfford || isProcessing}
                              className={`w-full py-2.5 rounded-xl font-black text-xs border transition flex items-center justify-center gap-2 cursor-pointer active:scale-95 ${
                                !canAfford 
                                  ? 'bg-[#180c05] text-amber-600/50 border-amber-900/40 opacity-60 cursor-not-allowed'
                                  : 'bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white border-emerald-400 shadow-lg shadow-emerald-950/80'
                              }`}
                            >
                              {isProcessing ? (
                                <span className="animate-pulse">...</span>
                              ) : (
                                <>
                                  {item.priceCoins ? (
                                    <span className={`flex items-center gap-1 ${!canAffordCoins ? 'text-red-400' : ''}`}>
                                      <GoldCoinIcon className="w-4 h-4" /> {item.priceCoins.toLocaleString()}
                                    </span>
                                  ) : null}
                                  {item.priceCoins && item.priceGems ? <span className="text-amber-200/40">|</span> : null}
                                  {item.priceGems ? (
                                    <span className={`flex items-center gap-1 ${!canAffordGems ? 'text-red-400' : ''}`}>
                                      <GemIcon className="w-4 h-4" /> {item.priceGems.toLocaleString()}
                                    </span>
                                  ) : null}
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
