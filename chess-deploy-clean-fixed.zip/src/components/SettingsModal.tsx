import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings, X, Globe, Bot, Volume2, VolumeX, Music, BookOpen, Disc, LogOut } from 'lucide-react';
import { Language, AIDifficulty } from '../types';
import { getTranslation } from '../lib/translations';
import { soundManager, MusicTrackId } from '../lib/soundManager';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSelectLanguage: (lang: Language) => void;
  aiDifficulty: AIDifficulty;
  onSelectAIDifficulty: (diff: AIDifficulty) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  musicEnabled: boolean;
  onToggleMusic: () => void;
  onLogout?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  language,
  onSelectLanguage,
  aiDifficulty,
  onSelectAIDifficulty,
  soundEnabled,
  onToggleSound,
  musicEnabled,
  onToggleMusic,
  onLogout,
}) => {
  const [currentTrack, setCurrentTrack] = useState<MusicTrackId>(soundManager.getCurrentTrack());

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  const handleSelectTrack = (track: MusicTrackId) => {
    setCurrentTrack(track);
    soundManager.setMusicTrack(track);
    if (!musicEnabled) {
      onToggleMusic();
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className={`w-full max-w-lg bg-gradient-to-b from-amber-950 via-amber-900 to-amber-950 border-2 border-amber-500/70 rounded-3xl p-6 shadow-2xl text-amber-50 relative overflow-hidden ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-amber-700/50 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-600 text-amber-950 shadow-lg">
                <Settings className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-amber-200">
                  {getTranslation(language, 'settings')}
                </h3>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-amber-900/60 hover:bg-amber-800 text-amber-300 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-5 max-h-96 overflow-y-auto p-1">
            {/* Language Setting */}
            <div className="bg-amber-900/50 border border-amber-700/50 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-2 font-bold text-amber-200 text-sm">
                <Globe className="w-4 h-4 text-yellow-400" />
                <span>{getTranslation(language, 'language')}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onSelectLanguage('ku')}
                  className={`py-2.5 rounded-xl font-bold text-xs border transition cursor-pointer ${
                    language === 'ku'
                      ? 'bg-yellow-400 text-amber-950 border-yellow-300 shadow'
                      : 'bg-amber-950/60 text-amber-200 border-amber-800 hover:border-amber-600'
                  }`}
                >
                  {getTranslation(language, 'kurdish')}
                </button>

                <button
                  onClick={() => onSelectLanguage('en')}
                  className={`py-2.5 rounded-xl font-bold text-xs border transition cursor-pointer ${
                    language === 'en'
                      ? 'bg-yellow-400 text-amber-950 border-yellow-300 shadow'
                      : 'bg-amber-950/60 text-amber-200 border-amber-800 hover:border-amber-600'
                  }`}
                >
                  {getTranslation(language, 'english')}
                </button>
              </div>
            </div>

            {/* AI Difficulty Setting */}
            <div className="bg-amber-900/50 border border-amber-700/50 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-2 font-bold text-amber-200 text-sm">
                <Bot className="w-4 h-4 text-yellow-400" />
                <span>{getTranslation(language, 'aiLevel')}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {(['easy', 'medium', 'hard', 'gemini_master'] as AIDifficulty[]).map((diff) => (
                  <button
                    key={diff}
                    onClick={() => onSelectAIDifficulty(diff)}
                    className={`py-2.5 rounded-xl font-bold text-xs border transition cursor-pointer ${
                      aiDifficulty === diff
                        ? 'bg-amber-500 text-amber-950 border-yellow-300 shadow'
                        : 'bg-amber-950/60 text-amber-200 border-amber-800 hover:border-amber-600'
                    }`}
                  >
                    {diff === 'easy'
                      ? getTranslation(language, 'easy')
                      : diff === 'medium'
                      ? getTranslation(language, 'medium')
                      : diff === 'hard'
                      ? getTranslation(language, 'hard')
                      : getTranslation(language, 'geminiMaster')}
                  </button>
                ))}
              </div>
            </div>

            {/* Sound & Music Toggles */}
            <div className="bg-amber-900/50 border border-amber-700/50 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-amber-200 text-sm">
                  <Volume2 className="w-4 h-4 text-yellow-400" />
                  <span>{getTranslation(language, 'soundEffects')}</span>
                </div>
                <button
                  onClick={onToggleSound}
                  className={`w-12 h-6 rounded-full p-1 transition cursor-pointer ${
                    soundEnabled ? 'bg-emerald-500' : 'bg-amber-950 border border-amber-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition transform ${
                      soundEnabled ? (isRtl ? '-translate-x-6' : 'translate-x-6') : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between border-t border-amber-800/40 pt-3">
                <div className="flex items-center gap-2 font-bold text-amber-200 text-sm">
                  <Music className="w-4 h-4 text-yellow-400" />
                  <span>{getTranslation(language, 'music')}</span>
                </div>
                <button
                  onClick={onToggleMusic}
                  className={`w-12 h-6 rounded-full p-1 transition cursor-pointer ${
                    musicEnabled ? 'bg-emerald-500' : 'bg-amber-950 border border-amber-700'
                  }`}
                >
                  <div
                    className={`w-4 h-4 rounded-full bg-white transition transform ${
                      musicEnabled ? (isRtl ? '-translate-x-6' : 'translate-x-6') : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Music Track Selection */}
              <div className="border-t border-amber-800/40 pt-3 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
                  <Disc className="w-3.5 h-3.5 text-yellow-400 animate-spin" style={{ animationDuration: '6s' }} />
                  <span>{isRtl ? 'ناوی مۆسیقای ناو یاری (Music Track)' : 'Chess Music Track'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    onClick={() => handleSelectTrack('royal_erbil')}
                    className={`p-2 rounded-xl text-[11px] font-bold border transition text-center cursor-pointer ${
                      currentTrack === 'royal_erbil' && musicEnabled
                        ? 'bg-yellow-500 text-amber-950 border-yellow-200 font-black shadow'
                        : 'bg-amber-950/70 text-amber-200 border-amber-800 hover:border-amber-600'
                    }`}
                  >
                    🎵 {isRtl ? 'شاهانەی قەڵا' : 'Royal Erbil Oud'}
                  </button>

                  <button
                    onClick={() => handleSelectTrack('classical_piano')}
                    className={`p-2 rounded-xl text-[11px] font-bold border transition text-center cursor-pointer ${
                      currentTrack === 'classical_piano' && musicEnabled
                        ? 'bg-yellow-500 text-amber-950 border-yellow-200 font-black shadow'
                        : 'bg-amber-950/70 text-amber-200 border-amber-800 hover:border-amber-600'
                    }`}
                  >
                    🎹 {isRtl ? 'پیانۆی گراندماستەر' : 'Grandmaster Piano'}
                  </button>

                  <button
                    onClick={() => handleSelectTrack('lofi_ambient')}
                    className={`p-2 rounded-xl text-[11px] font-bold border transition text-center cursor-pointer ${
                      currentTrack === 'lofi_ambient' && musicEnabled
                        ? 'bg-yellow-500 text-amber-950 border-yellow-200 font-black shadow'
                        : 'bg-amber-950/70 text-amber-200 border-amber-800 hover:border-amber-600'
                    }`}
                  >
                    🎧 {isRtl ? 'لۆفای ئارامبەخش' : 'Chill Lo-Fi Focus'}
                  </button>
                </div>
              </div>
            </div>

            {/* Rules Section */}
            <div className="bg-amber-900/50 border border-amber-700/50 rounded-2xl p-4 space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-200 text-sm">
                <BookOpen className="w-4 h-4 text-yellow-400" />
                <span>{getTranslation(language, 'rules')}</span>
              </div>
              <p className="text-xs text-amber-200/80 leading-relaxed">
                {getTranslation(language, 'rulesDesc')}
              </p>
            </div>

            {onLogout && (
              <div className="pt-2">
                <button
                  onClick={() => {
                    soundManager.playClick();
                    onClose();
                    onLogout();
                  }}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-red-700 via-rose-600 to-red-800 border border-red-400 text-white font-black text-xs shadow-xl flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 transition cursor-pointer"
                >
                  <LogOut className="w-4 h-4 text-red-200" />
                  <span>{isRtl ? 'دەرچوون لە هەژمار (Log Out)' : 'Log Out Account'}</span>
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
