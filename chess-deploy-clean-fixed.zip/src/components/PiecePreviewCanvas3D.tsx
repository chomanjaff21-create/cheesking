import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { PieceSkinId, BoardSkinId } from '../types';
import { getMaterialsForCustomSkins, create3DPieceGroup } from '../lib/3dPieceGenerator';

interface PiecePreviewCanvas3DProps {
  pieceSkin: PieceSkinId;
  boardSkin?: BoardSkinId;
}

export const PiecePreviewCanvas3D: React.FC<PiecePreviewCanvas3DProps> = ({
  pieceSkin,
  boardSkin = 'classic_wood',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 320;
    const height = container.clientHeight || 220;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(0, 2.5, 4.5);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 2.0;
    controls.maxDistance = 7.5;
    controls.maxPolarAngle = Math.PI / 2 - 0.05; // Don't go below floor
    controls.autoRotate = true;
    controls.autoRotateSpeed = 2.0;
    controlsRef.current = controls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xfffbeb, 1.6);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffedd5, 2.5);
    keyLight.position.set(4, 7, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    fillLight.position.set(-4, 5, -3);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xfef08a, 1.8);
    rimLight.position.set(0, 6, -5);
    scene.add(rimLight);

    // Mini Circular Pedestal Stage
    const stageGroup = new THREE.Group();
    const baseGeom = new THREE.CylinderGeometry(1.65, 1.8, 0.25, 48);
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x1c1917,
      roughness: 0.25,
      metalness: 0.8,
    });
    const stageBase = new THREE.Mesh(baseGeom, baseMat);
    stageBase.position.y = -0.125;
    stageBase.receiveShadow = true;
    stageGroup.add(stageBase);

    // Gold Rim Ring
    const goldRimGeom = new THREE.TorusGeometry(1.68, 0.035, 16, 48);
    const goldRimMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.95,
      roughness: 0.15,
    });
    const goldRim = new THREE.Mesh(goldRimGeom, goldRimMat);
    goldRim.rotation.x = Math.PI / 2;
    goldRim.position.y = 0.01;
    stageGroup.add(goldRim);

    // Inner Inlay
    const materials = getMaterialsForCustomSkins(pieceSkin as PieceSkinId, boardSkin as BoardSkinId);
    const inlayGeom = new THREE.CylinderGeometry(1.58, 1.58, 0.02, 48);
    const inlay = new THREE.Mesh(inlayGeom, materials.boardLight);
    inlay.position.y = 0.01;
    inlay.receiveShadow = true;
    stageGroup.add(inlay);

    scene.add(stageGroup);

    // Build the 3D showcase piece models: King (White) and Knight (Black) side-by-side
    const piecesHolder = new THREE.Group();
    piecesHolder.name = 'preview_pieces_holder';

    // White King
    const whitePiece = create3DPieceGroup('k', materials.whitePiece, pieceSkin as PieceSkinId);
    whitePiece.position.set(-0.6, 0.02, 0);
    whitePiece.rotation.y = 0.35;
    piecesHolder.add(whitePiece);

    // Black Knight (or Queen)
    const blackPiece = create3DPieceGroup('n', materials.blackPiece, pieceSkin as PieceSkinId);
    blackPiece.position.set(0.6, 0.02, 0);
    blackPiece.rotation.y = -0.35;
    piecesHolder.add(blackPiece);

    scene.add(piecesHolder);

    // Animation Loop
    let clock = new THREE.Clock();
    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();
      controls.update();

      // Subtle breathing float on pieces
      whitePiece.position.y = 0.02 + Math.sin(elapsed * 2.5) * 0.03;
      blackPiece.position.y = 0.02 + Math.cos(elapsed * 2.5) * 0.03;

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current || !renderer || !camera) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      renderer.dispose();
    };
  }, [pieceSkin, boardSkin]);

  return (
    <div className="w-full h-44 sm:h-52 relative rounded-2xl overflow-hidden bg-gradient-to-b from-black/70 via-amber-950/40 to-black/80 border border-amber-500/40 shadow-inner">
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] text-amber-300/80 bg-black/60 px-3 py-0.5 rounded-full border border-amber-600/40 pointer-events-none font-bold whitespace-nowrap">
        🔄 دەتوانیت بە دەست بیخولێنیتەوە (Interactive 3D)
      </div>
    </div>
  );
};
