import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  GraduationCap,
  X,
  Play,
  CheckCircle2,
  Lock,
  Star,
  List,
  Sparkles,
  Trophy,
  Award,
  Coins,
  ChevronRight,
  ChevronLeft,
  Info,
  Gift,
} from 'lucide-react';
import { Language, ChessPuzzle } from '../types';
import { CHESS_40_STAGES, StageItem } from '../data/stagesData';
import { soundManager } from '../lib/soundManager';
import { fetchPuzzleStatus, claimPuzzleReward } from '../lib/rewardsService';

interface PuzzlesModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onSelectPuzzle: (puzzle: ChessPuzzle) => void;
  userCoins?: number;
  onUpdateCoins?: (newCoins: number) => void;
}

interface FlyingCoin {
  id: number;
  startX: number;
  startY: number;
}

export const PuzzlesModal: React.FC<PuzzlesModalProps> = ({
  isOpen,
  onClose,
  language,
  onSelectPuzzle,
  userCoins = 17700,
  onUpdateCoins,
}) => {
  const [completedLevels, setCompletedLevels] = useState<number[]>([1, 2, 3]);
  const [claimedRewards, setClaimedRewards] = useState<number[]>([1, 2]);
  const [currentActiveLevel, setCurrentActiveLevel] = useState<number>(4);
  const [selectedStageModal, setSelectedStageModal] = useState<StageItem | null>(null);
  const [viewTab, setViewTab] = useState<'learn' | 'puzzles' | 'events'>('learn');
  const [isClaiming, setIsClaiming] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Animation states for money/coins
  const [flyingCoins, setFlyingCoins] = useState<FlyingCoin[]>([]);
  const [rewardToast, setRewardToast] = useState<{ coins: number; show: boolean }>({
    coins: 0,
    show: false,
  });

  const loadPuzzleStatus = useCallback(async () => {
    try {
      const status = await fetchPuzzleStatus();
      if (status) {
        if (status.completedLevels && status.completedLevels.length > 0) {
          setCompletedLevels(status.completedLevels);
        }
        if (status.claimedRewards && status.claimedRewards.length > 0) {
          setClaimedRewards(status.claimedRewards);
        }
        const maxCompleted = status.completedLevels && status.completedLevels.length > 0
          ? Math.max(...status.completedLevels)
          : 0;
        setCurrentActiveLevel(Math.min(40, maxCompleted + 1));
      }
    } catch (e) {
      console.warn('Failed to load puzzle status:', e);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      setErrorMessage(null);
      loadPuzzleStatus();
    }
  }, [isOpen, loadPuzzleStatus]);

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  // Trigger floating coin animation
  const triggerCoinAnimation = (rewardAmount: number, newBalance?: number, eventX?: number, eventY?: number) => {
    soundManager.playClick();

    // Spawning coin particles
    const newCoins: FlyingCoin[] = Array.from({ length: 8 }, (_, i) => ({
      id: Date.now() + i,
      startX: eventX ?? window.innerWidth / 2,
      startY: eventY ?? window.innerHeight / 2,
    }));

    setFlyingCoins((prev) => [...prev, ...newCoins]);

    // Show reward toast
    setRewardToast({ coins: rewardAmount, show: true });

    // Update global coin state with authoritative server balance
    if (onUpdateCoins) {
      if (typeof newBalance === 'number') {
        onUpdateCoins(newBalance);
      } else {
        onUpdateCoins(userCoins + rewardAmount);
      }
    }

    setTimeout(() => {
      setFlyingCoins((prev) => prev.filter((c) => !newCoins.some((nc) => nc.id === c.id)));
    }, 1200);

    setTimeout(() => {
      setRewardToast({ coins: 0, show: false });
    }, 2500);
  };

  const handleClaimReward = async (stg: StageItem, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (claimedRewards.includes(stg.levelNumber) || isClaiming) return;

    setIsClaiming(true);
    setErrorMessage(null);
    try {
      const res = await claimPuzzleReward(stg.id, stg.levelNumber);
      if (!res.success) {
        if (res.alreadyClaimed) {
          setClaimedRewards((prev) => Array.from(new Set([...prev, stg.levelNumber])));
        }
        setErrorMessage(res.error || (isRtl ? 'ئەم خەڵاتە پێشتر وەرگیراوە' : 'Reward already claimed'));
        return;
      }

      setClaimedRewards((prev) => Array.from(new Set([...prev, stg.levelNumber])));
      setCompletedLevels((prev) => Array.from(new Set([...prev, stg.levelNumber])));

      const rect = e?.currentTarget.getBoundingClientRect();
      const x = rect ? rect.left + rect.width / 2 : window.innerWidth / 2;
      const y = rect ? rect.top + rect.height / 2 : window.innerHeight / 2;

      triggerCoinAnimation(res.coinsAwarded, res.newBalance, x, y);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to claim reward');
    } finally {
      setIsClaiming(false);
    }
  };

  // Filter stages based on tab selection
  const filteredStages = CHESS_40_STAGES.filter((stg) => {
    if (viewTab === 'learn') return stg.chapterId === 1;
    if (viewTab === 'puzzles') return stg.chapterId === 2;
    return stg.chapterId === 3;
  });

  const activeStageItem = CHESS_40_STAGES.find((s) => s.levelNumber === currentActiveLevel) || CHESS_40_STAGES[0];

  const handleStageClick = (stg: StageItem, e?: React.MouseEvent) => {
    soundManager.playClick();
    setSelectedStageModal(stg);
  };

  const handleStartLevel = (stg: StageItem) => {
    soundManager.playClick();
    setSelectedStageModal(null);
    onSelectPuzzle(stg);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex flex-col justify-between bg-gradient-to-b from-[#2a0e02] via-[#160600] to-[#0a0200] text-amber-100 overflow-hidden select-none font-sans">
        
        {/* ========================================================= */}
        {/* TOP ROYAL APP BAR (MATCHING APP MAIN WOOD & GOLD THEME) */}
        {/* ========================================================= */}
        <div className="w-full bg-gradient-to-r from-amber-950 via-[#3a1606] to-amber-950 border-b-2 border-amber-600/80 px-3 sm:px-4 py-2.5 flex items-center justify-between z-30 shrink-0 shadow-2xl relative">
          
          {/* Gold Filigree Corner Accent */}
          <div className="absolute top-1 left-2 text-amber-400/60 text-xs">✦</div>
          <div className="absolute top-1 right-2 text-amber-400/60 text-xs">✦</div>

          {/* Close Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="w-9 h-9 rounded-xl bg-gradient-to-b from-amber-800 to-amber-950 border-2 border-amber-500/80 text-amber-200 hover:brightness-125 flex items-center justify-center transition cursor-pointer shadow-lg active:scale-95 shrink-0"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Center Title & Graduation Cap Icon */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-b from-amber-400 via-amber-500 to-amber-700 border border-yellow-300 text-amber-950 flex items-center justify-center shadow-[0_0_15px_rgba(245,158,11,0.6)]">
              <GraduationCap className="w-5 h-5 fill-amber-950" />
            </div>
            <h2 className="text-base sm:text-lg font-black text-yellow-300 tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
              {isRtl ? 'فێربوون و مەتەڵەکان' : 'Learn & Puzzles'}
            </h2>
          </div>

          {/* Top Coins Balance Counter (PROMINENT & GLOWING) */}
          <div className="flex items-center gap-1.5 bg-gradient-to-r from-amber-950/90 via-amber-900/90 to-amber-950/90 border-2 border-yellow-400/80 rounded-2xl px-2.5 sm:px-3 py-1 shadow-[0_0_15px_rgba(245,158,11,0.5)]">
            <div className="w-5 h-5 rounded-full bg-gradient-to-b from-yellow-300 to-amber-600 border border-yellow-200 flex items-center justify-center shadow">
              <Coins className="w-3.5 h-3.5 text-amber-950 fill-current" />
            </div>
            <span className="font-mono font-black text-yellow-300 text-sm sm:text-base tracking-wider drop-shadow">
              {userCoins.toLocaleString()} $
            </span>
          </div>

        </div>

        {/* ERROR NOTIFICATION BANNER */}
        {errorMessage && (
          <div className="w-full bg-red-950/90 border-b border-red-500/80 px-4 py-1.5 text-center text-xs text-red-200 shadow-md z-30">
            {errorMessage}
          </div>
        )}

        {/* ========================================================= */}
        {/* CHAPTER TABS SELECTOR (LEARN / PUZZLES / EVENTS) */}
        {/* ========================================================= */}
        <div className="w-full bg-[#1c0801] border-b border-amber-800/60 px-3 py-2 flex items-center justify-center gap-2 z-20 shrink-0">
          <div className="flex items-center gap-1.5 bg-[#0e0401] p-1 rounded-2xl border border-amber-700/60 shadow-inner max-w-md w-full justify-around">
            <button
              onClick={() => {
                soundManager.playClick();
                setViewTab('learn');
              }}
              className={`flex-1 py-1.5 rounded-xl text-xs sm:text-sm font-black transition cursor-pointer flex items-center justify-center gap-1.5 ${
                viewTab === 'learn'
                  ? 'bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 text-amber-950 border border-yellow-200 shadow-[0_4px_15px_rgba(245,158,11,0.5)]'
                  : 'text-amber-300/70 hover:text-amber-100'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>{isRtl ? 'وانەکان' : 'Learn'}</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                setViewTab('puzzles');
              }}
              className={`flex-1 py-1.5 rounded-xl text-xs sm:text-sm font-black transition cursor-pointer flex items-center justify-center gap-1.5 ${
                viewTab === 'puzzles'
                  ? 'bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 text-amber-950 border border-yellow-200 shadow-[0_4px_15px_rgba(245,158,11,0.5)]'
                  : 'text-amber-300/70 hover:text-amber-100'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>{isRtl ? 'مەتەڵەکان' : 'Puzzles'}</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                setViewTab('events');
              }}
              className={`flex-1 py-1.5 rounded-xl text-xs sm:text-sm font-black transition cursor-pointer flex items-center justify-center gap-1.5 ${
                viewTab === 'events'
                  ? 'bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 text-amber-950 border border-yellow-200 shadow-[0_4px_15px_rgba(245,158,11,0.5)]'
                  : 'text-amber-300/70 hover:text-amber-100'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>{isRtl ? 'ئیڤێنتەکان' : 'Events'}</span>
            </button>
          </div>
        </div>

        {/* ========================================================= */}
        {/* GRANDMASTER COACH SPEECH BUBBLE (PARCHMENT ROYAL CARD) */}
        {/* ========================================================= */}
        <div className="w-full bg-gradient-to-b from-[#240b02] to-[#1a0802] border-b border-amber-800/60 p-3 sm:p-4 flex items-center justify-center gap-3 z-20 shrink-0 shadow-xl">
          {/* Coach Male Avatar with Gold Frame */}
          <div className="relative shrink-0">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-b from-amber-400 via-amber-600 to-amber-950 p-0.5 border-2 border-yellow-300 shadow-[0_0_20px_rgba(245,158,11,0.6)] flex items-center justify-center overflow-hidden">
              <div className="w-full h-full rounded-xl bg-gradient-to-b from-[#3d1806] to-[#180802] flex items-center justify-center text-3xl sm:text-4xl">
                👨‍🏫
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 bg-emerald-500 border-2 border-amber-950 rounded-full w-4 h-4 shadow-md animate-pulse" />
          </div>

          {/* Parchment Speech Bubble */}
          <div className="relative bg-gradient-to-r from-amber-100 via-yellow-50 to-amber-100 text-amber-950 rounded-2xl p-3 sm:p-3.5 shadow-[0_8px_25px_rgba(0,0,0,0.6)] max-w-md w-full border-2 border-amber-400">
            {/* Pointer Arrow on Left / RTL Right */}
            <div className={`absolute top-5 w-0 h-0 border-y-8 border-y-transparent ${
              isRtl
                ? '-right-2 border-l-8 border-l-amber-100'
                : '-left-2 border-r-8 border-r-amber-100'
            }`} />
            
            <p className="text-xs sm:text-sm font-extrabold leading-snug">
              {isRtl ? activeStageItem.descriptionKu : activeStageItem.descriptionEn}
            </p>
            <div className="mt-1.5 flex items-center justify-between text-[11px] text-amber-900 font-bold border-t border-amber-300/80 pt-1">
              <span>{isRtl ? `قۆناغی ${activeStageItem.levelNumber} لە ٤٠` : `Stage ${activeStageItem.levelNumber} of 40`}</span>
              <div className="flex items-center gap-1 bg-amber-900/10 border border-amber-800/30 rounded-lg px-2 py-0.5 font-black text-amber-900">
                <Coins className="w-3.5 h-3.5 text-amber-700 fill-current" />
                <span>+{activeStageItem.rewardCoins} $</span>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================= */}
        {/* ISOMETRIC ROADMAP CANVAS (ROYAL WOOD PATTERN & GOLD PATH) */}
        {/* ========================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 custom-scrollbar relative bg-[#180802] bg-[radial-gradient(#381607_2px,transparent_2px)] [background-size:24px_24px]">
          
          {/* FLOATING REWARD TOAST NOTIFICATION */}
          <AnimatePresence>
            {rewardToast.show && (
              <motion.div
                initial={{ opacity: 0, y: -20, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.8 }}
                className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-amber-950 via-amber-900 to-amber-950 border-2 border-yellow-400 text-yellow-300 px-6 py-2.5 rounded-full shadow-[0_0_35px_rgba(245,158,11,0.8)] flex items-center gap-2 font-mono font-black text-lg tracking-wider"
              >
                <Coins className="w-6 h-6 text-yellow-400 animate-bounce" />
                <span>+{rewardToast.coins} $ {isRtl ? 'زێڕ وەرگیرا!' : 'Coins Claimed!'}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* FLYING COIN PARTICLES */}
          {flyingCoins.map((coin) => (
            <motion.div
              key={coin.id}
              initial={{
                x: coin.startX,
                y: coin.startY,
                opacity: 1,
                scale: 1,
              }}
              animate={{
                x: window.innerWidth - 60,
                y: 20,
                opacity: 0,
                scale: 0.4,
              }}
              transition={{ duration: 0.9, ease: 'easeOut' }}
              className="fixed z-50 pointer-events-none text-2xl filter drop-shadow-[0_0_8px_rgba(245,158,11,1)]"
            >
              🪙
            </motion.div>
          ))}

          <div className="max-w-md mx-auto py-6 flex flex-col items-center gap-12 relative">

            {/* Glowing Golden Connecting Line Path SVG */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none stroke-[#d6982a] stroke-[5] stroke-dasharray-[6_6]" fill="none">
              <path
                d="M 200 60 Q 280 120 200 180 Q 120 240 200 300 Q 280 360 200 420 Q 120 480 200 540 Q 280 600 200 660 Q 120 720 200 780"
                className="opacity-80 filter drop-shadow-[0_0_10px_rgba(214,152,42,0.8)]"
              />
            </svg>

            {filteredStages.map((stg, idx) => {
              const isCompleted = completedLevels.includes(stg.levelNumber);
              const isActive = stg.levelNumber === currentActiveLevel;
              const isLocked = !isCompleted && !isActive;
              const isClaimed = claimedRewards.includes(stg.levelNumber);

              // Alternating zig-zag offset positions
              const offsetPattern = [0, 52, 80, 52, 0, -52, -80, -52];
              const xOffset = offsetPattern[idx % offsetPattern.length];

              return (
                <div
                  key={stg.id}
                  style={{ transform: `translateX(${xOffset}px)` }}
                  className="relative flex flex-col items-center z-10 transition-transform duration-300"
                >
                  {/* FLOATING "Next / دواتر" SPEECH BUBBLE FOR ACTIVE STAGE */}
                  {isActive && (
                    <motion.div
                      animate={{ y: [-4, 4, -4] }}
                      transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                      className="absolute -top-12 z-30 flex flex-col items-center"
                    >
                      <div className="bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-300 text-amber-950 px-4 py-1 rounded-xl font-black text-xs sm:text-sm shadow-[0_6px_20px_rgba(245,158,11,0.8)] border border-white tracking-wider flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 fill-amber-950" />
                        <span>{isRtl ? 'دواتر (Next)' : 'Next'}</span>
                      </div>
                      <div className="w-0 h-0 border-x-6 border-x-transparent border-t-6 border-t-amber-400 -mt-0.5" />
                    </motion.div>
                  )}

                  {/* ISOMETRIC DIAMOND TILE STAGE NODE */}
                  <motion.button
                    whileHover={{ scale: 1.1, zIndex: 20 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={(e) => handleStageClick(stg, e)}
                    className={`relative w-20 h-20 sm:w-22 sm:h-22 rounded-2xl cursor-pointer transition-all duration-300 flex items-center justify-center shadow-2xl ${
                      isActive
                        ? 'bg-gradient-to-br from-yellow-300 via-amber-500 to-amber-700 border-4 border-yellow-200 shadow-[0_0_35px_rgba(245,158,11,0.9)] rotate-45 scale-105'
                        : isCompleted
                        ? 'bg-gradient-to-br from-emerald-600 via-emerald-800 to-emerald-950 border-2 border-yellow-400/80 rotate-45 shadow-[0_0_15px_rgba(16,185,129,0.5)]'
                        : 'bg-gradient-to-br from-[#2a0e02] to-[#120401] border-2 border-amber-900/60 rotate-45 opacity-80'
                    }`}
                  >
                    {/* Inner Diamond Content (Un-rotated text/icon) */}
                    <div className="-rotate-45 flex flex-col items-center justify-center text-center">
                      
                      {/* Piece Icon / Symbol */}
                      <span className={`text-2xl sm:text-3xl font-black leading-none ${
                        isActive
                          ? 'text-amber-950 drop-shadow-[0_1px_2px_rgba(255,255,255,0.6)]'
                          : isCompleted
                          ? 'text-yellow-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]'
                          : 'text-amber-700/60'
                      }`}>
                        {stg.pieceIcon}
                      </span>

                      {/* Level Number Badge */}
                      <span className={`text-[10px] font-black mt-0.5 ${
                        isActive ? 'text-amber-950 bg-yellow-200 px-1.5 py-0.2 rounded-md shadow' : 'text-amber-200/90'
                      }`}>
                        #{stg.levelNumber}
                      </span>

                      {/* Status Icon Indicator */}
                      {isCompleted && (
                        <CheckCircle2 className="w-4.5 h-4.5 text-yellow-300 absolute -bottom-1 -right-1 fill-emerald-900 shadow" />
                      )}
                      {isLocked && (
                        <Lock className="w-3.5 h-3.5 text-amber-700 absolute -bottom-1 -right-1" />
                      )}
                    </div>
                  </motion.button>

                  {/* Level Title & Reward Coins Badge below diamond */}
                  <div className="mt-2.5 flex flex-col items-center gap-0.5">
                    <span className={`text-xs font-black tracking-wide ${
                      isActive ? 'text-yellow-300 drop-shadow' : 'text-amber-200/80'
                    }`}>
                      {isRtl ? stg.titleKu : stg.titleEn}
                    </span>

                    {/* Money Amount Badge (+100 $) */}
                    {isCompleted && !isClaimed ? (
                      <button
                        onClick={(e) => handleClaimReward(stg, e)}
                        className="mt-0.5 px-2 py-0.5 rounded-full bg-gradient-to-r from-yellow-400 via-amber-500 to-amber-600 border border-yellow-200 text-amber-950 font-black text-[10px] shadow-[0_0_12px_rgba(245,158,11,0.8)] hover:scale-105 active:scale-95 transition cursor-pointer flex items-center gap-1 animate-bounce"
                      >
                        <Gift className="w-3 h-3 fill-amber-950" />
                        <span>+{stg.rewardCoins} $ (وەربگرە)</span>
                      </button>
                    ) : (
                      <div className="flex items-center gap-1 bg-amber-950/80 border border-amber-600/50 rounded-full px-2 py-0.2 text-[10px] font-mono font-black text-yellow-300 shadow">
                        <Coins className="w-3 h-3 text-yellow-400" />
                        <span>+{stg.rewardCoins} $</span>
                      </div>
                    )}
                  </div>

                </div>
              );
            })}

          </div>

        </div>

        {/* ========================================================= */}
        {/* BOTTOM ROYAL ACTION BAR & GREEN/GOLD "NEXT LESSON" BUTTON */}
        {/* ========================================================= */}
        <div className="w-full bg-gradient-to-r from-amber-950 via-[#3a1606] to-amber-950 border-t-2 border-amber-600/80 p-3 px-4 flex items-center justify-between gap-3 z-30 shrink-0 shadow-2xl">
          
          {/* Left List Menu Button */}
          <button
            onClick={() => {
              soundManager.playClick();
            }}
            className="w-12 h-12 rounded-2xl bg-gradient-to-b from-amber-800 to-amber-950 border-2 border-amber-500/80 text-amber-200 hover:brightness-125 flex items-center justify-center transition cursor-pointer shadow-lg active:scale-95 shrink-0"
          >
            <List className="w-6 h-6" />
          </button>

          {/* BIG 3D GOLDEN ACTION BUTTON */}
          <button
            onClick={() => handleStartLevel(activeStageItem)}
            className="flex-1 py-3.5 rounded-2xl bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 border-b-4 border-amber-800 text-amber-950 font-black text-base sm:text-lg shadow-[0_8px_25px_rgba(245,158,11,0.6)] hover:brightness-110 active:scale-98 transition cursor-pointer flex items-center justify-center gap-2"
          >
            <Play className="w-5.5 h-5.5 fill-amber-950 text-amber-950" />
            <span>{isRtl ? 'وانەی دواتر (Next Lesson)' : 'Next Lesson'}</span>
          </button>

          {/* Right Stage Info Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              setSelectedStageModal(activeStageItem);
            }}
            className="w-12 h-12 rounded-2xl bg-gradient-to-b from-amber-800 to-amber-950 border-2 border-amber-500/80 text-amber-200 hover:brightness-125 flex items-center justify-center transition cursor-pointer shadow-lg active:scale-95 shrink-0"
          >
            <Info className="w-6 h-6" />
          </button>
        </div>

        {/* ========================================================= */}
        {/* STAGE DETAILS POPUP MODAL (ROYAL WOOD & GOLD THEME) */}
        {/* ========================================================= */}
        {selectedStageModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-gradient-to-b from-[#3d1806] via-[#250c02] to-[#120401] border-2 border-yellow-400 rounded-3xl p-6 text-amber-100 shadow-[0_0_50px_rgba(245,158,11,0.6)] relative flex flex-col items-center"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedStageModal(null)}
                className="absolute top-3.5 right-3.5 text-amber-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Top Piece Icon */}
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-b from-yellow-300 via-amber-500 to-amber-700 border-2 border-yellow-200 flex items-center justify-center text-4xl shadow-[0_0_25px_rgba(245,158,11,0.8)] mb-3">
                {selectedStageModal.pieceIcon}
              </div>

              {/* Stage Level Number */}
              <span className="text-[11px] font-black bg-amber-900/80 text-yellow-300 border border-amber-600/60 px-3 py-0.5 rounded-full uppercase tracking-wider mb-1">
                {isRtl ? `قۆناغی #${selectedStageModal.levelNumber}` : `Stage #${selectedStageModal.levelNumber}`}
              </span>

              {/* Stage Title */}
              <h3 className="text-lg font-black text-yellow-300 text-center mb-3 drop-shadow">
                {isRtl ? selectedStageModal.titleKu : selectedStageModal.titleEn}
              </h3>

              {/* Description & Rewards Card */}
              <div className="w-full bg-amber-950/80 p-4 rounded-2xl border border-amber-700/60 space-y-3 text-xs text-amber-200/90 mb-5 shadow-inner text-center">
                <p className="font-medium leading-relaxed">
                  {isRtl ? selectedStageModal.descriptionKu : selectedStageModal.descriptionEn}
                </p>
                <div className="flex items-center justify-between pt-2.5 border-t border-amber-800/80 font-mono font-black text-yellow-300 text-sm">
                  <span>{isRtl ? 'خەڵاتی سەرکەوتن:' : 'Reward:'}</span>
                  <div className="flex items-center gap-1.5 bg-amber-900/90 border border-yellow-400/80 px-3 py-1 rounded-xl">
                    <Coins className="w-4 h-4 text-yellow-400" />
                    <span>+{selectedStageModal.rewardCoins} $</span>
                  </div>
                </div>
              </div>

              {/* Start Stage Button */}
              <button
                onClick={() => handleStartLevel(selectedStageModal)}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 border-b-4 border-amber-800 text-amber-950 font-black text-base shadow-[0_8px_25px_rgba(245,158,11,0.6)] hover:brightness-110 active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5 fill-amber-950" />
                <span>{isRtl ? 'دەستپێکردنی قۆناغ' : 'Start Stage'}</span>
              </button>
            </motion.div>
          </div>
        )}

      </div>
    </AnimatePresence>
  );
};
