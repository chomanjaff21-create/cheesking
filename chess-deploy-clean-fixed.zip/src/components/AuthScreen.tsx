import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useRealtimeStore } from '../lib/realtime';
import { Crown, Mail, Lock, User, AlertCircle, Loader2, Eye, EyeOff, Shield, LogIn, UserPlus } from 'lucide-react';
import { Language } from '../types';
import { soundManager } from '../lib/soundManager';

interface AuthScreenProps {
  language: Language;
  onAuthSuccess: () => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ language, onAuthSuccess }) => {
  const isRtl = language === 'ku';
  const { authenticate, authenticateDevice, authenticateWithGoogle, isAuthenticated, isConnecting, error } = useRealtimeStore();

  const [mode, setMode] = useState<'entry' | 'login' | 'register'>('entry');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState('');

  const handleGoogleSignIn = async () => {
    soundManager.playClick();
    setLocalError('');
    try {
      await authenticateWithGoogle();
    } catch (err: any) {
      setLocalError(err.message || (isRtl ? 'چوونەژوورەوە لەگەڵ Google سەرکەوتوو نەبوو' : 'Google sign-in failed'));
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      onAuthSuccess();
    }
  }, [isAuthenticated, onAuthSuccess]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playClick();
    setLocalError('');

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();

    if (mode === 'register') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(cleanEmail)) {
        setLocalError(isRtl ? 'تکایە ئیمەیڵێکی دروست و ڕاستەقینە بنووسە' : 'Please enter a valid email address');
        return;
      }

      if (cleanPassword.length < 6) {
        setLocalError(isRtl ? 'پاسۆرد دەبێت لانیکەم ٦ پیت یان ژمارە بێت' : 'Password must be at least 6 characters');
        return;
      }

      if (cleanPassword !== confirmPassword.trim()) {
        setLocalError(isRtl ? 'پاسۆردەکان وەک یەک نین' : 'Passwords do not match');
        return;
      }

      if (!username.trim()) {
        setLocalError(isRtl ? 'تکایە ناوی بەکارهێنەر بنووسە' : 'Please enter a username');
        return;
      }
    }

    try {
      await authenticate(cleanEmail, cleanPassword, mode === 'register', username.trim());
    } catch (err: any) {
      setLocalError(err.message || (isRtl ? 'چوونەژوورەوە سەرکەوتوو نەبوو' : 'Authentication failed'));
    }
  };

  const handleGuest = async () => {
    soundManager.playClick();
    setLocalError('');
    try {
      const guestUsername = `Guest_${Math.floor(1000 + Math.random() * 9000)}`;
      await authenticateDevice('guest', guestUsername);
    } catch (err: any) {
      setLocalError(err.message || (isRtl ? 'چوونەژوورەوەی میوان سەرکەوتوو نەبوو' : 'Guest authentication failed'));
    }
  };

  return (
    <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 bg-gradient-to-b from-[#1a0833] via-[#0f0422] to-[#080214] ${isRtl ? 'rtl' : 'ltr'}`}>
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-md bg-gradient-to-b from-[#2a0e4e] via-[#1a0833] to-[#0f0422] border-2 border-amber-500/60 rounded-[36px] p-6 sm:p-8 shadow-[0_20px_50px_rgba(0,0,0,0.9),0_0_30px_rgba(234,179,8,0.25)] overflow-hidden"
      >
        {/* Glow Effects */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-amber-600 via-yellow-400 to-amber-600" />
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-amber-500/20 blur-[60px] rounded-full pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-purple-500/20 blur-[60px] rounded-full pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center mb-6 text-center">
          {/* Royal Crown Crest */}
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 p-0.5 shadow-lg shadow-amber-500/30 mb-3 flex items-center justify-center">
            <Crown className="w-10 h-10 text-amber-950 fill-amber-950" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500 uppercase font-serif tracking-wider">
            {isRtl ? 'شەترەنجی شاهانە' : 'CHESS ROYAL'}
          </h1>
          <p className="text-purple-200/70 text-xs sm:text-sm font-medium mt-1">
            {isRtl ? 'مەیدانی یارییە سەرنجڕاکێشەکان' : 'The Royal Chess Realm'}
          </p>
        </div>

        {(localError || error) && (
          <div className="relative z-10 mb-4 bg-red-500/15 border border-red-500/50 text-red-300 text-xs p-3 rounded-2xl flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span>{localError || error}</span>
          </div>
        )}

        <AnimatePresence mode="wait">
          {mode === 'entry' ? (
            <motion.div
              key="entry"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative z-10 space-y-3"
            >
              {/* GOOGLE OAUTH BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleGoogleSignIn}
                disabled={isConnecting}
                className="w-full py-4 rounded-2xl bg-white hover:bg-slate-100 border-2 border-slate-200 text-slate-800 font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(255,255,255,0.2)] flex items-center justify-center gap-3 cursor-pointer transition-colors"
              >
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>{isRtl ? 'بەردەوامبە لەگەڵ Google' : 'CONTINUE WITH GOOGLE'}</span>
              </motion.button>

              {/* LOGIN WITH EMAIL BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  soundManager.playClick();
                  setMode('login');
                  setLocalError('');
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-2 border-yellow-200 text-amber-950 font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(234,179,8,0.4)] flex items-center justify-center gap-3 cursor-pointer"
              >
                <LogIn className="w-5 h-5" />
                <span>{isRtl ? 'چوونەژوورەوە بە ئیمەیڵ' : 'LOGIN WITH EMAIL'}</span>
              </motion.button>

              {/* CREATE ACCOUNT BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  soundManager.playClick();
                  setMode('register');
                  setLocalError('');
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-600 border-2 border-emerald-300 text-white font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(16,185,129,0.35)] flex items-center justify-center gap-3 cursor-pointer"
              >
                <UserPlus className="w-5 h-5 text-emerald-100" />
                <span>{isRtl ? 'دروستکردنی هەژمار' : 'CREATE ACCOUNT'}</span>
              </motion.button>

              {/* GUEST BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleGuest}
                disabled={isConnecting}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-800 border-2 border-blue-400/80 text-white font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(37,99,235,0.35)] cursor-pointer flex items-center justify-center gap-3"
              >
                {isConnecting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Shield className="w-5 h-5 text-blue-200" />
                    <span>{isRtl ? 'یاری وەک میوان' : 'CONTINUE AS GUEST'}</span>
                  </>
                )}
              </motion.button>
            </motion.div>
          ) : (
            <motion.form
              key={mode}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleSubmit}
              className="relative z-10 space-y-3.5"
            >
              {mode === 'register' && (
                <div className="relative">
                  <User className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 text-purple-300/60`} />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder={isRtl ? 'ناوی بەکارهێنەر (Username)' : 'Username'}
                    className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3.5 ${isRtl ? 'pr-11 pl-4' : 'pl-11 pr-4'} text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                  />
                </div>
              )}

              <div className="relative">
                <Mail className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 text-purple-300/60`} />
                <input
                  type="text"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={mode === 'register' ? (isRtl ? 'ئیمەیڵ (Email)' : 'Email') : (isRtl ? 'ئیمەیڵ یان ناوی بەکارهێنەر' : 'Email or Username')}
                  className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3.5 ${isRtl ? 'pr-11 pl-4' : 'pl-11 pr-4'} text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                />
              </div>

              <div className="relative">
                <Lock className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 text-purple-300/60`} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={isRtl ? 'وشەی نهێنی (پاسۆرد)' : 'Password'}
                  className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3.5 ${isRtl ? 'pr-11 pl-10' : 'pl-11 pr-10'} text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute ${isRtl ? 'left-3.5' : 'right-3.5'} top-1/2 -translate-y-1/2 text-purple-300/60 hover:text-white transition`}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {mode === 'register' && (
                <div className="relative">
                  <Lock className={`absolute ${isRtl ? 'right-4' : 'left-4'} top-1/2 -translate-y-1/2 w-4 h-4 text-purple-300/60`} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder={isRtl ? 'دووبارەکردنەوەی پاسۆرد' : 'Confirm Password'}
                    className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3.5 ${isRtl ? 'pr-11 pl-10' : 'pl-11 pr-10'} text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isConnecting}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-2 border-yellow-200 text-amber-950 font-black text-sm sm:text-base tracking-widest uppercase shadow-[0_8px_25px_rgba(234,179,8,0.4)] flex items-center justify-center gap-2 mt-2 cursor-pointer active:scale-95 transition"
              >
                {isConnecting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <span>
                    {mode === 'login'
                      ? (isRtl ? 'چوونەژوورەوە' : 'SIGN IN')
                      : (isRtl ? 'دروستکردنی هەژمار' : 'CREATE ACCOUNT')}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setMode('entry')}
                className="w-full text-center text-xs text-purple-300/70 hover:text-white transition pt-2"
              >
                ← {isRtl ? 'گەڕانەوە بۆ هەڵبژاردنەکان' : 'Back to options'}
              </button>
            </motion.form>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
