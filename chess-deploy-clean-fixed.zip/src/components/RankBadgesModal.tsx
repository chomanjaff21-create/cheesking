import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  Trophy,
  Crown,
  Shield,
  Swords,
  Sparkles,
  Award,
  Zap,
  Target,
  Flame,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';

interface RankBadgesModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile: UserProfile;
}

export interface RankBadgeItem {
  id: string;
  titleEn: string;
  titleKu: string;
  currentWins: number;
  requiredWins: number;
  iconType: 'conqueror' | 'dominator' | 'unstoppable' | 'warlord' | 'strategist' | 'builder' | 'collector' | 'legend' | 'apex' | 'titan' | 'master' | 'phantom' | 'gladiator' | 'immortal' | 'vanguard' | 'overlord' | 'phoenix' | 'sovereign' | 'emperor' | 'mythic';
  badgeColor: string;
  borderColor: string;
  rewardCoins: number;
}

// 20 EPIC CONQUEST RANK BADGES
const ALL_RANK_BADGES: RankBadgeItem[] = [
  {
    id: 'rank_1',
    titleEn: 'Conqueror',
    titleKu: 'داگیرکەر (Conqueror)',
    currentWins: 10,
    requiredWins: 10,
    iconType: 'conqueror',
    badgeColor: 'from-[#801414] via-[#b91c1c] to-[#450a0a]',
    borderColor: 'border-red-500',
    rewardCoins: 1000,
  },
  {
    id: 'rank_2',
    titleEn: 'World Dominator',
    titleKu: 'باڵادەستی جیهان',
    currentWins: 8,
    requiredWins: 10,
    iconType: 'dominator',
    badgeColor: 'from-[#1e293b] via-[#475569] to-[#0f172a]',
    borderColor: 'border-slate-300',
    rewardCoins: 1200,
  },
  {
    id: 'rank_3',
    titleEn: 'Unstoppable',
    titleKu: 'ڕانەگیراو (Unstoppable)',
    currentWins: 15,
    requiredWins: 20,
    iconType: 'unstoppable',
    badgeColor: 'from-[#78350f] via-[#d97706] to-[#451a03]',
    borderColor: 'border-amber-500',
    rewardCoins: 1500,
  },
  {
    id: 'rank_4',
    titleEn: 'Warlord',
    titleKu: 'پاشای جەنگ (Warlord)',
    currentWins: 26,
    requiredWins: 30,
    iconType: 'warlord',
    badgeColor: 'from-[#854d0e] via-[#ca8a04] to-[#3f2305]',
    borderColor: 'border-yellow-400',
    rewardCoins: 2000,
  },
  {
    id: 'rank_5',
    titleEn: 'Strategist',
    titleKu: 'نەخشەساز (Strategist)',
    currentWins: 12,
    requiredWins: 20,
    iconType: 'strategist',
    badgeColor: 'from-[#1e3a8a] via-[#2563eb] to-[#172554]',
    borderColor: 'border-blue-400',
    rewardCoins: 1200,
  },
  {
    id: 'rank_6',
    titleEn: 'Builder',
    titleKu: 'بونیاتنەر (Builder)',
    currentWins: 18,
    requiredWins: 30,
    iconType: 'builder',
    badgeColor: 'from-[#134e4a] via-[#0d9488] to-[#042f2e]',
    borderColor: 'border-teal-400',
    rewardCoins: 1400,
  },
  {
    id: 'rank_7',
    titleEn: 'Collector',
    titleKu: 'کۆکەرەوەی سەرکەوتن',
    currentWins: 22,
    requiredWins: 30,
    iconType: 'collector',
    badgeColor: 'from-[#164e63] via-[#0891b2] to-[#083344]',
    borderColor: 'border-cyan-400',
    rewardCoins: 1800,
  },
  {
    id: 'rank_8',
    titleEn: 'Legend',
    titleKu: 'ئەفسانەی یاری (Legend)',
    currentWins: 5,
    requiredWins: 10,
    iconType: 'legend',
    badgeColor: 'from-[#581c87] via-[#9333ea] to-[#3b0764]',
    borderColor: 'border-purple-400',
    rewardCoins: 2500,
  },
  {
    id: 'rank_9',
    titleEn: 'Grandmaster',
    titleKu: 'مامۆستای مەزن',
    currentWins: 30,
    requiredWins: 30,
    iconType: 'master',
    badgeColor: 'from-[#701a75] via-[#c026d3] to-[#4a044e]',
    borderColor: 'border-fuchsia-400',
    rewardCoins: 3000,
  },
  {
    id: 'rank_10',
    titleEn: 'Apex Sovereign',
    titleKu: 'پاشای لوتکە (Apex)',
    currentWins: 3,
    requiredWins: 5,
    iconType: 'sovereign',
    badgeColor: 'from-[#991b1b] via-[#f43f5e] to-[#4c0519]',
    borderColor: 'border-rose-400',
    rewardCoins: 3500,
  },
  {
    id: 'rank_11',
    titleEn: 'Gladiator',
    titleKu: 'شۆڕشگێڕ (Gladiator)',
    currentWins: 14,
    requiredWins: 20,
    iconType: 'gladiator',
    badgeColor: 'from-[#9a3412] via-[#ea580c] to-[#431407]',
    borderColor: 'border-orange-400',
    rewardCoins: 1300,
  },
  {
    id: 'rank_12',
    titleEn: 'Vanguard Guard',
    titleKu: 'پاسەوانی پێشەنگ',
    currentWins: 25,
    requiredWins: 25,
    iconType: 'vanguard',
    badgeColor: 'from-[#065f46] via-[#10b981] to-[#022c22]',
    borderColor: 'border-emerald-400',
    rewardCoins: 1600,
  },
  {
    id: 'rank_13',
    titleEn: 'Titan Champion',
    titleKu: 'پاڵەوانی تایپکەر',
    currentWins: 7,
    requiredWins: 15,
    iconType: 'titan',
    badgeColor: 'from-[#3730a3] via-[#6366f1] to-[#1e1b4b]',
    borderColor: 'border-indigo-400',
    rewardCoins: 2200,
  },
  {
    id: 'rank_14',
    titleEn: 'Overlord',
    titleKu: 'فەرمانڕەوای مەزن',
    currentWins: 19,
    requiredWins: 40,
    iconType: 'overlord',
    badgeColor: 'from-[#4c1d95] via-[#7c3aed] to-[#2e1065]',
    borderColor: 'border-[#a855f7]',
    rewardCoins: 4000,
  },
  {
    id: 'rank_15',
    titleEn: 'Phoenix Flame',
    titleKu: 'قاقنوسی سوور',
    currentWins: 11,
    requiredWins: 15,
    iconType: 'phoenix',
    badgeColor: 'from-[#9f1239] via-[#f43f5e] to-[#4c0519]',
    borderColor: 'border-pink-500',
    rewardCoins: 2100,
  },
  {
    id: 'rank_16',
    titleEn: 'Immortal Warrior',
    titleKu: 'جەنگاوەری نەمر',
    currentWins: 50,
    requiredWins: 50,
    iconType: 'immortal',
    badgeColor: 'from-[#854d0e] via-[#eab308] to-[#451a03]',
    borderColor: 'border-yellow-200',
    rewardCoins: 5000,
  },
  {
    id: 'rank_17',
    titleEn: 'Phantom Stalker',
    titleKu: 'شەبەحی تاریکی',
    currentWins: 9,
    requiredWins: 10,
    iconType: 'phantom',
    badgeColor: 'from-[#0f172a] via-[#334155] to-[#020617]',
    borderColor: 'border-slate-400',
    rewardCoins: 1700,
  },
  {
    id: 'rank_18',
    titleEn: 'Emperor',
    titleKu: 'ئیمپراتۆر (Emperor)',
    currentWins: 42,
    requiredWins: 50,
    iconType: 'emperor',
    badgeColor: 'from-[#713f12] via-[#f59e0b] to-[#291e05]',
    borderColor: 'border-amber-300',
    rewardCoins: 6000,
  },
  {
    id: 'rank_19',
    titleEn: 'Mythic Sovereign',
    titleKu: 'فەرمانڕەوای میتۆلۆجی',
    currentWins: 8,
    requiredWins: 20,
    iconType: 'mythic',
    badgeColor: 'from-[#0284c7] via-[#38bdf8] to-[#0c4a6e]',
    borderColor: 'border-sky-300',
    rewardCoins: 4500,
  },
  {
    id: 'rank_20',
    titleEn: 'Supreme King',
    titleKu: 'پاشای هەرە مەزن',
    currentWins: 100,
    requiredWins: 100,
    iconType: 'conqueror',
    badgeColor: 'from-[#b45309] via-[#fef08a] to-[#78350f]',
    borderColor: 'border-yellow-100',
    rewardCoins: 10000,
  },
];

export const RankBadgesModal: React.FC<RankBadgesModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
}) => {
  const [claimedBadges, setClaimedBadges] = useState<Record<string, boolean>>({
    rank_1: true,
    rank_12: true,
  });

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  const handleClaimReward = (badge: RankBadgeItem) => {
    soundManager.playVictory();
    setClaimedBadges((prev) => ({ ...prev, [badge.id]: true }));
  };

  const renderBadgeIcon = (type: RankBadgeItem['iconType']) => {
    switch (type) {
      case 'conqueror':
        return (
          <div className="relative w-12 h-12 flex items-center justify-center">
            <Crown className="w-10 h-10 text-amber-300 fill-amber-500 drop-shadow-[0_0_10px_rgba(245,158,11,0.8)]" />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 border border-yellow-200 animate-ping" />
            </div>
          </div>
        );
      case 'dominator':
        return <Shield className="w-10 h-10 text-slate-200 fill-slate-700 drop-shadow" />;
      case 'unstoppable':
        return <Trophy className="w-10 h-10 text-amber-400 fill-amber-600 drop-shadow" />;
      case 'warlord':
        return <Swords className="w-10 h-10 text-yellow-300 drop-shadow" />;
      case 'strategist':
        return <Target className="w-10 h-10 text-blue-300 fill-blue-600 drop-shadow" />;
      case 'builder':
        return <Award className="w-10 h-10 text-teal-300 fill-teal-600 drop-shadow" />;
      case 'collector':
        return <Sparkles className="w-10 h-10 text-cyan-300 fill-cyan-500 drop-shadow" />;
      case 'legend':
        return <Zap className="w-10 h-10 text-purple-300 fill-purple-600 drop-shadow" />;
      case 'master':
      case 'sovereign':
      case 'emperor':
        return <Crown className="w-10 h-10 text-fuchsia-300 fill-fuchsia-600 drop-shadow" />;
      default:
        return <Flame className="w-10 h-10 text-orange-400 fill-orange-600 drop-shadow" />;
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md select-none">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className={`relative w-full max-w-2xl bg-gradient-to-b from-[#1a1208] via-[#0f0b05] to-[#080502] border-2 border-yellow-500/80 rounded-3xl p-4 sm:p-5 shadow-[0_0_60px_rgba(234,179,8,0.3)] text-amber-100 flex flex-col max-h-[88vh] ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header Bar */}
          <div className="w-full flex items-center justify-between mb-3 border-b border-amber-800/40 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-600 text-amber-950 shadow-md">
                <Trophy className="w-6 h-6 fill-amber-950" />
              </div>
              <div>
                <h2 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-300 to-yellow-500">
                  {isRtl ? 'پلە و مدالیای یاریزان (٢٠ پلەی سەرکەوتن)' : 'Player Conquest Ranks (20 Badges)'}
                </h2>
                <p className="text-[11px] font-semibold text-amber-300/70">
                  {isRtl
                    ? 'یاری ببرەوە، پلەی بەرز بەدەستبهێنە و مدالیاکانی جەنگ کۆبکەرەوە'
                    : 'Win matches to progress through 20 epic conquest badges!'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                soundManager.playClick();
                onClose();
              }}
              className="p-2 rounded-xl bg-amber-950 hover:bg-amber-900 border border-amber-700/60 text-amber-200 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Badges Grid (Responsive 2 to 4 columns matching Screenshot 3) */}
          <div className="w-full flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 pr-1 custom-scrollbar">
            {ALL_RANK_BADGES.map((badge) => {
              const isCompleted = badge.currentWins >= badge.requiredWins;
              const isClaimed = claimedBadges[badge.id];
              const progressPercent = Math.min(
                100,
                Math.round((badge.currentWins / badge.requiredWins) * 100)
              );

              return (
                <div
                  key={badge.id}
                  className={`relative rounded-2xl border-2 ${badge.borderColor} p-3 flex flex-col items-center justify-between bg-gradient-to-b ${badge.badgeColor} shadow-lg group hover:scale-[1.02] transition overflow-hidden min-h-[170px]`}
                >
                  {/* Status Indicator Pill */}
                  <div className="absolute top-2 right-2">
                    {isCompleted ? (
                      <span className="p-1 rounded-full bg-emerald-500 text-white shadow">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <span className="p-1 rounded-full bg-black/40 text-amber-300/80">
                        <Lock className="w-3 h-3" />
                      </span>
                    )}
                  </div>

                  {/* Badge Icon Crest */}
                  <div className="my-1 my-auto flex items-center justify-center">
                    {renderBadgeIcon(badge.iconType)}
                  </div>

                  {/* Badge Title */}
                  <div className="text-center w-full">
                    <h3 className="text-xs font-black text-amber-100 truncate px-1">
                      {isRtl ? badge.titleKu : badge.titleEn}
                    </h3>

                    {/* Progress Text e.g. 10 / 10 */}
                    <div className="text-[11px] font-mono font-black text-yellow-300 mt-1">
                      {badge.currentWins} / {badge.requiredWins}
                    </div>

                    {/* Golden Progress Bar */}
                    <div className="w-full h-2 bg-black/60 rounded-full border border-amber-500/40 overflow-hidden my-1.5 p-0.5">
                      <div
                        className="h-full bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 rounded-full shadow-[0_0_8px_rgba(234,179,8,0.9)]"
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Claim Reward Button */}
                  {isCompleted && !isClaimed && (
                    <button
                      onClick={() => handleClaimReward(badge)}
                      className="w-full py-1 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-amber-950 font-black text-[10px] shadow hover:brightness-110 active:scale-95 transition cursor-pointer"
                    >
                      {isRtl ? 'وەرگرتنی دیاری 🪙' : 'Claim Reward 🪙'}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
