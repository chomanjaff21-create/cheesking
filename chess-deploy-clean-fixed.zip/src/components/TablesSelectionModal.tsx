import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Search,
  ChevronLeft,
  ChevronRight,
  Wifi,
  Info,
  Grid,
  Swords,
  Crown,
  Trophy,
  ShieldCheck,
  Zap,
  Clock,
  Sparkles,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';
import { buildApiUrl } from '../lib/api';
import { GoldCoinIcon } from './CurrencyIcons';

// =========================================================
// REALISTIC 3D GEM COMPONENT
// =========================================================
export const GemIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={`${className} shrink-0 filter drop-shadow-[0_2px_5px_rgba(6,182,212,0.5)]`} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="gemGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#CFFAFE" />
        <stop offset="30%" stopColor="#22D3EE" />
        <stop offset="70%" stopColor="#0891B2" />
        <stop offset="100%" stopColor="#164E63" />
      </linearGradient>
    </defs>
    <path
      d="M15 11L33 11L42 21L24 41L6 21L15 11Z"
      fill="url(#gemGrad)"
      stroke="#E0F2FE"
      strokeWidth="1.5"
    />
    <path d="M15 11L24 21L33 11" stroke="#FFFFFF" strokeWidth="1.2" opacity="0.8" />
    <path d="M6 21L24 21L42 21" stroke="#FFFFFF" strokeWidth="1.2" opacity="0.8" />
    <path d="M24 21L24 41" stroke="#083344" strokeWidth="1.2" opacity="0.6" />
    <polygon points="17,13 24,19 21,13" fill="#FFFFFF" opacity="0.75" />
  </svg>
);

// =========================================================
// STUNNING 3D CHESS BOARD & PIECES STAGE (TOP GRAPHIC)
// =========================================================
const MiniChessStage: React.FC<{ themeId: number; icon: string }> = ({ themeId, icon }) => {
  // Color presets based on theme ID
  const getStageColors = () => {
    switch (themeId) {
      case 2: // Purple
        return { darkSquare: '#4c1d95', lightSquare: '#ddd6fe', border: '#7e22ce' };
      case 3: // Red
        return { darkSquare: '#881337', lightSquare: '#fecdd3', border: '#be123c' };
      case 4: // Blue
        return { darkSquare: '#1e3a8a', lightSquare: '#bfdbfe', border: '#1d4ed8' };
      case 5: // Green
        return { darkSquare: '#064e3b', lightSquare: '#a7f3d0', border: '#047857' };
      case 6: // Gold
        return { darkSquare: '#78350f', lightSquare: '#fef3c7', border: '#b45309' };
      case 7: // Obsidian Dark
        return { darkSquare: '#18181b', lightSquare: '#e4e4e7', border: '#3f3f46' };
      default: // Classic Wood/Brown
        return { darkSquare: '#b45309', lightSquare: '#fef3c7', border: '#78350f' };
    }
  };

  const colors = getStageColors();

  return (
    <div className="relative w-44 h-32 sm:w-52 sm:h-36 flex items-center justify-center shrink-0 my-[-8px]">
      {/* Radial Back Glow */}
      <div className="absolute inset-0 bg-amber-400/20 blur-xl rounded-full scale-90" />

      {/* SVG 3D Isometric Chess Stage */}
      <svg className="w-full h-full filter drop-shadow-[0_12px_15px_rgba(0,0,0,0.85)]" viewBox="0 0 200 140" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="boardEdge" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#d97706" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>
          <linearGradient id="pieceGold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="50%" stopColor="#eab308" />
            <stop offset="100%" stopColor="#854d0e" />
          </linearGradient>
          <linearGradient id="pieceWood" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#a16207" />
            <stop offset="50%" stopColor="#713f12" />
            <stop offset="100%" stopColor="#3b1a03" />
          </linearGradient>
          <radialGradient id="shadowGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(0,0,0,0.6)" />
            <stop offset="100%" stopColor="rgba(0,0,0,0)" />
          </radialGradient>
        </defs>

        {/* Board Shadow */}
        <ellipse cx="100" cy="118" rx="85" ry="18" fill="url(#shadowGlow)" />

        {/* 3D Isometric Board Base Thickness */}
        <polygon points="20,80 100,115 180,80 180,92 100,127 20,92" fill="url(#boardEdge)" />
        <polygon points="100,115 180,80 180,92 100,127" fill="#451a03" />

        {/* Board Top Face */}
        <polygon points="20,80 100,45 180,80 100,115" fill={colors.border} stroke="#fef08a" strokeWidth="1.5" />

        {/* Checkered Grid Squares */}
        {/* Row 1 */}
        <polygon points="100,45 120,53.75 100,62.5 80,53.75" fill={colors.lightSquare} />
        <polygon points="120,53.75 140,62.5 120,71.25 100,62.5" fill={colors.darkSquare} />
        <polygon points="140,62.5 160,71.25 140,80 120,71.25" fill={colors.lightSquare} />

        {/* Row 2 */}
        <polygon points="80,53.75 100,62.5 80,71.25 60,62.5" fill={colors.darkSquare} />
        <polygon points="100,62.5 120,71.25 100,80 80,71.25" fill={colors.lightSquare} />
        <polygon points="120,71.25 140,80 120,88.75 100,80" fill={colors.darkSquare} />

        {/* Row 3 */}
        <polygon points="60,62.5 80,71.25 60,80 40,71.25" fill={colors.lightSquare} />
        <polygon points="80,71.25 100,80 80,88.75 60,80" fill={colors.darkSquare} />
        <polygon points="100,80 120,88.75 100,97.5 80,88.75" fill={colors.lightSquare} />

        {/* Row 4 */}
        <polygon points="40,71.25 60,80 40,88.75 20,80" fill={colors.darkSquare} />
        <polygon points="60,80 80,88.75 60,97.5 40,88.75" fill={colors.lightSquare} />
        <polygon points="80,88.75 100,97.5 80,106.25 60,97.5" fill={colors.darkSquare} />
        <polygon points="100,97.5 120,106.25 100,115 80,106.25" fill={colors.lightSquare} />

        {/* 3D CHESS PIECES STANDING ON BOARD */}
        {/* Left Bishop */}
        <g transform="translate(62, 42)">
          <ellipse cx="12" cy="32" rx="7" ry="2.5" fill="#000" opacity="0.4" />
          <path d="M7,31 C7,25 10,20 10,14 C10,10 14,10 14,14 C14,20 17,25 17,31 Z" fill="url(#pieceGold)" />
          <ellipse cx="12" cy="11" rx="3.5" ry="3.5" fill="#fef08a" />
          <path d="M12,4 L12,8 M10,6 L14,6" stroke="#78350f" strokeWidth="1" />
        </g>

        {/* Center KING Piece (Grand) */}
        <g transform="translate(86, 20)">
          <ellipse cx="14" cy="52" rx="11" ry="4" fill="#000" opacity="0.5" />
          {/* Base */}
          <path d="M5,50 C5,45 8,40 10,32 C12,24 8,18 14,12 C20,18 16,24 18,32 C20,40 23,45 23,50 Z" fill="url(#pieceGold)" />
          {/* Crown head */}
          <path d="M8,16 C8,12 20,12 20,16 C20,20 8,20 8,16 Z" fill="#fef08a" />
          {/* Cross */}
          <path d="M14,4 L14,12 M10,7 L18,7" stroke="#78350f" strokeWidth="2" strokeLinecap="round" />
          <circle cx="14" cy="4" r="1.5" fill="#ffffff" />
        </g>

        {/* Right Pawn / Queen */}
        <g transform="translate(112, 48)">
          <ellipse cx="12" cy="30" rx="6" ry="2.2" fill="#000" opacity="0.4" />
          <path d="M7,29 C7,23 10,18 10,13 C10,9 14,9 14,13 C14,18 17,23 17,29 Z" fill="url(#pieceGold)" />
          <circle cx="12" cy="10" r="3" fill="#fef08a" />
        </g>
      </svg>

      {/* Floating Emoji/Icon Badge */}
      <div className="absolute top-0 right-2 w-9 h-9 rounded-xl bg-gradient-to-br from-amber-300 via-yellow-500 to-amber-700 p-0.5 border border-yellow-100 shadow-lg flex items-center justify-center text-lg animate-bounce">
        {icon}
      </div>
    </div>
  );
};

export interface ChessTable {
  id: number;
  nameKu: string;
  nameEn: string;
  cityNameKu: string;
  cityNameEn: string;
  icon: string;
  bgTheme: string;
  cardHeaderColor: string;
  ribbonGradient: string;
  badgeTag?: string;
  entryFee: number;
  prizePool: number;
  activePlayers: number;
  themeDescKu: string;
  themeDescEn: string;
  minLevel: number;
  rulesTimeFormatKu: string;
  rulesTimeFormatEn: string;
}

export const CHESS_TABLES: ChessTable[] = [
  {
    id: 1,
    nameKu: 'ساحەی کلاسیک',
    nameEn: 'CLASSIC ARENA',
    cityNameKu: 'ڕەش و سپی',
    cityNameEn: 'Black & White',
    icon: '♟️',
    bgTheme: 'from-[#7f1d1d] via-[#450a0a] to-[#1a0202]',
    cardHeaderColor: 'from-[#15803d] via-[#22c55e] to-[#166534]',
    ribbonGradient: 'from-emerald-700 via-green-500 to-emerald-800',
    badgeTag: 'Classic',
    entryFee: 250,
    prizePool: 500,
    activePlayers: 620,
    themeDescKu: 'مێزی شەتڕەنجی کلاسیکی خاوەن خانەی ڕەش و سپی',
    themeDescEn: 'High-contrast classic black & white chess arena',
    minLevel: 1,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک Blitz',
    rulesTimeFormatEn: 'Rules: 5 min Blitz',
  },
  {
    id: 2,
    nameKu: 'تەختی مۆر',
    nameEn: 'PURPLE PALACE',
    cityNameKu: 'مۆر',
    cityNameEn: 'Purple Palace',
    icon: '🔮',
    bgTheme: 'from-[#4c1d95] via-[#2e1065] to-[#14052e]',
    cardHeaderColor: 'from-[#a855f7] to-[#7e22ce]',
    ribbonGradient: 'from-purple-700 via-fuchsia-500 to-purple-900',
    badgeTag: 'Royal',
    entryFee: 500,
    prizePool: 1000,
    activePlayers: 890,
    themeDescKu: 'دیزاینی تایبەتی مۆر بە پاشبنەمای شاهانە',
    themeDescEn: 'Vibrant purple board and deep royal backdrop',
    minLevel: 2,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک Blitz',
    rulesTimeFormatEn: 'Rules: 5 min Blitz',
  },
  {
    id: 3,
    nameKu: 'تەختی سوور',
    nameEn: 'CRIMSON RED',
    cityNameKu: 'سوور',
    cityNameEn: 'Red Citadel',
    icon: '🔴',
    bgTheme: 'from-[#881337] via-[#4c0519] to-[#1f020a]',
    cardHeaderColor: 'from-[#f43f5e] to-[#be123c]',
    ribbonGradient: 'from-rose-700 via-red-500 to-rose-900',
    badgeTag: 'Crimson',
    entryFee: 5000,
    prizePool: 10000,
    activePlayers: 540,
    themeDescKu: 'مێزی سووری درەوشاوە و بەهێز',
    themeDescEn: 'Fierce crimson red chess board & arena',
    minLevel: 3,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک Blitz',
    rulesTimeFormatEn: 'Rules: 5 min Blitz',
  },
  {
    id: 4,
    nameKu: 'تەختی شین',
    nameEn: 'BLUE HAVEN',
    cityNameKu: 'شین',
    cityNameEn: 'Blue Haven',
    icon: '🌊',
    bgTheme: 'from-[#1e3a8a] via-[#172554] to-[#090d1f]',
    cardHeaderColor: 'from-[#3b82f6] to-[#1d4ed8]',
    ribbonGradient: 'from-blue-700 via-sky-500 to-blue-900',
    badgeTag: 'Cobalt',
    entryFee: 10000,
    prizePool: 20000,
    activePlayers: 480,
    themeDescKu: 'مێزی شینی پاشایی و ئارامکەرەوە',
    themeDescEn: 'Calm and royal cobalt blue arena',
    minLevel: 4,
    rulesTimeFormatKu: 'یاساکان: ١٠ خولەک Rapid',
    rulesTimeFormatEn: 'Rules: 10 min Rapid',
  },
  {
    id: 5,
    nameKu: 'تەختی زومڕود',
    nameEn: 'EMERALD GREEN',
    cityNameKu: 'سەوز',
    cityNameEn: 'Emerald Green',
    icon: '❇️',
    bgTheme: 'from-[#064e3b] via-[#022c22] to-[#01140f]',
    cardHeaderColor: 'from-[#10b981] to-[#047857]',
    ribbonGradient: 'from-emerald-700 via-teal-500 to-emerald-900',
    badgeTag: 'Emerald',
    entryFee: 25000,
    prizePool: 50000,
    activePlayers: 410,
    themeDescKu: 'مێزی سەوزی زمروودی پادشایەتی',
    themeDescEn: 'Majestic emerald green chess board arena',
    minLevel: 5,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک Blitz',
    rulesTimeFormatEn: 'Rules: 5 min Blitz',
  },
  {
    id: 6,
    nameKu: 'تەختی زێڕین',
    nameEn: 'GOLDEN SULTAN',
    cityNameKu: 'زێڕین',
    cityNameEn: 'Gold Sultan',
    icon: '👑',
    bgTheme: 'from-[#78350f] via-[#451a03] to-[#1c0a00]',
    cardHeaderColor: 'from-[#f59e0b] to-[#b45309]',
    ribbonGradient: 'from-amber-600 via-yellow-400 to-amber-800',
    badgeTag: 'Sultan',
    entryFee: 50000,
    prizePool: 100000,
    activePlayers: 350,
    themeDescKu: 'مێزی زێڕینی درەوشاوە و گرانبەها',
    themeDescEn: 'High-stakes luxury golden arena',
    minLevel: 6,
    rulesTimeFormatKu: 'یاساکان: ٣ خولەک Bullet',
    rulesTimeFormatEn: 'Rules: 3 min Bullet',
  },
  {
    id: 7,
    nameKu: 'تەختی ئۆبسیدیان',
    nameEn: 'DARK OBSIDIAN',
    cityNameKu: 'تۆخ',
    cityNameEn: 'Dark Obsidian',
    icon: '🖤',
    bgTheme: 'from-[#27272a] via-[#18181b] to-[#09090b]',
    cardHeaderColor: 'from-[#71717a] to-[#27272a]',
    ribbonGradient: 'from-zinc-700 via-zinc-500 to-zinc-900',
    badgeTag: 'Obsidian',
    entryFee: 100000,
    prizePool: 200000,
    activePlayers: 290,
    themeDescKu: 'مێزی تۆخی سادە و هێور',
    themeDescEn: 'Sleek dark obsidian minimalist chess arena',
    minLevel: 7,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک Blitz',
    rulesTimeFormatEn: 'Rules: 5 min Blitz',
  },
  {
    id: 8,
    nameKu: 'تاوەری لەندەن',
    nameEn: 'LONDON BIG BEN',
    cityNameKu: 'لەندەن',
    cityNameEn: 'London',
    icon: '🕰️',
    bgTheme: 'from-[#1e293b] via-[#0f172a] to-[#020617]',
    cardHeaderColor: 'from-[#64748b] to-[#334155]',
    ribbonGradient: 'from-slate-700 via-slate-500 to-slate-900',
    badgeTag: 'London',
    entryFee: 500000,
    prizePool: 1000000,
    activePlayers: 210,
    themeDescKu: 'مێزی سەعات و تاکتیکی لەندەن',
    themeDescEn: 'Tactical clock chess in London',
    minLevel: 15,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک',
    rulesTimeFormatEn: 'Rules: 5 min',
  },
  {
    id: 9,
    nameKu: 'هەرەمەکانی قاهیرە',
    nameEn: 'CAIRO PYRAMIDS',
    cityNameKu: 'قاهیرە',
    cityNameEn: 'Cairo',
    icon: '🐫',
    bgTheme: 'from-[#78350f] via-[#451a03] to-[#1c0a00]',
    cardHeaderColor: 'from-[#d97706] to-[#92400e]',
    ribbonGradient: 'from-amber-700 via-orange-500 to-amber-900',
    badgeTag: 'Pharaoh',
    entryFee: 1000000,
    prizePool: 2000000,
    activePlayers: 180,
    themeDescKu: 'مێزی فیرعەون و دێرینی قاهیرە',
    themeDescEn: 'Ancient Pharaoh arena in Cairo',
    minLevel: 18,
    rulesTimeFormatKu: 'یاساکان: ٥ خولەک',
    rulesTimeFormatEn: 'Rules: 5 min',
  },
  {
    id: 10,
    nameKu: 'کۆلیزیۆمی ڕۆما',
    nameEn: 'ROME COLOSSEUM',
    cityNameKu: 'ڕۆما',
    cityNameEn: 'Rome',
    icon: '🏛️',
    bgTheme: 'from-[#7f1d1d] via-[#450a0a] to-[#1a0202]',
    cardHeaderColor: 'from-[#ef4444] to-[#b91c1c]',
    ribbonGradient: 'from-red-700 via-rose-500 to-red-900',
    badgeTag: 'Rome',
    entryFee: 2500000,
    prizePool: 5000000,
    activePlayers: 160,
    themeDescKu: 'مێزی جەنگاوەرانی ڕۆما',
    themeDescEn: 'Gladiator battle in Rome Colosseum',
    minLevel: 20,
    rulesTimeFormatKu: 'یاساکان: ٣ خولەک',
    rulesTimeFormatEn: 'Rules: 3 min',
  },
];

interface TablesSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile: UserProfile;
  onSelectTable: (table: ChessTable) => void;
}

export const TablesSelectionModal: React.FC<TablesSelectionModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
  onSelectTable,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [viewMode, setViewMode] = useState<'carousel' | 'grid'>('carousel');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedRulesTable, setSelectedRulesTable] = useState<ChessTable | null>(null);
  // Real per-table player counts from the server (the old numbers were hardcoded).
  const [liveCounts, setLiveCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    if (!isOpen) return;
    let stop = false;
    const load = async () => {
      try {
        const r = await fetch(buildApiUrl('/api/tables/online'));
        if (!r.ok) return;
        const d = await r.json();
        if (!stop && d?.counts) setLiveCounts(d.counts);
      } catch {}
    };
    load();
    const t = setInterval(load, 15000);
    return () => { stop = true; clearInterval(t); };
  }, [isOpen]);

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  const formatCoins = (amount: number) => {
    if (amount >= 1000000000) return `${(amount / 1000000000).toLocaleString('en-US')} B`;
    if (amount >= 1000000) return `${(amount / 1000000).toLocaleString('en-US')} M`;
    if (amount >= 1000) return `${amount.toLocaleString('en-US')}`;
    return `${amount}`;
  };

  const handlePrev = () => {
    soundManager.playClick();
    setCurrentIndex((prev) => (prev === 0 ? CHESS_TABLES.length - 1 : prev - 1));
  };

  const handleNext = () => {
    soundManager.playClick();
    setCurrentIndex((prev) => (prev === CHESS_TABLES.length - 1 ? 0 : prev + 1));
  };

  const filteredTables = CHESS_TABLES.filter((tbl) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      tbl.nameKu.toLowerCase().includes(q) ||
      tbl.nameEn.toLowerCase().includes(q) ||
      tbl.cityNameKu.toLowerCase().includes(q) ||
      tbl.cityNameEn.toLowerCase().includes(q) ||
      tbl.id.toString() === q
    );
  });

  const activeTable = CHESS_TABLES[currentIndex];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex flex-col justify-between bg-[#2d020a] text-amber-100 overflow-hidden select-none font-sans">
        
        {/* Subtle Crimson Diamond Texture Overlay */}
        <div 
          className="absolute inset-0 opacity-25 pointer-events-none"
          style={{
            backgroundImage: `radial-gradient(#f59e0b 0.75px, transparent 0.75px), radial-gradient(#f59e0b 0.75px, #2d020a 0.75px)`,
            backgroundSize: `30px 30px`,
            backgroundPosition: `0 0, 15px 15px`
          }}
        />

        {/* ========================================== */}
        {/* TOP BAR: Clean Royal Currency Header */}
        {/* ========================================== */}
        <div className="w-full bg-gradient-to-b from-[#4a0511] via-[#35030b] to-transparent px-3 py-3 flex items-center justify-between z-30 shrink-0 relative">
          
          {/* Left: Close / Back Arrow Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="w-10 h-10 rounded-full bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-700 p-0.5 border-2 border-yellow-200 text-amber-950 flex items-center justify-center transition shadow-lg hover:scale-105 active:scale-95 cursor-pointer shrink-0"
          >
            <div className="w-full h-full rounded-full bg-gradient-to-b from-amber-700 to-amber-950 flex items-center justify-center">
              <X className="w-5 h-5 text-amber-200" />
            </div>
          </button>

          {/* Center: Currency Displays (Coins & Gems) */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Coins Counter */}
            <div className="flex items-center gap-1.5 bg-black/60 border border-amber-500/80 rounded-full px-2.5 py-1 shadow-inner">
              <GoldCoinIcon className="w-5 h-5" />
              <span className="font-black text-xs sm:text-sm text-yellow-300 font-mono">
                {userProfile.coins.toLocaleString('en-US')}
              </span>
              <button className="w-4 h-4 rounded-full bg-emerald-500 text-amber-950 font-black text-[11px] flex items-center justify-center ml-1">
                +
              </button>
            </div>

            {/* Gems Counter */}
            <div className="flex items-center gap-1.5 bg-black/60 border border-cyan-500/80 rounded-full px-2.5 py-1 shadow-inner">
              <GemIcon className="w-4 h-4" />
              <span className="font-black text-xs sm:text-sm text-cyan-200 font-mono">
                {userProfile.gems.toLocaleString('en-US')}
              </span>
              <button className="w-4 h-4 rounded-full bg-emerald-500 text-amber-950 font-black text-[11px] flex items-center justify-center ml-1">
                +
              </button>
            </div>
          </div>

          {/* Right: View Mode Toggle (Carousel vs Grid) */}
          <div className="flex items-center bg-black/60 p-0.5 rounded-full border border-amber-500/60 shadow shrink-0">
            <button
              onClick={() => setViewMode('carousel')}
              className={`p-1.5 rounded-full text-xs font-bold transition cursor-pointer ${
                viewMode === 'carousel'
                  ? 'bg-gradient-to-b from-yellow-400 to-amber-600 text-amber-950 font-black shadow'
                  : 'text-amber-300/70 hover:text-amber-100'
              }`}
              title={isRtl ? 'تەختەی کاردکان' : 'Carousel'}
            >
              <Swords className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-full text-xs font-bold transition cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-gradient-to-b from-yellow-400 to-amber-600 text-amber-950 font-black shadow'
                  : 'text-amber-300/70 hover:text-amber-100'
              }`}
              title={isRtl ? 'هەموو مێزەکان' : 'Grid'}
            >
              <Grid className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================== */}
        {/* MAIN CAROUSEL / SHIELD BANNER VIEW */}
        {/* ========================================== */}
        {viewMode === 'carousel' ? (
          <div className="relative flex-1 flex flex-col items-center justify-center p-2 sm:p-4 overflow-hidden z-20 my-auto">
            
            {/* CAROUSEL CONTAINER */}
            <div className="relative w-full max-w-[320px] sm:max-w-[360px] flex flex-col items-center">

              {/* LEFT ARROW BUTTON */}
              <button
                onClick={handlePrev}
                className="absolute left-[-24px] sm:left-[-40px] top-1/2 -translate-y-1/2 z-40 w-11 h-11 sm:w-13 sm:h-13 rounded-full bg-gradient-to-b from-yellow-300 via-amber-500 to-amber-800 p-0.5 border-2 border-yellow-100 text-amber-950 shadow-[0_4px_20px_rgba(0,0,0,0.8)] flex items-center justify-center cursor-pointer transition hover:scale-110 active:scale-95"
              >
                <div className="w-full h-full rounded-full bg-gradient-to-b from-amber-600 to-amber-900 flex items-center justify-center">
                  <ChevronLeft className="w-7 h-7 text-yellow-300 stroke-[3]" />
                </div>
              </button>

              {/* RIGHT ARROW BUTTON */}
              <button
                onClick={handleNext}
                className="absolute right-[-24px] sm:right-[-40px] top-1/2 -translate-y-1/2 z-40 w-11 h-11 sm:w-13 sm:h-13 rounded-full bg-gradient-to-b from-yellow-300 via-amber-500 to-amber-800 p-0.5 border-2 border-yellow-100 text-amber-950 shadow-[0_4px_20px_rgba(0,0,0,0.8)] flex items-center justify-center cursor-pointer transition hover:scale-110 active:scale-95"
              >
                <div className="w-full h-full rounded-full bg-gradient-to-b from-amber-600 to-amber-900 flex items-center justify-center">
                  <ChevronRight className="w-7 h-7 text-yellow-300 stroke-[3]" />
                </div>
              </button>

              {/* TOP 3D CHESS STAGE */}
              <MiniChessStage themeId={activeTable.id} icon={activeTable.icon} />

              {/* THE MAIN ROYAL BANNER / SCROLL CARD */}
              <motion.div
                key={activeTable.id}
                initial={{ opacity: 0.8, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.25 }}
                className="w-full rounded-[32px] border-4 border-amber-400/90 bg-gradient-to-b from-[#8f0d22] via-[#610614] to-[#3a010a] shadow-[0_20px_50px_rgba(0,0,0,0.9)] p-4 sm:p-5 flex flex-col items-center relative overflow-hidden text-center z-10"
              >
                {/* Golden Corner Details */}
                <div className="absolute top-3 left-3 w-3 h-3 rounded-full bg-yellow-400 border border-amber-800 shadow" />
                <div className="absolute top-3 right-3 w-3 h-3 rounded-full bg-yellow-400 border border-amber-800 shadow" />

                {/* CURVED SATIN RIBBON TITLE HEADER */}
                <div className="relative w-[108%] -mt-2 mb-3 z-20 flex justify-center">
                  <div className={`w-full py-2 px-4 rounded-xl bg-gradient-to-r ${activeTable.cardHeaderColor} border-2 border-yellow-300 shadow-[0_5px_15px_rgba(0,0,0,0.6)] flex items-center justify-center gap-2 text-center`}>
                    <span className="text-base sm:text-lg font-black text-white tracking-widest uppercase font-serif drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                      {isRtl ? activeTable.nameKu : activeTable.nameEn}
                    </span>
                  </div>
                </div>

                {/* PRIZE SECTION */}
                <div className="w-full my-1 flex flex-col items-center">
                  <div className="flex items-center justify-center gap-2 text-amber-300 text-xs font-bold uppercase tracking-wider mb-1">
                    <span className="opacity-60">───</span>
                    <span>{isRtl ? 'خەڵاتی بردنەوە :' : 'Prize:'}</span>
                    <span className="opacity-60">───</span>
                  </div>

                  {/* Prize Amount + XP Badge */}
                  <div className="flex items-center justify-center gap-3 bg-black/40 border border-amber-500/40 rounded-2xl py-2 px-4 w-full shadow-inner">
                    {/* Gold Coins Stack */}
                    <div className="flex items-center gap-2">
                      <GoldCoinIcon className="w-8 h-8 sm:w-9 sm:h-9 filter drop-shadow-[0_4px_8px_rgba(245,158,11,0.6)]" />
                      <span className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-100 via-yellow-300 to-amber-400 font-mono tracking-tight drop-shadow">
                        {formatCoins(activeTable.prizePool)}
                      </span>
                    </div>

                    {/* XP Pill Badge */}
                    <div className="bg-gradient-to-r from-purple-600 to-indigo-600 border border-purple-300 rounded-lg px-2 py-1 text-[11px] font-black text-white shadow flex items-center gap-1">
                      <span>10</span>
                      <span className="text-[9px] bg-purple-800 px-1 rounded">XP</span>
                    </div>
                  </div>
                </div>

                {/* GAME SPECS (Entry Fee, Turn Duration, Players Online) */}
                <div className="w-full my-3 space-y-1.5 text-xs sm:text-sm font-bold text-amber-100/90 text-center">
                  <p className="flex items-center justify-center gap-1.5">
                    <span className="text-amber-300">{isRtl ? 'تێچووی چوونەژوورەوە:' : 'Entry fee:'}</span>
                    <span className="text-yellow-300 font-mono font-black">
                      {activeTable.entryFee === 0 ? (isRtl ? 'بێبەرامبەر (Free)' : 'Free') : `🪙 ${formatCoins(activeTable.entryFee)}`}
                    </span>
                  </p>

                  <p className="flex items-center justify-center gap-1.5">
                    <span className="text-amber-300">{isRtl ? 'کاتی یاری:' : 'Turn duration:'}</span>
                    <span className="text-amber-100 flex items-center gap-1">
                      <span>⏱️</span>
                      <span>{isRtl ? activeTable.rulesTimeFormatKu.replace('یاساکان: ', '') : activeTable.rulesTimeFormatEn.replace('Rules: ', '')}</span>
                    </span>
                  </p>

                  <p className="flex items-center justify-center gap-1 text-[11px] text-emerald-300 pt-0.5">
                    <Wifi className="w-3.5 h-3.5 animate-pulse" />
                    <span>{isRtl ? `یاریزانان: ${liveCounts[String(activeTable.id)] ?? 0}` : `Online: ${liveCounts[String(activeTable.id)] ?? 0}`}</span>
                  </p>
                </div>

                {/* BIG VIBRANT 3D GREEN PLAY BUTTON */}
                <div className="relative w-full mt-1">
                  {/* Free / Entry Tag Ribbon */}
                  <div className="absolute -top-2.5 left-4 z-20 bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 text-[10px] font-black px-2 py-0.5 rounded-md shadow uppercase tracking-wider border border-yellow-100 rotate-[-4deg]">
                    {activeTable.entryFee === 0 ? 'Free' : '1v1 Match'}
                  </div>

                  <button
                    onClick={() => {
                      soundManager.playClick();
                      onSelectTable(activeTable);
                    }}
                    className="w-full py-3.5 sm:py-4 rounded-full bg-gradient-to-b from-emerald-400 via-green-500 to-emerald-700 hover:brightness-110 active:scale-95 border-2 border-green-200 text-white font-black text-base sm:text-lg shadow-[0_8px_25px_rgba(34,197,94,0.6)] transition cursor-pointer flex items-center justify-center gap-2 relative overflow-hidden tracking-wider uppercase font-serif"
                  >
                    {/* Gloss Shine Highlight */}
                    <div className="absolute top-0 inset-x-0 h-1/2 bg-white/20 rounded-t-full pointer-events-none" />
                    <span>{isRtl ? 'دەستپێکردنی یاری (Play)' : 'Play'}</span>
                  </button>
                </div>

              </motion.div>

              {/* PAGINATION DOTS */}
              <div className="flex items-center gap-1.5 mt-4 bg-black/60 px-3 py-1 rounded-full border border-amber-800/80 shadow-lg z-30">
                {CHESS_TABLES.map((t, idx) => (
                  <button
                    key={t.id}
                    onClick={() => setCurrentIndex(idx)}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      currentIndex === idx ? 'w-5 bg-yellow-400' : 'w-2 bg-amber-800/80 hover:bg-amber-600'
                    }`}
                  />
                ))}
              </div>

              {/* BOTTOM RANKING / CLASSIC BADGE */}
              <button 
                onClick={() => setSelectedRulesTable(activeTable)}
                className="mt-2 text-xs font-bold text-yellow-300/90 hover:text-yellow-100 flex items-center gap-1.5 transition cursor-pointer bg-black/40 px-3 py-1 rounded-xl border border-amber-600/40"
              >
                <Trophy className="w-3.5 h-3.5 text-yellow-400" />
                <span>{isRtl ? `ڕیزبەندی: ${activeTable.nameKu}` : `Ranking: ${activeTable.nameEn}`}</span>
              </button>

            </div>

          </div>
        ) : (
          /* ========================================== */
          /* ALL TABLES GRID VIEW */
          /* ========================================== */
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 custom-scrollbar max-h-[80vh] z-20">
            
            {/* Search input */}
            <div className="mb-4 relative max-w-md mx-auto">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isRtl ? 'سێرچی مێزی یاری بکه...' : 'Search chess arena...'}
                className="w-full bg-black/60 border border-amber-600/80 rounded-2xl py-2.5 px-9 text-xs sm:text-sm text-amber-100 placeholder-amber-400/50 focus:outline-none focus:border-yellow-400 shadow-inner"
              />
              <Search className="w-4 h-4 text-amber-400 absolute left-3 rtl:right-3 top-3" />
            </div>

            {/* Grid list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {filteredTables.map((tbl) => (
                <div
                  key={tbl.id}
                  onClick={() => {
                    soundManager.playClick();
                    onSelectTable(tbl);
                  }}
                  className={`rounded-3xl border-2 border-amber-500/70 bg-gradient-to-b ${tbl.bgTheme} p-4 flex flex-col justify-between shadow-xl cursor-pointer hover:border-yellow-300 hover:scale-[1.02] transition relative overflow-hidden`}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-3xl p-2 bg-black/50 rounded-2xl border border-amber-600/50 shadow">{tbl.icon}</span>
                    <div className="flex flex-col">
                      <h4 className="font-black text-amber-100 text-sm sm:text-base">{isRtl ? tbl.nameKu : tbl.nameEn}</h4>
                      <span className="text-[10px] text-amber-300/80">{isRtl ? tbl.themeDescKu : tbl.themeDescEn}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-amber-800/60 text-xs font-bold">
                    <div className="flex items-center gap-1 text-yellow-300">
                      <GoldCoinIcon className="w-4 h-4" />
                      <span>{formatCoins(tbl.entryFee)}</span>
                    </div>
                    <div className="flex items-center gap-1 text-emerald-300">
                      <span>🏆</span>
                      <span>{formatCoins(tbl.prizePool)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================== */}
        {/* RULES MODAL POPUP ([i] INFO) */}
        {/* ========================================== */}
        {selectedRulesTable && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
            <div className="w-full max-w-sm bg-gradient-to-b from-[#281309] to-[#0d0502] border-2 border-amber-500 rounded-3xl p-5 text-amber-100 shadow-2xl relative">
              <button
                onClick={() => setSelectedRulesTable(null)}
                className="absolute top-3 right-3 text-amber-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2.5 mb-3">
                <span className="text-3xl p-1 bg-black/50 rounded-2xl border border-amber-600/40">{selectedRulesTable.icon}</span>
                <h3 className="text-base font-black text-yellow-300">
                  {isRtl ? selectedRulesTable.nameKu : selectedRulesTable.nameEn}
                </h3>
              </div>

              <div className="space-y-2.5 text-xs text-amber-200/90 font-medium bg-black/50 p-3.5 rounded-2xl border border-amber-800/60 shadow-inner">
                <p className="flex items-center gap-2">
                  <span>🕒</span>
                  <span>{isRtl ? selectedRulesTable.rulesTimeFormatKu : selectedRulesTable.rulesTimeFormatEn}</span>
                </p>
                <p className="flex items-center gap-2">
                  <GoldCoinIcon className="w-4 h-4" />
                  <span>{isRtl ? `پاداشتی سەرکەوتن: ${selectedRulesTable.prizePool.toLocaleString()} سکە` : `Win Reward: ${selectedRulesTable.prizePool.toLocaleString()} coins`}</span>
                </p>
                <p className="flex items-center gap-2">
                  <span>⭐</span>
                  <span>{isRtl ? `ئاستی پێویست: لێڤڵ ${selectedRulesTable.minLevel}` : `Required Level: Lvl ${selectedRulesTable.minLevel}`}</span>
                </p>
                <p className="flex items-center gap-2 text-emerald-400 font-bold">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>{isRtl ? 'سیستەمی پاراستنی Fair Play لەگەڵ دژی Cheat' : 'Fair Play Protected & Cheat Detection Active'}</span>
                </p>
              </div>

              <button
                onClick={() => setSelectedRulesTable(null)}
                className="mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-amber-950 font-black text-xs shadow-md hover:brightness-110 cursor-pointer"
              >
                {isRtl ? 'باشە (تێگەیشتم)' : 'Got it'}
              </button>
            </div>
          </div>
        )}

      </div>
    </AnimatePresence>
  );
};
