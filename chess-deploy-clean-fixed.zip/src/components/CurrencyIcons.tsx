import React from 'react';

// =========================================================
// UNIFIED 3D SHINY GOLD COIN SVG
// =========================================================
export const GoldCoinIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={`${className} shrink-0 filter drop-shadow-[0_2px_6px_rgba(245,158,11,0.6)]`} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="uniCoinGrad" cx="35%" cy="30%" r="65%">
        <stop offset="0%" stopColor="#FFF9C4" />
        <stop offset="30%" stopColor="#FACC15" />
        <stop offset="70%" stopColor="#EAB308" />
        <stop offset="90%" stopColor="#CA8A04" />
        <stop offset="100%" stopColor="#713F12" />
      </radialGradient>
      <linearGradient id="uniCoinRim" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#FEF08A" />
        <stop offset="40%" stopColor="#EAB308" />
        <stop offset="100%" stopColor="#713F12" />
      </linearGradient>
      <linearGradient id="uniCoinShine" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.9" />
        <stop offset="60%" stopColor="#FFFFFF" stopOpacity="0" />
      </linearGradient>
    </defs>
    {/* Outer Rim */}
    <circle cx="24" cy="24" r="22" fill="url(#uniCoinRim)" stroke="#3F2207" strokeWidth="1" />
    {/* Inner Face */}
    <circle cx="24" cy="24" r="19.5" fill="url(#uniCoinGrad)" />
    {/* Bevel rings */}
    <circle cx="24" cy="24" r="16.5" fill="none" stroke="#FEF08A" strokeWidth="1.2" opacity="0.85" />
    <circle cx="24" cy="24" r="15" fill="none" stroke="#A16207" strokeWidth="1" opacity="0.6" />
    {/* Dotted Milling */}
    <circle cx="24" cy="24" r="17.8" fill="none" stroke="#713F12" strokeWidth="1" strokeDasharray="1.5 2" opacity="0.75" />
    {/* Center Crown / Star Emblem */}
    <path
      d="M24 12.5L26.5 17.5H31.5L27.5 20.8L29 26L24 22.8L19 26L20.5 20.8L16.5 17.5H21.5L24 12.5Z"
      fill="#713F12"
      opacity="0.85"
    />
    <path
      d="M24 14L25.8 18H29.5L26.5 20.4L27.5 24.5L24 22L20.5 24.5L21.5 20.4L18.5 18H22.2L24 14Z"
      fill="#FEF08A"
    />
    {/* Gloss Reflection Arc */}
    <path
      d="M8.5 22C8.5 14.5 14.5 8.5 22 8.5C25.5 8.5 28.5 9.8 31 12"
      stroke="url(#uniCoinShine)"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
  </svg>
);

// =========================================================
// UNIFIED 3D SHINY GEM SVG
// =========================================================
export const GemIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg className={`${className} shrink-0 filter drop-shadow-[0_2px_6px_rgba(6,182,212,0.6)]`} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="uniGemGrad" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stopColor="#ECFEFF" />
        <stop offset="25%" stopColor="#67E8F9" />
        <stop offset="60%" stopColor="#06B6D4" />
        <stop offset="90%" stopColor="#0891B2" />
        <stop offset="100%" stopColor="#164E63" />
      </linearGradient>
    </defs>
    <path
      d="M15 11L33 11L42 21L24 41L6 21L15 11Z"
      fill="url(#uniGemGrad)"
      stroke="#E0F2FE"
      strokeWidth="1.5"
    />
    <path d="M15 11L24 21L33 11" stroke="#FFFFFF" strokeWidth="1.2" opacity="0.85" />
    <path d="M6 21L24 21L42 21" stroke="#FFFFFF" strokeWidth="1.2" opacity="0.85" />
    <path d="M24 21L24 41" stroke="#083344" strokeWidth="1.2" opacity="0.6" />
    <polygon points="17,13 24,19 21,13" fill="#FFFFFF" opacity="0.85" />
  </svg>
);

// =========================================================
// UNIFIED CAPSULE BADGE FOR HEADER & MODALS
// =========================================================
interface CurrencyBadgeProps {
  type: 'coins' | 'gems';
  amount: number;
  onPlusClick?: () => void;
  className?: string;
}

export const CurrencyBadge: React.FC<CurrencyBadgeProps> = ({
  type,
  amount,
  onPlusClick,
  className = '',
}) => {
  const isCoins = type === 'coins';

  const formattedAmount = amount >= 1000000
    ? `${(amount / 1000000).toFixed(1)}M`
    : amount >= 1000
    ? `${(amount / 1000).toFixed(1)}K`
    : amount.toLocaleString();

  return (
    <div
      className={`relative inline-flex items-center bg-gradient-to-r ${
        isCoins
          ? 'from-[#2a1708] via-[#1a0e05] to-[#0f0702] border-amber-500/80'
          : 'from-[#07212b] via-[#04151c] to-[#020b0e] border-cyan-500/80'
      } border-2 rounded-2xl px-2 py-1 shadow-[0_4px_12px_rgba(0,0,0,0.6)] gap-1.5 ${className}`}
    >
      {/* Icon */}
      {isCoins ? <GoldCoinIcon className="w-5 h-5 sm:w-6 sm:h-6" /> : <GemIcon className="w-5 h-5 sm:w-6 sm:h-6" />}

      {/* Amount Number */}
      <span
        className={`font-mono font-black text-xs sm:text-sm tracking-tight ${
          isCoins
            ? 'text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500'
            : 'text-transparent bg-clip-text bg-gradient-to-r from-cyan-100 via-sky-300 to-cyan-400'
        }`}
      >
        {formattedAmount}
      </span>

      {/* Plus Button */}
      {onPlusClick && (
        <button
          onClick={onPlusClick}
          className={`w-5 h-5 sm:w-5.5 sm:h-5.5 rounded-xl ${
            isCoins
              ? 'bg-gradient-to-b from-yellow-400 to-amber-600 text-amber-950 border border-yellow-200 shadow-[0_0_8px_rgba(245,158,11,0.5)]'
              : 'bg-gradient-to-b from-cyan-300 to-cyan-600 text-cyan-950 border border-cyan-100 shadow-[0_0_8px_rgba(6,182,212,0.5)]'
          } flex items-center justify-center font-black text-xs hover:scale-110 active:scale-95 transition cursor-pointer shrink-0`}
        >
          +
        </button>
      )}
    </div>
  );
};
