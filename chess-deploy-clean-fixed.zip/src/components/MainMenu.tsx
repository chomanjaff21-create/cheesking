import React from 'react';
import { motion } from 'motion/react';
import {
  Trophy,
  Volume2,
  VolumeX,
  HelpCircle,
  Settings,
  Plus,
  Gamepad2,
  Gift,
  MessageSquare,
  ShoppingBag,
  Users,
  UserPlus,
  Crown,
  Download,
  LogOut,
} from 'lucide-react';
import { Language, GameMode, AIDifficulty, UserProfile } from '../types';
import { getTranslation } from '../lib/translations';
import { soundManager } from '../lib/soundManager';
import { LevelCrown } from './LevelCrown';
import { CurrencyBadge } from './CurrencyIcons';
import royalChessKurdCastleBg from '../assets/images/royal_chess_kurd_castle_bg_1788296185378.jpg';

interface MainMenuProps {
  language: Language;
  coins: number;
  userProfile?: UserProfile;
  soundEnabled: boolean;
  musicEnabled: boolean;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onStartGame: (mode: GameMode, aiDiff?: AIDifficulty) => void;
  onOpenSettings: () => void;
  onOpenLeaderboard: () => void;
  onOpenTournament?: () => void;
  onOpenShop: () => void;
  onOpenCoach: () => void;
  onOpenHelp: () => void;
  onOpenProfile?: () => void;
  onOpenDailyReward?: () => void;
  onOpenFriends?: () => void;
  onOpenMatchmaking?: () => void;
  onOpenLiveChatHub?: () => void;
  onOpenRoyalPass?: () => void;
  onOpenCustomRoom?: () => void;
  onLogout?: () => void;
}

/* Custom 3D Icon Components Matching Image 2 - High Realism, Metallic Depth & Floating Animations */

// Icon 1: 3D White Knight/King + Globe Badge (1vs1 Real Online Match)
const OnlineMatch3DIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-11 h-11 sm:w-13 sm:h-13 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-300"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
      <defs>
        <radialGradient id="globeEarth" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#60a5fa" />
          <stop offset="40%" stopColor="#2563eb" />
          <stop offset="85%" stopColor="#1e3a8a" />
          <stop offset="100%" stopColor="#0f172a" />
        </radialGradient>
        <linearGradient id="globeLand" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4ade80" />
          <stop offset="100%" stopColor="#16a34a" />
        </linearGradient>
        <linearGradient id="kingIvory" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="60%" stopColor="#fef08a" />
          <stop offset="100%" stopColor="#ca8a04" />
        </linearGradient>
      </defs>

      {/* 3D Earth Globe Sphere */}
      <circle cx="50" cy="50" r="44" fill="url(#globeEarth)" stroke="#93c5fd" strokeWidth="2" />

      {/* Globe Continent Shapes */}
      <path d="M 25 32 C 30 20, 50 25, 48 38 C 42 45, 30 42, 25 32 Z" fill="url(#globeLand)" opacity="0.9" />
      <path d="M 58 22 C 72 20, 80 35, 70 48 C 60 42, 62 28, 58 22 Z" fill="url(#globeLand)" opacity="0.9" />
      <path d="M 32 60 C 45 55, 60 62, 52 78 C 38 82, 28 70, 32 60 Z" fill="url(#globeLand)" opacity="0.9" />

      {/* Glossy Top Reflection Arc */}
      <ellipse cx="50" cy="22" rx="30" ry="12" fill="#ffffff" opacity="0.25" />

      {/* 3D King Chess Piece Standing in front */}
      <g className="filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)]">
        <ellipse cx="50" cy="82" rx="20" ry="6" fill="#854d0e" />
        <ellipse cx="50" cy="80" rx="18" ry="5" fill="url(#kingIvory)" />
        <path d="M 38 78 L 42 54 L 58 54 L 62 78 Z" fill="url(#kingIvory)" stroke="#854d0e" strokeWidth="1" />
        <path d="M 36 54 L 34 40 L 44 46 L 50 36 L 56 46 L 66 40 L 64 54 Z" fill="url(#kingIvory)" stroke="#854d0e" strokeWidth="1" />
        <path d="M 50 26 L 50 36 M 45 30 L 55 30" stroke="#fef08a" strokeWidth="3" strokeLinecap="round" />
        <circle cx="50" cy="24" r="3" fill="#ffffff" />
      </g>
    </svg>
  </motion.div>
);

// Icon 2: 3D Golden Trophy Cup Badge (1vs1 Private Room)
const Room3DIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-11 h-11 sm:w-13 sm:h-13 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-300"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="trophyGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fff8d6" />
          <stop offset="30%" stopColor="#fde047" />
          <stop offset="70%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#713f12" />
        </linearGradient>
      </defs>

      {/* Outer Glowing Golden Circle Ring */}
      <circle cx="50" cy="50" r="44" fill="none" stroke="#fde047" strokeWidth="3.5" className="opacity-80" />
      <circle cx="50" cy="50" r="40" fill="#2e1065" />

      {/* 3D Trophy Cup */}
      <g className="filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)]">
        <path d="M 26 32 C 14 32 14 54 30 56" fill="none" stroke="url(#trophyGoldGrad)" strokeWidth="4.5" strokeLinecap="round" />
        <path d="M 74 32 C 86 32 86 54 70 56" fill="none" stroke="url(#trophyGoldGrad)" strokeWidth="4.5" strokeLinecap="round" />
        <path d="M 28 26 L 72 26 L 65 58 C 60 66 40 66 35 58 Z" fill="url(#trophyGoldGrad)" stroke="#fef08a" strokeWidth="1.5" />
        <ellipse cx="50" cy="26" rx="22" ry="5" fill="#fef08a" />
        <rect x="45" y="62" width="10" height="14" fill="#a16207" />
        <rect x="30" y="74" width="40" height="10" rx="3" fill="url(#trophyGoldGrad)" stroke="#fef08a" strokeWidth="1" />
        <polygon points="50,12 52,18 58,18 53,22 55,28 50,24 45,28 47,22 42,18 48,18" fill="#ffffff" className="animate-pulse" />
      </g>
    </svg>
  </motion.div>
);

// Icon 3: 3D Cute AI Robot + Blue Piece (1vsAI Match)
const Ai3DIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-11 h-11 sm:w-13 sm:h-13 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-300"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="robotMetal" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="40%" stopColor="#cbd5e1" />
          <stop offset="80%" stopColor="#64748b" />
          <stop offset="100%" stopColor="#1e293b" />
        </linearGradient>
        <linearGradient id="robotEye" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#0284c7" />
        </linearGradient>
      </defs>

      {/* 3D Robot Head */}
      <g className="filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)]">
        <line x1="50" y1="12" x2="50" y2="28" stroke="#38bdf8" strokeWidth="4" />
        <circle cx="50" cy="10" r="5" fill="#38bdf8" className="animate-pulse" />
        <rect x="18" y="40" width="8" height="18" rx="3" fill="url(#robotMetal)" />
        <rect x="74" y="40" width="8" height="18" rx="3" fill="url(#robotMetal)" />
        <rect x="24" y="26" width="52" height="46" rx="14" fill="url(#robotMetal)" stroke="#f1f5f9" strokeWidth="2" />
        <rect x="30" y="34" width="40" height="22" rx="8" fill="#0f172a" stroke="#0284c7" strokeWidth="2" />
        <circle cx="41" cy="45" r="5" fill="url(#robotEye)" className="animate-pulse" />
        <circle cx="59" cy="45" r="5" fill="url(#robotEye)" className="animate-pulse" />
        <circle cx="41" cy="43" r="2" fill="#ffffff" />
        <circle cx="59" cy="43" r="2" fill="#ffffff" />
        <path d="M 40 60 Q 50 66 60 60" stroke="#0284c7" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        <path d="M 26 62 L 20 88 L 36 88 L 30 62 Z" fill="#2563eb" stroke="#60a5fa" strokeWidth="1.5" />
        <circle cx="28" cy="58" r="5" fill="#60a5fa" />
      </g>
    </svg>
  </motion.div>
);

// Icon 4: 3D Black & Gold King Chess Pieces (Offline / Practice Match)
const Tutorial3DIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-11 h-11 sm:w-13 sm:h-13 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-300"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="blackKingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#475569" />
          <stop offset="60%" stopColor="#1e293b" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>
        <linearGradient id="goldKingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fff8d6" />
          <stop offset="50%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#78350f" />
        </linearGradient>
      </defs>

      {/* Black King (Left) */}
      <g className="filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)]">
        <ellipse cx="36" cy="82" rx="16" ry="5" fill="#020617" />
        <path d="M 24 80 L 28 52 L 44 52 L 48 80 Z" fill="url(#blackKingGrad)" stroke="#94a3b8" strokeWidth="1" />
        <path d="M 22 52 L 20 38 L 30 44 L 36 34 L 42 44 L 52 38 L 50 52 Z" fill="url(#blackKingGrad)" stroke="#94a3b8" strokeWidth="1" />
        <path d="M 36 24 L 36 34 M 31 28 L 41 28" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />
      </g>

      {/* Gold King (Right) */}
      <g className="filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)]">
        <ellipse cx="64" cy="82" rx="16" ry="5" fill="#451a03" />
        <path d="M 52 80 L 56 52 L 72 52 L 76 80 Z" fill="url(#goldKingGrad)" stroke="#fef08a" strokeWidth="1" />
        <path d="M 50 52 L 48 38 L 58 44 L 64 34 L 70 44 L 80 38 L 78 52 Z" fill="url(#goldKingGrad)" stroke="#fef08a" strokeWidth="1" />
        <path d="M 64 24 L 64 34 M 59 28 L 69 28" stroke="#fde047" strokeWidth="2.5" strokeLinecap="round" />
      </g>
    </svg>
  </motion.div>
);

// Icon 5: 3D Ruby Shield Badge (40 Stages / Level Events)
const LevelMode3DIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-11 h-11 sm:w-13 sm:h-13 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-300"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)]">
      <defs>
        <radialGradient id="rubyGlow" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#fecdd3" />
          <stop offset="40%" stopColor="#e11d48" />
          <stop offset="85%" stopColor="#881337" />
          <stop offset="100%" stopColor="#4c0519" />
        </radialGradient>
        <linearGradient id="shieldGoldRim" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fff8d6" />
          <stop offset="50%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#78350f" />
        </linearGradient>
      </defs>

      <path
        d="M 50 10 L 84 22 C 84 55, 68 78, 50 90 C 32 78, 16 55, 16 22 Z"
        fill="url(#rubyGlow)"
        stroke="url(#shieldGoldRim)"
        strokeWidth="3.5"
      />
      <polygon
        points="50,22 57,36 72,37 60,48 64,64 50,55 36,64 40,48 28,37 43,36"
        fill="#fde047"
        stroke="#ffffff"
        strokeWidth="1.5"
      />
      <rect x="30" y="66" width="40" height="18" rx="9" fill="#78350f" stroke="#fde047" strokeWidth="2" />
      <text x="50" y="79" fontSize="13" fontWeight="900" fill="#fde047" textAnchor="middle" fontFamily="sans-serif">
        40
      </text>
    </svg>
  </motion.div>
);

/* =========================================================================
   5 RP PASS LUXURY 3D NAVIGATION ICONS (GAMES, RP PASS, EVENTS, CHAT, SHOP)
   ========================================================================= */

// 1. RP Game / Play 3D Icon
const GameRPNavIcon = () => (
  <motion.div
    animate={{ scale: [1, 1.05, 1] }}
    transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="gamePadGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="30%" stopColor="#fde047" />
          <stop offset="70%" stopColor="#ca8a04" />
          <stop offset="100%" stopColor="#713f12" />
        </linearGradient>
      </defs>
      <rect x="15" y="32" width="70" height="42" rx="18" fill="url(#gamePadGold)" stroke="#fef08a" strokeWidth="3" />
      <circle cx="34" cy="53" r="10" fill="#451a03" />
      <path d="M 34 47 L 34 59 M 28 53 L 40 53" stroke="#fde047" strokeWidth="3.5" strokeLinecap="round" />
      <circle cx="62" cy="48" r="4.5" fill="#ef4444" />
      <circle cx="72" cy="56" r="4.5" fill="#3b82f6" />
      <circle cx="56" cy="58" r="4.5" fill="#10b981" />
      <circle cx="66" cy="42" r="4.5" fill="#eab308" />
    </svg>
  </motion.div>
);

// 2. RP Royal Pass Crown 3D Icon
const RoyalPassRPNavIcon = () => (
  <motion.div
    animate={{ rotate: [-2, 2, -2], y: [-1, 1, -1] }}
    transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_2px_10px_rgba(250,204,21,0.9)]">
      <defs>
        <linearGradient id="crownGold3D" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="25%" stopColor="#fde047" />
          <stop offset="65%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#854d0e" />
        </linearGradient>
      </defs>
      <path
        d="M 16 75 L 22 35 L 40 52 L 50 22 L 60 52 L 78 35 L 84 75 Z"
        fill="url(#crownGold3D)"
        stroke="#fff8d6"
        strokeWidth="3.5"
        strokeLinejoin="round"
      />
      <rect x="18" y="75" width="64" height="10" rx="3" fill="#854d0e" stroke="#fde047" strokeWidth="2" />
      <circle cx="22" cy="35" r="4.5" fill="#ef4444" />
      <circle cx="50" cy="22" r="6" fill="#ef4444" className="animate-ping" />
      <circle cx="78" cy="35" r="4.5" fill="#ef4444" />
      <circle cx="36" cy="79" r="3" fill="#38bdf8" />
      <circle cx="50" cy="79" r="3.5" fill="#ef4444" />
      <circle cx="64" cy="79" r="3" fill="#38bdf8" />
    </svg>
  </motion.div>
);

// 3. RP Events / Daily Chest 3D Icon
const EventsRPNavIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="giftBoxRed" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fca5a5" />
          <stop offset="40%" stopColor="#dc2626" />
          <stop offset="100%" stopColor="#7f1d1d" />
        </linearGradient>
        <linearGradient id="ribbonGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="50%" stopColor="#fde047" />
          <stop offset="100%" stopColor="#a16207" />
        </linearGradient>
      </defs>
      <rect x="20" y="42" width="60" height="42" rx="8" fill="url(#giftBoxRed)" stroke="#fecaca" strokeWidth="2" />
      <rect x="15" y="30" width="70" height="16" rx="6" fill="url(#giftBoxRed)" stroke="#fef08a" strokeWidth="2.5" />
      <rect x="44" y="30" width="12" height="54" fill="url(#ribbonGold)" stroke="#fef08a" strokeWidth="1" />
      <rect x="15" y="34" width="70" height="8" fill="url(#ribbonGold)" opacity="0.4" />
      <path d="M 38 20 C 30 10, 48 10, 50 28 C 52 10, 70 10, 62 20 Z" fill="url(#ribbonGold)" stroke="#fff" strokeWidth="1.5" />
      <circle cx="50" cy="26" r="4" fill="#fde047" />
    </svg>
  </motion.div>
);

// 4. RP Chat & Live Hub 3D Icon
const ChatLiveRPNavIcon = () => (
  <motion.div
    animate={{ scale: [1, 1.05, 1] }}
    transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="chatBubbleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fed7aa" />
          <stop offset="40%" stopColor="#f97316" />
          <stop offset="100%" stopColor="#7c2d12" />
        </linearGradient>
      </defs>
      <path
        d="M 20 25 C 20 18, 80 18, 80 25 L 80 62 C 80 68, 48 68, 40 75 L 32 82 L 32 68 C 20 68, 20 62, 20 55 Z"
        fill="url(#chatBubbleGrad)"
        stroke="#ffedd5"
        strokeWidth="3"
        strokeLinejoin="round"
      />
      <circle cx="38" cy="42" r="5" fill="#ffffff" />
      <circle cx="50" cy="42" r="5" fill="#ffffff" />
      <circle cx="62" cy="42" r="5" fill="#ffffff" />
    </svg>
  </motion.div>
);

// 5. RP Shop Vault 3D Icon
const ShopRPNavIcon = () => (
  <motion.div
    animate={{ y: [-2, 2, -2] }}
    transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
    className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center"
  >
    <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
      <defs>
        <linearGradient id="shopGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="40%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#713f12" />
        </linearGradient>
      </defs>
      <path d="M 22 36 L 28 82 L 72 82 L 78 36 Z" fill="url(#shopGoldGrad)" stroke="#fff" strokeWidth="2.5" />
      <path d="M 36 36 C 36 20, 64 20, 64 36" fill="none" stroke="#fde047" strokeWidth="5" strokeLinecap="round" />
      <circle cx="50" cy="58" r="11" fill="#451a03" stroke="#fde047" strokeWidth="2" />
      <text x="50" y="63" fontSize="14" fontWeight="bold" fill="#fde047" textAnchor="middle">$</text>
    </svg>
  </motion.div>
);

export const MainMenu: React.FC<MainMenuProps> = ({
  language,
  coins,
  userProfile,
  soundEnabled,
  musicEnabled,
  onToggleSound,
  onToggleMusic,
  onStartGame,
  onOpenSettings,
  onOpenLeaderboard,
  onOpenTournament,
  onOpenShop,
  onOpenCoach,
  onOpenHelp,
  onOpenProfile,
  onOpenDailyReward,
  onOpenFriends,
  onOpenMatchmaking,
  onOpenLiveChatHub,
  onOpenRoyalPass,
  onOpenCustomRoom,
  onLogout,
}) => {
  const isRtl = language === 'ku';
  const [activeNav, setActiveNav] = React.useState<'game' | 'rp' | 'events' | 'chat' | 'shop'>('rp');

  return (
    <div
      className={`relative w-full h-full min-h-screen flex flex-col justify-between p-3 sm:p-4 bg-cover bg-center text-amber-50 select-none overflow-y-auto ${
        isRtl ? 'rtl' : 'ltr'
      }`}
      style={{
        backgroundImage: `linear-gradient(to bottom, rgba(15, 10, 5, 0.35), rgba(20, 12, 6, 0.75)), url(${royalChessKurdCastleBg})`,
      }}
    >
      {/* Full-Screen Dynamic Motion Particle & Dragon Ember Background Layer */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-600/20 via-transparent to-black/80 animate-pulse" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-red-600/15 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,_var(--tw-gradient-stops))] from-yellow-500/15 via-transparent to-transparent" />

        {/* Floating Sparks/Embers Motion */}
        <div className="absolute inset-0 opacity-60">
          {[...Array(18)].map((_, i) => (
            <motion.div
              key={i}
              initial={{
                x: `${Math.random() * 100}%`,
                y: '100%',
                opacity: 0,
                scale: Math.random() * 0.8 + 0.4,
              }}
              animate={{
                y: '-10%',
                opacity: [0, 0.9, 0.9, 0],
                x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              }}
              transition={{
                duration: 6 + Math.random() * 8,
                repeat: Infinity,
                delay: Math.random() * 5,
                ease: 'linear',
              }}
              className="absolute w-2 h-2 rounded-full bg-gradient-to-t from-amber-400 to-yellow-200 shadow-[0_0_8px_rgba(250,204,21,0.9)]"
            />
          ))}
        </div>
      </div>
      {/* Top Header Bar */}
      <div className="w-full max-w-lg mx-auto flex items-center justify-between z-10 pt-0.5">
        {/* User Profile + Coin & Purple Gem Counters */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => {
              soundManager.playClick();
              if (onOpenProfile) onOpenProfile();
            }}
            className="relative cursor-pointer group focus:outline-none"
            title="Open Profile"
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full border-2 sm:border-3 border-amber-400 p-0.5 shadow-lg bg-amber-950 overflow-hidden group-hover:scale-105 group-hover:border-yellow-300 transition">
              <img
                src={
                  userProfile?.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'
                }
                alt={userProfile?.name || 'User Profile'}
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Level Badge Positioned BELOW the Avatar Photo */}
            <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 z-20">
              <span className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 text-[9px] sm:text-[10px] font-black px-1.5 py-0.2 rounded-full border border-yellow-200 shadow-md font-mono whitespace-nowrap flex items-center gap-0.5">
                <span>LV</span>
                <span>{userProfile?.level || 24}</span>
              </span>
            </div>
          </button>

          {/* Gold Coins Badge */}
          <CurrencyBadge
            type="coins"
            amount={typeof coins === 'number' && !isNaN(coins) ? coins : (userProfile?.coins ?? 5000)}
            onPlusClick={() => {
              soundManager.playClick();
              onOpenShop();
            }}
          />

          {/* Gems Badge */}
          <CurrencyBadge
            type="gems"
            amount={userProfile?.gems ?? 50}
            onPlusClick={() => {
              soundManager.playClick();
              onOpenShop();
            }}
          />
        </div>

        {/* Right Top Actions */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {/* Friends Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              if (onOpenFriends) onOpenFriends();
              else if (onOpenProfile) onOpenProfile();
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-amber-800 to-amber-950 border border-amber-500/60 flex items-center justify-center text-amber-200 hover:text-white transition shadow-md cursor-pointer"
            title={language === 'ku' ? 'هاوڕێیان' : 'Friends'}
          >
            <Users className="w-4 h-4 text-yellow-300" />
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onOpenHelp();
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-amber-800 to-amber-950 border border-amber-500/60 flex items-center justify-center text-amber-200 hover:text-white transition shadow-md cursor-pointer"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onToggleMusic();
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-amber-800 to-amber-950 border border-amber-500/60 flex items-center justify-center text-amber-200 hover:text-white transition shadow-md cursor-pointer"
          >
            {musicEnabled ? <Volume2 className="w-4 h-4 text-yellow-400" /> : <VolumeX className="w-4 h-4 text-amber-400/50" />}
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onOpenSettings();
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-amber-800 to-amber-950 border border-amber-500/60 flex items-center justify-center text-amber-200 hover:text-white transition shadow-md cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Container Content */}
      <div className="w-full max-w-md mx-auto mt-3 sm:mt-4.5 mb-auto flex flex-col items-center gap-2 sm:gap-3 pt-1 pb-1 z-10">
        {/* Top Widget Row: RANKING (Compact Trophy + 3 Avatars, NO Gap) & EVENTS (Clean Box, No Text) */}
        <div className="w-full flex items-center justify-between gap-2 px-1">
          {/* Left: Ranking Plaque (Compact, Trophy + 3 Avatars snugly together) */}
          <motion.button
            whileHover={{ scale: 1.02, y: -1 }}
            whileTap={{ scale: 0.98, y: 1 }}
            onClick={() => {
              soundManager.playClick();
              onOpenLeaderboard();
            }}
            className="bg-gradient-to-r from-[#4d2105] via-[#2f1302] to-[#4d2105] border-2 border-yellow-500/80 rounded-2xl p-1.5 sm:p-2 flex items-center gap-2 backdrop-blur-md shadow-[0_6px_16px_rgba(0,0,0,0.8)] hover:border-yellow-300 transition cursor-pointer group relative overflow-hidden shrink-0"
          >
            {/* Background Shimmer Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-400/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />

            <div className="relative p-1.5 rounded-xl bg-gradient-to-b from-yellow-300 via-amber-500 to-amber-700 text-amber-950 shadow-md border border-yellow-200 shrink-0">
              <Trophy className="w-4 h-4 text-amber-950 fill-yellow-200" />
            </div>

            {/* Top 3 Avatars Row - Compact Spacing with No Blank Space */}
            <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
              {/* 1st Place Gold */}
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80"
                  className="w-6 h-6 sm:w-7 sm:h-7 rounded-full border-2 border-yellow-400 object-cover shadow-[0_2px_6px_rgba(250,204,21,0.6)]"
                  alt="1st Place"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -bottom-1 -right-0.5 bg-gradient-to-r from-yellow-400 to-amber-500 text-amber-950 text-[8px] font-black w-3.5 h-3.5 rounded-full border border-yellow-200 shadow flex items-center justify-center font-mono">
                  1
                </span>
              </div>

              {/* 2nd Place Silver */}
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=100&q=80"
                  className="w-6 h-6 sm:w-7 sm:h-7 rounded-full border-2 border-slate-300 object-cover shadow-[0_2px_6px_rgba(203,213,225,0.5)]"
                  alt="2nd Place"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -bottom-1 -right-0.5 bg-gradient-to-r from-slate-200 to-slate-400 text-slate-900 text-[8px] font-black w-3.5 h-3.5 rounded-full border border-white shadow flex items-center justify-center font-mono">
                  2
                </span>
              </div>

              {/* 3rd Place Bronze */}
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                  className="w-6 h-6 sm:w-7 sm:h-7 rounded-full border-2 border-amber-600 object-cover shadow-[0_2px_6px_rgba(217,119,6,0.5)]"
                  alt="3rd Place"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute -bottom-1 -right-0.5 bg-gradient-to-r from-amber-600 to-amber-800 text-yellow-100 text-[8px] font-black w-3.5 h-3.5 rounded-full border border-amber-300 shadow flex items-center justify-center font-mono">
                  3
                </span>
              </div>
            </div>
          </motion.button>

          {/* Right: Events Box (Clean Icon Box, No Text) */}
          <motion.button
            whileHover={{ scale: 1.05, y: -1 }}
            whileTap={{ scale: 0.95, y: 1 }}
            onClick={() => {
              soundManager.playClick();
              if (onOpenDailyReward) onOpenDailyReward();
              else if (onOpenTournament) onOpenTournament();
              else onOpenLeaderboard();
            }}
            className="bg-gradient-to-b from-[#7c1d12] via-[#591008] to-[#380904] border-2 border-amber-400/80 rounded-2xl p-1.5 sm:p-2 flex items-center justify-center backdrop-blur-md shadow-[0_6px_16px_rgba(0,0,0,0.8)] hover:border-yellow-300 transition cursor-pointer group relative shrink-0"
            title={language === 'ku' ? 'دیاری و بۆنەکان' : 'Events'}
          >
            <div className="relative p-1.5 rounded-xl bg-gradient-to-b from-red-500 via-red-600 to-red-800 text-yellow-300 shadow-md border border-yellow-300 shrink-0 flex items-center justify-center">
              <Gift className="w-4.5 h-4.5 text-yellow-200 fill-yellow-400/20 animate-pulse" />
            </div>
          </motion.button>
        </div>

        {/* Game Title Header Banner - ROYAL CHESS KURD (Grand Royal 3D Design - Wider & Prettier) */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1, y: [0, -2, 0] }}
          transition={{
            scale: { duration: 0.4 },
            opacity: { duration: 0.4 },
            y: { duration: 3.5, repeat: Infinity, ease: 'easeInOut' },
          }}
          className="relative my-0.5 text-center flex flex-col items-center cursor-pointer group shrink-0 w-full"
        >
          {/* Floating Top Crown & 3D Chess Crest */}
          <div className="flex items-center justify-center gap-2.5 -mb-2.5 z-20">
            <motion.div
              animate={{ rotate: [-8, -2, -8], y: [-2, 1, -2] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              className="text-xl sm:text-2xl filter drop-shadow-[0_4px_8px_rgba(255,215,0,0.9)]"
            >
              ♔
            </motion.div>

            {/* Glowing Royal Crown SVG */}
            <motion.div
              animate={{ y: [-2, 2, -2], scale: [1, 1.05, 1] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
              className="w-9 h-7 filter drop-shadow-[0_4px_10px_rgba(234,179,8,1)]"
            >
              <svg viewBox="0 0 100 80" className="w-full h-full">
                <defs>
                  <linearGradient id="crestGold" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#fff7d6" />
                    <stop offset="30%" stopColor="#f59e0b" />
                    <stop offset="70%" stopColor="#b45309" />
                    <stop offset="100%" stopColor="#451a03" />
                  </linearGradient>
                </defs>
                <path
                  d="M 12 70 L 20 25 L 38 48 L 50 15 L 62 48 L 80 25 L 88 70 Z"
                  fill="url(#crestGold)"
                  stroke="#fef08a"
                  strokeWidth="3.5"
                />
                <circle cx="20" cy="23" r="5" fill="#ef4444" />
                <circle cx="50" cy="13" r="6" fill="#3b82f6" stroke="#fef08a" strokeWidth="2" />
                <circle cx="80" cy="23" r="5" fill="#10b981" />
                <rect x="10" y="68" width="80" height="10" rx="3" fill="url(#crestGold)" stroke="#fef08a" strokeWidth="2" />
              </svg>
            </motion.div>

            <motion.div
              animate={{ rotate: [8, 2, 8], y: [-2, 1, -2] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
              className="text-xl sm:text-2xl filter drop-shadow-[0_4px_8px_rgba(255,255,255,0.9)]"
            >
              ♘
            </motion.div>
          </div>

          {/* Golden Ornate Plaque with Animated Shimmer Sweep - Wider & Glossier */}
          <div className="relative w-full max-w-[340px] sm:max-w-[380px] bg-gradient-to-b from-[#ffe58f] via-[#d97706] to-[#78350f] p-0.5 rounded-2xl shadow-[0_8px_25px_rgba(217,119,6,0.65),0_0_20px_rgba(234,179,8,0.3)] overflow-hidden">
            <div className="bg-gradient-to-b from-[#fffbe8] via-[#fef3c7] to-[#fde68a] border-2 border-[#b45309] rounded-[14px] px-6 sm:px-10 py-2 text-amber-950 flex items-center justify-center gap-2.5 shadow-inner relative overflow-hidden w-full">
              {/* Continuous Light Shimmer Sweep Animation */}
              <motion.div
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', repeatDelay: 1 }}
                className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/70 to-transparent transform -skew-x-12 pointer-events-none"
              />

              <h1 className="text-base sm:text-xl font-black font-serif text-[#3e1703] tracking-[0.18em] drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)] uppercase">
                ROYAL CHESS
              </h1>

              {/* KURD Badge with Kurdish Tricolor Glow */}
              <span className="bg-gradient-to-r from-red-600 via-amber-400 to-emerald-600 text-white text-[10px] sm:text-xs font-black px-2.5 py-0.5 rounded-md border border-amber-200 shadow-md tracking-widest uppercase shadow-[0_2px_6px_rgba(0,0,0,0.4)]">
                KURD
              </span>
            </div>
          </div>
        </motion.div>

        {/* MAIN ACTION BUTTONS: BUTTONS 1, 2, 3 (SHORTER, WIDER, Glossy 3D) */}
        <div className="w-full flex flex-col gap-1.5 my-0.5">
          {/* Button 1: 1vs1 Real Online Match (Blue / Navy - Shorter & Wider) */}
          <motion.button
            whileHover={{ scale: 1.015, y: -1 }}
            whileTap={{ scale: 0.985, y: 1 }}
            onClick={() => {
              soundManager.playClick();
              if (onOpenMatchmaking) onOpenMatchmaking();
              else onStartGame('vs_ai');
            }}
            className="w-full relative min-h-[2.7rem] sm:min-h-[3.0rem] rounded-2xl bg-gradient-to-r from-[#2563eb] via-[#1d4ed8] to-[#1e3a8a] border-2 border-[#60a5fa] p-0.5 shadow-[0_4px_14px_rgba(37,99,235,0.5)] flex items-center justify-between overflow-hidden cursor-pointer group transition-all"
          >
            {/* 4 Corner Metallic Rivets */}
            <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute bottom-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />

            <div className="w-full h-full rounded-xl border border-blue-200/30 py-1 px-3 flex items-center justify-between relative overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-300/25 via-transparent to-black/30">
              {/* Top Glossy Bevel Reflection */}
              <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/25 via-white/10 to-transparent pointer-events-none z-10" />

              {/* Shimmer Sweep */}
              <motion.div
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut', repeatDelay: 1 }}
                className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 pointer-events-none"
              />

              <div className="flex flex-col items-start text-left rtl:text-right z-10 pl-1 rtl:pl-0 rtl:pr-1">
                <span className="text-xs sm:text-sm font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] tracking-wide font-sans">
                  1vs1 یاری واقیعی (Play Online)
                </span>
                <span className="text-[9px] sm:text-[10px] text-blue-100/90 font-bold drop-shadow">
                  {language === 'ku' ? 'یاری لەگەڵ یاریزانانی ڕاستەقینە' : 'Play with real players'}
                </span>
              </div>

              <OnlineMatch3DIcon />
            </div>
          </motion.button>

          {/* Button 2: 1vs1 Room (Purple / Amethyst - Shorter & Wider) */}
          <motion.button
            whileHover={{ scale: 1.015, y: -1 }}
            whileTap={{ scale: 0.985, y: 1 }}
            onClick={() => {
              soundManager.playClick();
              if (onOpenCustomRoom) onOpenCustomRoom();
              else onStartGame('pass_and_play');
            }}
            className="w-full relative min-h-[2.7rem] sm:min-h-[3.0rem] rounded-2xl bg-gradient-to-r from-[#9333ea] via-[#7e22ce] to-[#4c1d95] border-2 border-[#c084fc] p-0.5 shadow-[0_4px_14px_rgba(147,51,234,0.5)] flex items-center justify-between overflow-hidden cursor-pointer group transition-all"
          >
            {/* 4 Corner Metallic Rivets */}
            <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute bottom-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />

            <div className="w-full h-full rounded-xl border border-purple-200/30 py-1 px-3 flex items-center justify-between relative overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-fuchsia-300/25 via-transparent to-black/30">
              {/* Top Glossy Bevel Reflection */}
              <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/25 via-white/10 to-transparent pointer-events-none z-10" />

              {/* Shimmer Sweep */}
              <motion.div
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 4.2, repeat: Infinity, ease: 'easeInOut', repeatDelay: 1.2 }}
                className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 pointer-events-none"
              />

              <div className="flex flex-col items-start text-left rtl:text-right z-10 pl-1 rtl:pl-0 rtl:pr-1">
                <span className="text-xs sm:text-sm font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] tracking-wide font-sans">
                  1vs1 Room (ژووری تایبەت)
                </span>
                <span className="text-[9px] sm:text-[10px] text-purple-100/90 font-bold drop-shadow">
                  {language === 'ku' ? 'دروستکردنی ژووری تایبەت' : 'Create a private room'}
                </span>
              </div>

              <Room3DIcon />
            </div>
          </motion.button>

          {/* Button 3: 1vsAI (Orange / Amber - Shorter & Wider) */}
          <motion.button
            whileHover={{ scale: 1.015, y: -1 }}
            whileTap={{ scale: 0.985, y: 1 }}
            onClick={() => {
              soundManager.playClick();
              onStartGame('vs_ai');
            }}
            className="w-full relative min-h-[2.7rem] sm:min-h-[3.0rem] rounded-2xl bg-gradient-to-r from-[#ea580c] via-[#c2410c] to-[#7c2d12] border-2 border-[#fb923c] p-0.5 shadow-[0_4px_14px_rgba(234,88,12,0.5)] flex items-center justify-between overflow-hidden cursor-pointer group transition-all"
          >
            {/* 4 Corner Metallic Rivets */}
            <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute bottom-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
            <div className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />

            <div className="w-full h-full rounded-xl border border-orange-200/30 py-1 px-3 flex items-center justify-between relative overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-300/25 via-transparent to-black/30">
              {/* Top Glossy Bevel Reflection */}
              <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/25 via-white/10 to-transparent pointer-events-none z-10" />

              {/* Shimmer Sweep */}
              <motion.div
                animate={{ x: ['-100%', '200%'] }}
                transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut', repeatDelay: 1.5 }}
                className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 pointer-events-none"
              />

              <div className="flex flex-col items-start text-left rtl:text-right z-10 pl-1 rtl:pl-0 rtl:pr-1">
                <span className="text-xs sm:text-sm font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] tracking-wide font-sans">
                  1vsAI (یاری بەڕامبەر AI)
                </span>
                <span className="text-[9px] sm:text-[10px] text-orange-100/90 font-bold drop-shadow">
                  {language === 'ku' ? 'ڕکابەرایەتی ئاستەکانی ژیری دەستکرد' : 'Challenge AI opponents'}
                </span>
              </div>

              <Ai3DIcon />
            </div>
          </motion.button>

          {/* BUTTONS 4 & 5: SIDE-BY-SIDE WINDOW GRID (EXACT STYLING OF IMAGE 2!) */}
          <div className="w-full grid grid-cols-2 gap-2 sm:gap-2.5 mt-0.5">
            {/* Button 4 (Left Window): Play Puzzles / فێرکاری و مەتەڵەکان */}
            <motion.button
              whileHover={{ scale: 1.02, y: -1 }}
              whileTap={{ scale: 0.98, y: 1 }}
              onClick={() => {
                soundManager.playClick();
                onStartGame('puzzles');
              }}
              className="relative min-h-[3.2rem] sm:min-h-[3.6rem] rounded-2xl bg-gradient-to-r from-[#0284c7] via-[#0369a1] to-[#075985] border-2 border-[#38bdf8] p-0.5 shadow-[0_4px_14px_rgba(2,132,199,0.55)] flex flex-col justify-between overflow-hidden cursor-pointer group transition-all"
            >
              {/* Corner Metallic Rivets */}
              <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
              <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
              <div className="absolute bottom-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
              <div className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />

              <div className="w-full h-full rounded-xl border border-sky-200/30 p-2 flex items-center justify-between relative overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-300/25 via-transparent to-black/30">
                {/* Top Glossy Bevel */}
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/25 via-white/10 to-transparent pointer-events-none z-10" />

                <div className="flex flex-col items-start text-left rtl:text-right z-10 pr-1 rtl:pr-0 rtl:pl-1">
                  <span className="text-xs sm:text-sm font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] tracking-tight font-sans">
                    مەتەڵەکان
                  </span>
                  <span className="text-[9px] text-sky-100/90 font-extrabold drop-shadow">
                    Play Puzzles
                  </span>
                </div>

                <div className="shrink-0 transform scale-90 sm:scale-100">
                  <Tutorial3DIcon />
                </div>
              </div>
            </motion.button>

            {/* Button 5 (Right Window): 40 Stages & Mail Chess / شوێنی مەڕحەلەکان */}
            <motion.button
              whileHover={{ scale: 1.02, y: -1 }}
              whileTap={{ scale: 0.98, y: 1 }}
              onClick={() => {
                soundManager.playClick();
                onStartGame('puzzles');
              }}
              className="relative min-h-[3.2rem] sm:min-h-[3.6rem] rounded-2xl bg-gradient-to-r from-[#15803d] via-[#166534] to-[#14532d] border-2 border-[#4ade80] p-0.5 shadow-[0_4px_14px_rgba(21,128,61,0.55)] flex flex-col justify-between overflow-hidden cursor-pointer group transition-all"
            >
              {/* Corner Metallic Rivets */}
              <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
              <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
              <div className="absolute bottom-1 left-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />
              <div className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-white/50 shadow-inner z-20 pointer-events-none" />

              <div className="w-full h-full rounded-xl border border-emerald-200/30 p-2 flex items-center justify-between relative overflow-hidden bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-300/25 via-transparent to-black/30">
                {/* Top Glossy Bevel */}
                <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/25 via-white/10 to-transparent pointer-events-none z-10" />

                <div className="flex flex-col items-start text-left rtl:text-right z-10 pr-1 rtl:pr-0 rtl:pl-1">
                  <span className="text-xs sm:text-sm font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] tracking-tight font-sans">
                    مەڕحەلەکان
                  </span>
                  <span className="text-[9px] text-emerald-100/90 font-extrabold drop-shadow">
                    40 Stages
                  </span>
                </div>

                <div className="shrink-0 transform scale-90 sm:scale-100">
                  <LevelMode3DIcon />
                </div>
              </div>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Bottom RP Pass Luxury Navigation Bar (5 Items: Game, RP Pass, Events, Chat/Live, Shop) */}
      <div className="w-full max-w-lg mx-auto bg-gradient-to-r from-[#1f0d04] via-[#3a1908] to-[#1f0d04] border-t-2 border-yellow-500/90 rounded-t-[28px] p-2 px-1 sm:px-3 flex items-center justify-around z-10 shadow-[0_-10px_30px_rgba(0,0,0,0.9)] backdrop-blur-xl">
        {/* Nav 1: Game (یاری) */}
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveNav('game');
          }}
          className="flex flex-col items-center gap-1 cursor-pointer group relative"
        >
          <div
            className={`w-11 h-11 sm:w-13 sm:h-13 rounded-[18px] relative flex items-center justify-center p-1 transition-all duration-300 ${
              activeNav === 'game'
                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 border-2 border-yellow-100 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105 ring-2 ring-yellow-300/80'
                : 'bg-gradient-to-b from-amber-600/90 via-amber-700/80 to-amber-950/95 border-2 border-yellow-500/80 shadow-[0_4px_12px_rgba(180,83,9,0.5)] group-hover:scale-105 group-hover:border-yellow-300'
            }`}
          >
            <GameRPNavIcon />
            <span className="absolute -top-2 -right-1.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full border border-yellow-200 shadow-lg">
              PLAY
            </span>
          </div>
          <span
            className={`text-[10px] sm:text-xs font-black tracking-tight ${
              activeNav === 'game'
                ? 'text-yellow-300 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]'
                : 'text-yellow-100/90 group-hover:text-yellow-200'
            }`}
          >
            {language === 'ku' ? 'یاری' : 'Game'}
          </span>
        </button>

        {/* Nav 2: Royal Pass (RP پاس) */}
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveNav('rp');
            if (onOpenRoyalPass) onOpenRoyalPass();
          }}
          className="flex flex-col items-center gap-1 cursor-pointer group relative"
        >
          <div
            className={`w-11 h-11 sm:w-13 sm:h-13 rounded-[18px] relative flex items-center justify-center p-1 transition-all duration-300 ${
              activeNav === 'rp'
                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 border-2 border-yellow-100 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105 ring-2 ring-yellow-300/80'
                : 'bg-gradient-to-b from-amber-600/90 via-amber-700/80 to-amber-950/95 border-2 border-yellow-500/80 shadow-[0_4px_12px_rgba(180,83,9,0.5)] group-hover:scale-105 group-hover:border-yellow-300'
            }`}
          >
            <RoyalPassRPNavIcon />
            <span className="absolute -top-2 -right-1.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full border border-yellow-200 shadow-lg animate-pulse">
              RP
            </span>
          </div>
          <span
            className={`text-[10px] sm:text-xs font-black tracking-tight ${
              activeNav === 'rp'
                ? 'text-yellow-300 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]'
                : 'text-yellow-100/90 group-hover:text-yellow-200'
            }`}
          >
            {language === 'ku' ? 'پاسی RP' : 'RP Pass'}
          </span>
        </button>

        {/* Nav 3: Event (ئێڤێنت) - RENAMED FROM بۆنەکان */}
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveNav('events');
            if (onOpenTournament) onOpenTournament();
            else onOpenLeaderboard();
          }}
          className="flex flex-col items-center gap-1 cursor-pointer group relative"
        >
          <div
            className={`w-11 h-11 sm:w-13 sm:h-13 rounded-[18px] relative flex items-center justify-center p-1 transition-all duration-300 ${
              activeNav === 'events'
                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 border-2 border-yellow-100 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105 ring-2 ring-yellow-300/80'
                : 'bg-gradient-to-b from-amber-600/90 via-amber-700/80 to-amber-950/95 border-2 border-yellow-500/80 shadow-[0_4px_12px_rgba(180,83,9,0.5)] group-hover:scale-105 group-hover:border-yellow-300'
            }`}
          >
            <EventsRPNavIcon />
            <span className="absolute -top-2 -right-1.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full border border-yellow-200 shadow-lg">
              EVENT
            </span>
          </div>
          <span
            className={`text-[10px] sm:text-xs font-black tracking-tight ${
              activeNav === 'events'
                ? 'text-yellow-300 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]'
                : 'text-yellow-100/90 group-hover:text-yellow-200'
            }`}
          >
            {language === 'ku' ? 'ئێڤێنت' : 'Event'}
          </span>
        </button>

        {/* Nav 4: Social / Live Chat & Streams Hub (چات و لاف) */}
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveNav('chat');
            if (onOpenLiveChatHub) onOpenLiveChatHub();
            else onOpenCoach();
          }}
          className="flex flex-col items-center gap-1 cursor-pointer group relative"
        >
          <div
            className={`w-11 h-11 sm:w-13 sm:h-13 rounded-[18px] relative flex items-center justify-center p-1 transition-all duration-300 ${
              activeNav === 'chat'
                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 border-2 border-yellow-100 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105 ring-2 ring-yellow-300/80'
                : 'bg-gradient-to-b from-amber-600/90 via-amber-700/80 to-amber-950/95 border-2 border-yellow-500/80 shadow-[0_4px_12px_rgba(180,83,9,0.5)] group-hover:scale-105 group-hover:border-yellow-300'
            }`}
          >
            <ChatLiveRPNavIcon />
            <span className="absolute -top-2 -right-1.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full border border-yellow-200 shadow-lg flex items-center gap-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping" />
              LIVE
            </span>
          </div>
          <span
            className={`text-[10px] sm:text-xs font-black tracking-tight ${
              activeNav === 'chat'
                ? 'text-yellow-300 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]'
                : 'text-yellow-100/90 group-hover:text-yellow-200'
            }`}
          >
            {language === 'ku' ? 'چات و لاف' : 'Chat & Live'}
          </span>
        </button>

        {/* Nav 5: Shop (فرۆشگا) */}
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveNav('shop');
            onOpenShop();
          }}
          className="flex flex-col items-center gap-1 cursor-pointer group relative"
        >
          <div
            className={`w-11 h-11 sm:w-13 sm:h-13 rounded-[18px] relative flex items-center justify-center p-1 transition-all duration-300 ${
              activeNav === 'shop'
                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 border-2 border-yellow-100 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105 ring-2 ring-yellow-300/80'
                : 'bg-gradient-to-b from-amber-600/90 via-amber-700/80 to-amber-950/95 border-2 border-yellow-500/80 shadow-[0_4px_12px_rgba(180,83,9,0.5)] group-hover:scale-105 group-hover:border-yellow-300'
            }`}
          >
            <ShopRPNavIcon />
            <span className="absolute -top-2 -right-1.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white text-[8px] font-black px-1.5 py-0.2 rounded-full border border-yellow-200 shadow-lg">
              HOT
            </span>
          </div>
          <span
            className={`text-[10px] sm:text-xs font-black tracking-tight ${
              activeNav === 'shop'
                ? 'text-yellow-300 drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]'
                : 'text-yellow-100/90 group-hover:text-yellow-200'
            }`}
          >
            {language === 'ku' ? 'فرۆشگا' : 'Shop'}
          </span>
        </button>
      </div>
    </div>
  );
};
