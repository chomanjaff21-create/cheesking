import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { soundManager } from '../lib/soundManager';
import { useRealtimeStore } from '../lib/realtime';
import { buildApiUrl } from '../lib/api';
import { resetPasswordEmail, upgradeAnonymousAccount } from '../lib/supabase';
import {
  Shield,
  Sparkles,
  AlertCircle,
  Mail,
  User,
  CheckCircle2,
  Lock,
  Eye,
  EyeOff,
  UserPlus,
  LogIn,
  ArrowLeft,
  Crown,
  Sparkle,
} from 'lucide-react';

interface LoginModalProps {
  language: Language;
  onLoginSuccess: (username: string) => void;
  onContinueAsGuest: () => void;
  onClose?: () => void;
  initialMode?: 'entry' | 'login' | 'register' | 'upgrade';
}

export const LoginModal: React.FC<LoginModalProps> = ({
  language,
  onLoginSuccess,
  onContinueAsGuest,
  onClose,
  initialMode = 'entry',
}) => {
  const isRtl = language === 'ku';

  const session = useRealtimeStore((state) => state.session);
  const isCurrentGuest = session?.isGuest || false;

  const [mode, setMode] = useState<'entry' | 'login' | 'register' | 'upgrade' | 'forgot'>(
    isCurrentGuest && initialMode === 'upgrade' ? 'upgrade' : initialMode
  );

  const [emailOrUser, setEmailOrUser] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const { authenticate, authenticateDevice, authenticateWithGoogle } = useRealtimeStore();

  const handleGoogleSignIn = async () => {
    soundManager.playClick();
    setErrorMessage('');
    setSuccessMessage('');
    setIsLoading(true);
    try {
      await authenticateWithGoogle();
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err.message || (isRtl ? 'چوونەژوورەوە لەگەڵ Google سەرکەوتوو نەبوو' : 'Google sign-in failed'));
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playClick();
    setErrorMessage('');
    setSuccessMessage('');

    if (mode === 'forgot') {
      if (!emailOrUser.trim()) {
        setErrorMessage(isRtl ? 'تکایە ئیمەیڵەکەت بنووسە' : 'Please enter your email');
        return;
      }
      const targetEmail = emailOrUser.trim().includes('@')
        ? emailOrUser.trim()
        : `${emailOrUser.trim()}@gmail.com`;
      setIsLoading(true);
      const res = await resetPasswordEmail(targetEmail);
      setIsLoading(false);
      if (res.success) {
        setSuccessMessage(
          isRtl
            ? 'لینکێک بۆ سەرڕاستکردنەوەی وشەی نهێنی نێردرا بۆ ئیمەیڵەکەت'
            : 'Password reset email sent successfully!'
        );
      } else {
        setErrorMessage(res.error || (isRtl ? 'ناردنی فایلی سەرڕاستکردنەوە سەرکەوتوو نەبوو' : 'Failed to send reset email'));
      }
      return;
    }

    if (mode === 'upgrade') {
      const cleanEmail = emailOrUser.trim().toLowerCase();
      const cleanPassword = password.trim();
      const cleanConfirm = confirmPassword.trim();
      const cleanUser = username.trim() || session?.username || 'Player';

      if (!cleanEmail || !cleanEmail.includes('@')) {
        setErrorMessage(isRtl ? 'تکایە ئیمەیڵێکی دروست بنووسە' : 'Please enter a valid email address');
        return;
      }

      if (cleanPassword.length < 6) {
        setErrorMessage(isRtl ? 'وشەی نهێنی دەبێت لانیکەم ٦ پیت یان ژمارە بێت' : 'Password must be at least 6 characters');
        return;
      }

      if (cleanPassword !== cleanConfirm) {
        setErrorMessage(isRtl ? 'وشەی نهێنی و دووبارەکردنەوەکەی وەک یەک نین' : 'Passwords do not match');
        return;
      }

      setIsLoading(true);
      const upgradeRes = await upgradeAnonymousAccount(cleanEmail, cleanPassword, cleanUser);
      setIsLoading(false);

      if (upgradeRes.error) {
        setErrorMessage(upgradeRes.error);
        return;
      }

      setSuccessMessage(isRtl ? 'هەژمارەکەت بە سەرکەوتوویی نوێکرایەوە!' : 'Account upgraded successfully!');
      setTimeout(() => {
        onLoginSuccess(cleanUser);
        if (onClose) onClose();
      }, 1000);
      return;
    }

    const cleanInput = emailOrUser.trim();
    const cleanPassword = password.trim();

    if (!cleanInput) {
      setErrorMessage(isRtl ? 'تکایە ئیمەیڵ یاخود ناوی بەکارهێنەر بنووسە' : 'Please enter email or username');
      return;
    }

    if (cleanPassword.length < 6) {
      setErrorMessage(isRtl ? 'وشەی نهێنی دەبێت لانیکەم ٦ پیت یان ژمارە بێت' : 'Password must be at least 6 characters');
      return;
    }

    if (mode === 'register') {
      if (!emailOrUser.includes('@')) {
        setErrorMessage(isRtl ? 'تکایە ئیمەیڵێکی دروست و ڕاستەقینە بنووسە (نموونە: name@gmail.com)' : 'Please enter a valid email address (e.g., name@gmail.com)');
        return;
      }

      if (!username.trim()) {
        setErrorMessage(isRtl ? 'تکایە ناوی بەکارهێنەر بنووسە' : 'Please enter a username');
        return;
      }

      if (password.trim() !== confirmPassword.trim()) {
        setErrorMessage(isRtl ? 'وشەی نهێنی و دووبارەکردنەوەکەی وەک یەک نین' : 'Passwords do not match');
        return;
      }
    }

    setIsLoading(true);

    try {
      let targetEmail = cleanInput.toLowerCase();
      let finalUsername = username.trim() || cleanInput.split('@')[0] || cleanInput;

      // Username logins are resolved server-side (signInWithEmail); the email is never exposed.

      await authenticate(targetEmail, cleanPassword, mode === 'register', finalUsername);

      const account = useRealtimeStore.getState().account;
      setIsLoading(false);
      onLoginSuccess(account?.user?.username || finalUsername || cleanInput);
      if (onClose) onClose();
    } catch (err: any) {
      setIsLoading(false);
      const msg = err.message || '';
      if (msg.includes('check your email') || msg.includes('ئیمەیڵەکەت بپشکنە')) {
        setSuccessMessage(msg);
      } else {
        setErrorMessage(msg || (mode === 'register' ? 'Registration failed' : 'Login failed'));
      }
    }
  };

  const handleGuest = async () => {
    soundManager.playClick();
    setIsLoading(true);
    setErrorMessage('');
    try {
      const guestUsername = `Guest_${Math.floor(1000 + Math.random() * 9000)}`;
      await authenticateDevice('guest', guestUsername);

      const account = useRealtimeStore.getState().account;
      const finalName = account?.user?.username || guestUsername;

      setIsLoading(false);
      onLoginSuccess(finalName);
      onContinueAsGuest();
      if (onClose) onClose();
    } catch (err: any) {
      setIsLoading(false);
      onContinueAsGuest();
      if (onClose) onClose();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className={`fixed inset-0 z-[120] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto ${
        isRtl ? 'rtl' : 'ltr'
      }`}
    >
      {/* Cartoon Royal Mobile Container Frame */}
      <motion.div
        initial={{ scale: 0.92, y: 15 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.92, y: 15 }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        className="relative w-full max-w-[440px] bg-gradient-to-b from-[#2a0e4e] via-[#1a0833] to-[#0f0422] rounded-[36px] border-[3px] border-amber-500/70 shadow-[0_20px_60px_rgba(0,0,0,0.95),0_0_35px_rgba(234,179,8,0.3)] overflow-hidden flex flex-col justify-between p-5 sm:p-7 my-auto max-h-[95vh]"
      >
        {/* Top Glow & Lighting Decor */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-80 h-44 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 right-0 w-52 h-52 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Header Controls */}
        <div className="relative z-10 flex items-center justify-between w-full mb-3">
          {mode !== 'entry' ? (
            <button
              onClick={() => {
                soundManager.playClick();
                setMode('entry');
                setErrorMessage('');
                setSuccessMessage('');
              }}
              className="w-10 h-10 rounded-2xl bg-purple-950/90 border border-purple-500/50 text-amber-300 flex items-center justify-center hover:bg-purple-900 transition active:scale-95 shadow-md"
            >
              <ArrowLeft className={`w-5 h-5 ${isRtl ? 'rotate-180' : ''}`} />
            </button>
          ) : onClose ? (
            <button
              onClick={() => {
                soundManager.playClick();
                onClose();
              }}
              className="w-10 h-10 rounded-2xl bg-purple-950/90 border border-purple-500/50 text-amber-300 flex items-center justify-center hover:bg-purple-900 transition active:scale-95 shadow-md"
            >
              <span className="text-xl font-bold">✕</span>
            </button>
          ) : (
            <div className="w-10 h-10" />
          )}

          <div className="flex items-center gap-1.5 text-xs font-black text-amber-300 bg-amber-950/80 px-3.5 py-1.5 rounded-full border border-amber-500/50 shadow-inner">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>CHESS ROYAL</span>
          </div>
        </div>

        {/* Center Royal Crest Artwork */}
        <div className="relative z-10 flex flex-col items-center text-center my-2">
          <motion.div
            animate={{ y: [-2, 2, -2] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
            className="relative flex flex-col items-center"
          >
            {/* Crown Crest Icon */}
            <div className="w-14 h-12 -mb-2 z-20 filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)]">
              <svg viewBox="0 0 100 80" className="w-full h-full">
                <defs>
                  <linearGradient id="royalCrownGradModal" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#fff7ed" />
                    <stop offset="35%" stopColor="#f59e0b" />
                    <stop offset="100%" stopColor="#b45309" />
                  </linearGradient>
                </defs>
                <path
                  d="M 12 70 L 20 25 L 38 48 L 50 15 L 62 48 L 80 25 L 88 70 Z"
                  fill="url(#royalCrownGradModal)"
                  stroke="#fef08a"
                  strokeWidth="3"
                />
                <circle cx="20" cy="23" r="5" fill="#ef4444" />
                <circle cx="50" cy="13" r="6" fill="#3b82f6" stroke="#fef08a" strokeWidth="2" />
                <circle cx="80" cy="23" r="5" fill="#10b981" />
                <rect x="10" y="68" width="80" height="12" rx="4" fill="url(#royalCrownGradModal)" stroke="#fef08a" strokeWidth="2" />
              </svg>
            </div>

            {/* Title Banner */}
            <div className="relative px-7 py-2 rounded-2xl bg-gradient-to-b from-[#b91c1c] via-[#991b1b] to-[#450a0a] border-2 border-[#f59e0b] shadow-[0_8px_25px_rgba(0,0,0,0.8),0_0_20px_rgba(245,158,11,0.3)] flex flex-col items-center overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12 animate-pulse pointer-events-none" />
              <h1 className="text-2xl sm:text-3xl font-black text-amber-200 tracking-wider font-serif uppercase z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                CHESS ROYAL
              </h1>
            </div>
          </motion.div>

          <h2 className="text-xl sm:text-2xl font-black text-amber-100 mt-4 tracking-wide">
            {mode === 'entry'
              ? isRtl
                ? 'بەخێربێیت بۆ شەترەنجی شاهانە'
                : 'WELCOME TO CHESS ROYAL'
              : mode === 'register'
              ? isRtl
                ? 'دروستکردنی هەژمار'
                : 'Create Account'
              : mode === 'upgrade'
              ? isRtl
                ? 'نوێکردنەوەی هەژماری میوان'
                : 'Upgrade Guest Account'
              : mode === 'forgot'
              ? isRtl
                ? 'سەرڕاستکردنەوەی پاسۆرد'
                : 'Reset Password'
              : isRtl
              ? 'چوونەژوورەوە بۆ هەژمار'
              : 'Login to Account'}
          </h2>
          <p className="text-xs text-purple-200/70 mt-1 max-w-xs">
            {mode === 'entry'
              ? isRtl
                ? 'جۆری چوونەژوورەوە هەڵبژێرە بۆ بەردەوامبوون'
                : 'Select an option to enter the royal arena'
              : mode === 'upgrade'
              ? isRtl
                ? 'ئیمەیڵ و پاسۆردت بنووسە بۆ پاراستنی هەمیشەیی پلە و دراوەکانت'
                : 'Add email & password to save all your guest progress forever'
              : mode === 'register'
              ? isRtl
                ? 'زانیارییەکانت بنووسە بۆ تۆمارکردنی هەژماری ڕاستەقینە'
                : 'Register your details for official leaderboard ranking'
              : isRtl
              ? 'بچۆ ژوورەوە بۆ گەیشتن بە زانیارییەکانت'
              : 'Sign in with your credentials'}
          </p>
        </div>

        {/* Content Views */}
        <AnimatePresence mode="wait">
          {mode === 'entry' ? (
            <motion.div
              key="entry"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative z-10 flex flex-col gap-3 my-4 w-full"
            >
              {/* GOOGLE OAUTH BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-4 rounded-2xl bg-white hover:bg-slate-100 border-2 border-slate-200 text-slate-800 font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(255,255,255,0.2)] flex items-center justify-center gap-3 cursor-pointer transition-colors"
              >
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>{isRtl ? 'بەردەوامبە لەگەڵ Google' : 'CONTINUE WITH GOOGLE'}</span>
              </motion.button>

              {/* LOGIN WITH EMAIL BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  soundManager.playClick();
                  setMode('login');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-2 border-yellow-200 text-amber-950 font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(234,179,8,0.4)] flex items-center justify-center gap-3 cursor-pointer"
              >
                <LogIn className="w-5 h-5" />
                <span>{isRtl ? 'چوونەژوورەوە بە ئیمەیڵ' : 'LOGIN WITH EMAIL'}</span>
              </motion.button>

              {/* CREATE ACCOUNT BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  soundManager.playClick();
                  setMode('register');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-600 border-2 border-emerald-300 text-white font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(16,185,129,0.35)] flex items-center justify-center gap-3 cursor-pointer"
              >
                <UserPlus className="w-5 h-5 text-emerald-100" />
                <span>{isRtl ? 'دروستکردنی هەژمار' : 'CREATE ACCOUNT'}</span>
              </motion.button>

              {/* GUEST BUTTON */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleGuest}
                disabled={isLoading}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-800 border-2 border-blue-400/80 text-white font-black text-sm sm:text-base tracking-wider uppercase shadow-[0_8px_25px_rgba(37,99,235,0.35)] cursor-pointer flex items-center justify-center gap-3"
              >
                {isLoading ? (
                  <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Shield className="w-5 h-5 text-blue-200" />
                    <span>{isRtl ? 'یاری وەک میوان (GUEST)' : 'CONTINUE AS GUEST'}</span>
                  </>
                )}
              </motion.button>

              {isCurrentGuest && (
                <button
                  onClick={() => {
                    soundManager.playClick();
                    setMode('upgrade');
                    setErrorMessage('');
                    setSuccessMessage('');
                  }}
                  className="mt-2 text-xs font-bold text-amber-300 hover:underline text-center flex items-center justify-center gap-1.5"
                >
                  <Crown className="w-4 h-4 text-amber-400" />
                  <span>{isRtl ? 'گەشەپێدانی هەژماری میوانی لەسەر هەمان پرۆفایل' : 'Upgrade Guest Account to Permanent'}</span>
                </button>
              )}
            </motion.div>
          ) : (
            <motion.form
              key={mode}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleLoginSubmit}
              className="relative z-10 flex flex-col gap-3 my-2 w-full"
            >
              {errorMessage && (
                <div className="bg-red-500/15 border border-red-500/50 text-red-300 text-xs p-3 rounded-2xl flex items-start gap-2.5 shadow-md">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                  <span className="leading-tight">{errorMessage}</span>
                </div>
              )}

              {successMessage && (
                <div className="bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 text-xs p-3 rounded-2xl flex items-start gap-2.5 shadow-md">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                  <span className="leading-tight">{successMessage}</span>
                </div>
              )}

              {(mode === 'register' || mode === 'upgrade') && (
                <div className="relative flex items-center">
                  <User className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} w-4 h-4 text-purple-300/60 pointer-events-none`} />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder={isRtl ? 'ناوی بەکارهێنەر (Username)' : 'Username'}
                    className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3 ${
                      isRtl ? 'pr-10 pl-4' : 'pl-10 pr-4'
                    } text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                  />
                </div>
              )}

              <div className="relative flex items-center">
                <Mail className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} w-4 h-4 text-purple-300/60 pointer-events-none`} />
                <input
                  type="text"
                  required
                  value={emailOrUser}
                  onChange={(e) => setEmailOrUser(e.target.value)}
                  placeholder={
                    mode === 'forgot'
                      ? isRtl
                        ? 'ئیمەیڵەکەت'
                        : 'Your Email address'
                      : mode === 'upgrade' || mode === 'register'
                      ? isRtl
                        ? 'ئیمەیڵ (Email Address)'
                        : 'Email Address'
                      : isRtl
                      ? 'ئیمەیڵ یاخود ناوی بەکارهێنەر'
                      : 'Email or Username'
                  }
                  className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3 ${
                    isRtl ? 'pr-10 pl-4' : 'pl-10 pr-4'
                  } text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                />
              </div>

              {mode !== 'forgot' && (
                <div className="relative flex items-center">
                  <Lock className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} w-4 h-4 text-purple-300/60 pointer-events-none`} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={isRtl ? 'وشەی نهێنی (پاسۆرد)' : 'Password'}
                    className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3 ${
                      isRtl ? 'pr-10 pl-10' : 'pl-10 pr-10'
                    } text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute ${isRtl ? 'left-3.5' : 'right-3.5'} text-purple-300/60 hover:text-white transition`}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              )}

              {(mode === 'register' || mode === 'upgrade') && (
                <div className="relative flex items-center">
                  <Lock className={`absolute ${isRtl ? 'right-3.5' : 'left-3.5'} w-4 h-4 text-purple-300/60 pointer-events-none`} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder={isRtl ? 'دووبارەکردنەوەی پاسۆرد' : 'Confirm Password'}
                    className={`w-full bg-[#130626]/90 border border-purple-500/40 rounded-2xl py-3 ${
                      isRtl ? 'pr-10 pl-10' : 'pl-10 pr-10'
                    } text-sm text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-500/30 transition shadow-inner`}
                  />
                </div>
              )}

              {mode === 'login' && (
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      soundManager.playClick();
                      setMode('forgot');
                      setErrorMessage('');
                      setSuccessMessage('');
                    }}
                    className="text-xs text-purple-300/80 hover:text-amber-300 transition font-medium"
                  >
                    {isRtl ? 'وشەی نهێنیت لەبیرچووە؟' : 'Forgot Password?'}
                  </button>
                </div>
              )}

              {/* Submit Golden Button */}
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                disabled={isLoading}
                className="w-full mt-2 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-2 border-yellow-200 text-amber-950 font-black text-sm sm:text-base tracking-widest uppercase shadow-[0_8px_25px_rgba(234,179,8,0.4)] flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition"
              >
                {isLoading ? (
                  <span className="w-5 h-5 border-2 border-amber-950 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <span>
                    {mode === 'register'
                      ? isRtl
                        ? 'تۆمارکردنی هەژمار'
                        : 'CREATE ACCOUNT'
                      : mode === 'upgrade'
                      ? isRtl
                        ? 'گەشەپێدانی هەژمار'
                        : 'UPGRADE ACCOUNT'
                      : mode === 'forgot'
                      ? isRtl
                        ? 'ناردنی لینک'
                        : 'SEND RESET LINK'
                      : isRtl
                      ? 'چوونەژوورەوە'
                      : 'SIGN IN'}
                  </span>
                )}
              </motion.button>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Footer Navigation */}
        <div className="relative z-10 pt-3 border-t border-purple-900/50 mt-3 text-center text-xs text-purple-300/70 flex items-center justify-between">
          <button
            onClick={() => {
              soundManager.playClick();
              setMode('entry');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className="text-purple-300/80 hover:text-white transition flex items-center gap-1"
          >
            ← {isRtl ? 'گەڕانەوە' : 'Back'}
          </button>

          {mode === 'login' && (
            <button
              onClick={() => {
                soundManager.playClick();
                setMode('register');
                setErrorMessage('');
                setSuccessMessage('');
              }}
              className="text-amber-300 font-bold hover:underline"
            >
              {isRtl ? 'دروستکردنی هەژمار' : 'Create Account'}
            </button>
          )}

          {mode === 'register' && (
            <button
              onClick={() => {
                soundManager.playClick();
                setMode('login');
                setErrorMessage('');
                setSuccessMessage('');
              }}
              className="text-amber-300 font-bold hover:underline"
            >
              {isRtl ? 'چوونەژوورەوە' : 'Sign In'}
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};
