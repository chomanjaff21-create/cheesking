import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Trophy, Coins, Gem, RotateCcw, Home } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';

interface GameResultModalProps {
  isOpen: boolean;
  isVictory: boolean;
  isDraw?: boolean;
  rewardCoins?: number;
  earnedXp?: number;
  newLevel?: number;
  ratingBefore?: number;
  ratingAfter?: number;
  onPlayAgain: () => void;
  onMainMenu: () => void;
  language: Language;
  userProfile?: UserProfile;
}

export const GameResultModal: React.FC<GameResultModalProps> = ({
  isOpen,
  isVictory,
  isDraw,
  rewardCoins,
  earnedXp,
  newLevel,
  ratingBefore,
  ratingAfter,
  onPlayAgain,
  onMainMenu,
  language,
  userProfile,
}) => {
  useEffect(() => {
    if (isOpen && isVictory && !isDraw) {
      soundManager.playVictory();
      
      // Multi-stage golden victory fireworks confetti cannons
      const end = Date.now() + 2500;
      const colors = ['#ffd700', '#f59e0b', '#38bdf8', '#c084fc', '#ffffff'];

      (function frame() {
        confetti({
          particleCount: 4,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: colors,
        });
        confetti({
          particleCount: 4,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: colors,
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      })();
    }
  }, [isOpen, isVictory]);

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.8, opacity: 0, y: 30 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.8, opacity: 0, y: 30 }}
          className={`relative w-full max-w-sm rounded-3xl p-6 shadow-[0_0_60px_rgba(0,0,0,0.9)] text-amber-100 flex flex-col items-center text-center overflow-hidden border-2 ${
            isDraw
              ? 'bg-gradient-to-b from-[#1c1a24] via-[#100e17] to-[#08070c] border-amber-500/70 shadow-[0_0_50px_rgba(245,158,11,0.3)]'
              : isVictory
              ? 'bg-gradient-to-b from-[#2b1c03] via-[#1a0e02] to-[#0d0701] border-yellow-500/90 shadow-[0_0_50px_rgba(234,179,8,0.4)]'
              : 'bg-gradient-to-b from-[#2b0805] via-[#1a0302] to-[#0c0101] border-red-600/90 shadow-[0_0_50px_rgba(239,68,68,0.4)]'
          } ${isRtl ? 'rtl' : 'ltr'}`}
        >
          {/* Background Sparks / Radial Glow */}
          <div
            className={`absolute inset-0 opacity-25 pointer-events-none ${
              isDraw
                ? 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-400 via-purple-900 to-transparent'
                : isVictory
                ? 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-yellow-300 via-amber-600 to-transparent'
                : 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-red-500 via-rose-900 to-transparent'
            }`}
          />

          {/* Title Header */}
          <div className="relative z-10 mb-2">
            <h1
              className={`text-3xl sm:text-4xl font-black tracking-wider filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)] ${
                isDraw
                  ? 'text-transparent bg-clip-text bg-gradient-to-b from-amber-100 via-amber-300 to-yellow-500'
                  : isVictory
                  ? 'text-transparent bg-clip-text bg-gradient-to-b from-yellow-100 via-yellow-300 to-amber-500'
                  : 'text-transparent bg-clip-text bg-gradient-to-b from-red-200 via-red-500 to-rose-700'
              }`}
            >
              {isDraw
                ? language === 'ku'
                  ? 'یەکسانبوون!'
                  : 'DRAW!'
                : isVictory
                ? language === 'ku'
                  ? 'سەرکەوتن!'
                  : 'VICTORY!'
                : language === 'ku'
                ? 'دۆڕاندن'
                : 'DEFEAT'}
            </h1>
          </div>

          {/* 3D Artwork Graphic (Victory Golden King vs Defeat Fallen Dark King - Image 3 & 4) */}
          <div className="relative z-10 my-3 w-full h-40 flex items-center justify-center">
            {isVictory ? (
              <div className="relative flex flex-col items-center justify-center">
                {/* Golden King with Trumpets */}
                <motion.div
                  animate={{ scale: [1, 1.05, 1], y: [0, -4, 0] }}
                  transition={{ repeat: Infinity, duration: 2.5, ease: 'easeInOut' }}
                  className="text-7xl filter drop-shadow-[0_8px_16px_rgba(234,179,8,0.6)] text-yellow-300"
                >
                  ♔
                </motion.div>
                <div className="absolute -left-10 text-3xl opacity-80 animate-pulse">🎺</div>
                <div className="absolute -right-10 text-3xl opacity-80 animate-pulse">🎺</div>
              </div>
            ) : (
              <div className="relative flex flex-col items-center justify-center">
                {/* Fallen Dark King Piece */}
                <motion.div
                  animate={{ rotate: [0, 45, 45] }}
                  transition={{ duration: 0.5 }}
                  className="text-7xl filter drop-shadow-[0_8px_16px_rgba(239,68,68,0.8)] text-slate-900 transform rotate-45"
                  style={{ textShadow: '0 0 10px rgba(220, 38, 38, 0.8)' }}
                >
                  ♚
                </motion.div>
                <div className="absolute bottom-0 text-xl text-red-500 font-mono animate-bounce">
                  🔥 🔥
                </div>
              </div>
            )}
          </div>

          {/* Player Rating & Trophies Card (Exact Image 3/4) */}
          <div className="relative z-10 w-full bg-amber-950/70 border border-amber-600/60 rounded-2xl p-3 my-2 flex items-center justify-between backdrop-blur-md">
            <div className="flex items-center gap-2.5">
              <img
                src={
                  userProfile?.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'
                }
                className="w-11 h-11 rounded-full border-2 border-yellow-400 object-cover shadow"
                alt="Player Avatar"
                referrerPolicy="no-referrer"
              />
              <div className="text-left rtl:text-right">
                <div className="text-sm font-extrabold text-amber-100">
                  {userProfile?.name || 'Player'}
                </div>
                <div className="text-xs text-amber-400/80 font-mono">
                  {ratingBefore !== undefined && ratingAfter !== undefined ? `${ratingBefore} → ${ratingAfter}` : String(userProfile?.rating ?? '')}
                </div>
              </div>
            </div>

            {/* Trophy Badge */}
            <div
              className={`flex items-center gap-1 font-mono font-black text-sm px-3 py-1 rounded-xl border ${
                isDraw
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400/60'
                  : isVictory
                  ? 'bg-yellow-500/20 text-yellow-300 border-yellow-400/60'
                  : 'bg-red-500/20 text-red-300 border-red-400/60'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>{ratingBefore !== undefined && ratingAfter !== undefined ? ((ratingAfter - ratingBefore) > 0 ? `+${ratingAfter - ratingBefore}` : ((ratingAfter - ratingBefore) < 0 ? `${ratingAfter - ratingBefore}` : '±0')) : '±0'}</span>
            </div>
          </div>

          {/* Rewards Card (Exact Image 3 & 4) */}
          <div className="relative z-10 w-full bg-slate-950/80 border border-amber-600/40 rounded-2xl p-2.5 my-1.5 flex flex-col items-center">
            <span className="text-[11px] font-bold text-amber-300/80 uppercase tracking-widest mb-1">
              {language === 'ku' ? 'خەڵاتەکان' : 'Rewards'}
            </span>
            
            <div className="flex items-center justify-center gap-6">
              <div className="flex items-center gap-1.5 text-yellow-300 font-mono font-black text-base">
                <Coins className="w-5 h-5 text-yellow-400" />
                <span className={!isVictory && !isDraw ? 'text-red-400' : ''}>
                  {rewardCoins !== undefined
                    ? isDraw
                      ? `+${rewardCoins.toLocaleString()}` // Refund
                      : isVictory
                      ? `+${rewardCoins.toLocaleString()}`
                      : `-${rewardCoins.toLocaleString()}` // Loss
                    : isVictory
                    ? '+50'
                    : '-50'}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-cyan-300 font-mono font-black text-base">
                <Gem className="w-5 h-5 text-cyan-400" />
                <span>{earnedXp !== undefined ? `+${earnedXp} XP` : (isDraw ? '+15 XP' : isVictory ? '+35 XP' : '+0 XP')}</span>
              </div>
              {newLevel !== undefined && newLevel > (userProfile?.level || 1) && (
                <div className="flex items-center gap-1.5 text-purple-300 font-mono font-black text-base animate-pulse">
                  <span>Level Up! {newLevel}</span>
                </div>
              )}
            </div>
          </div>

          {/* Buttons Row */}
          <div className="relative z-10 w-full flex items-center gap-2 mt-4">
            <button
              onClick={() => {
                soundManager.playClick();
                onMainMenu();
              }}
              className="p-3 rounded-2xl bg-amber-950/80 hover:bg-amber-900 border border-amber-600/60 text-amber-200 transition cursor-pointer"
            >
              <Home className="w-5 h-5" />
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                onPlayAgain();
              }}
              className="flex-1 py-3 rounded-2xl bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 text-amber-950 font-black text-sm border border-yellow-200 shadow-xl hover:brightness-110 active:scale-95 transition cursor-pointer flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{language === 'ku' ? 'دووبارە یاری بکەرەوە' : 'Play Again'}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
