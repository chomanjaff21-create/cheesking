import React from 'react';
import { Move } from 'chess.js';

// ============================================================================
// NEO VECTOR CHESS PIECES (Exact visual clone of IMG_5008.png)
// ============================================================================

export const VectorPawn: React.FC<{ color: 'w' | 'b' }> = ({ color }) => {
  const isWhite = color === 'w';
  const id = isWhite ? 'wp' : 'bp';
  const stroke = isWhite ? '#222222' : '#141413';

  return (
    <svg viewBox="0 0 45 45" className="w-full h-full drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] select-none pointer-events-none">
      <defs>
        <linearGradient id={`${id}-grad`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isWhite ? '#ffffff' : '#4a4947'} />
          <stop offset="60%" stopColor={isWhite ? '#f8f9fa' : '#333230'} />
          <stop offset="100%" stopColor={isWhite ? '#e2e5e8' : '#222120'} />
        </linearGradient>
      </defs>
      {/* Base */}
      <path
        d="M 12 39.5 L 33 39.5 C 33 37 31 36 29.5 35.5 L 15.5 35.5 C 14 36 12 37 12 39.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Body */}
      <path
        d="M 15.5 35.5 C 15.5 30 18.5 24 19.5 19.5 L 25.5 19.5 C 26.5 24 29.5 30 29.5 35.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Collar Ring */}
      <path
        d="M 17 19.5 C 17 18 20 17 22.5 17 C 25 17 28 18 28 19.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Head */}
      <circle
        cx="22.5"
        cy="11.5"
        r="6"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
      />
      {/* Tactile Highlight */}
      {!isWhite ? (
        <path
          d="M 18.5 9 C 19.5 7.5 21.5 7 23.5 7.2"
          stroke="#73726f"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
        />
      ) : (
        <path
          d="M 19 9 C 20 8 21.5 7.5 23 7.6"
          stroke="#ffffff"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
        />
      )}
    </svg>
  );
};

export const VectorRook: React.FC<{ color: 'w' | 'b' }> = ({ color }) => {
  const isWhite = color === 'w';
  const id = isWhite ? 'wr' : 'br';
  const stroke = isWhite ? '#222222' : '#141413';

  return (
    <svg viewBox="0 0 45 45" className="w-full h-full drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] select-none pointer-events-none">
      <defs>
        <linearGradient id={`${id}-grad`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isWhite ? '#ffffff' : '#4a4947'} />
          <stop offset="60%" stopColor={isWhite ? '#f8f9fa' : '#333230'} />
          <stop offset="100%" stopColor={isWhite ? '#e2e5e8' : '#222120'} />
        </linearGradient>
      </defs>
      {/* Base */}
      <path
        d="M 10 39.5 L 35 39.5 L 35 36.5 L 10 36.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M 12 36.5 L 33 36.5 L 32 33 L 13 33 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Tower Stem */}
      <path
        d="M 13 33 L 15 19 L 30 19 L 32 33 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Battlements Rim */}
      <path
        d="M 12 19 L 33 19 L 33 15 L 12 15 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Crenellations (3 Battlements) */}
      <path
        d="M 12 15 L 12 9 L 16.5 9 L 16.5 12 L 20.5 12 L 20.5 9 L 24.5 9 L 24.5 12 L 28.5 12 L 28.5 9 L 33 9 L 33 15 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Decorative groove lines */}
      <line x1="14" y1="31" x2="31" y2="31" stroke={stroke} strokeWidth="1.2" />
      <line x1="14" y1="22" x2="31" y2="22" stroke={stroke} strokeWidth="1.2" />
      {!isWhite && (
        <path
          d="M 13.5 10.5 L 13.5 14.5 M 14 16 L 31 16"
          stroke="#73726f"
          strokeWidth="1.0"
          strokeLinecap="round"
        />
      )}
    </svg>
  );
};

export const VectorKnight: React.FC<{ color: 'w' | 'b' }> = ({ color }) => {
  const isWhite = color === 'w';
  const id = isWhite ? 'wn' : 'bn';
  const stroke = isWhite ? '#222222' : '#141413';

  return (
    <svg viewBox="0 0 45 45" className="w-full h-full drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] select-none pointer-events-none">
      <defs>
        <linearGradient id={`${id}-grad`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isWhite ? '#ffffff' : '#4a4947'} />
          <stop offset="60%" stopColor={isWhite ? '#f8f9fa' : '#333230'} />
          <stop offset="100%" stopColor={isWhite ? '#e2e5e8' : '#222120'} />
        </linearGradient>
      </defs>
      {/* Base */}
      <path
        d="M 10 39.5 L 35 39.5 C 35 37 32 35.5 30 35 L 14.5 35 C 12.5 35.5 10 37 10 39.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Horse Head Profile */}
      <path
        d="M 14.5 35 C 14.5 32 13 29 11.5 27 C 9.5 24 10 21 14 20 C 13.5 18 14.5 16 17 14 C 18 12.5 20.5 9 22 8 C 22.5 8 23 9 22.5 10.5 C 24 9.5 26.5 9.5 28 11.5 C 29.5 13.5 30.5 16.5 31.5 21 C 32.5 25.5 33 30 30 35 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Eye */}
      <circle cx="17.5" cy="18.5" r="1.5" fill={isWhite ? '#222222' : '#ffffff'} />
      {/* Muzzle Notch */}
      <path
        d="M 11.5 24 C 13.5 23.5 16 23.5 17.5 25"
        stroke={stroke}
        strokeWidth="1.4"
        strokeLinecap="round"
        fill="none"
      />
      {/* Mane Lines */}
      <path
        d="M 24 13 C 25.5 17 26.5 22 26 27"
        stroke={stroke}
        strokeWidth="1.3"
        strokeLinecap="round"
        fill="none"
      />
      {!isWhite && (
        <path
          d="M 19 11 C 21 9.5 24 10 26 12 C 27.5 14 28.5 17 29.5 22"
          stroke="#73726f"
          strokeWidth="1.1"
          strokeLinecap="round"
          fill="none"
        />
      )}
    </svg>
  );
};

export const VectorBishop: React.FC<{ color: 'w' | 'b' }> = ({ color }) => {
  const isWhite = color === 'w';
  const id = isWhite ? 'wb' : 'bb';
  const stroke = isWhite ? '#222222' : '#141413';

  return (
    <svg viewBox="0 0 45 45" className="w-full h-full drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] select-none pointer-events-none">
      <defs>
        <linearGradient id={`${id}-grad`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isWhite ? '#ffffff' : '#4a4947'} />
          <stop offset="60%" stopColor={isWhite ? '#f8f9fa' : '#333230'} />
          <stop offset="100%" stopColor={isWhite ? '#e2e5e8' : '#222120'} />
        </linearGradient>
      </defs>
      {/* Base */}
      <path
        d="M 11 39.5 L 34 39.5 C 34 37 31 36 29 35.5 L 16 35.5 C 14 36 11 37 11 39.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Pedestal collar */}
      <path
        d="M 14.5 35.5 L 16 31 L 29 31 L 30.5 35.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Mitre body */}
      <path
        d="M 16 31 C 13.5 26 13 18 22.5 12 C 32 18 31.5 26 29 31 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Mitre cut (diagonal slash) */}
      <path
        d="M 18.5 17.5 L 23.5 22.5"
        stroke={stroke}
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      {/* Finial Ball */}
      <circle
        cx="22.5"
        cy="9.5"
        r="2.5"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
      />
      {/* Horizontal band */}
      <path
        d="M 16 26.5 C 19 28 26 28 29 26.5"
        stroke={stroke}
        strokeWidth="1.4"
        fill="none"
      />
      {!isWhite && (
        <path
          d="M 16 20 C 17.5 16 20 13.5 22 13"
          stroke="#73726f"
          strokeWidth="1.1"
          strokeLinecap="round"
          fill="none"
        />
      )}
    </svg>
  );
};

export const VectorQueen: React.FC<{ color: 'w' | 'b' }> = ({ color }) => {
  const isWhite = color === 'w';
  const id = isWhite ? 'wq' : 'bq';
  const stroke = isWhite ? '#222222' : '#141413';

  return (
    <svg viewBox="0 0 45 45" className="w-full h-full drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] select-none pointer-events-none">
      <defs>
        <linearGradient id={`${id}-grad`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isWhite ? '#ffffff' : '#4a4947'} />
          <stop offset="60%" stopColor={isWhite ? '#f8f9fa' : '#333230'} />
          <stop offset="100%" stopColor={isWhite ? '#e2e5e8' : '#222120'} />
        </linearGradient>
      </defs>
      {/* Base */}
      <path
        d="M 10 39.5 L 35 39.5 C 35 37 32 35.5 29.5 35 L 15.5 35 C 13 35.5 10 37 10 39.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Lower Waist */}
      <path
        d="M 14.5 35 L 16 29 L 29 29 L 30.5 35 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* 5-point Tiara */}
      <path
        d="M 16 29 L 10.5 15 L 17 22 L 22.5 11 L 28 22 L 34.5 15 L 29 29 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* 5 Crown Pearls */}
      <circle cx="10.5" cy="14" r="1.8" fill={`url(#${id}-grad)`} stroke={stroke} strokeWidth="1.4" />
      <circle cx="17" cy="20.5" r="1.6" fill={`url(#${id}-grad)`} stroke={stroke} strokeWidth="1.4" />
      <circle cx="22.5" cy="10" r="2.0" fill={`url(#${id}-grad)`} stroke={stroke} strokeWidth="1.4" />
      <circle cx="28" cy="20.5" r="1.6" fill={`url(#${id}-grad)`} stroke={stroke} strokeWidth="1.4" />
      <circle cx="34.5" cy="14" r="1.8" fill={`url(#${id}-grad)`} stroke={stroke} strokeWidth="1.4" />
      {/* Accent headband curve */}
      <path
        d="M 16 31 C 19.5 33 25.5 33 29 31"
        stroke={stroke}
        strokeWidth="1.4"
        fill="none"
      />
    </svg>
  );
};

export const VectorKing: React.FC<{ color: 'w' | 'b' }> = ({ color }) => {
  const isWhite = color === 'w';
  const id = isWhite ? 'wk' : 'bk';
  const stroke = isWhite ? '#222222' : '#141413';

  return (
    <svg viewBox="0 0 45 45" className="w-full h-full drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] select-none pointer-events-none">
      <defs>
        <linearGradient id={`${id}-grad`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isWhite ? '#ffffff' : '#4a4947'} />
          <stop offset="60%" stopColor={isWhite ? '#f8f9fa' : '#333230'} />
          <stop offset="100%" stopColor={isWhite ? '#e2e5e8' : '#222120'} />
        </linearGradient>
      </defs>
      {/* Base */}
      <path
        d="M 10 39.5 L 35 39.5 C 35 37 32 35.5 29.5 35 L 15.5 35 C 13 35.5 10 37 10 39.5 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Pedestal */}
      <path
        d="M 14.5 35 L 15.5 30 L 29.5 30 L 30.5 35 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Crown Body */}
      <path
        d="M 15.5 30 C 13 24 13.5 17 22.5 15 C 31.5 17 32 24 29.5 30 Z"
        fill={`url(#${id}-grad)`}
        stroke={stroke}
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Cross Finial */}
      <path
        d="M 22.5 6 L 22.5 15 M 19 9.5 L 26 9.5"
        stroke={stroke}
        strokeWidth="2.2"
        strokeLinecap="square"
      />
      {/* Inner Crown Arches */}
      <path
        d="M 16 24 C 18 21 21 19 22.5 19 C 24 19 27 21 29 24"
        stroke={stroke}
        strokeWidth="1.4"
        fill="none"
      />
      <path
        d="M 15.5 30 C 18.5 31.5 26.5 31.5 29.5 30"
        stroke={stroke}
        strokeWidth="1.4"
        fill="none"
      />
      {!isWhite && (
        <path
          d="M 16.5 19 C 18 17 20 16 22 16"
          stroke="#73726f"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
        />
      )}
    </svg>
  );
};

// Helper renderer for any chess piece
export const RenderChessPiece: React.FC<{ type: string; color: 'w' | 'b' }> = ({ type, color }) => {
  const t = type.toLowerCase();
  if (t === 'p') return <VectorPawn color={color} />;
  if (t === 'r') return <VectorRook color={color} />;
  if (t === 'n') return <VectorKnight color={color} />;
  if (t === 'b') return <VectorBishop color={color} />;
  if (t === 'q') return <VectorQueen color={color} />;
  if (t === 'k') return <VectorKing color={color} />;
  return null;
};

// ============================================================================
// MAIN 2D CHESS BOARD COMPONENT (Pixel-Perfect Match with IMG_5008.png)
// ============================================================================

export interface Chess2DBoardProps {
  board: ({ type: string; color: 'w' | 'b' } | null)[][];
  selectedSquare: string | null;
  validMoves: Move[];
  lastMove: Move | null;
  isCheck: boolean;
  turn: 'w' | 'b';
  onSquareClick: (square: string) => void;
  isFlipped?: boolean;
  themeStyle?: 'classic' | 'purple' | 'red' | 'blue' | 'green' | 'gold' | 'dark' | 'wood';
  capturedWhite?: string[];
  capturedBlack?: string[];
}

const pieceOrderMap: Record<string, number> = {
  p: 1,
  n: 2,
  b: 3,
  r: 4,
  q: 5,
  k: 6,
};

const pieceValueMap: Record<string, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
};

const SleekCapturedBar: React.FC<{
  titleKu: string;
  pieces: { type: string; color: 'w' | 'b' }[];
  materialAdvantage?: number;
}> = ({ titleKu, pieces, materialAdvantage = 0 }) => {
  if (pieces.length === 0 && materialAdvantage === 0) return null;

  return (
    <div className="w-full max-w-[min(94vw,560px)] px-3 py-1 my-0.5 rounded-lg bg-black/60 border border-white/10 backdrop-blur-md flex items-center justify-between gap-2 overflow-hidden select-none">
      <div className="flex items-center gap-2 shrink-0">
        <span className="text-[11px] font-semibold text-slate-400">
          {titleKu}
        </span>
        {materialAdvantage > 0 && (
          <span className="px-1.5 py-0.2 rounded bg-sky-500/20 border border-sky-400/40 text-sky-300 text-[10px] font-bold">
            +{materialAdvantage}
          </span>
        )}
      </div>

      <div className="flex items-center gap-1 overflow-x-auto py-0.5 no-scrollbar">
        {pieces.map((piece, idx) => (
          <div
            key={idx}
            className="w-5 h-5 sm:w-6 sm:h-6 flex items-center justify-center shrink-0 opacity-90 hover:opacity-100 transition-opacity"
          >
            <RenderChessPiece type={piece.type} color={piece.color} />
          </div>
        ))}
      </div>
    </div>
  );
};

export const Chess2DBoard: React.FC<Chess2DBoardProps> = ({
  board,
  selectedSquare,
  validMoves,
  lastMove,
  isCheck,
  turn,
  onSquareClick,
  isFlipped = false,
  themeStyle = 'classic',
  capturedWhite = [],
  capturedBlack = [],
}) => {
  const validSquareNames = new Set(validMoves.map((m) => m.to));

  // Sort captured pieces
  const sortedWhiteCaptured = [...capturedWhite]
    .map((p) => p.toLowerCase())
    .sort((a, b) => (pieceOrderMap[a] || 99) - (pieceOrderMap[b] || 99));

  const sortedBlackCaptured = [...capturedBlack]
    .map((p) => p.toLowerCase())
    .sort((a, b) => (pieceOrderMap[a] || 99) - (pieceOrderMap[b] || 99));

  const whiteVal = sortedWhiteCaptured.reduce((sum, p) => sum + (pieceValueMap[p] || 0), 0);
  const blackVal = sortedBlackCaptured.reduce((sum, p) => sum + (pieceValueMap[p] || 0), 0);

  const topPieces = (!isFlipped ? sortedWhiteCaptured : sortedBlackCaptured).map((type) => ({
    type,
    color: (!isFlipped ? 'w' : 'b') as 'w' | 'b',
  }));

  const bottomPieces = (!isFlipped ? sortedBlackCaptured : sortedWhiteCaptured).map((type) => ({
    type,
    color: (!isFlipped ? 'b' : 'w') as 'w' | 'b',
  }));

  const topMaterialAdv = !isFlipped ? whiteVal - blackVal : blackVal - whiteVal;
  const bottomMaterialAdv = !isFlipped ? blackVal - whiteVal : whiteVal - blackVal;

  // Board square colors - Exact clone of IMG_5008.png (Classic Ocean Slate Blue & Cream)
  let lightBgHex = '#ebecd0';  // Warm Ivory Cream
  let darkBgHex = '#4b7399';   // Slate Ocean Blue
  let lastMoveHex = '#00a2ea'; // Vibrant Electric Sky Blue (Exact match for e2 and e4 in IMG_5008.png)
  let selectBgHex = '#1ca3ec'; // Selected square highlight

  if (themeStyle === 'purple') {
    lightBgHex = '#c084fc';
    darkBgHex = '#7e22ce';
    lastMoveHex = '#e879f9';
    selectBgHex = '#f472b6';
  } else if (themeStyle === 'red') {
    lightBgHex = '#fca5a5';
    darkBgHex = '#b91c1c';
    lastMoveHex = '#f87171';
    selectBgHex = '#ef4444';
  } else if (themeStyle === 'green') {
    lightBgHex = '#eeeed2';
    darkBgHex = '#769656';
    lastMoveHex = '#baca44';
    selectBgHex = '#cddc39';
  } else if (themeStyle === 'gold') {
    lightBgHex = '#fef08a';
    darkBgHex = '#b45309';
    lastMoveHex = '#f59e0b';
    selectBgHex = '#fbbf24';
  } else if (themeStyle === 'dark') {
    lightBgHex = '#64748b';
    darkBgHex = '#1e293b';
    lastMoveHex = '#38bdf8';
    selectBgHex = '#0ea5e9';
  }

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-1 sm:p-3 select-none overflow-y-auto">
      {/* Top Player Captured Pieces */}
      <SleekCapturedBar
        titleKu="خوراوەکان"
        pieces={topPieces}
        materialAdvantage={topMaterialAdv}
      />

      {/* Flush Square Chessboard Grid (Exact Match to IMG_5008.png) */}
      <div className="relative w-full max-w-[min(94vw,560px)] aspect-square rounded-sm overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.9)] border border-black/40">
        <div className="w-full h-full grid grid-cols-8 grid-rows-8">
          {Array.from({ length: 8 }).map((_, rIdx) => {
            const actualRow = isFlipped ? 7 - rIdx : rIdx;
            const rankNum = 8 - actualRow;

            return Array.from({ length: 8 }).map((__, cIdx) => {
              const actualCol = isFlipped ? 7 - cIdx : cIdx;
              const fileChar = String.fromCharCode(97 + actualCol);
              const squareName = `${fileChar}${rankNum}`;

              const piece = board[actualRow]?.[actualCol];
              const isLightSquare = (actualRow + actualCol) % 2 === 0;

              const isSelected = selectedSquare === squareName;
              const isValidTarget = validSquareNames.has(squareName);
              const isLastMoveSource = lastMove?.from === squareName;
              const isLastMoveDest = lastMove?.to === squareName;
              const isLastMove = isLastMoveSource || isLastMoveDest;
              const isKingInCheck =
                isCheck && piece?.type.toLowerCase() === 'k' && piece?.color === turn;

              // Color of the square (Last Move takes priority as vibrant azure blue, matching IMG_5008.png)
              let squareBg = isLightSquare ? lightBgHex : darkBgHex;
              if (isSelected) {
                squareBg = selectBgHex;
              } else if (isLastMove) {
                squareBg = lastMoveHex;
              }

              // Corner coordinates inside squares (Chess.com layout in IMG_5008.png):
              // Ranks (1-8): Top-left corner of the leftmost column (cIdx === 0)
              const showRankNotation = cIdx === 0;
              // Files (a-h): Bottom-right corner of the bottom row (rIdx === 7)
              const showFileNotation = rIdx === 7;

              // Text color inverts based on square background
              const rankColor = isLastMove
                ? '#ffffff'
                : isLightSquare
                ? darkBgHex
                : lightBgHex;

              const fileColor = isLastMove
                ? '#ffffff'
                : isLightSquare
                ? darkBgHex
                : lightBgHex;

              return (
                <div
                  key={squareName}
                  onClick={() => onSquareClick(squareName)}
                  style={{ backgroundColor: squareBg }}
                  className="relative w-full h-full flex items-center justify-center cursor-pointer transition-colors duration-100 select-none"
                >
                  {/* Rank Notation (1-8) at Top-Left Corner of leftmost column */}
                  {showRankNotation && (
                    <span
                      style={{ color: rankColor }}
                      className="absolute top-0.5 left-1 text-[10px] sm:text-[12px] font-bold leading-none pointer-events-none z-20 select-none"
                    >
                      {rankNum}
                    </span>
                  )}

                  {/* File Notation (a-h) at Bottom-Right Corner of bottom row */}
                  {showFileNotation && (
                    <span
                      style={{ color: fileColor }}
                      className="absolute bottom-0.5 right-1 text-[10px] sm:text-[12px] font-bold leading-none pointer-events-none z-20 select-none"
                    >
                      {fileChar}
                    </span>
                  )}

                  {/* Selected Square Subtle Inner Glow */}
                  {isSelected && (
                    <div className="absolute inset-0 ring-2 ring-white/60 z-10 pointer-events-none" />
                  )}

                  {/* Check Highlight */}
                  {isKingInCheck && (
                    <div className="absolute inset-0 bg-red-600/60 ring-2 ring-red-400 animate-pulse z-15 pointer-events-none" />
                  )}

                  {/* Valid Move Indicator: Clean Center Dot */}
                  {isValidTarget && !piece && (
                    <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-black/25 z-20 pointer-events-none" />
                  )}

                  {/* Valid Capture Target: Subtle Hollow Ring */}
                  {isValidTarget && piece && (
                    <div className="absolute inset-1 rounded-full border-[3.5px] border-black/25 z-20 pointer-events-none" />
                  )}

                  {/* Render Chess Piece SVG */}
                  {piece && (
                    <div className="w-[88%] h-[88%] z-10 flex items-center justify-center transition-transform duration-100 hover:scale-105 pointer-events-none">
                      <RenderChessPiece type={piece.type} color={piece.color} />
                    </div>
                  )}
                </div>
              );
            });
          })}
        </div>
      </div>

      {/* Bottom Player Captured Pieces */}
      <SleekCapturedBar
        titleKu="خوراوەکان"
        pieces={bottomPieces}
        materialAdvantage={bottomMaterialAdv}
      />
    </div>
  );
};

