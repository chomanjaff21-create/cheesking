import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, Sparkles, X, Lightbulb, ShieldAlert, ArrowRight } from 'lucide-react';
import { Language, AICoachResponse } from '../types';
import { getTranslation } from '../lib/translations';

interface AICoachModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  loading: boolean;
  advice: AICoachResponse | null;
  onRequestAdvice: () => void;
}

export const AICoachModal: React.FC<AICoachModalProps> = ({
  isOpen,
  onClose,
  language,
  loading,
  advice,
  onRequestAdvice,
}) => {
  if (!isOpen) return null;

  const isRtl = language === 'ku';

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className={`w-full max-w-lg bg-gradient-to-b from-amber-950 via-amber-900 to-amber-950 border-2 border-amber-500/70 rounded-3xl p-6 shadow-2xl text-amber-50 relative overflow-hidden ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-amber-700/50 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-gradient-to-br from-yellow-400 to-amber-600 text-amber-950 shadow-lg">
                <Bot className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-amber-200">
                  {getTranslation(language, 'social')}
                </h3>
                <p className="text-xs text-amber-300/80">Gemini Grandmaster AI Coach</p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full bg-amber-900/60 hover:bg-amber-800 text-amber-300 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="space-y-4">
            {loading ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3 text-center">
                <div className="w-10 h-10 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin" />
                <p className="text-sm font-semibold text-amber-200">
                  {getTranslation(language, 'askingGemini')}
                </p>
              </div>
            ) : advice ? (
              <div className="space-y-4">
                {/* Tactical Analysis */}
                <div className="bg-amber-900/50 border border-amber-600/40 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2 text-yellow-300 font-bold text-sm">
                    <Sparkles className="w-4 h-4" />
                    <span>کۆمێنتی تاکتیکی</span>
                  </div>
                  <p className="text-sm text-amber-100 leading-relaxed">
                    {language === 'ku' ? advice.analysisKu : advice.analysisEn}
                  </p>
                </div>

                {/* Suggested Move */}
                {advice.suggestedMoveSan && (
                  <div className="bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-yellow-400/50 rounded-2xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-yellow-200 font-bold text-sm">
                      <ArrowRight className="w-5 h-5 text-yellow-400" />
                      <span>پێشنیاری جووڵە:</span>
                    </div>
                    <span className="text-lg font-black font-mono text-yellow-300 bg-amber-950 px-3 py-1 rounded-xl border border-yellow-400/50">
                      {advice.suggestedMoveSan}
                    </span>
                  </div>
                )}

                {/* Tactical Tip */}
                <div className="bg-amber-900/50 border border-amber-600/40 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                    <Lightbulb className="w-4 h-4 text-yellow-400" />
                    <span>ئامۆژگاری بۆ داهاتوو</span>
                  </div>
                  <p className="text-sm text-amber-200/90 leading-relaxed">
                    {language === 'ku' ? advice.tacticalTipKu : advice.tacticalTipEn}
                  </p>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center space-y-3">
                <ShieldAlert className="w-12 h-12 text-yellow-400 mx-auto opacity-80" />
                <p className="text-sm text-amber-200">
                  داوای شیکاری لە ڕاهێنەر بکە بۆ وەدەستخستنی پێشنیاری جووڵەی داهاتوو!
                </p>
              </div>
            )}

            <button
              onClick={onRequestAdvice}
              disabled={loading}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-amber-950 font-black text-base shadow-xl hover:brightness-110 active:scale-95 transition cursor-pointer disabled:opacity-50"
            >
              {getTranslation(language, 'getAdvice')}
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
