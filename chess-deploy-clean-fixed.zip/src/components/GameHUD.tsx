import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  RotateCcw,
  Sparkles,
  Home,
  Eye,
  Camera,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  MessageSquare,
  X,
  Send,
  RefreshCw,
  Flag,
  AlertTriangle,
} from 'lucide-react';
import { Language, GameMode, AIDifficulty, UserProfile } from '../types';
import { getTranslation } from '../lib/translations';
import { useRealtimeStore } from '../lib/realtime';
import { soundManager } from '../lib/soundManager';
import { LevelCrown } from './LevelCrown';

interface GameHUDProps {
  language: Language;
  gameMode: GameMode;
  aiDifficulty: AIDifficulty;
  turn: 'w' | 'b';
  isCheck: boolean;
  isGameOver: boolean;
  isCheckmate: boolean;
  winner: 'w' | 'b' | 'draw' | null;
  whiteTime: number; // in seconds
  blackTime: number; // in seconds
  capturedWhite: string[]; // captured white pieces
  capturedBlack: string[]; // captured black pieces
  lastMoveSan?: string;
  soundEnabled: boolean;
  userProfile?: UserProfile;
  onOpenProfile?: () => void;
  onToggleSound: () => void;
  onUndo: () => void;
  onResign?: () => void;
  onHint: () => void;
  onAskCoach: () => void;
  onRestart: () => void;
  onMainMenu: () => void;
  cameraPreset: 'perspective' | 'top' | 'black';
  onChangeCamera: (preset: 'perspective' | 'top' | 'black') => void;
  opponentDisconnected?: boolean;
  disconnectCountdown?: number;
  isReconnecting?: boolean;
  isOffline?: boolean;
  onManualReconnect?: () => void;
  onlineMatchId?: string | null;
}

const formatTime = (secs: number) => {
  if (secs <= 0) return '00:00';
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
};

const pieceSymbolMap: Record<string, string> = {
  p: '♟',
  r: '♜',
  n: '♞',
  b: '♝',
  q: '♛',
  k: '♚',
};

const pieceValueMap: Record<string, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
};

const getCapturedSummary = (pieces: string[]) => {
  const counts: Record<string, number> = {};
  let totalValue = 0;
  pieces.forEach((p) => {
    const key = p.toLowerCase();
    counts[key] = (counts[key] || 0) + 1;
    totalValue += pieceValueMap[key] || 0;
  });
  return { counts, totalValue };
};

const quickPhrasesKu = [
  'سڵاو! ♟️',
  'یارییەکی باش! 🏆',
  'دەستت خۆش! 👏',
  'کاتی تۆیە! ⏱️',
  'ببورە! 😅',
  'دووبارە یاری؟ 🔄',
];

const quickPhrasesEn = [
  'Hello! ♟️',
  'Good Game! 🏆',
  'Well Played! 👏',
  'Your Turn! ⏱️',
  'Oops! 😅',
  'Rematch? 🔄',
];

export const GameHUD: React.FC<GameHUDProps> = ({
  language,
  gameMode,
  aiDifficulty,
  turn,
  isCheck,
  isGameOver,
  isCheckmate,
  winner,
  whiteTime,
  blackTime,
  capturedWhite,
  capturedBlack,
  lastMoveSan,
  soundEnabled,
  userProfile,
  onOpenProfile,
  onToggleSound,
  onUndo,
  onResign,
  onHint,
  onAskCoach,
  onRestart,
  onMainMenu,
  cameraPreset,
  onChangeCamera,
  opponentDisconnected = false,
  disconnectCountdown = 40,
  isReconnecting = false,
  isOffline = false,
  onManualReconnect,
  onlineMatchId,
}) => {
  const isRtl = language === 'ku';
  const isOnlineMatch = gameMode === 'online';

  // Mic & In-Game Chat State & Confirmation Modals
  const [isMicOn, setIsMicOn] = useState<boolean>(false);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatMessage, setChatMessage] = useState<string>('');
  const [showStartBanner, setShowStartBanner] = useState<boolean>(true);
  const [showResignConfirm, setShowResignConfirm] = useState<boolean>(false);
  const [showHomeConfirm, setShowHomeConfirm] = useState<boolean>(false);
  const [activeSpeechBubble, setActiveSpeechBubble] = useState<{
    text: string;
    sender: 'user' | 'opponent';
  } | null>(null);

  const [boomPlayer, setBoomPlayer] = useState<'w' | 'b' | null>(null);

  React.useEffect(() => {
    if (blackTime <= 0 && boomPlayer !== 'b') {
      setBoomPlayer('b');
      soundManager.playTimeoutBoom();
    } else if (whiteTime <= 0 && boomPlayer !== 'w') {
      setBoomPlayer('w');
      soundManager.playTimeoutBoom();
    }
  }, [blackTime, whiteTime, boomPlayer]);

  React.useEffect(() => {
    setShowStartBanner(true);
    const timer = setTimeout(() => {
      setShowStartBanner(false);
    }, 2800);
    return () => clearTimeout(timer);
  }, []);

  // Real in-game chat: messages are relayed by the server to the opponent, and the
  // opponent's messages arrive here (before, nothing was ever sent over the network).
  React.useEffect(() => {
    if (!isOnlineMatch || !onlineMatchId) return;
    const sock: any = useRealtimeStore.getState().socket;
    if (!sock) return;
    const prev = sock.onmatchchat;
    sock.onmatchchat = (m: any) => {
      if (m?.matchId !== onlineMatchId || typeof m?.text !== 'string') return;
      soundManager.playClick();
      setActiveSpeechBubble({ text: m.text, sender: 'opponent' });
      setTimeout(() => setActiveSpeechBubble(null), 3500);
    };
    return () => { sock.onmatchchat = prev; };
  }, [isOnlineMatch, onlineMatchId]);

  const handleSendQuickMessage = (msg: string) => {
    soundManager.playClick();
    setActiveSpeechBubble({ text: msg, sender: 'user' });
    setIsChatOpen(false);
    setChatMessage('');
    if (isOnlineMatch && onlineMatchId) {
      try { (useRealtimeStore.getState().socket as any)?.sendMatchChat?.(onlineMatchId, msg); } catch {}
    }

    setTimeout(() => {
      setActiveSpeechBubble(null);
    }, 3500);

    // Simulate AI or opponent reply after 2 seconds
    if (gameMode === 'vs_ai') {
      setTimeout(() => {
        const repliesKu = ['دەستت خۆش! 👏', 'باشە بەڕێزم! ♟️', 'ببینین کێ دەباتەوە! 🔥'];
        const repliesEn = ['Well played! 👏', 'Let us see! ♟️', 'Nice move! 🔥'];
        const choices = language === 'ku' ? repliesKu : repliesEn;
        const randomReply = choices[Math.floor(Math.random() * choices.length)];
        setActiveSpeechBubble({ text: randomReply, sender: 'opponent' });

        setTimeout(() => {
          setActiveSpeechBubble(null);
        }, 3500);
      }, 2000);
    }
  };

  const whiteSummary = getCapturedSummary(capturedBlack);
  const blackSummary = getCapturedSummary(capturedWhite);
  const materialDiff = whiteSummary.totalValue - blackSummary.totalValue;

  return (
    <div
      className={`absolute inset-0 pointer-events-none flex flex-col justify-between pt-[max(env(safe-area-inset-top),0.75rem)] pb-[max(env(safe-area-inset-bottom),0.75rem)] px-[max(env(safe-area-inset-left),0.75rem)] pr-[max(env(safe-area-inset-right),0.75rem)] z-20 overflow-hidden ${
        isRtl ? 'rtl' : 'ltr'
      }`}
    >
      {/* Top Header: Opponent (Black Player) Card & Main Controls */}
      <div className="w-full flex items-center justify-between gap-2 pointer-events-auto">
        {/* Opponent Card (Premium Glass & Dynamic Turn Glow) */}
        <div
          className={`relative bg-slate-950/85 border rounded-2xl px-2.5 py-1.5 sm:px-3 sm:py-2 flex items-center gap-2.5 backdrop-blur-xl transition-all duration-300 shadow-2xl text-amber-100 ${
            turn === 'b'
              ? 'border-yellow-400 ring-2 ring-yellow-400/80 shadow-[0_0_20px_rgba(250,204,21,0.45)]'
              : 'border-amber-600/40 shadow-lg'
          }`}
        >
          <div className="relative">
            <img
              src={
                gameMode === 'vs_ai'
                  ? 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=100&q=80'
                  : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'
              }
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border-2 border-amber-400 object-cover shadow"
              alt="Black Player"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-slate-900 border border-amber-300 flex items-center justify-center text-[9px] font-bold shadow">
              ♚
            </div>
          </div>

          <div className="flex flex-col">
            <div className="text-[11px] sm:text-xs font-black flex items-center gap-1.5 text-amber-200">
              <span className="truncate max-w-[90px] sm:max-w-[120px]">
                {gameMode === 'vs_ai'
                  ? `AI (${aiDifficulty})`
                  : gameMode === 'online'
                  ? 'Opponent'
                  : 'Player 2'}
              </span>
              <LevelCrown level={gameMode === 'vs_ai' ? 12 : 8} size="sm" showLevelNumber={true} />
            </div>

            {gameMode === 'vs_ai' && (
              <div className="flex items-center gap-1 mt-0.5">
                <span className="inline-flex items-center gap-1 text-[8px] sm:text-[9px] font-black bg-gradient-to-r from-amber-500 via-yellow-300 to-amber-500 text-amber-950 px-1.5 py-0.2 rounded border border-yellow-200 shadow-sm font-sans whitespace-nowrap">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                  Gold Servers Full
                </span>
              </div>
            )}

            {/* Timer & Low-Time Warning */}
            <div className="relative flex items-center gap-1.5 mt-1">
              <div
                className={`relative flex items-center gap-1 px-2.5 py-0.5 rounded-lg font-mono font-black text-xs sm:text-sm tracking-wider transition-all duration-300 ${
                  blackTime <= 0
                    ? 'bg-red-950 text-red-400 border border-red-500 shadow-[0_0_20px_rgba(239,68,68,1)] ring-2 ring-red-500'
                    : blackTime <= 10
                    ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white border-2 border-red-300 shadow-[0_0_18px_rgba(239,68,68,1)] animate-bounce'
                    : blackTime <= 30
                    ? 'bg-red-600/90 text-white border border-red-300 shadow-[0_0_12px_rgba(239,68,68,0.9)] animate-pulse'
                    : turn === 'b'
                    ? 'bg-amber-950/90 text-yellow-300 border border-yellow-400/80 shadow-[0_0_10px_rgba(250,204,21,0.5)]'
                    : 'bg-black/80 text-amber-200/90 border border-amber-700/50'
                }`}
              >
                <span>{formatTime(blackTime)}</span>
                {blackTime <= 10 && blackTime > 0 && (
                  <span className="text-[10px] animate-ping">⚠️</span>
                )}
              </div>
              {turn === 'b' && (
                <span className="text-[9px] font-black bg-gradient-to-r from-yellow-400 to-amber-400 text-amber-950 px-1.5 py-0.5 rounded-md shadow animate-pulse">
                  {isRtl ? 'تۆڕ' : 'TURN'}
                </span>
              )}

              {/* BOOM! Timeout Explosion Badge (کات تەواو بوو) */}
              {boomPlayer === 'b' && (
                <motion.div
                  initial={{ scale: 0.2, opacity: 0, rotate: -15 }}
                  animate={{ scale: [0.2, 1.3, 1], opacity: 1, rotate: [0, -5, 5, 0] }}
                  transition={{ duration: 0.4 }}
                  className="absolute -top-6 left-0 z-40 bg-gradient-to-r from-red-600 via-amber-500 to-red-600 border-2 border-yellow-300 text-white font-black text-[10px] sm:text-xs px-2 py-0.5 rounded-full shadow-[0_0_25px_rgba(239,68,68,0.9)] flex items-center gap-1 whitespace-nowrap"
                >
                  <span>💥</span>
                  <span>{isRtl ? 'بووم! کات تەواو بوو!' : 'BOOM! TIME OUT!'}</span>
                </motion.div>
              )}
            </div>

            {/* Captured white pieces summary */}
            {Object.keys(blackSummary.counts).length > 0 && (
              <div className="flex items-center gap-1 text-[10px] text-amber-100/90 mt-1 flex-wrap max-w-[140px] sm:max-w-[180px]">
                {Object.entries(blackSummary.counts).map(([type, count]) => (
                  <span
                    key={type}
                    className="inline-flex items-center gap-0.5 px-1 py-0.2 bg-amber-950/90 border border-amber-600/60 rounded text-[9.5px] font-bold shadow-sm"
                  >
                    <span className="text-amber-200">{pieceSymbolMap[type] || type}</span>
                    {count > 1 && <span className="text-[8.5px] text-yellow-300 font-mono">x{count}</span>}
                  </span>
                ))}
                {materialDiff < 0 && (
                  <span className="text-[9px] font-black text-amber-950 bg-yellow-400 px-1.5 py-0.2 rounded shadow">
                    +{Math.abs(materialDiff)}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Opponent Speech Bubble */}
          <AnimatePresence>
            {activeSpeechBubble && activeSpeechBubble.sender === 'opponent' && (
              <motion.div
                initial={{ scale: 0.5, opacity: 0, y: 10 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.5, opacity: 0 }}
                className="absolute top-12 left-2 bg-gradient-to-r from-yellow-400 to-amber-400 text-amber-950 font-black text-xs px-3 py-1.5 rounded-2xl shadow-2xl border-2 border-yellow-200 z-30 whitespace-nowrap"
              >
                {activeSpeechBubble.text}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action Controls & Camera Presets (Compact Glass Group) */}
        <div className="flex items-center gap-1 sm:gap-1.5 bg-slate-950/85 border border-amber-600/40 rounded-2xl p-1.5 sm:p-2 backdrop-blur-xl shadow-2xl">
          <button
            onClick={() => {
              soundManager.playClick();
              if (isGameOver) {
                onMainMenu();
              } else {
                setShowHomeConfirm(true);
              }
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-950/80 hover:bg-amber-900 border border-amber-600/50 text-amber-200 transition flex items-center justify-center cursor-pointer active:scale-95 shadow"
            title={getTranslation(language, 'mainMenu')}
          >
            <Home className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onToggleSound();
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-950/80 hover:bg-amber-900 border border-amber-600/50 text-amber-200 transition flex items-center justify-center cursor-pointer active:scale-95 shadow"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-yellow-400" />
            ) : (
              <VolumeX className="w-4 h-4 sm:w-4.5 sm:h-4.5 opacity-50" />
            )}
          </button>

          {/* View Preset Toggles (3D / 2D Top) */}
          <div className="h-5 w-px bg-amber-700/50 mx-0.5" />

          <button
            onClick={() => {
              soundManager.playClick();
              onChangeCamera('perspective');
            }}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1 cursor-pointer active:scale-95 shadow ${
              cameraPreset === 'perspective'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 shadow-md ring-1 ring-amber-300'
                : 'bg-amber-950/60 text-amber-200 hover:bg-amber-900 border border-amber-700/30'
            }`}
            title={getTranslation(language, 'cameraPerspective')}
          >
            <Camera className="w-3.5 h-3.5" />
            <span className="hidden xs:inline font-mono">3D</span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onChangeCamera('top');
            }}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1 cursor-pointer active:scale-95 shadow ${
              cameraPreset === 'top'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 shadow-md ring-1 ring-amber-300'
                : 'bg-amber-950/60 text-amber-200 hover:bg-amber-900 border border-amber-700/30'
            }`}
            title={getTranslation(language, 'cameraTopView')}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="font-mono">2D</span>
          </button>
        </div>
      </div>

      {/* Game Start Entrance Banner & Check Banner */}
      <div className="w-full flex flex-col items-center gap-2 pointer-events-none relative">
        <AnimatePresence>
          {showStartBanner && !isGameOver && (
            <motion.div
              initial={{ scale: 0.4, opacity: 0, y: -30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 1.15, opacity: 0, y: -20 }}
              transition={{ type: 'spring', damping: 14, stiffness: 180 }}
              className="bg-gradient-to-r from-slate-950/95 via-amber-950/95 to-slate-950/95 border-2 border-yellow-400 rounded-3xl px-6 py-3 backdrop-blur-xl shadow-[0_0_40px_rgba(250,204,21,0.6)] flex flex-col items-center text-center"
            >
              <div className="text-yellow-400 text-xs font-black tracking-widest uppercase flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
                <span>{isRtl ? '⚔️ ڕکابەرییە پاشایەتییەکە دەستی پێکرد ⚔️' : '⚔️ THE ROYAL BATTLE BEGINS ⚔️'}</span>
                <Sparkles className="w-4 h-4 text-yellow-300 animate-pulse" />
              </div>
              <div className="text-amber-100 text-sm font-extrabold mt-0.5 tracking-wide drop-shadow-md flex items-center gap-1.5">
                {gameMode === 'vs_ai' ? (
                  <>
                    <span>{isRtl ? `یاری بەرامبەر ژیری دەستکرد (${aiDifficulty})` : `vs Royal AI (${aiDifficulty})`}</span>
                    <span className="text-[10px] bg-yellow-400 text-amber-950 px-2 py-0.2 rounded-full font-black border border-yellow-200">
                      Gold Servers Full
                    </span>
                  </>
                ) : (
                  <span>{isRtl ? 'یاری دوو کەسی بێوێنە' : 'Player 1 vs Player 2'}</span>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {isCheck && !isGameOver && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: [1, 1.1, 1], opacity: 1 }}
            transition={{ repeat: Infinity, duration: 1 }}
            className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white font-black text-base sm:text-lg px-6 py-1.5 rounded-full border-2 border-yellow-300 shadow-[0_0_20px_rgba(239,68,68,0.8)] tracking-wider"
          >
            {getTranslation(language, 'check')}
          </motion.div>
        )}

        {/* Connection banners removed per user request */}
      </div>

      {/* Floating In-Game Quick Chat Popup Modal */}
      <AnimatePresence>
        {isChatOpen && (
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            className="pointer-events-auto absolute bottom-20 left-4 right-4 sm:left-auto sm:right-4 sm:w-80 bg-slate-950/95 border-2 border-yellow-500/80 rounded-3xl p-3.5 backdrop-blur-xl shadow-[0_0_40px_rgba(0,0,0,0.9)] text-amber-100 z-40 flex flex-col gap-2"
          >
            <div className="flex items-center justify-between border-b border-amber-800/40 pb-2">
              <span className="text-xs font-black text-yellow-300 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4" />
                {language === 'ku' ? 'چاتی خێرا' : 'Quick Chat'}
              </span>
              <button
                onClick={() => setIsChatOpen(false)}
                className="p-1.5 rounded-xl bg-amber-950/80 hover:bg-amber-900 text-amber-200 border border-amber-700/40 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Phrase Chips */}
            <div className="grid grid-cols-2 gap-2 my-1">
              {(language === 'ku' ? quickPhrasesKu : quickPhrasesEn).map((phrase, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendQuickMessage(phrase)}
                  className="py-2 px-2.5 bg-amber-950/70 hover:bg-amber-900 border border-amber-700/50 rounded-xl text-xs font-bold text-amber-200 transition text-center cursor-pointer active:scale-95 shadow-sm"
                >
                  {phrase}
                </button>
              ))}
            </div>

            {/* Custom Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (chatMessage.trim()) handleSendQuickMessage(chatMessage);
              }}
              className="flex items-center gap-1.5 mt-1"
            >
              <input
                type="text"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder={language === 'ku' ? 'نامەیەک بنووسە...' : 'Type message...'}
                className="flex-1 bg-slate-900/90 border border-amber-700/60 rounded-xl py-2 px-3 text-xs font-sans text-amber-100 focus:border-yellow-400 focus:outline-none shadow-inner"
              />
              <button
                type="submit"
                className="p-2 bg-gradient-to-r from-yellow-400 to-amber-400 hover:brightness-110 text-amber-950 rounded-xl font-bold transition cursor-pointer shadow active:scale-95"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Header: Player Card & Gameplay Controls */}
      <div className="w-full flex items-end justify-between gap-2 pointer-events-auto">
        {/* White Player Card with Mic & Crown (Premium Glass & Dynamic Turn Glow) */}
        <div
          className={`relative bg-slate-950/85 border rounded-2xl px-2.5 py-1.5 sm:px-3 sm:py-2 flex items-center gap-2.5 backdrop-blur-xl transition-all duration-300 shadow-2xl text-amber-100 ${
            turn === 'w'
              ? 'border-yellow-400 ring-2 ring-yellow-400/80 shadow-[0_0_20px_rgba(250,204,21,0.45)]'
              : 'border-amber-600/40 shadow-lg'
          }`}
        >
          <button
            onClick={() => {
              soundManager.playClick();
              if (onOpenProfile) onOpenProfile();
            }}
            className="flex items-center gap-2 transition cursor-pointer group text-left rtl:text-right"
          >
            <div className="relative">
              <img
                src={
                  userProfile?.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'
                }
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border-2 border-yellow-400 object-cover group-hover:scale-105 transition shadow"
                alt={userProfile?.name || 'White Player'}
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-yellow-200 border border-amber-900 flex items-center justify-center text-[9px] text-amber-950 font-bold shadow">
                ♔
              </div>
            </div>

            <div className="flex flex-col">
              <div className="text-[11px] sm:text-xs font-black text-amber-200 flex items-center gap-1.5">
                <span className="truncate max-w-[85px] sm:max-w-[120px]">{userProfile?.name || 'You'}</span>
                <LevelCrown level={userProfile?.level || 24} size="sm" showLevelNumber={true} />
              </div>

              {/* Timer & Low-Time Warning */}
              <div className="relative flex items-center gap-1.5 mt-1">
                <div
                  className={`relative flex items-center gap-1 px-2.5 py-0.5 rounded-lg font-mono font-black text-xs sm:text-sm tracking-wider transition-all duration-300 ${
                    whiteTime <= 0
                      ? 'bg-red-950 text-red-400 border border-red-500 shadow-[0_0_20px_rgba(239,68,68,1)] ring-2 ring-red-500'
                      : whiteTime <= 10
                      ? 'bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white border-2 border-red-300 shadow-[0_0_18px_rgba(239,68,68,1)] animate-bounce'
                      : whiteTime <= 30
                      ? 'bg-red-600/90 text-white border border-red-300 shadow-[0_0_12px_rgba(239,68,68,0.9)] animate-pulse'
                      : turn === 'w'
                      ? 'bg-amber-950/90 text-yellow-300 border border-yellow-400/80 shadow-[0_0_10px_rgba(250,204,21,0.5)]'
                      : 'bg-black/80 text-amber-200/90 border border-amber-700/50'
                  }`}
                >
                  <span>{formatTime(whiteTime)}</span>
                  {whiteTime <= 10 && whiteTime > 0 && (
                    <span className="text-[10px] animate-ping">⚠️</span>
                  )}
                </div>
                {turn === 'w' && (
                  <span className="text-[9px] font-black bg-gradient-to-r from-yellow-400 to-amber-400 text-amber-950 px-1.5 py-0.5 rounded-md shadow animate-pulse">
                    {isRtl ? 'تۆڕ' : 'TURN'}
                  </span>
                )}

                {/* BOOM! Timeout Explosion Badge (کات تەواو بوو) */}
                {boomPlayer === 'w' && (
                  <motion.div
                    initial={{ scale: 0.2, opacity: 0, rotate: -15 }}
                    animate={{ scale: [0.2, 1.3, 1], opacity: 1, rotate: [0, -5, 5, 0] }}
                    transition={{ duration: 0.4 }}
                    className="absolute -top-6 left-0 z-40 bg-gradient-to-r from-red-600 via-amber-500 to-red-600 border-2 border-yellow-300 text-white font-black text-[10px] sm:text-xs px-2 py-0.5 rounded-full shadow-[0_0_25px_rgba(239,68,68,0.9)] flex items-center gap-1 whitespace-nowrap"
                  >
                    <span>💥</span>
                    <span>{isRtl ? 'بووم! کات تەواو بوو!' : 'BOOM! TIME OUT!'}</span>
                  </motion.div>
                )}
              </div>

              {/* Captured black pieces summary */}
              {Object.keys(whiteSummary.counts).length > 0 && (
                <div className="flex items-center gap-1 text-[10px] text-amber-100/90 mt-1 flex-wrap max-w-[140px] sm:max-w-[180px]">
                  {Object.entries(whiteSummary.counts).map(([type, count]) => (
                    <span
                      key={type}
                      className="inline-flex items-center gap-0.5 px-1 py-0.2 bg-amber-950/90 border border-amber-600/60 rounded text-[9.5px] font-bold shadow-sm"
                    >
                      <span className="text-amber-200">{pieceSymbolMap[type] || type}</span>
                      {count > 1 && <span className="text-[8.5px] text-yellow-300 font-mono">x{count}</span>}
                    </span>
                  ))}
                  {materialDiff > 0 && (
                    <span className="text-[9px] font-black text-amber-950 bg-yellow-400 px-1.5 py-0.2 rounded shadow">
                      +{materialDiff}
                    </span>
                  )}
                </div>
              )}
            </div>
          </button>

          {/* Mic Toggle Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              setIsMicOn(!isMicOn);
            }}
            className={`w-7 h-7 sm:w-8 sm:h-8 rounded-xl transition border flex items-center justify-center cursor-pointer active:scale-95 shadow ${
              isMicOn
                ? 'bg-emerald-600 border-emerald-400 text-white animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                : 'bg-amber-950/70 border-amber-700/60 text-amber-300 hover:bg-amber-900'
            }`}
            title={isMicOn ? 'Mute Mic' : 'Unmute Mic'}
          >
            {isMicOn ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5 opacity-60" />}
          </button>

          {/* User Speech Bubble */}
          <AnimatePresence>
            {activeSpeechBubble && activeSpeechBubble.sender === 'user' && (
              <motion.div
                initial={{ scale: 0.5, opacity: 0, y: -10 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.5, opacity: 0 }}
                className="absolute -top-12 left-2 bg-gradient-to-r from-yellow-400 to-amber-400 text-amber-950 font-black text-xs px-3 py-1.5 rounded-2xl shadow-2xl border-2 border-yellow-200 z-30 whitespace-nowrap"
              >
                {activeSpeechBubble.text}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Action Buttons: Unified, Ergonomic Touch Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 bg-slate-950/85 border border-amber-600/40 rounded-2xl p-1.5 sm:p-2 backdrop-blur-xl shadow-2xl">
          {/* Quick Chat Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              setIsChatOpen(!isChatOpen);
            }}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-b from-emerald-600 to-emerald-800 hover:from-emerald-500 hover:to-emerald-700 active:scale-95 border border-emerald-400/70 text-white font-black transition cursor-pointer shadow-lg flex items-center justify-center"
            title={language === 'ku' ? 'چاتی خێرا' : 'Quick Chat'}
          >
            <MessageSquare className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>

          {/* Resign / Surrender Compact Button next to Chat Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              setShowResignConfirm(true);
            }}
            className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-gradient-to-b from-rose-700 to-red-900 hover:from-rose-600 hover:to-red-800 active:scale-95 border border-rose-400/70 text-white font-black transition cursor-pointer shadow-lg flex items-center gap-1.5"
            title={language === 'ku' ? 'خۆ بەدەستدانەوە (دۆڕان)' : 'Resign Match'}
          >
            <Flag className="w-3.5 h-3.5 text-rose-200 fill-white/20" />
            <span className="text-[11px] sm:text-xs font-black text-rose-100 whitespace-nowrap">
              {language === 'ku' ? 'خۆبەدەستدان' : 'Resign'}
            </span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onUndo();
            }}
            className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-gradient-to-b from-slate-800 to-slate-950 hover:from-slate-700 hover:to-slate-900 active:scale-95 border border-amber-600/50 text-slate-100 text-xs font-black transition cursor-pointer shadow flex items-center gap-1"
            title={getTranslation(language, 'undo')}
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-300" />
            <span className="hidden sm:inline font-sans">{getTranslation(language, 'undo')}</span>
          </button>

          {(gameMode === 'pass_and_play' || gameMode === 'puzzles' || gameMode === 'vs_ai') && (
            <button
              onClick={() => {
                soundManager.playClick();
                onHint();
              }}
              className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-gradient-to-b from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 active:scale-95 border border-yellow-300 text-amber-950 text-xs font-black transition cursor-pointer shadow-lg flex items-center gap-1"
              title={getTranslation(language, 'hint')}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-950 fill-amber-950/30" />
              <span className="hidden sm:inline font-sans">{getTranslation(language, 'hint')}</span>
            </button>
          )}
        </div>
      </div>

      {/* Resign / Surrender Confirmation Modal */}
      <AnimatePresence>
        {showResignConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md pointer-events-auto">
            <motion.div
              initial={{ scale: 0.85, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.85, opacity: 0, y: 10 }}
              className="w-full max-w-sm bg-gradient-to-b from-[#2a1208] via-[#1c0a03] to-[#0f0401] border-2 border-red-500/80 rounded-3xl p-5 shadow-[0_0_50px_rgba(239,68,68,0.4)] text-amber-50 flex flex-col items-center text-center gap-3"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-red-500 to-red-800 border-2 border-red-300 flex items-center justify-center text-white shadow-lg">
                <Flag className="w-7 h-7 text-white fill-white/30 animate-pulse" />
              </div>

              <div>
                <h3 className="text-lg font-black text-red-400 tracking-wide">
                  {isRtl ? '🏳️ خۆ بەدەستدانەوە' : '🏳️ Resign Match'}
                </h3>
                <p className="text-xs text-amber-200/90 mt-1.5 leading-relaxed font-sans">
                  {isRtl
                    ? 'ئایا دڵنیایت لە خۆ بەدەستدانەوە؟ ئەگەر خۆت بەدەستەوە بدەیت بە دۆڕاو حساب دەکرێیت!'
                    : 'Are you sure you want to resign? You will forfeit the match and be counted as lost!'}
                </p>
              </div>

              <div className="w-full flex items-center gap-2 mt-2">
                <button
                  onClick={() => {
                    soundManager.playClick();
                    setShowResignConfirm(false);
                    if (onResign) onResign();
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-red-600 border border-red-300 text-white font-black text-xs shadow-lg transition cursor-pointer active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Flag className="w-4 h-4" />
                  <span>{isRtl ? 'بەڵێ، خۆبەدەستدانەوە' : 'Yes, Resign'}</span>
                </button>

                <button
                  onClick={() => {
                    soundManager.playClick();
                    setShowResignConfirm(false);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-amber-900/80 hover:bg-amber-800 border border-amber-600/60 text-amber-200 font-bold text-xs shadow transition cursor-pointer active:scale-95"
                >
                  {isRtl ? 'نەخێر، بەردەوامبوون' : 'Cancel'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Home / Exit Confirmation Modal */}
      <AnimatePresence>
        {showHomeConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md pointer-events-auto">
            <motion.div
              initial={{ scale: 0.85, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.85, opacity: 0, y: 10 }}
              className="w-full max-w-sm bg-gradient-to-b from-[#2a1805] via-[#1c0f02] to-[#0f0700] border-2 border-yellow-500/80 rounded-3xl p-5 shadow-[0_0_50px_rgba(250,204,21,0.3)] text-amber-50 flex flex-col items-center text-center gap-3"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-b from-yellow-400 to-amber-600 border-2 border-yellow-200 flex items-center justify-center text-amber-950 shadow-lg">
                <AlertTriangle className="w-7 h-7 text-amber-950 animate-bounce" />
              </div>

              <div>
                <h3 className="text-lg font-black text-yellow-400 tracking-wide">
                  {isRtl ? '🚪 چوونە دەرەوە لە یاری' : '🚪 Leave Match'}
                </h3>
                <p className="text-xs text-amber-200/90 mt-1.5 leading-relaxed font-sans">
                  {isRtl
                    ? 'ئایا دڵنیایت لە چوونە دەرەوە؟ لەبەر ئەوەی یارییەکە بەردەوامە، ئەگەر بچیتە دەرەوە بە دۆڕاو حساب دەکرێیت!'
                    : 'Are you sure you want to leave? Since the game is active, exiting will forfeit the match!'}
                </p>
              </div>

              <div className="w-full flex items-center gap-2 mt-2">
                <button
                  onClick={() => {
                    soundManager.playClick();
                    setShowHomeConfirm(false);
                    if (onResign) onResign();
                    onMainMenu();
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 hover:from-red-500 hover:to-red-600 border border-red-300 text-white font-black text-xs shadow-lg transition cursor-pointer active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Home className="w-4 h-4" />
                  <span>{isRtl ? 'بەڵێ، دۆڕان و دەرچوون' : 'Yes, Leave'}</span>
                </button>

                <button
                  onClick={() => {
                    soundManager.playClick();
                    setShowHomeConfirm(false);
                  }}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-amber-900/80 hover:bg-amber-800 border border-amber-600/60 text-amber-200 font-bold text-xs shadow transition cursor-pointer active:scale-95"
                >
                  {isRtl ? 'نەخێر، مانەوە لە یاری' : 'Stay in Game'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
