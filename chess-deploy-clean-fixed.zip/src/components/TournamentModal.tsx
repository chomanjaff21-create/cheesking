import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Plus,
  Settings,
  Trophy,
  Gift,
  Crown,
  Sparkles,
  CheckCircle2,
  Swords,
  Eye,
  ShieldCheck,
  Zap,
  Calendar,
  Clock,
  Bell,
  UserCheck,
  Flame,
  Award,
  AlertCircle,
  Users,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { useRealtimeStore } from '../lib/realtime';
import { buildApiUrl } from '../lib/api';
import { soundManager } from '../lib/soundManager';

interface TournamentModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile: UserProfile;
  coins: number;
  onOpenShop: () => void;
  onOpenCoach: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onStartSpectate: () => void;
  onStartGame: () => void;
}

export interface TournamentMatch {
  id: string;
  roundNameKu: string;
  roundNameEn: string;
  scheduledTime: string;
  p1: { id: number; name: string; avatar: string; score?: number; isWinner?: boolean; isEliminated?: boolean };
  p2: { id: number; name: string; avatar: string; score?: number; isWinner?: boolean; isEliminated?: boolean };
  status: 'upcoming' | 'live' | 'completed';
}

// 16 Participants


// Sample Matches Schedule for the 1-Month Tournament


export const TournamentModal: React.FC<TournamentModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
  coins,
  onOpenShop,
  onOpenProfile,
  onOpenSettings,
  onStartSpectate,
  onStartGame,
}) => {
  
  const [activeTab, setActiveTab] = useState<'bracket' | 'matches' | 'schedule' | 'players'>('bracket');
  const [isRegistered, setIsRegistered] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [tournamentType, setTournamentType] = useState<'monthly' | 'weekly'>('monthly');
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  
  const [tournament, setTournament] = useState<any>(null);
  const [participants, setParticipants] = useState<any[]>([]);
  const [matches, setMatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    if (isOpen) {
       fetchTournament();
    }
  }, [isOpen]);

  const fetchTournament = async () => {
     setLoading(true);
     try {
       const token = useRealtimeStore.getState().session?.token;
       const headers: any = {};
       if (token) headers['Authorization'] = `Bearer ${token}`;
       const res = await fetch(buildApiUrl('/api/tournaments/current'), { headers });
       if (res.ok) {
         const data = await res.json();
         setTournament(data.tournament);
         setParticipants(data.participants || []);
         setMatches(data.matches || []);
         setIsRegistered(data.isRegistered || false);
       }
     } catch (e) {
       console.error(e);
     }
     setLoading(false);
  };

  const ENTRY_FEE = tournament ? tournament.entry_fee : 1000;
  const PRIZE_POOL = tournament ? tournament.prize_pool : 50000;
  const MAX_PLAYERS = tournament ? tournament.max_participants : 16;

  const isRtl = language === 'ku';
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3200);
  };

  const handleJoinTournament = () => {
    soundManager.playClick();
    if (isRegistered) {
      showToast(
        isRtl
          ? 'چوونە ناو یارییەکەی ئەمڕۆت! ♟️'
          : 'Entering today\'s match against Kurdish_Knight99 ♟️'
      );
      onStartGame();
      return;
    }

    setIsRegistered(true);
    soundManager.playVictory();
    showToast(
      isRtl
        ? 'پیرۆزە! ناوت تۆمارکرا لە خولی ۱ مانگی شاهانە 🏆'
        : 'Successfully registered for 1-Month Grand Championship! 🏆'
    );
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-1 sm:p-3 bg-black/85 backdrop-blur-md select-none overflow-hidden font-sans">
        
        {/* MAIN CONTAINER */}
        <motion.div
          initial={{ scale: 0.94, opacity: 0, y: 10 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.94, opacity: 0, y: 10 }}
          className={`relative w-full max-w-lg h-[96vh] max-h-[840px] rounded-[36px] p-2.5 sm:p-4 shadow-[0_25px_80px_rgba(0,0,0,0.95)] flex flex-col justify-between overflow-hidden border-2 border-[#d6982a] bg-gradient-to-b from-[#7a3911] via-[#4d1f06] to-[#210901] text-amber-50 ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* TOAST NOTIFICATION BANNER */}
          {toastMsg && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-16 left-1/2 -translate-x-1/2 bg-amber-400 text-amber-950 font-black text-xs px-4 py-2 rounded-full border-2 border-yellow-100 shadow-2xl flex items-center gap-2 z-50 whitespace-nowrap"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-900" />
              <span>{toastMsg}</span>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* 1. TOP HEADER BAR: Profile Avatar + Coins + Settings */}
          {/* ========================================================= */}
          <div className="w-full bg-[#361405]/95 border border-amber-600/60 rounded-2xl p-1.5 px-3 flex items-center justify-between shrink-0 shadow-lg backdrop-blur-md z-20">
            {/* User Profile Avatar */}
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenProfile();
              }}
              className="flex items-center gap-2 group cursor-pointer"
            >
              <div className="relative w-10 h-10 rounded-full border-2 border-yellow-400 p-0.5 bg-amber-950 shrink-0 shadow-md group-hover:scale-105 transition">
                <img
                  src={userProfile.avatar}
                  alt={userProfile.name}
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="text-left rtl:text-right hidden sm:block">
                <div className="text-xs font-black text-amber-200">{userProfile.name}</div>
                <div className="text-[10px] text-yellow-400 font-bold">LV {userProfile.level || 24}</div>
              </div>
            </button>

            {/* Coins Badge Pill */}
            <div
              onClick={() => {
                soundManager.playClick();
                onOpenShop();
              }}
              className="bg-[#1f0901] border border-amber-600/80 rounded-full px-3 py-1 flex items-center gap-2 shadow-inner cursor-pointer hover:border-yellow-300 transition"
            >
              <div className="w-5 h-5 rounded-full bg-yellow-400 border border-yellow-100 flex items-center justify-center text-amber-950 font-black text-xs shadow-inner">
                $
              </div>
              <span className="font-mono font-black text-yellow-300 text-xs sm:text-sm tracking-wider">
                17.7k
              </span>
              <div className="w-4 h-4 rounded-full bg-emerald-500 text-white flex items-center justify-center">
                <Plus className="w-3 h-3 stroke-[3]" />
              </div>
            </div>

            {/* Gear & Close Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  soundManager.playClick();
                  onOpenSettings();
                }}
                className="w-8 h-8 rounded-full bg-amber-950/80 border border-amber-600/70 text-amber-200 flex items-center justify-center hover:text-white transition cursor-pointer"
              >
                <Settings className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  soundManager.playClick();
                  onClose();
                }}
                className="w-8 h-8 rounded-full bg-red-900/90 border border-red-500 text-white flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer shadow"
              >
                <X className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 2. SUB-HEADER RIBBON & COUNTDOWN TIMER */}
          {/* ========================================================= */}
          <div className="flex items-center justify-between px-1 my-1.5 shrink-0">
            {/* Left Ribbon Tag: Tournament Selector Switcher */}
            <button
              onClick={() => {
                soundManager.playClick();
                setTournamentType(tournamentType === 'monthly' ? 'weekly' : 'monthly');
              }}
              className="relative bg-gradient-to-r from-[#f0d38d] via-[#c99a3c] to-[#8c6016] text-amber-950 font-black text-xs px-3.5 py-1 rounded-r-full rounded-l-md border-y border-r border-amber-200 shadow-md flex items-center gap-1.5 cursor-pointer hover:brightness-110 transition"
            >
              <Trophy className="w-3.5 h-3.5 text-amber-950" />
              <span>
                {tournamentType === 'monthly'
                  ? isRtl ? 'خولی ۱ مانگی شاهانە 🏆' : '1-Month Grand Cup 🏆'
                  : isRtl ? 'پێشبڕکێی هەفتانە ⚡' : 'Weekly Blitz Cup ⚡'}
              </span>
            </button>

            {/* Right Status & 1-Month Countdown */}
            <div className="flex items-center gap-2">
              <div className="bg-amber-950/80 border border-amber-600/60 rounded-full px-2.5 py-1 text-[11px] font-mono font-black text-yellow-300 flex items-center gap-1 shadow">
                <Clock className="w-3 h-3 text-yellow-400" />
                <span>18d 14h 22m</span>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 3. MATCHMAKING NOTIFICATION ALERT CARD (HIGH PRIORITY) */}
          {/* ========================================================= */}
          {isRegistered && (
            <motion.div
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full bg-gradient-to-r from-amber-950 via-[#3d1a04] to-amber-950 border-2 border-yellow-400/90 rounded-2xl p-2 sm:p-2.5 shadow-[0_0_20px_rgba(234,179,8,0.3)] mb-1 shrink-0 flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-gradient-to-br from-red-600 to-amber-600 text-white shadow animate-pulse">
                  <Bell className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div className="text-left rtl:text-right">
                  <div className="text-xs font-black text-yellow-300 flex items-center gap-1">
                    <span>{isRtl ? 'ئاگاداری: بەرامبەرەکەت دیاریکرا! ⚔️' : 'Match Alert: Opponent Found! ⚔️'}</span>
                  </div>
                  <div className="text-[10px] text-amber-200/90 font-bold">
                    {isRtl
                      ? 'بەرامبەر: Kurdish_Knight99 (کاتی یاری: ئەمڕۆ 09:30 PM)'
                      : 'Opponent: Kurdish_Knight99 (Time: Today 09:30 PM)'}
                  </div>
                </div>
              </div>

              <button
                onClick={handleJoinTournament}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-amber-950 font-black text-xs shadow hover:scale-105 active:scale-95 transition cursor-pointer shrink-0 flex items-center gap-1"
              >
                <Swords className="w-3.5 h-3.5 fill-amber-950" />
                <span>{isRtl ? 'دەستپێکردن' : 'Start'}</span>
              </button>
            </motion.div>
          )}

          {/* NAV TABS SELECTOR ROW */}
          <div className="w-full flex items-center gap-1 bg-[#230a01]/90 p-1 rounded-2xl border border-amber-800/40 mb-1 shrink-0">
            <button
              onClick={() => setActiveTab('bracket')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'bracket'
                  ? 'bg-amber-500 text-amber-950 shadow-md font-black'
                  : 'text-amber-200 hover:bg-amber-900/50'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>{isRtl ? 'درەختی خول' : 'Tree Bracket'}</span>
            </button>

            <button
              onClick={() => setActiveTab('matches')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'matches'
                  ? 'bg-amber-500 text-amber-950 shadow-md font-black'
                  : 'text-amber-200 hover:bg-amber-900/50'
              }`}
            >
              <Swords className="w-3.5 h-3.5" />
              <span>{isRtl ? 'خشتەی یارییەکان' : 'Matches'}</span>
            </button>

            <button
              onClick={() => setActiveTab('schedule')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'schedule'
                  ? 'bg-amber-500 text-amber-950 shadow-md font-black'
                  : 'text-amber-200 hover:bg-amber-900/50'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>{isRtl ? 'خشتەی ۳۰ ڕۆژ' : '30-Day Plan'}</span>
            </button>

            <button
              onClick={() => setActiveTab('players')}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                activeTab === 'players'
                  ? 'bg-amber-500 text-amber-950 shadow-md font-black'
                  : 'text-amber-200 hover:bg-amber-900/50'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{isRtl ? 'یاریزانان (16)' : 'Players'}</span>
            </button>
          </div>

          {/* ========================================================= */}
          {/* 4. TAB CONTENT AREA */}
          {/* ========================================================= */}
          <div className="relative w-full flex-1 rounded-3xl border-2 border-[#d6982a] bg-gradient-to-b from-[#2a0e02] via-[#160600] to-[#0a0200] p-2.5 sm:p-3 shadow-2xl overflow-hidden flex flex-col justify-between my-1 min-h-[280px]">
            
            {/* Gold Corner Ornaments */}
            <div className="absolute top-2 left-2 text-amber-400/80 text-xs select-none">✦</div>
            <div className="absolute top-2 right-2 text-amber-400/80 text-xs select-none">✦</div>
            <div className="absolute bottom-2 left-2 text-amber-400/80 text-xs select-none">✦</div>
            <div className="absolute bottom-2 right-2 text-amber-400/80 text-xs select-none">✦</div>

            {/* TAB 1: BRACKET TREE VISUALIZER */}
            {activeTab === 'bracket' && (
              <div className="w-full h-full flex flex-col justify-between">
                {/* PRIZE POOL HEADER */}
                <div className="flex items-center justify-between pt-1 px-1 z-20">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-gradient-to-b from-red-500 to-red-800 border-2 border-yellow-300 flex items-center justify-center text-white shadow-lg">
                      <Gift className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-yellow-200" />
                    </div>
                    <div className="flex flex-col text-left rtl:text-right">
                      <span className="text-[9px] sm:text-[10px] uppercase font-black tracking-widest text-amber-300/80">Prize Pool</span>
                      <span className="font-mono font-black text-yellow-300 text-base sm:text-lg tracking-wider drop-shadow">
                        50,000,000 $ + 👑
                      </span>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-amber-900/90 to-amber-950/90 border border-amber-500/80 rounded-2xl px-2.5 py-1 flex items-center gap-1.5 shadow">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-[11px] sm:text-xs font-black text-amber-100">
                      {isRtl ? 'قۆناغی ۱۶ دەستیپێکرد' : 'Round of 16 Active'}
                    </span>
                  </div>
                </div>

                {/* BRACKET TREE GRID */}
                <div className="relative w-full h-[250px] sm:h-[280px] my-auto overflow-hidden">
                  <svg
                    className="absolute inset-0 w-full h-full pointer-events-none z-0"
                    viewBox="0 0 1000 1000"
                    preserveAspectRatio="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    {/* LEFT BRACKETS */}
                    <path d="M 60 62.5 H 140 V 187.5 H 60 M 140 125 H 220" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 60 312.5 H 140 V 437.5 H 60 M 140 375 H 220" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 60 562.5 H 140 V 687.5 H 60 M 140 625 H 220" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 60 812.5 H 140 V 937.5 H 60 M 140 875 H 220" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 220 125 H 300 V 375 H 220 M 300 250 H 380" fill="none" stroke="#f0c85b" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 220 625 H 300 V 875 H 220 M 300 750 H 380" fill="none" stroke="#f0c85b" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 380 250 H 435 V 750 H 380 M 435 500 H 450" fill="none" stroke="#f59e0b" strokeWidth="3.5" strokeLinecap="round" />

                    {/* RIGHT BRACKETS */}
                    <path d="M 940 62.5 H 860 V 187.5 H 940 M 860 125 H 780" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 940 312.5 H 860 V 437.5 H 940 M 860 375 H 780" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 940 562.5 H 860 V 687.5 H 940 M 860 625 H 780" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 940 812.5 H 860 V 937.5 H 940 M 860 875 H 780" fill="none" stroke="#d6982a" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 780 125 H 700 V 375 H 780 M 700 250 H 620" fill="none" stroke="#f0c85b" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 780 625 H 700 V 875 H 780 M 700 750 H 620" fill="none" stroke="#f0c85b" strokeWidth="3" strokeLinecap="round" />
                    <path d="M 620 250 H 565 V 750 H 620 M 565 500 H 550" fill="none" stroke="#f59e0b" strokeWidth="3.5" strokeLinecap="round" />
                  </svg>

                  {/* LEFT PLAYERS */}
                  {participants.slice(0, 8).map((p, idx) => {
                    const yPercent = 6.25 + idx * 12.5;
                    const isEliminated = idx === 1 || idx === 2;
                    return (
                      <div
                        key={p.id}
                        style={{ left: '6%', top: `${yPercent}%` }}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 sm:w-8 sm:h-8 rounded-full border-2 ${
                          isEliminated ? 'border-rose-600 opacity-50 grayscale' : 'border-[#d6982a]'
                        } bg-amber-950 overflow-hidden shadow z-10`}
                      >
                        <img src={p.avatar} alt={p.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        {isEliminated && (
                          <span className="absolute inset-0 bg-red-900/60 flex items-center justify-center text-white font-bold text-[8px]">
                            ✕
                          </span>
                        )}
                      </div>
                    );
                  })}

                  {/* CENTER CHAMPION BOX */}
                  <div
                    style={{ left: '50%', top: '50%' }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center z-20"
                  >
                    <Crown className="w-7 h-7 text-yellow-400 filter drop-shadow-[0_2px_12px_rgba(234,179,8,1)] mb-1 animate-bounce" />
                    <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border-2 border-[#f0c85b] bg-gradient-to-b from-amber-950 via-amber-900 to-black flex items-center justify-center shadow-[0_0_25px_rgba(240,200,91,0.8)] overflow-hidden">
                      <span className="text-xl font-black text-yellow-300 font-serif">?</span>
                    </div>
                  </div>

                  {/* RIGHT PLAYERS */}
                  {participants.slice(8, 16).map((p, idx) => {
                    const yPercent = 6.25 + idx * 12.5;
                    return (
                      <div
                        key={p.id}
                        style={{ left: '94%', top: `${yPercent}%` }}
                        className="absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 sm:w-8 sm:h-8 rounded-full border-2 border-[#d6982a] bg-amber-950 overflow-hidden shadow z-10"
                      >
                        <img src={p.avatar} alt={p.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                    );
                  })}
                </div>

                {/* BOTTOM LEGEND INFO */}
                <div className="w-full bg-amber-950/60 border border-amber-700/50 rounded-2xl p-1.5 flex items-center justify-around text-center text-[10px] text-amber-200 z-20">
                  <div className="flex items-center gap-1 font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span>{isRtl ? '🟢 براوە (سەرکەوتوو)' : '🟢 Winner'}</span>
                  </div>
                  <div className="flex items-center gap-1 font-bold">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                    <span>{isRtl ? '🔴 دۆڕاو (دەرکراو)' : '🔴 Eliminated'}</span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: MATCHES SCHEDULE & RESULTS */}
            {activeTab === 'matches' && (
              <div className="w-full h-full overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                <h3 className="text-xs font-black text-yellow-300 mb-2">
                  {isRtl ? 'خشتەی کاتی یارییەکان و ئەنجامەکان (30 Days)' : 'Match Schedule & Live Results'}
                </h3>

                {matches.map((match) => (
                  <div
                    key={match.id}
                    className={`rounded-2xl border p-2.5 flex flex-col gap-2 transition ${
                      match.status === 'live'
                        ? 'bg-amber-950/90 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                        : 'bg-amber-950/50 border-amber-800/50'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] font-bold text-amber-300/80 border-b border-amber-800/40 pb-1">
                      <span>{isRtl ? match.roundNameKu : match.roundNameEn}</span>
                      <span className="font-mono text-yellow-400 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {match.scheduledTime}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      {/* Player 1 */}
                      <div className="flex items-center gap-2">
                        <div className="relative">
                          <img
                            src={match.p1.avatar}
                            className={`w-8 h-8 rounded-full border ${
                              match.p1.isWinner ? 'border-emerald-400 ring-2 ring-emerald-500' : 'border-amber-600'
                            }`}
                            alt={match.p1.name}
                            referrerPolicy="no-referrer"
                          />
                          {match.p1.isWinner && (
                            <span className="absolute -top-1 -right-1 bg-emerald-500 text-white rounded-full p-0.5 text-[8px] font-black">
                              ✓
                            </span>
                          )}
                        </div>
                        <span className={`text-xs font-bold ${match.p1.isEliminated ? 'line-through text-red-400/70' : 'text-amber-100'}`}>
                          {match.p1.name}
                        </span>
                      </div>

                      {/* VS / Score */}
                      <div className="px-2 py-0.5 rounded-lg bg-black/60 border border-amber-600/60 font-mono font-black text-xs text-yellow-300">
                        {match.status === 'completed' ? `${match.p1.score} - ${match.p2.score}` : 'VS'}
                      </div>

                      {/* Player 2 */}
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-bold ${match.p2.isEliminated ? 'line-through text-red-400/70' : 'text-amber-100'}`}>
                          {match.p2.name}
                        </span>
                        <div className="relative">
                          <img
                            src={match.p2.avatar}
                            className={`w-8 h-8 rounded-full border ${
                              match.p2.isWinner ? 'border-emerald-400 ring-2 ring-emerald-500' : 'border-amber-600'
                            }`}
                            alt={match.p2.name}
                            referrerPolicy="no-referrer"
                          />
                          {match.p2.isWinner && (
                            <span className="absolute -top-1 -right-1 bg-emerald-500 text-white rounded-full p-0.5 text-[8px] font-black">
                              ✓
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Action Button */}
                    {match.status === 'live' && (
                      <button
                        onClick={handleJoinTournament}
                        className="w-full py-1.5 rounded-xl bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-amber-950 font-black text-xs shadow hover:scale-[1.01] active:scale-95 transition cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Swords className="w-3.5 h-3.5 fill-amber-950" />
                        <span>{isRtl ? 'چوونە ناو یارییەکە ♟️' : 'Play Match Now ♟️'}</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* TAB 3: 30-DAY TOURNAMENT ROADMAP */}
            {activeTab === 'schedule' && (
              <div className="w-full h-full overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                <h3 className="text-xs font-black text-yellow-300 mb-2">
                  {isRtl ? 'خشتەی ۳۰ ڕۆژەی خولی شاهانەی ۱ مانگ' : '30-Day Grand Championship Schedule'}
                </h3>

                {[
                  { week: 1, titleKu: 'هەفتەی ۱ (ڕۆژی ۱ تا ۷)', titleEn: 'Week 1 (Days 1-7)', descKu: 'تۆمارکردن و یارییەکانی قۆناغی ۳۲', descEn: 'Registration & Round of 32', active: false },
                  { week: 2, titleKu: 'هەفتەی ۲ (ڕۆژی ۸ تا ۱۴)', titleEn: 'Week 2 (Days 8-14)', descKu: 'یارییەکانی قۆناغی ۱۶ بە شێوازی Knockout', descEn: 'Round of 16 Knockout Matches', active: true },
                  { week: 3, titleKu: 'هەفتەی ۳ (ڕۆژی ۱۵ تا ۲۲)', titleEn: 'Week 3 (Days 15-22)', descKu: 'چارەگی کۆتایی و نیوەی کۆتایی (Semi-Finals)', descEn: 'Quarterfinals & Semifinals', active: false },
                  { week: 4, titleKu: 'هەفتەی ۴ (ڕۆژی ۲۳ تا ۳۰)', titleEn: 'Week 4 (Days 23-30)', descKu: 'یاری کۆتایی (Grand Final) و دابەشکردنی ۵۰ ملیۆن زێڕ 🏆', descEn: 'Grand Final & $50M Prize Ceremony 🏆', active: false },
                ].map((item) => (
                  <div
                    key={item.week}
                    className={`rounded-2xl border p-2.5 flex items-center gap-3 ${
                      item.active
                        ? 'bg-amber-950/90 border-yellow-400 shadow'
                        : 'bg-amber-950/40 border-amber-800/40 opacity-80'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-2xl bg-amber-900 border border-yellow-400/80 flex items-center justify-center font-black text-yellow-300 text-sm shrink-0">
                      W{item.week}
                    </div>
                    <div className="text-left rtl:text-right">
                      <div className="text-xs font-bold text-amber-100">
                        {isRtl ? item.titleKu : item.titleEn}
                      </div>
                      <div className="text-[10px] text-amber-300/80">
                        {isRtl ? item.descKu : item.descEn}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* TAB 4: PLAYERS LIST */}
            {activeTab === 'players' && (
              <div className="w-full h-full overflow-y-auto grid grid-cols-2 gap-2 pr-1 custom-scrollbar">
                {participants.map((p) => (
                  <div
                    key={p.id}
                    className="bg-amber-950/60 border border-amber-700/50 rounded-2xl p-2 flex items-center gap-2"
                  >
                    <img
                      src={p.avatar}
                      className="w-8 h-8 rounded-full border border-yellow-400 object-cover shrink-0"
                      alt={p.name}
                      referrerPolicy="no-referrer"
                    />
                    <div className="text-left rtl:text-right truncate">
                      <div className="text-xs font-bold text-amber-100 truncate">{p.name}</div>
                      <div className="text-[10px] text-yellow-400 font-semibold">LV {p.level}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>

          {/* ========================================================= */}
          {/* 5. BIG GLOSSY ACTION BUTTON */}
          {/* ========================================================= */}
          <div className="w-full my-2 flex justify-center shrink-0">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={handleJoinTournament}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-b from-[#c0321a] via-[#94200d] to-[#590e02] border-2 border-[#f59e0b] text-yellow-100 font-black text-base tracking-wider shadow-[0_8px_25px_rgba(192,50,26,0.8)] cursor-pointer flex items-center justify-center gap-2 hover:brightness-110 transition"
            >
              <Trophy className="w-5 h-5 text-yellow-300" />
              <span>
                {isRegistered
                  ? isRtl ? 'چوونە ناو یارییەکەی ئەمڕۆت ♟️' : 'Enter Today\'s Match ♟️'
                  : isRtl ? 'بەشداربوون لە خول' : 'Join Tournament'}
              </span>
            </motion.button>
          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
