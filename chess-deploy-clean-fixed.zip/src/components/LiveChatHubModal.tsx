import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  MessageSquare,
  Radio,
  Tv,
  Eye,
  Send,
  Bot,
  Sparkles,
  Swords,
  Users,
  Flame,
  ArrowRight,
  ChevronRight,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';
import { buildApiUrl } from '../lib/api';
import { useRealtimeStore } from '../lib/realtime';
import { LevelCrown } from './LevelCrown';

interface LiveChatHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile?: UserProfile;
  onWatchLiveGame: (gameId: string) => void;
  onOpenCoach: () => void;
}

interface LiveStreamItem {
  id: string;
  player1: { name: string; avatar: string; rating: number; level: number };
  player2: { name: string; avatar: string; rating: number; level: number };
  viewers: number;
  tournamentName: string;
  turnSan: string;
}

interface ChatMessage {
  id: string;
  senderName: string;
  avatar: string;
  level: number;
  text: string;
  time: string;
  isMe?: boolean;
}



export const LiveChatHubModal: React.FC<LiveChatHubModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
  onWatchLiveGame,
  onOpenCoach,
}) => {
  const [activeTab, setActiveTab] = useState<'streams' | 'global_chat' | 'coach'>('streams');
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const [inputMsg, setInputMsg] = useState('');
  const [liveStreams, setLiveStreams] = useState<any[]>([]);

  const DEFAULT_AVATAR = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80';
  const lastIdRef = React.useRef<string>('');
  const authHeaders = (): Record<string, string> => {
    const tk = (useRealtimeStore.getState().session?.token || '').trim();
    return tk ? { Authorization: `Bearer ${tk}` } : {};
  };

  // Live matches: real list from the server (matches being played right now).
  useEffect(() => {
    if (!isOpen || activeTab !== 'streams') return;
    let stop = false;
    const load = async () => {
      try {
        const r = await fetch(buildApiUrl('/api/matches/live'), { headers: authHeaders() });
        if (!r.ok) return;
        const d = await r.json();
        if (stop) return;
        setLiveStreams((d.liveMatches || []).map((m: any) => ({
          id: m.id,
          viewers: m.viewers || 0,
          tournamentName: m.stake > 0
            ? (language === 'ku' ? `یاریی پارەدار — ${Number(m.stake).toLocaleString()} 🪙` : `Staked Match — ${Number(m.stake).toLocaleString()} 🪙`)
            : (language === 'ku' ? 'یاریی ئۆنلاین ⚔️' : 'Live 1v1 Match ⚔️'),
          turnSan: m.turn === 'w' ? (language === 'ku' ? 'نۆرەی سپی' : "White's turn") : (language === 'ku' ? 'نۆرەی ڕەش' : "Black's turn"),
          player1: { ...m.player1, avatar: m.player1?.avatar || DEFAULT_AVATAR },
          player2: { ...m.player2, avatar: m.player2?.avatar || DEFAULT_AVATAR },
        })));
      } catch {}
    };
    load();
    const t = setInterval(load, 10000);
    return () => { stop = true; clearInterval(t); };
  }, [isOpen, activeTab, language]);

  // Global chat: messages come from the server (stored in Postgres), polled every 3 s.
  useEffect(() => {
    if (!isOpen || activeTab !== 'global_chat') return;
    let stop = false;
    const myId = useRealtimeStore.getState().session?.user_id;
    const poll = async () => {
      try {
        const url = buildApiUrl('/api/chat/global' + (lastIdRef.current ? `?after=${encodeURIComponent(lastIdRef.current)}` : ''));
        const r = await fetch(url, { headers: authHeaders() });
        if (!r.ok) return;
        const d = await r.json();
        if (stop) return;
        const incoming: ChatMessage[] = (d.messages || []).map((m: any) => ({
          id: m.id,
          senderName: m.senderName,
          avatar: m.avatar || DEFAULT_AVATAR,
          level: m.level || 1,
          text: m.text,
          time: new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isMe: m.userId === myId,
        }));
        if (incoming.length > 0) {
          lastIdRef.current = incoming[incoming.length - 1].id;
          setMessages((prev) => {
            const seen = new Set(prev.map((p) => p.id));
            return [...prev, ...incoming.filter((i) => !seen.has(i.id))].slice(-200);
          });
        }
      } catch {}
    };
    poll();
    const t = setInterval(poll, 3000);
    return () => { stop = true; clearInterval(t); };
  }, [isOpen, activeTab]);

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = inputMsg.trim();
    if (!text) return;

    soundManager.playClick();
    setInputMsg('');
    try {
      const r = await fetch(buildApiUrl('/api/chat/global'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ text }),
      });
      const d = await r.json().catch(() => ({}));
      if (r.ok && d.message) {
        setMessages((prev) => prev.some((p) => p.id === d.message.id) ? prev : [...prev, {
          id: d.message.id,
          senderName: d.message.senderName,
          avatar: d.message.avatar || DEFAULT_AVATAR,
          level: d.message.level || 1,
          text: d.message.text,
          time: new Date(d.message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isMe: true,
        }].slice(-200));
      } else {
        setInputMsg(text); // not sent (rate limit / suspended): keep the text
      }
    } catch {
      setInputMsg(text);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className={`relative w-full max-w-lg bg-gradient-to-b from-[#1e1107] via-[#120902] to-[#080401] border-2 border-yellow-500/80 rounded-3xl p-4 sm:p-5 shadow-[0_0_50px_rgba(234,179,8,0.35)] text-amber-100 flex flex-col h-[85vh] max-h-[640px] ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header Bar */}
          <div className="w-full flex items-center justify-between border-b border-amber-800/40 pb-3 mb-3 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="relative p-2 rounded-2xl bg-gradient-to-r from-red-600 to-amber-600 text-white shadow-lg border border-yellow-300">
                <Radio className="w-5 h-5 animate-pulse" />
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-red-500 border-2 border-amber-950 animate-ping" />
              </div>
              <div>
                <h2 className="text-lg font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500 tracking-wide flex items-center gap-2">
                  <span>{language === 'ku' ? 'چات و لاڤی ڕاستەوخۆ' : 'Chat & Live Streams'}</span>
                  <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest animate-pulse border border-red-300">
                    LIVE
                  </span>
                </h2>
                <p className="text-[11px] text-amber-300/70">
                  {language === 'ku'
                    ? 'سەیری یارییە ڕاستەوخۆکان بکە و چات لەگەڵ یاریزانان بکە!'
                    : 'Watch live matches and chat with players!'}
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                soundManager.playClick();
                onClose();
              }}
              className="p-2 rounded-xl bg-amber-950 hover:bg-amber-900 border border-amber-700/60 text-amber-200 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Navigation Controls */}
          <div className="w-full flex items-center gap-1.5 bg-amber-950/80 p-1.5 rounded-2xl border border-amber-800/50 mb-3 shrink-0">
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('streams');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'streams'
                  ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-amber-950 shadow-md'
                  : 'text-amber-200 hover:bg-amber-900/50'
              }`}
            >
              <Tv className="w-4 h-4" />
              <span>{language === 'ku' ? 'یارییە لاڤەکان' : 'Live Streams'}</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab('global_chat');
              }}
              className={`flex-1 py-2 rounded-xl text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'global_chat'
                  ? 'bg-gradient-to-r from-yellow-400 to-amber-500 text-amber-950 shadow-md'
                  : 'text-amber-200 hover:bg-amber-900/50'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{language === 'ku' ? 'چاتی گشتی' : 'Global Chat'}</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                onOpenCoach();
                onClose();
              }}
              className="px-3 py-2 rounded-xl text-xs font-black bg-amber-900/60 hover:bg-amber-800 text-amber-300 border border-amber-700/40 transition flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
            >
              <Bot className="w-4 h-4 text-yellow-400" />
              <span className="hidden sm:inline">{language === 'ku' ? 'ڕاهێنەر' : 'Coach'}</span>
            </button>
          </div>

          {/* TAB 1: LIVE STREAMS LIST */}
          {activeTab === 'streams' && (
            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {liveStreams.map((stream) => (
                <div
                  key={stream.id}
                  className="relative bg-gradient-to-r from-amber-950/80 via-amber-900/40 to-amber-950/80 border-2 border-amber-600/60 rounded-2xl p-3 shadow-lg hover:border-yellow-400 transition group overflow-hidden"
                >
                  {/* Top Bar: Tournament Title & Viewers Counter Badge */}
                  <div className="flex items-center justify-between mb-2 pb-2 border-b border-amber-800/40">
                    <span className="text-xs font-bold text-amber-300 flex items-center gap-1">
                      <Swords className="w-3.5 h-3.5 text-yellow-400" />
                      {stream.tournamentName}
                    </span>

                    <div className="flex items-center gap-1.5 bg-red-950/90 border border-red-500/60 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-black text-red-300 shadow">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                      <Eye className="w-3.5 h-3.5 text-red-400" />
                      <span>{stream.viewers.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Middle: Player 1 VS Player 2 Card */}
                  <div className="flex items-center justify-between my-2">
                    {/* Player 1 */}
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <img
                          src={stream.player1.avatar}
                          className="w-10 h-10 rounded-full border-2 border-yellow-400 object-cover shadow"
                          alt={stream.player1.name}
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute -top-1 -right-1">
                          <LevelCrown level={stream.player1.level} size="sm" showLevelNumber={false} />
                        </div>
                      </div>
                      <div className="text-left rtl:text-right">
                        <div className="text-xs font-bold text-amber-100">{stream.player1.name}</div>
                        <div className="text-[10px] text-amber-400/80 font-mono">
                          Rating: {stream.player1.rating}
                        </div>
                      </div>
                    </div>

                    {/* VS Badge */}
                    <div className="px-2.5 py-1 rounded-xl bg-amber-950 border border-amber-500/80 text-yellow-400 font-black text-xs font-mono shadow">
                      VS
                    </div>

                    {/* Player 2 */}
                    <div className="flex items-center gap-2 flex-row-reverse text-right rtl:text-left">
                      <div className="relative">
                        <img
                          src={stream.player2.avatar}
                          className="w-10 h-10 rounded-full border-2 border-amber-400 object-cover shadow"
                          alt={stream.player2.name}
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute -top-1 -left-1">
                          <LevelCrown level={stream.player2.level} size="sm" showLevelNumber={false} />
                        </div>
                      </div>
                      <div>
                        <div className="text-xs font-bold text-amber-100">{stream.player2.name}</div>
                        <div className="text-[10px] text-amber-400/80 font-mono">
                          Rating: {stream.player2.rating}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Move Preview & Watch Live Button */}
                  <div className="mt-3 flex items-center justify-between pt-2 border-t border-amber-800/40">
                    <span className="text-[11px] text-amber-300/80 font-mono flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-orange-400 animate-bounce" />
                      {stream.turnSan}
                    </span>

                    <button
                      onClick={() => {
                        soundManager.playClick();
                        onWatchLiveGame(stream.id);
                        onClose();
                      }}
                      className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 via-amber-500 to-yellow-400 text-amber-950 font-black text-xs shadow-lg hover:brightness-110 active:scale-95 transition cursor-pointer flex items-center gap-1.5"
                    >
                      <span>{language === 'ku' ? 'سەیرکردنی لاڤ' : 'Watch Live'}</span>
                      <ChevronRight className="w-4 h-4 rtl:rotate-180" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: GLOBAL COMMUNITY CHATROOM */}
          {activeTab === 'global_chat' && (
            <div className="flex-1 flex flex-col min-h-0">
              {/* Message List */}
              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 mb-2">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-2.5 p-2 rounded-2xl border ${
                      msg.isMe
                        ? 'bg-amber-900/60 border-amber-500/60 ml-6 rtl:ml-0 rtl:mr-6'
                        : 'bg-slate-900/80 border-amber-800/40 mr-6 rtl:mr-0 rtl:ml-6'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img
                        src={msg.avatar}
                        className="w-8 h-8 rounded-full border border-yellow-400 object-cover"
                        alt={msg.senderName}
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute -bottom-1 -right-1">
                        <LevelCrown level={msg.level} size="sm" showLevelNumber={false} />
                      </div>
                    </div>

                    <div className="flex-1 text-left rtl:text-right">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-xs font-bold text-amber-200">{msg.senderName}</span>
                        <span className="text-[10px] text-amber-400/60 font-mono">{msg.time}</span>
                      </div>
                      <p className="text-xs text-amber-100 font-medium">{msg.text}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Chat Input Bar */}
              <form onSubmit={handleSendMessage} className="flex items-center gap-2 pt-2 border-t border-amber-800/40">
                <input
                  type="text"
                  value={inputMsg}
                  onChange={(e) => setInputMsg(e.target.value)}
                  placeholder={language === 'ku' ? 'نامەیەک بنووسە لە چاتی ڕاستەوخۆ...' : 'Type a live message...'}
                  className="flex-1 bg-slate-900/90 border border-amber-600/60 rounded-2xl py-2 px-3.5 text-xs text-amber-100 focus:border-yellow-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="p-2 bg-gradient-to-r from-yellow-400 to-amber-500 text-amber-950 rounded-2xl font-bold transition shadow hover:brightness-110 active:scale-95 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
