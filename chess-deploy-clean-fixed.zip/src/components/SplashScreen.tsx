import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Language } from '../types';
import { soundManager } from '../lib/soundManager';

const splashImg = '/src/assets/images/chess_royale_splash_1786403750624.jpg';

interface SplashScreenProps {
  language: Language;
  onEnterGame: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  language,
  onEnterGame,
}) => {
  const [progress, setProgress] = useState<number>(0);
  const [isLoaded, setIsLoaded] = useState<boolean>(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsLoaded(true);
          return 100;
        }
        // Organic loading speed increase
        const step = Math.floor(Math.random() * 12) + 6;
        return Math.min(100, prev + step);
      });
    }, 180);

    return () => clearInterval(interval);
  }, []);

  const handleStart = () => {
    soundManager.playClick();
    onEnterGame();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 z-50 w-full h-full bg-slate-950 flex flex-col justify-between select-none overflow-hidden"
    >
      {/* Edge-to-Edge Background Image */}
      <div className="absolute inset-0 bg-gradient-to-b from-amber-950 via-slate-900 to-slate-950">
        <img
          src={splashImg}
          alt="Royal Chess Kurd Splash"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center filter brightness-105 contrast-105"
        />
        {/* Subtle Vignette and Lighting Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-amber-950/40 pointer-events-none" />
      </div>

      {/* Top Floating Header & Logo Shield */}
      <div className="relative z-10 pt-2 px-6 max-w-md w-full mx-auto flex flex-col items-center gap-2">
        {/* Top Status Bar (Version Tag Only) */}
        <div className="flex justify-end items-center w-full">
          <div className="text-[11px] font-mono font-bold text-amber-200/90 bg-black/60 backdrop-blur-md px-2.5 py-0.5 rounded-lg border border-amber-500/30 shadow-lg">
            v2.4.0
          </div>
        </div>

        {/* Top Logo Shield - "ROYAL CHESS KURD" (Moved Higher Up & Compact) */}
        <motion.div
          initial={{ scale: 0.85, y: -15, opacity: 0 }}
          animate={{ scale: 0.9, y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.5, type: 'spring', stiffness: 120 }}
          className="relative flex flex-col items-center max-w-xs w-full -mt-2"
        >
          {/* Compact Crown Emblem */}
          <motion.div 
            animate={{ y: [0, -3, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
            className="w-11 h-9 -mb-2 z-20 filter drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)]"
          >
            <svg viewBox="0 0 100 80" className="w-full h-full">
              <defs>
                <linearGradient id="splashCrownGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fff2a8" />
                  <stop offset="40%" stopColor="#eab308" />
                  <stop offset="100%" stopColor="#854d0e" />
                </linearGradient>
              </defs>
              <path
                d="M 12 70 L 20 25 L 38 48 L 50 15 L 62 48 L 80 25 L 88 70 Z"
                fill="url(#splashCrownGrad)"
                stroke="#fef08a"
                strokeWidth="3"
              />
              <circle cx="20" cy="23" r="5" fill="#ef4444" />
              <circle cx="50" cy="13" r="6" fill="#3b82f6" stroke="#fef08a" strokeWidth="2" />
              <circle cx="80" cy="23" r="5" fill="#10b981" />
              <rect x="10" y="68" width="80" height="12" rx="4" fill="url(#splashCrownGrad)" stroke="#fef08a" strokeWidth="2" />
            </svg>
          </motion.div>

          {/* Main Shield / Compact Frame Box */}
          <div className="relative w-full px-5 py-2 rounded-2xl bg-gradient-to-b from-[#b91c1c] via-[#991b1b] to-[#450a0a] border-3 border-[#eab308] shadow-[0_10px_30px_rgba(0,0,0,0.9),0_0_20px_rgba(234,179,8,0.4)] flex flex-col items-center overflow-hidden">
            {/* Continuous Light Shimmer Sweep Animation */}
            <motion.div
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut', repeatDelay: 0.8 }}
              className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/40 to-transparent transform -skew-x-12 pointer-events-none"
            />
            {/* Inner Decorative Line */}
            <div className="absolute inset-1 rounded-xl border border-amber-300/30 pointer-events-none" />

            <h1 className="text-xl sm:text-2xl font-black text-amber-200 tracking-wider drop-shadow-[0_3px_6px_rgba(0,0,0,0.9)] font-serif uppercase z-10">
              ROYAL CHESS
            </h1>
          </div>

          {/* Banner "KURD" underneath */}
          <div className="-mt-2.5 z-20 px-4 py-0.5 rounded-md bg-gradient-to-r from-red-600 via-amber-500 to-emerald-600 border border-amber-300 shadow-[0_6px_16px_rgba(0,0,0,0.85)]">
            <span className="text-[11px] font-black text-white tracking-widest uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
              KURD
            </span>
          </div>
        </motion.div>
      </div>

      {/* Spacer for clear center view of background artwork */}
      <div className="my-auto" />

      {/* Bottom Loading Progress Bar & Ultra 3D Prettier Start Button Section */}
      <div className="relative z-10 pb-8 px-6 max-w-md w-full mx-auto flex flex-col items-center">
        {!isLoaded ? (
          <div className="w-full flex flex-col items-center gap-2.5">
            <div className="flex items-center justify-between w-full text-xs font-bold text-amber-200/90 tracking-wide">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                {language === 'ku' ? 'چاوەڕێ بە...' : 'Loading...'}
              </span>
              <span className="font-mono text-base font-black text-amber-300">
                {progress}%
              </span>
            </div>

            {/* Glowing Blue Bar */}
            <div className="w-full h-4 rounded-full bg-slate-900/90 border-2 border-amber-500/60 p-0.5 shadow-[inset_0_2px_6px_rgba(0,0,0,0.9)] overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-sky-500 via-blue-500 to-cyan-300 shadow-[0_0_14px_rgba(56,189,248,0.9)]"
                style={{ width: `${progress}%` }}
                transition={{ ease: 'easeOut' }}
              />
            </div>
          </div>
        ) : (
          <motion.button
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: [1, 1.03, 1], opacity: 1 }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.96, y: 1 }}
            onClick={handleStart}
            className="w-full relative py-4 sm:py-4.5 rounded-3xl bg-gradient-to-b from-[#fef08a] via-[#f59e0b] to-[#b45309] border-3 border-yellow-200 text-amber-950 font-black text-lg sm:text-xl tracking-wider shadow-[0_12px_35px_rgba(245,158,11,0.85),0_0_25px_rgba(254,240,138,0.6)] flex items-center justify-center gap-3 cursor-pointer overflow-hidden group"
          >
            {/* Shimmer Sweep Effect */}
            <motion.div
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut', repeatDelay: 0.5 }}
              className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/70 to-transparent transform -skew-x-12 pointer-events-none"
            />
            
            {/* Inner Gold Bevel Ring */}
            <div className="absolute inset-1 rounded-2xl border border-yellow-100/60 pointer-events-none" />

            <span className="text-2xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]">♟️</span>
            <span className="drop-shadow-[0_2px_4px_rgba(255,255,255,0.7)] uppercase font-extrabold">
              {language === 'ku' ? 'دەستپێکردنی یاری' : 'ENTER GAME'}
            </span>
            <span className="text-xl font-black bg-amber-950/90 text-yellow-300 w-8 h-8 rounded-full flex items-center justify-center border border-yellow-200/80 shadow-inner group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform">
              ➔
            </span>
          </motion.button>
        )}
      </div>
    </motion.div>
  );
};
