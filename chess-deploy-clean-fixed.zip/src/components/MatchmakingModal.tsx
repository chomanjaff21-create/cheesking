import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Search, CheckCircle2, Shield, Swords, Trophy, Flame, Sparkles } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';
import { ChessTable, CHESS_TABLES } from './TablesSelectionModal';
import { useRealtimeStore } from '../lib/realtime';
import { getOpponentProfile } from '../lib/profileService';

interface MatchmakingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMatchFound: (matchId: string, opponentProfile: any, assignedColor: 'w' | 'b') => void;
  language: Language;
  userProfile?: UserProfile;
  selectedTable?: ChessTable | null;
}

export const MatchmakingModal: React.FC<MatchmakingModalProps> = ({
  isOpen,
  onClose,
  onMatchFound,
  language,
  userProfile,
  selectedTable,
}) => {
  const table = selectedTable || CHESS_TABLES[0];
  const [seconds, setSeconds] = useState<number>(0);
  const [matchPhase, setMatchPhase] = useState<'searching' | 'vs_clash' | 'ready'>('searching');

  const [opponent, setOpponent] = useState({
    name: 'Rwanduz_Master',
    avatar: '♟️',
    level: 28,
    rating: 1450,
    countryFlag: '☀️',
  });

  const { socket, session, connectSocket } = useRealtimeStore();

  const matchPhaseRef = React.useRef(matchPhase);
  useEffect(() => {
    matchPhaseRef.current = matchPhase;
  }, [matchPhase]);

  // Ensure socket is connected when modal opens
  useEffect(() => {
    if (isOpen && (!socket || !socket.isOpen)) {
      connectSocket().catch(() => {});
    }
  }, [isOpen, socket, connectSocket]);

  const onCloseRef = React.useRef(onClose);
  const onMatchFoundRef = React.useRef(onMatchFound);
  const languageRef = React.useRef(language);

  useEffect(() => {
    onCloseRef.current = onClose;
    onMatchFoundRef.current = onMatchFound;
    languageRef.current = language;
  }, [onClose, onMatchFound, language]);

  useEffect(() => {
    if (!isOpen) {
      setSeconds(0);
      setMatchPhase('searching');
      return;
    }

    let isMounted = true;
    let activeSocketRef: any = null;

    const setupQueue = async () => {
      let currentSocket = socket;
      if (!currentSocket || !currentSocket.isOpen) {
        currentSocket = await connectSocket();
      }

      if (!isMounted || !isOpen) return;
      if (!currentSocket || !currentSocket.isOpen) {
         alert(languageRef.current === 'ku' ? 'نەتوانرا پەیوەندی بە سێرڤەرەوە بکرێت. ئینتەرنێتەکەت بپشکنە.' : 'Could not connect to server. Check your internet.');
         onCloseRef.current();
         return;
      }
      activeSocketRef = currentSocket;

      const username = session?.username || userProfile?.name || 'Player';
      currentSocket.joinQueue(String(table.id), username);

      currentSocket.onqueueerror = (evt: any) => {
        if (!isMounted) return;
        alert(evt.error || (languageRef.current === 'ku' ? 'پارەی پێویستت نییە بۆ ئەم مێزە' : 'Insufficient coins for this table'));
        onCloseRef.current();
      };

      currentSocket.onmatched = async (matched: any) => {
        if (!isMounted) return;
        console.log('[Matchmaking] Matched successfully:', matched);

        const profile = await getOpponentProfile(matched.opponent.userId).catch(() => null);
        if (isMounted) {
          setOpponent({
            name: matched.opponent.username || 'Opponent',
            avatar: profile?.avatar || '♟️',
            level: profile?.level || 1,
            rating: profile?.thisWeekRank ? parseInt(profile.thisWeekRank) || 1200 : 1200,
            countryFlag: profile?.countryFlag || '🌍',
          });
        }

        try {
          await currentSocket.joinMatch(matched.matchId);
          if (!isMounted) return;
          setMatchPhase('vs_clash');
          soundManager.playMove();

          setTimeout(() => {
            if (!isMounted) return;
            setMatchPhase('ready');
            setTimeout(() => {
              if (!isMounted) return;
              onMatchFoundRef.current(
                matched.matchId,
                { user_id: matched.opponent.userId, username: matched.opponent.username },
                matched.assignedColor
              );
            }, 600);
          }, 2000);
        } catch (err) {
          console.error('Error joining match:', err);
        }
      };
    };

    setupQueue();

    const interval = setInterval(() => {
      if (matchPhaseRef.current === 'searching') {
        setSeconds((prev) => {
          if (prev >= 60) {
            alert(languageRef.current === 'ku' ? 'هیچ یاریزانێک نەدۆزرایەوە، تکایە دووبارە هەوڵ بدەرەوە.' : 'No opponent found, please try again.');
            onCloseRef.current();
            return 0;
          }
          return prev + 1;
        });
      }
    }, 1000);

    return () => {
      isMounted = false;
      clearInterval(interval);
      if (activeSocketRef) {
        activeSocketRef.onmatched = null;
        activeSocketRef.onqueueerror = null;
        if (matchPhaseRef.current === 'searching') {
          activeSocketRef.leaveQueue();
        }
      }
    };
  }, [isOpen, socket, session, table.id, connectSocket, userProfile?.name]);

  if (!isOpen) return null;

  const isRtl = languageRef.current === 'ku';

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const formatMoney = (amount: number) => {
    if (amount >= 1000000000) return `${(amount / 1000000000).toFixed(0)}B $`;
    if (amount >= 1000000) return `${(amount / 1000000).toFixed(0)}M $`;
    if (amount >= 1000) return `${(amount / 1000).toFixed(0)}k $`;
    return `${amount} $`;
  };

  const player1Name = userProfile?.name || 'Player';
  const player1Level = userProfile?.level || 24;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/92 backdrop-blur-lg overflow-hidden">
        <motion.div
          initial={{ scale: 0.88, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.88, opacity: 0 }}
          className={`relative w-full max-w-md bg-gradient-to-b from-[#180e2b] via-[#0f091c] to-[#06030b] border-2 border-yellow-500/80 rounded-3xl p-5 sm:p-6 shadow-[0_0_60px_rgba(234,179,8,0.4)] text-amber-100 flex flex-col items-center text-center overflow-hidden ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header Bar */}
          <div className="w-full flex items-center justify-between mb-3 z-20">
            <button
              onClick={() => {
                soundManager.playClick();
                onCloseRef.current();
              }}
              className="p-2 rounded-xl bg-purple-950/70 hover:bg-purple-900 border border-purple-500/40 text-amber-200 transition cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-500/60 shadow">
              <span className="text-lg">{table.icon}</span>
              <span className="text-xs sm:text-sm font-black text-yellow-300">
                {isRtl ? table.nameKu : table.nameEn}
              </span>
            </div>

            <div className="w-8" />
          </div>

          {/* Table Prize Pool Banner */}
          <div className="w-full py-1.5 px-4 rounded-2xl bg-gradient-to-r from-amber-600/30 via-yellow-500/20 to-amber-600/30 border border-yellow-400/50 mb-4 flex items-center justify-between z-20">
            <span className="text-xs text-amber-200 font-bold">
              {isRtl ? 'تێچووی چوونە ژوور:' : 'Entry:'}{' '}
              <strong className="text-yellow-300 font-mono">{formatMoney(table.entryFee)}</strong>
            </span>
            <span className="text-xs text-emerald-300 font-extrabold flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-yellow-400 animate-pulse" />
              <span>{isRtl ? 'خەڵاتی سەرکەوتن:' : 'Prize:'}</span>
              <strong className="text-emerald-300 font-mono text-sm">{formatMoney(table.prizePool)}</strong>
            </span>
          </div>

          {/* PHASE 1: SEARCHING FOR OPPONENT */}
          {matchPhase === 'searching' && (
            <div className="w-full flex flex-col items-center my-2 z-20">
              <h3 className="text-lg sm:text-xl font-extrabold text-amber-100 flex items-center gap-2">
                <Search className="w-5 h-5 text-yellow-400 animate-spin" />
                <span>{isRtl ? 'گەڕان بەدوای ڕکابەر...' : 'Finding Opponent...'}</span>
              </h3>
              <p className="text-xs text-purple-300/80 mt-1">
                {isRtl ? 'دۆزینەوەی یاریزانی شایستە لە سەرانسەری جیهان' : 'Matching with online chess master'}
              </p>

              {/* Center Magnifying Glass Scanner Graphic */}
              <div className="relative my-6 w-full h-36 flex items-center justify-center">
                {/* Left Queen */}
                <motion.div
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 2.5, ease: 'easeInOut' }}
                  className="absolute left-8 text-5xl filter drop-shadow-[0_6px_10px_rgba(0,0,0,0.9)] opacity-70"
                >
                  ♛
                </motion.div>

                {/* Right Queen */}
                <motion.div
                  animate={{ y: [0, -6, 0] }}
                  transition={{ repeat: Infinity, duration: 2.5, ease: 'easeInOut', delay: 1.2 }}
                  className="absolute right-8 text-5xl filter drop-shadow-[0_6px_10px_rgba(0,0,0,0.9)] text-slate-800 opacity-80"
                >
                  ♛
                </motion.div>

                {/* Pulsing Aura Ring */}
                <motion.div
                  animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.8, 0.3] }}
                  transition={{ repeat: Infinity, duration: 1.8 }}
                  className="absolute w-28 h-28 rounded-full bg-yellow-500/20 border-2 border-yellow-400/50"
                />

                {/* Searching Radar Scanner */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 3, ease: 'linear' }}
                  className="w-24 h-24 rounded-full bg-gradient-to-b from-yellow-400/40 via-amber-600/20 to-transparent border-2 border-yellow-300 flex items-center justify-center shadow-2xl relative"
                >
                  <div className="w-full h-full rounded-full border border-cyan-300/30 flex items-center justify-center">
                    <span className="text-3xl text-yellow-300">♚</span>
                  </div>
                </motion.div>
              </div>

              {/* Timer */}
              <div className="bg-slate-950/90 border border-yellow-500/60 px-6 py-1.5 rounded-2xl font-mono text-lg font-black text-amber-300 tracking-wider mb-4 shadow-inner">
                {formatTimer(seconds)}
              </div>
            </div>
          )}

          {/* PHASE 2: EPIC VS CLASH ANIMATION */}
          {(matchPhase === 'vs_clash' || matchPhase === 'ready') && (
            <div className="w-full flex flex-col items-center my-1 z-20 overflow-hidden">
              <motion.div
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-emerald-500/20 border border-emerald-400 px-4 py-1 rounded-full text-emerald-300 font-extrabold text-xs mb-3 flex items-center gap-1.5 shadow-[0_0_20px_rgba(16,185,129,0.5)]"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 animate-bounce" />
                <span>{isRtl ? 'ڕکابەر دۆزرایەوە! ئامادەباشی یاری' : 'Opponent Found! Get Ready'}</span>
              </motion.div>

              {/* VS Collision Arena */}
              <div className="relative w-full py-4 flex items-center justify-between gap-2 my-2 overflow-hidden">
                {/* Background Lightning Shockwave */}
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: [1, 1.8, 1], opacity: [0.8, 0.2, 0.8] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="absolute inset-0 m-auto w-32 h-32 rounded-full bg-gradient-to-r from-red-500/30 via-yellow-400/40 to-blue-500/30 blur-md pointer-events-none"
                />

                {/* PLAYER 1 (YOU) - Flies in from Left */}
                <motion.div
                  initial={{ x: -180, opacity: 0, rotate: -15 }}
                  animate={{ x: 0, opacity: 1, rotate: 0 }}
                  transition={{ type: 'spring', stiffness: 180, damping: 14 }}
                  className="flex flex-col items-center flex-1 z-10"
                >
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-blue-600 via-indigo-700 to-slate-900 border-2 border-cyan-300 p-1 shadow-[0_0_25px_rgba(6,182,212,0.6)] flex items-center justify-center">
                    <span className="text-3xl sm:text-4xl filter drop-shadow">👑</span>
                    <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full border border-cyan-200">
                      LV.{player1Level}
                    </span>
                  </div>
                  <span className="text-xs sm:text-sm font-black text-cyan-200 mt-2 truncate max-w-[100px]">
                    {player1Name}
                  </span>
                  <span className="text-[10px] text-cyan-400 font-bold"> Rating: 1420 ☀️</span>
                </motion.div>

                {/* CENTER GLOWING METALLIC 3D VS EMBLEM */}
                <motion.div
                  initial={{ scale: 3, opacity: 0, rotate: 180 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{ delay: 0.25, type: 'spring', stiffness: 220, damping: 12 }}
                  className="relative z-20 shrink-0 mx-1"
                >
                  <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-b from-amber-300 via-red-600 to-amber-950 border-3 border-yellow-300 shadow-[0_0_35px_rgba(239,68,68,0.9)] flex items-center justify-center">
                    <motion.span
                      animate={{ scale: [1, 1.15, 1] }}
                      transition={{ repeat: Infinity, duration: 1 }}
                      className="text-xl sm:text-2xl font-black text-amber-100 drop-shadow-[0_4px_8px_rgba(0,0,0,0.9)] italic tracking-tighter"
                    >
                      VS
                    </motion.span>
                    <div className="absolute inset-0 rounded-full border-2 border-yellow-200/50 animate-ping pointer-events-none" />
                  </div>
                </motion.div>

                {/* PLAYER 2 (OPPONENT) - Flies in from Right */}
                <motion.div
                  initial={{ x: 180, opacity: 0, rotate: 15 }}
                  animate={{ x: 0, opacity: 1, rotate: 0 }}
                  transition={{ type: 'spring', stiffness: 180, damping: 14 }}
                  className="flex flex-col items-center flex-1 z-10"
                >
                  <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-b from-rose-600 via-red-800 to-slate-900 border-2 border-amber-300 p-1 shadow-[0_0_25px_rgba(244,63,94,0.6)] flex items-center justify-center">
                    <span className="text-3xl sm:text-4xl filter drop-shadow">♟️</span>
                    <span className="absolute -top-2 -right-2 bg-rose-600 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full border border-amber-200">
                      LV.{opponent.level}
                    </span>
                  </div>
                  <span className="text-xs sm:text-sm font-black text-amber-200 mt-2 truncate max-w-[100px]">
                    {opponent.name}
                  </span>
                  <span className="text-[10px] text-amber-400 font-bold"> Rating: {opponent.rating} {opponent.countryFlag}</span>
                </motion.div>
              </div>

              {/* COUNTDOWN TO MATCH START */}
              <div className="mt-3 py-2 px-6 rounded-2xl bg-gradient-to-r from-yellow-500/20 via-amber-500/40 to-yellow-500/20 border border-yellow-400/60 shadow-lg">
                <span className="text-xs font-black text-yellow-300 tracking-wider">
                  {isRtl ? 'دەستپێکردنی یاری لە 3 چرکەدا...' : 'Starting Match in 3s...'}
                </span>
              </div>
            </div>
          )}

          {/* Cancel Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              onCloseRef.current();
            }}
            className="w-full mt-2 py-2.5 rounded-2xl bg-gradient-to-b from-yellow-300 via-amber-400 to-amber-600 text-amber-950 font-black text-xs sm:text-sm border border-yellow-200 shadow-xl hover:brightness-110 active:scale-95 transition cursor-pointer z-20"
          >
            {isRtl ? 'پەشیمانبوونەوە' : 'Cancel'}
          </button>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
