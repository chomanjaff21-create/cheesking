import React from 'react';

interface LevelCrownProps {
  level: number;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showLevelNumber?: boolean;
  className?: string;
  redBackdrop?: boolean;
}

/**
 * Level Crown Badge component supporting Crown Tiers 1 to 12
 * Crown Tiers:
 * 1-3: Bronze Crown
 * 4-6: Silver Crown
 * 7-9: Gold Crown
 * 10: Diamond Crown (Cyan Glow)
 * 11: Ruby Crown (Crimson Glow)
 * 12: Royal Onyx Gold Flame Crown (Supreme Tier)
 */
export const LevelCrown: React.FC<LevelCrownProps> = ({
  level,
  size = 'md',
  showLevelNumber = true,
  className = '',
  redBackdrop = false,
}) => {
  // Map level (1..100) to Crown Tier (1..12)
  const crownTier = Math.min(12, Math.max(1, Math.ceil(level / 3)));

  const dimensions = {
    sm: { container: 'w-7 h-7', text: 'text-[9px]' },
    md: { container: 'w-9 h-9', text: 'text-[10px]' },
    lg: { container: 'w-12 h-12', text: 'text-xs' },
    xl: { container: 'w-16 h-16', text: 'text-sm' },
    '2xl': { container: 'w-20 h-20', text: 'text-base' },
  }[size];

  // Colors per crown tier
  const getCrownGradient = () => {
    if (crownTier <= 3) {
      // Bronze
      return {
        gradId: 'bronzeCrown',
        stop1: '#fcd34d',
        stop2: '#b45309',
        stop3: '#451a03',
        glow: 'drop-shadow-[0_2px_8px_rgba(180,83,9,0.7)]',
        border: '#fbbf24',
        textColor: 'text-amber-200',
        centerJewel: '#ef4444',
      };
    } else if (crownTier <= 6) {
      // Silver
      return {
        gradId: 'silverCrown',
        stop1: '#ffffff',
        stop2: '#94a3b8',
        stop3: '#334155',
        glow: 'drop-shadow-[0_2px_10px_rgba(148,163,184,0.8)]',
        border: '#f1f5f9',
        textColor: 'text-slate-100',
        centerJewel: '#3b82f6',
      };
    } else if (crownTier <= 9) {
      // Gold
      return {
        gradId: 'goldCrown',
        stop1: '#fef08a',
        stop2: '#eab308',
        stop3: '#713f12',
        glow: 'drop-shadow-[0_2px_12px_rgba(234,179,8,0.95)]',
        border: '#fef08a',
        textColor: 'text-yellow-100',
        centerJewel: '#e11d48',
      };
    } else if (crownTier === 10) {
      // Diamond Cyan
      return {
        gradId: 'diamondCrown',
        stop1: '#cffaff',
        stop2: '#06b6d4',
        stop3: '#083344',
        glow: 'drop-shadow-[0_2px_14px_rgba(6,182,212,0.95)]',
        border: '#e0f2fe',
        textColor: 'text-cyan-100',
        centerJewel: '#f43f5e',
      };
    } else if (crownTier === 11) {
      // Ruby Crimson
      return {
        gradId: 'rubyCrown',
        stop1: '#fecaca',
        stop2: '#dc2626',
        stop3: '#450a0a',
        glow: 'drop-shadow-[0_2px_14px_rgba(220,38,38,0.95)]',
        border: '#fca5a5',
        textColor: 'text-rose-100',
        centerJewel: '#eab308',
      };
    } else {
      // Tier 12: Royal Supreme Onyx & Gold Flame Crown
      return {
        gradId: 'supremeCrown',
        stop1: '#fffbeb',
        stop2: '#f59e0b',
        stop3: '#000000',
        glow: 'drop-shadow-[0_0_16px_rgba(251,191,36,0.95)]',
        border: '#fef08a',
        textColor: 'text-yellow-200',
        centerJewel: '#8b5cf6',
      };
    }
  };

  const style = getCrownGradient();

  return (
    <div className={`relative inline-flex items-center justify-center ${dimensions.container} ${className}`}>
      {/* Optional Red Velvet Backdrop (Unlocked via RP Level 20) */}
      {redBackdrop && (
        <div className="absolute inset-0 rounded-full bg-gradient-to-b from-rose-600 via-red-700 to-red-950 border-2 border-yellow-300 shadow-[0_0_15px_rgba(220,38,38,0.9)] -z-10 animate-pulse" />
      )}

      <svg viewBox="0 0 100 100" className={`w-full h-full ${style.glow}`}>
        <defs>
          <linearGradient id={style.gradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={style.stop1} />
            <stop offset="35%" stopColor={style.border} />
            <stop offset="70%" stopColor={style.stop2} />
            <stop offset="100%" stopColor={style.stop3} />
          </linearGradient>
          <linearGradient id={`${style.gradId}_shine`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#ffffff" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0.3" />
          </linearGradient>
        </defs>

        {/* Crown Shadow Base */}
        <path
          d="M 12 75 L 20 30 L 38 52 L 50 18 L 62 52 L 80 30 L 88 75 Z"
          fill="rgba(0,0,0,0.35)"
          transform="translate(1, 2)"
        />
        {/* Crown Main Body */}
        <path
          d="M 12 75 L 20 30 L 38 52 L 50 18 L 62 52 L 80 30 L 88 75 Z"
          fill={`url(#${style.gradId})`}
          stroke={style.border}
          strokeWidth="3.5"
          strokeLinejoin="round"
        />
        {/* Shiny Highlight Layer */}
        <path
          d="M 12 75 L 20 30 L 38 52 L 50 18 L 62 52 L 80 30 L 88 75 Z"
          fill={`url(#${style.gradId}_shine)`}
          style={{ mixBlendMode: 'overlay' }}
        />
        {/* Crown Jewels on tips */}
        <circle cx="20" cy="28" r="4.5" fill="#3b82f6" stroke={style.border} strokeWidth="1.5" />
        <circle cx="50" cy="16" r="6.5" fill={style.centerJewel} stroke="#fef08a" strokeWidth="2" />
        <circle cx="80" cy="28" r="4.5" fill="#10b981" stroke={style.border} strokeWidth="1.5" />
        {/* Sparkle on top jewel */}
        <path d="M 50 11 L 51.5 14.5 L 54 15.5 L 51.5 16.5 L 50 20 L 48.5 16.5 L 46 15.5 L 48.5 14.5 Z" fill="#ffffff" />
        {/* Base Rim */}
        <rect x="10" y="72" width="80" height="14" rx="4" fill={`url(#${style.gradId})`} stroke={style.border} strokeWidth="2" />
        <rect x="12" y="74" width="76" height="4" rx="2" fill="#ffffff" fillOpacity="0.4" />
        {/* Gemstones on Base Rim */}
        <circle cx="25" cy="79" r="2.5" fill="#3b82f6" />
        <circle cx="50" cy="79" r="3" fill="#ef4444" />
        <circle cx="75" cy="79" r="2.5" fill="#10b981" />
      </svg>

      {/* Level Number Badge underneath crown */}
      {showLevelNumber && (
        <span
          className={`absolute -bottom-1 bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-700 border-2 border-yellow-200 text-amber-950 ${dimensions.text} font-black px-1.5 py-0.2 rounded-full shadow-md font-mono whitespace-nowrap`}
        >
          {level}
        </span>
      )}
    </div>
  );
};

