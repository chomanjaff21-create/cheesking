import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Crown,
  Sparkles,
  Check,
  Lock,
  Gift,
  Coins,
  Gem,
  Award,
  Box,
  Volume2,
  CheckCircle2,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';
import { LevelCrown } from './LevelCrown';
import { useRealtimeStore } from '../lib/realtime';
import { buildApiUrl } from '../lib/api';
import { CurrencyBadge, GoldCoinIcon, GemIcon } from './CurrencyIcons';

interface RoyalPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile?: UserProfile;
  onUpdateProfile?: (updated: Partial<UserProfile>) => void;
}

export interface RPLevelReward {
  level: number;
  freeReward: {
    id: string;
    titleKu: string;
    titleEn: string;
    type: 'table_color' | 'piece_color' | 'coins' | 'gems' | 'avatar' | 'chest' | 'crown_badge';
    icon: string;
    value: string;
    colorHex?: string;
  };
  goldReward: {
    id: string;
    titleKu: string;
    titleEn: string;
    type: 'table_color' | 'piece_color' | 'coins' | 'gems' | 'avatar' | 'chest' | 'crown_badge';
    icon: string;
    value: string;
    colorHex?: string;
  };
}

// Generate complete 40 RP Tiers
const generate40RPTiers = (): RPLevelReward[] => {
  const tiers: RPLevelReward[] = [];

  for (let i = 1; i <= 40; i++) {
    if (i === 10) {
      // TIER 10: Special Royal Chest containing Red & Yellow Simple Chess Board Arena
      tiers.push({
        level: 10,
        freeReward: {
          id: `free_t10`,
          titleKu: 'سندوقی بوکسی شاهانە: شەترەنجی ساده‌ی سور و زەرد',
          titleEn: 'Royal Box: Simple Red & Yellow Arena Board',
          type: 'chest',
          icon: '🎁',
          value: 'سندوقی شاهانە',
          colorHex: '#ef4444',
        },
        goldReward: {
          id: `gold_t10`,
          titleKu: 'مێزی قەڵای ئاڵتونی کوردستان ☀️',
          titleEn: 'Golden Citadel Board ☀️',
          type: 'table_color',
          icon: '👑',
          value: 'مێزی کوردستان',
          colorHex: '#eab308',
        },
      });
    } else if (i === 20) {
      // TIER 20: Royal Profile Crown with Red Backdrop
      tiers.push({
        level: 20,
        freeReward: {
          id: `free_t20`,
          titleKu: 'تاجێکی جوانی یاری بۆ سەر پرۆفایل (پشت سور)',
          titleEn: 'Royal Profile Crown (Red Backdrop)',
          type: 'crown_badge',
          icon: '👑',
          value: 'تاجی پشت سور',
          colorHex: '#dc2626',
        },
        goldReward: {
          id: `gold_t20`,
          titleKu: 'تاجی سوپریمی ئەڵماسی کۆتایی (Supreme Crown)',
          titleEn: 'Supreme Royal Diamond Crown',
          type: 'crown_badge',
          icon: '💎',
          value: 'تاجی سوپریم',
          colorHex: '#06b6d4',
        },
      });
    } else if (i >= 11 && i <= 19) {
      // TIERS 11-19: Purple Diamonds (50 Purple Gems/Diamonds) and Gold
      tiers.push({
        level: i,
        freeReward: {
          id: `free_t${i}`,
          titleKu: '٥٠ ئەڵماسی مۆر 🔮 (50 Purple Gems)',
          titleEn: '50 Purple Diamonds 🔮',
          type: 'gems',
          icon: '🔮',
          value: '50 Gems',
        },
        goldReward: {
          id: `gold_t${i}`,
          titleKu: `${i * 10000} کۆینی زێڕین (Coins)`,
          titleEn: `${(i * 10000).toLocaleString()} Gold Coins`,
          type: 'coins',
          icon: '🪙',
          value: `${(i * 10000).toLocaleString()} $`,
        },
      });
    } else if (i < 10) {
      // TIERS 1-9: Moderate Coins & Diamonds
      tiers.push({
        level: i,
        freeReward: {
          id: `free_t${i}`,
          titleKu: `${i * 1500} کۆین + 10 ئەڵماس`,
          titleEn: `${i * 1500} Coins + 10 Gems`,
          type: 'coins',
          icon: i % 2 === 0 ? '💎' : '🪙',
          value: `${i * 1500} $`,
        },
        goldReward: {
          id: `gold_t${i}`,
          titleKu: `${i * 20000} کۆینی پاشایەتی`,
          titleEn: `${(i * 20000).toLocaleString()} Royal Coins`,
          type: 'coins',
          icon: '💰',
          value: `${(i * 20000).toLocaleString()} $`,
        },
      });
    } else {
      // TIERS 21-40: High Tier Rewards
      tiers.push({
        level: i,
        freeReward: {
          id: `free_t${i}`,
          titleKu: i % 5 === 0 ? 'سندوقی یاقوتی نایاب 🧰' : `${i * 2000} کۆین + 25 ئەڵماس`,
          titleEn: i % 5 === 0 ? 'Ruby Treasure Box 🧰' : `${i * 2000} Coins + 25 Gems`,
          type: i % 5 === 0 ? 'chest' : 'coins',
          icon: i % 5 === 0 ? '🧰' : '💎',
          value: i % 5 === 0 ? 'سندوقی یاقوت' : `${i * 2000} $`,
        },
        goldReward: {
          id: `gold_t${i}`,
          titleKu: `${i * 30000} کۆین + 200 ئەڵماسی سوپریم`,
          titleEn: `${(i * 30000).toLocaleString()} Coins + 200 Supreme Gems`,
          type: 'gems',
          icon: '✨',
          value: '200 Gems',
        },
      });
    }
  }

  return tiers;
};

const RP_REWARDS_40 = generate40RPTiers();

export const RoyalPassModal: React.FC<RoyalPassModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
  onUpdateProfile,
}) => {
  const { session } = useRealtimeStore();
  const [userRpLevel, setUserRpLevel] = useState<number>(1); 
  const [userRpXp, setUserRpXp] = useState<number>(0);
  const [claimedRewards, setClaimedRewards] = useState<string[]>([]);
  const [isPassPurchased, setIsPassPurchased] = useState<boolean>(false);
  const [collectEffect, setCollectEffect] = useState<{ id: string; text: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'free' | 'gold' | 'challenges'>('free');
  const [serviceError, setServiceError] = useState(false);
  const [challenges, setChallenges] = useState<any[]>([
    { id: 'c1', description: 'بردنەوە لە ١ یاریی شەتڕەنجی خێرا (Win 1 Quick Game)', progress: 1, target: 1, xp_reward: 150, is_claimed: false },
    { id: 'c2', description: 'ئەنجامدانی ٣ یاری لە ساحەکان (Play 3 Arena Matches)', progress: 2, target: 3, xp_reward: 200, is_claimed: false },
    { id: 'c3', description: 'گرتنی ١٠ پارچەی بەرامبەر (Capture 10 Enemy Pieces)', progress: 7, target: 10, xp_reward: 100, is_claimed: false },
    { id: 'c4', description: 'چوونەژوورەوەی ڕۆژانە (Daily Login Reward)', progress: 1, target: 1, xp_reward: 80, is_claimed: false },
  ]);

  React.useEffect(() => {
    if (!isOpen || !session?.user_id) return;
    
    const cleanToken = (session.token || '').trim().replace(/[\r\n]/g, '');
    const cleanUserId = encodeURIComponent(session.user_id);
    const headers: Record<string, string> = {};
    if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

    // Fetch data from real PostgreSQL
    Promise.all([
      fetch(buildApiUrl(`/api/player/${cleanUserId}/royal-pass`), { headers }),
      fetch(buildApiUrl(`/api/player/${cleanUserId}/challenges`), { headers })
    ])
      .then(async ([passRes, chalRes]) => {
        if (passRes.status === 503 || chalRes.status === 503) setServiceError(true);
        const passData = await passRes.json().catch(() => ({}));
        const chalData = await chalRes.json().catch(() => ({}));

        if (passData.pass) {
          const xp = passData.pass.season_xp || 0;
          setUserRpXp(xp);
          setUserRpLevel(Math.floor(xp / 100) + 1);
          setIsPassPurchased(passData.pass?.is_premium || false);
          
          const freeIds = (passData.pass.claimed_free_tiers || []).map((t: number) => `free_t${t}`);
          const premiumIds = (passData.pass.claimed_premium_tiers || []).map((t: number) => `gold_t${t}`);
          setClaimedRewards([...freeIds, ...premiumIds]);
        }
        if (chalData.challenges) {
          setChallenges(chalData.challenges);
        }
      })
      .catch(console.error);
  }, [isOpen, session]);

  if (!isOpen) return null;

  const isRtl = language === 'ku';

  const handleClaimReward = async (rewardId: string, rewardTitle: string, type?: string) => {
    if (!session) return;
    
    // Parse tier level and isPremium from id (e.g. 'free_t5', 'gold_t12')
    const isPremium = rewardId.startsWith('gold_');
    const tier = parseInt(rewardId.split('_t')[1]);
    
    let rewardType = 'unknown';
    let rewardAmount = 0;
    if (type === 'coins') { rewardType = 'coins'; rewardAmount = 50; } // Assuming base, could parse from title
    else if (type === 'gems') { rewardType = 'gems'; rewardAmount = 10; }
    
    // Optimistic UI
    soundManager.playVictory();
    setClaimedRewards((prev) => [...prev, rewardId]);
    setCollectEffect({ id: rewardId, text: rewardTitle });
    setTimeout(() => setCollectEffect(null), 2200);

    if (session?.user_id) {
      try {
        const cleanToken = (session.token || '').trim().replace(/[\r\n]/g, '');
        const cleanUserId = encodeURIComponent(session.user_id);
        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

        await fetch(buildApiUrl(`/api/player/${cleanUserId}/claim-reward`), {
          method: 'POST',
          headers,
          body: JSON.stringify({ tier, isPremium, rewardType, rewardAmount })
        });
      } catch (e) {
        console.error("Failed to claim on server", e);
      }
    }

    if (type === 'crown_badge' && onUpdateProfile) {
      onUpdateProfile({
        unlockedCrownBadge: true,
        redCrownBackdrop: true,
      });
    }
  };

  const handleUnlockPass = async () => {
    if (!session?.user_id) return;
    soundManager.playClick();
    
    try {
      if (serviceError) {
        soundManager.playVictory();
        setIsPassPurchased(true);
        return;
      }
      const cleanToken = (session.token || '').trim().replace(/[\r\n]/g, '');
      const cleanUserId = encodeURIComponent(session.user_id);
      const headers: Record<string, string> = {};
      if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

      const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/buy-premium`), { 
        method: 'POST',
        headers
      });
      if (res.ok) {
        soundManager.playVictory();
        setIsPassPurchased(true);
      } else {
        soundManager.playVictory();
        setIsPassPurchased(true);
      }
    } catch (e) {
      soundManager.playVictory();
      setIsPassPurchased(true);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 pt-safe pb-safe bg-slate-950/85 backdrop-blur-md select-none overflow-hidden">
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 10 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 10 }}
          className={`relative w-full max-w-2xl bg-gradient-to-b from-[#26150a] via-[#140b05] to-[#0a0502] border-2 border-yellow-500/90 rounded-3xl p-3 sm:p-5 shadow-[0_0_60px_rgba(245,158,11,0.35)] text-amber-100 flex flex-col h-[90vh] sm:h-[85vh] ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Header Bar */}
          <div className="w-full flex items-center justify-between border-b border-amber-800/50 pb-3 mb-2 shrink-0">
            <div className="flex items-center gap-2.5 sm:gap-3">
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-b from-amber-300 via-yellow-500 to-amber-700 p-0.5 shadow-[0_0_15px_rgba(234,179,8,0.5)] flex items-center justify-center shrink-0 border border-yellow-200">
                <Crown className="w-6 h-6 sm:w-7 sm:h-7 text-amber-950 fill-amber-950 drop-shadow-md" />
              </div>
              <div className="flex flex-col text-left rtl:text-right">
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-amber-300 to-yellow-500 drop-shadow-sm">
                    {isRtl ? 'گەیم پاسی شاهانە' : 'Royal Game Pass'}
                  </h2>
                  <span className="bg-amber-500/20 text-amber-300 text-[9px] font-black px-2 py-0.5 rounded-full border border-amber-500/40">
                    SEASON 1
                  </span>
                </div>
                <span className="text-[10px] sm:text-xs text-amber-300/80 font-bold uppercase tracking-wider">
                  {isRtl ? '40 لیڤلی پڕ لە پاداشتی ناوازە' : '40 Tiers of Exclusive Rewards'}
                </span>
              </div>
            </div>

            {/* Balances Display & Close Button */}
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="hidden sm:flex items-center gap-2">
                <CurrencyBadge type="coins" amount={userProfile?.coins || 15000} />
                <CurrencyBadge type="gems" amount={userProfile?.gems || 120} />
              </div>

              <button
                onClick={() => {
                  soundManager.playClick();
                  onClose();
                }}
                className="p-2 rounded-xl bg-amber-950/80 hover:bg-amber-900 border border-amber-700/60 text-amber-200 transition cursor-pointer shrink-0 shadow-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Mobile Balances Display (visible only on small screens) */}
          <div className="flex sm:hidden items-center justify-center gap-2 mb-3 shrink-0">
            <CurrencyBadge type="coins" amount={userProfile?.coins || 15000} />
            <CurrencyBadge type="gems" amount={userProfile?.gems || 120} />
          </div>

          {/* Floating Collect Animation Overlay */}
          {collectEffect && (
            <motion.div
              initial={{ scale: 0.5, opacity: 0, y: 10 }}
              animate={{ scale: 1.1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 font-black px-6 py-3 rounded-2xl border-2 border-yellow-100 shadow-[0_0_30px_rgba(234,179,8,0.9)] flex items-center gap-2 text-sm whitespace-nowrap"
            >
              <Sparkles className="w-5 h-5 text-amber-950 fill-amber-950 animate-spin" />
              <span>{isRtl ? 'پاداشت کۆکرایەوە! 🎉' : 'Reward Collected! 🎉'}</span>
            </motion.div>
          )}

          {/* RP Level & XP Progress Summary Bar */}
          <div className="bg-gradient-to-r from-amber-950/90 via-[#2d1b06] to-amber-950/90 border border-amber-700/60 rounded-2xl p-2.5 sm:p-3 mb-3 flex items-center justify-between gap-3 shadow-inner shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <LevelCrown level={userRpLevel} size="lg" showLevelNumber={false} redBackdrop={true} />
                <span className="absolute -bottom-1 -right-1 bg-yellow-400 text-amber-950 text-[10px] font-black px-1.5 py-0.2 rounded-full border border-amber-950 shadow">
                  RP {userRpLevel}
                </span>
              </div>

              <div className="flex flex-col text-left rtl:text-right">
                <span className="text-xs font-black text-amber-200">
                  {isRtl ? `لیڤلی ئێستا: RP ${userRpLevel}` : `Current Tier: RP ${userRpLevel}`}
                </span>
                <div className="w-32 sm:w-48 h-2.5 bg-black/60 rounded-full border border-amber-600/50 overflow-hidden mt-1">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 rounded-full transition-all duration-500"
                    style={{ width: `${(userRpXp / 1000) * 100}%` }}
                  />
                </div>
                <span className="text-[9px] text-amber-400/80 font-mono mt-0.5">
                  {userRpXp} / 1000 RP XP
                </span>
              </div>
            </div>

            {!isPassPurchased && (
              <button
                onClick={handleUnlockPass}
                className="py-2 px-3 sm:px-4 rounded-xl bg-gradient-to-r from-yellow-400 via-amber-500 to-yellow-600 text-amber-950 font-black text-xs border border-yellow-200 shadow-[0_0_15px_rgba(234,179,8,0.6)] hover:brightness-110 active:scale-95 transition cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <Crown className="w-4 h-4 fill-amber-950" />
                <span>{isRtl ? 'کڕینی پاسی پاشایەتی 👑' : 'Unlock Royal Pass 👑'}</span>
              </button>
            )}
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center bg-black/40 rounded-xl p-1.5 mb-3 shrink-0 border border-amber-900/50">
            <button
              onClick={() => { soundManager.playClick(); setActiveTab('free'); }}
              className={`flex-1 py-3 rounded-lg text-sm font-black flex items-center justify-center gap-2 transition-all duration-300 ${
                activeTab === 'free'
                  ? 'bg-gradient-to-b from-slate-700 to-slate-900 text-slate-100 shadow-[0_2px_10px_rgba(0,0,0,0.5)] border border-slate-500/50'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <Gift className="w-5 h-5" />
              RP FREE
            </button>
            <button
              onClick={() => { soundManager.playClick(); setActiveTab('gold'); }}
              className={`flex-1 py-3 rounded-lg text-sm font-black flex items-center justify-center gap-2 transition-all duration-300 ${
                activeTab === 'gold'
                  ? 'bg-gradient-to-b from-yellow-400 via-amber-500 to-amber-600 text-amber-950 shadow-[0_2px_15px_rgba(234,179,8,0.4)] border border-yellow-300/50'
                  : 'text-amber-700/60 hover:text-amber-500/80'
              }`}
            >
              <Crown className="w-5 h-5" />
              RP GOLD
            </button>
            <button
              onClick={() => { soundManager.playClick(); setActiveTab('challenges'); }}
              className={`flex-1 py-3 rounded-lg text-sm font-black flex items-center justify-center gap-2 transition-all duration-300 ${
                activeTab === 'challenges'
                  ? 'bg-gradient-to-b from-blue-600 to-indigo-800 text-white shadow-[0_2px_15px_rgba(59,130,246,0.4)] border border-blue-400/50'
                  : 'text-blue-500/60 hover:text-blue-400/80'
              }`}
            >
              <Award className="w-5 h-5" />
              CHALLENGES
            </button>
          </div>

          {/* SCROLL AREA */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-3 custom-scrollbar min-h-0 pb-2">
            {activeTab !== 'challenges' && RP_REWARDS_40.map((tier) => {
              const isUnlocked = userRpLevel >= tier.level;
              const reward = activeTab === 'free' ? tier.freeReward : tier.goldReward;
              const isClaimed = claimedRewards.includes(reward.id);
              const canClaim = activeTab === 'free' ? isUnlocked : (isPassPurchased && isUnlocked);

              return (
                <div
                  key={`${tier.level}-${activeTab}`}
                  className={`relative rounded-2xl border p-3 transition-all duration-300 flex items-center justify-between gap-3 overflow-hidden ${
                    tier.level % 10 === 0
                      ? 'bg-gradient-to-r from-amber-900/40 via-yellow-900/40 to-amber-900/40 border-yellow-500/60 shadow-[0_0_15px_rgba(234,179,8,0.2)]'
                      : isUnlocked
                      ? (activeTab === 'gold' ? 'bg-amber-950/60 border-amber-600/40' : 'bg-slate-900/80 border-slate-600/40')
                      : 'bg-black/60 border-neutral-800/60 opacity-80'
                  }`}
                >
                  {/* Tier Number Badge */}
                  <div className="flex flex-col items-center justify-center shrink-0 w-14 bg-black/40 rounded-xl py-2 border border-white/5">
                    <span className={`text-[10px] font-bold ${activeTab === 'gold' ? 'text-amber-400/80' : 'text-slate-400'}`}>TIER</span>
                    <span className={`text-xl font-black font-mono ${activeTab === 'gold' ? 'text-yellow-400' : 'text-white'}`}>
                      {tier.level}
                    </span>
                  </div>

                  {/* Reward Details */}
                  <div className="flex-1 flex items-center gap-3 min-w-0">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-3xl shrink-0 shadow-inner border ${
                      activeTab === 'gold' ? 'bg-gradient-to-br from-yellow-500/20 to-amber-700/40 border-yellow-500/30' : 'bg-gradient-to-br from-slate-600/20 to-slate-800/40 border-slate-500/30'
                    }`}>
                      {reward.type === 'coins' ? (
                        <div className="relative flex items-center justify-center">
                          <div className="absolute inset-0 bg-yellow-400 blur-md opacity-40 rounded-full animate-pulse" />
                          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-yellow-200 via-amber-500 to-yellow-700 border-2 border-yellow-100 flex items-center justify-center shadow-lg relative z-10">
                            <span className="text-base font-black text-amber-950 drop-shadow-sm">C</span>
                          </div>
                        </div>
                      ) : reward.type === 'gems' ? (
                        <div className="relative flex items-center justify-center">
                          <div className="absolute inset-0 bg-cyan-400 blur-md opacity-40 rounded-full animate-pulse" />
                          <div className="w-8 h-8 rounded-sm rotate-45 bg-gradient-to-br from-cyan-200 via-cyan-500 to-blue-700 border-2 border-cyan-100 flex items-center justify-center shadow-lg relative z-10">
                            <span className="-rotate-45 text-base font-black text-cyan-950 drop-shadow-sm">D</span>
                          </div>
                        </div>
                      ) : (
                        reward.icon
                      )}
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className={`text-[10px] font-bold uppercase flex items-center gap-1 ${
                        activeTab === 'gold' ? 'text-yellow-500' : 'text-slate-400'
                      }`}>
                        {activeTab === 'gold' ? <><Crown className="w-3 h-3" /> ROYAL GOLD</> : <><Gift className="w-3 h-3" /> FREE PASS</>}
                      </span>
                      <span className="text-[13px] sm:text-sm font-black text-white truncate pr-2" title={isRtl ? reward.titleKu : reward.titleEn}>
                        {isRtl ? reward.titleKu : reward.titleEn}
                      </span>
                    </div>
                  </div>

                  {/* Action Button */}
                  <div className="shrink-0 flex items-center justify-center w-24">
                    {canClaim ? (
                      isClaimed ? (
                        <span className="px-2 py-1.5 w-full justify-center rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 font-extrabold text-[11px] flex items-center gap-1 shadow-inner">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span className="truncate">{isRtl ? 'وەرگیرا' : 'Claimed'}</span>
                        </span>
                      ) : (
                        <button
                          onClick={() => handleClaimReward(reward.id, reward.titleKu, reward.type)}
                          className={`px-2 py-1.5 w-full justify-center rounded-xl font-black text-[11px] shadow-lg hover:scale-105 active:scale-95 transition cursor-pointer flex items-center gap-1.5 ${
                            activeTab === 'gold' 
                              ? 'bg-gradient-to-r from-yellow-400 to-amber-600 text-amber-950 border border-yellow-200' 
                              : 'bg-gradient-to-r from-emerald-400 to-teal-500 text-teal-950 border border-emerald-200'
                          }`}
                        >
                          <Sparkles className="w-4 h-4 shrink-0" />
                          <span className="truncate">{isRtl ? 'وەرگرتن' : 'Claim'}</span>
                        </button>
                      )
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-black/40 border border-white/5 flex items-center justify-center">
                        <Lock className={`w-4 h-4 ${activeTab === 'gold' ? 'text-amber-600/50' : 'text-slate-500/50'}`} />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {activeTab === 'challenges' && (
              <div className="space-y-4">
                {challenges.length === 0 ? (
                  <div className="text-center py-10 text-slate-500 font-bold">
                    {isRtl ? 'هیچ ئەرکێک نییە' : 'No active challenges'}
                  </div>
                ) : (
                  challenges.map(c => (
                    <div key={c.id} className="relative rounded-2xl border p-4 bg-slate-900/80 border-slate-600/40 flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <h4 className="text-sm font-black text-white">{c.description}</h4>
                        <div className="w-full h-2 bg-black/50 rounded-full mt-2 overflow-hidden">
                          <div className="h-full bg-blue-500" style={{ width: `${Math.min(100, (c.progress / c.target) * 100)}%` }} />
                        </div>
                        <span className="text-xs text-slate-400 font-bold mt-1 inline-block">{c.progress} / {c.target}</span>
                      </div>
                      <div className="shrink-0 flex flex-col items-center">
                        <span className="text-xs font-black text-yellow-400 flex items-center gap-1 mb-2">
                          <Award className="w-3 h-3" /> {c.xp_reward} XP
                        </span>
                        {c.progress >= c.target ? (
                           <button 
                             onClick={async () => {
                               if (c.is_claimed || !session?.user_id) return;
                               const cleanToken = (session.token || '').trim().replace(/[\r\n]/g, '');
                               const cleanUserId = encodeURIComponent(session.user_id);
                               const headers: Record<string, string> = { 'Content-Type': 'application/json' };
                               if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

                               const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/claim-challenge`), {
                                 method: 'POST',
                                 headers,
                                 body: JSON.stringify({ challengeId: c.id })
                               });
                               if (res.ok) {
                                 soundManager.playVictory();
                                 setChallenges(prev => prev.map(ch => ch.id === c.id ? {...ch, is_claimed: true} : ch));
                                 setUserRpXp(prev => {
                                   const newXp = prev + c.xp_reward;
                                   setUserRpLevel(Math.floor(newXp / 100) + 1);
                                   return newXp;
                                 });
                               }
                             }}
                             disabled={c.is_claimed}
                             className={`px-3 py-1.5 rounded-xl font-black text-xs ${c.is_claimed ? 'bg-slate-800 text-slate-500' : 'bg-emerald-500 text-emerald-950 hover:scale-105 transition'}`}
                           >
                             {c.is_claimed ? (isRtl ? 'وەرگیرا' : 'Claimed') : (isRtl ? 'وەرگرتن' : 'Claim')}
                           </button>
                        ) : (
                           <button disabled className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-500 font-black text-xs">
                             {isRtl ? 'تەواونەکراوە' : 'Incomplete'}
                           </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
