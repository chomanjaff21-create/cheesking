import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { soundManager } from '../lib/soundManager';
import { Language } from '../types';

interface MatchStartCountdownOverlayProps {
  isActive: boolean;
  language: Language;
  onFinished: () => void;
}

export const MatchStartCountdownOverlay: React.FC<MatchStartCountdownOverlayProps> = ({
  isActive,
  language,
  onFinished,
}) => {
  const [stage, setStage] = useState<'3' | '2' | '1' | 'START' | null>(null);
  const onFinishedRef = useRef(onFinished);

  useEffect(() => {
    onFinishedRef.current = onFinished;
  }, [onFinished]);

  useEffect(() => {
    if (!isActive) {
      setStage(null);
      return;
    }

    // Step 1: 3 (Energetic, snappy)
    setStage('3');
    soundManager.playCountdownBeep(false);

    // Step 2: 2 at 1000ms
    const t2 = setTimeout(() => {
      setStage('2');
      soundManager.playCountdownBeep(false);
    }, 1000);

    // Step 3: 1 at 2000ms
    const t3 = setTimeout(() => {
      setStage('1');
      soundManager.playCountdownBeep(false);
    }, 2000);

    // Step 4: START! at 3000ms
    const tStart = setTimeout(() => {
      setStage('START');
      soundManager.playCountdownBeep(true);
    }, 3000);

    // Step 5: Finish and enter game immediately at 4000ms
    const tDone = setTimeout(() => {
      setStage(null);
      onFinishedRef.current();
    }, 4000);

    return () => {
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(tStart);
      clearTimeout(tDone);
    };
  }, [isActive]);

  if (!isActive || !stage) return null;

  const isKurdish = language === 'ku';

  return (
    <div
      id="match-start-countdown-overlay"
      className="absolute inset-0 z-40 flex items-center justify-center pointer-events-none select-none overflow-hidden"
    >
      {/* Cinematic dark blur vignette to focus visual attention on the board */}
      <div className="absolute inset-0 bg-slate-950/45 backdrop-blur-[2px] transition-opacity duration-300" />

      {/* Pulsing light rings */}
      <div className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-gradient-to-r from-amber-500/20 via-yellow-500/30 to-amber-600/20 animate-ping opacity-30" />

      <AnimatePresence mode="wait">
        {stage === '3' && (
          <motion.div
            key="count-3"
            initial={{ scale: 0.2, opacity: 0, rotate: -15 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            exit={{ scale: 1.6, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 380, damping: 22 }}
            className="relative flex flex-col items-center justify-center"
          >
            <div className="w-32 h-32 sm:w-44 sm:h-44 rounded-full bg-gradient-to-br from-rose-600 via-red-600 to-amber-900 border-4 border-amber-400 p-2 shadow-[0_0_60px_rgba(239,68,68,0.7)] flex items-center justify-center">
              <span className="text-7xl sm:text-9xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-b from-yellow-100 via-amber-200 to-yellow-400 drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
                {isKurdish ? '٣' : '3'}
              </span>
            </div>
            <span className="mt-3 text-sm sm:text-base font-black tracking-widest text-amber-200 uppercase drop-shadow">
              {isKurdish ? 'ئامادەبە...' : 'GET READY...'}
            </span>
          </motion.div>
        )}

        {stage === '2' && (
          <motion.div
            key="count-2"
            initial={{ scale: 0.2, opacity: 0, rotate: 15 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            exit={{ scale: 1.6, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 380, damping: 22 }}
            className="relative flex flex-col items-center justify-center"
          >
            <div className="w-32 h-32 sm:w-44 sm:h-44 rounded-full bg-gradient-to-br from-amber-500 via-yellow-600 to-amber-950 border-4 border-yellow-300 p-2 shadow-[0_0_60px_rgba(245,158,11,0.7)] flex items-center justify-center">
              <span className="text-7xl sm:text-9xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-b from-white via-yellow-200 to-amber-400 drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
                {isKurdish ? '٢' : '2'}
              </span>
            </div>
            <span className="mt-3 text-sm sm:text-base font-black tracking-widest text-yellow-200 uppercase drop-shadow">
              {isKurdish ? 'خۆت ڕێکبخە...' : 'STEADY...'}
            </span>
          </motion.div>
        )}

        {stage === '1' && (
          <motion.div
            key="count-1"
            initial={{ scale: 0.2, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 1.6, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 380, damping: 22 }}
            className="relative flex flex-col items-center justify-center"
          >
            <div className="w-32 h-32 sm:w-44 sm:h-44 rounded-full bg-gradient-to-br from-emerald-600 via-teal-700 to-emerald-950 border-4 border-emerald-300 p-2 shadow-[0_0_60px_rgba(16,185,129,0.7)] flex items-center justify-center">
              <span className="text-7xl sm:text-9xl font-black font-mono text-transparent bg-clip-text bg-gradient-to-b from-white via-emerald-100 to-emerald-300 drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
                {isKurdish ? '١' : '1'}
              </span>
            </div>
            <span className="mt-3 text-sm sm:text-base font-black tracking-widest text-emerald-200 uppercase drop-shadow">
              {isKurdish ? 'نزیکە...' : 'ALMOST...'}
            </span>
          </motion.div>
        )}

        {stage === 'START' && (
          <motion.div
            key="count-start"
            initial={{ scale: 0.3, opacity: 0, y: 30 }}
            animate={{ scale: [0.3, 1.15, 1], opacity: 1, y: 0 }}
            exit={{ scale: 1.8, opacity: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="relative flex flex-col items-center justify-center text-center px-6 py-4"
          >
            {/* Golden Starburst Flash Behind */}
            <div className="absolute w-80 h-80 sm:w-[480px] sm:h-[480px] bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-400/60 via-yellow-500/25 to-transparent rounded-full animate-pulse" />

            <div className="relative z-10 px-8 py-3.5 rounded-3xl bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-600 border-3 border-yellow-200 shadow-[0_0_80px_rgba(250,204,21,0.9)]">
              <h1 className="text-4xl sm:text-6xl font-black tracking-wider text-amber-950 drop-shadow-[0_2px_4px_rgba(255,255,255,0.8)]">
                {isKurdish ? 'دەست پێبکە!' : 'START!'}
              </h1>
            </div>
            <span className="relative z-10 mt-2 text-xs sm:text-sm font-black tracking-widest text-amber-300 drop-shadow">
              {isKurdish ? 'یاری دەستی پێکرد - بەختێکی باش!' : 'MATCH HAS STARTED - GOOD LUCK!'}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
