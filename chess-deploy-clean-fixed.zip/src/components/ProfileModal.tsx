import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  Edit2,
  Copy,
  Check,
  UserPlus,
  Trophy,
  Shield,
  Sparkles,
  Users,
  Camera,
  CheckCircle2,
  Ban,
  ShieldAlert,
  Coins,
  Swords,
  Award,
  Lock,
  Unlock,
  Gem,
  AlertCircle,
  Download,
  LogOut,
} from 'lucide-react';
import { Language, UserProfile, Friend } from '../types';
import { getTranslation } from '../lib/translations';
import { soundManager } from '../lib/soundManager';
import { LevelCrown } from './LevelCrown';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  userProfile: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
  onOpenLeaderboard?: () => void;
  onOpenRankBadges?: () => void;
  onChallengeFriend?: (friend: Friend) => void;
  onLogout?: () => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&q=80',
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&q=80',
];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  language,
  userProfile,
  onUpdateProfile,
  onOpenLeaderboard,
  onOpenRankBadges,
  onChallengeFriend,
  onLogout,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'edit'>('profile');
  const [friendSubTab, setFriendSubTab] = useState<'list' | 'blocked'>('list');
  const [copiedId, setCopiedId] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Edit profile form state
  const [editName, setEditName] = useState<string>(userProfile.name);
  const [editBio, setEditBio] = useState<string>(userProfile.bio);
  const [editAvatar, setEditAvatar] = useState<string>(userProfile.avatar);
  const [customAvatarUrl, setCustomAvatarUrl] = useState<string>('');

  // Add friend state
  const [friendIdInput, setFriendIdInput] = useState<string>('');

  const isRtl = language === 'ku';

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2800);
  };

  const handleCopyId = () => {
    soundManager.playClick();
    navigator.clipboard.writeText(userProfile.id);
    setCopiedId(true);
    showToast(getTranslation(language, 'copiedId'));
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleSaveProfile = () => {
    soundManager.playClick();
    const finalName = editName.trim() || userProfile.name;
    const finalAvatar = customAvatarUrl.trim() || editAvatar;
    const isNameChanged = finalName !== userProfile.name;

    // Check Name Change Rules:
    // First time is free. Subsequent times cost 500 Gems!
    if (isNameChanged && userProfile.hasChangedNameOnce) {
      const currentGems = userProfile.gems || 1250;
      if (currentGems < 500) {
        showToast(
          isRtl
            ? 'بڕی ئەڵماسەکەت بەش ناکات! ٥٠٠ ئەڵماس پێویستە 💎'
            : 'Insufficient Gems! 500 Diamonds required 💎'
        );
        return;
      }

      // Deduct 500 Gems for second+ name change
      onUpdateProfile({
        name: finalName,
        bio: editBio.trim() || userProfile.bio,
        avatar: finalAvatar,
        gems: currentGems - 500,
        nameChangeCount: (userProfile.nameChangeCount || 1) + 1,
      });

      showToast(
        isRtl
          ? 'ناو بە سەرکەوتوویی گۆڕدرا! (٥٠٠ ئەڵماس دابەزی) 💎'
          : 'Name changed! (500 Gems deducted) 💎'
      );
    } else {
      // Free first name change or no name change
      onUpdateProfile({
        name: finalName,
        bio: editBio.trim() || userProfile.bio,
        avatar: finalAvatar,
        hasChangedNameOnce: userProfile.hasChangedNameOnce || isNameChanged,
        nameChangeCount: isNameChanged ? 1 : userProfile.nameChangeCount || 0,
      });

      showToast(
        isNameChanged
          ? isRtl
            ? 'ناوی یەکەم بە خۆڕایی گۆڕدرا! ✨'
            : 'First name change was FREE! ✨'
          : getTranslation(language, 'saveChanges')
      );
    }

    setActiveTab('profile');
  };

  const handleToggleLockProfile = () => {
    soundManager.playClick();
    const newLockState = !userProfile.isLocked;
    onUpdateProfile({ isLocked: newLockState });
    showToast(
      newLockState
        ? isRtl
          ? 'پڕۆفایل قفلکرا! 🔒 (تەنها وێنە دیار دەبێت)'
          : 'Profile Locked! 🔒 (Only avatar visible)'
        : isRtl
        ? 'قفلکردنی پڕۆفایل لادرا 🔓'
        : 'Profile Unlocked 🔓'
    );
  };

  const handleAddFriend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendIdInput.trim()) return;

    soundManager.playClick();
    const newFriend: Friend = {
      id: friendIdInput.trim(),
      name: `Player_${friendIdInput.trim().slice(-4)}`,
      avatar: AVATAR_PRESETS[Math.floor(Math.random() * AVATAR_PRESETS.length)],
      level: Math.floor(Math.random() * 20) + 10,
      isOnline: true,
      statusText: 'Online',
    };

    onUpdateProfile({
      friends: [...(userProfile.friends || []), newFriend],
    });

    setFriendIdInput('');
    showToast(getTranslation(language, 'friendAdded'));
  };

  const handleBlockUser = (friend: Friend) => {
    soundManager.playClick();
    const updatedFriends = (userProfile.friends || []).filter((f) => f.id !== friend.id);
    const updatedBlocked = [...(userProfile.blockedUsers || []), { ...friend, isBlocked: true }];

    onUpdateProfile({
      friends: updatedFriends,
      blockedUsers: updatedBlocked,
    });

    showToast(isRtl ? `یاریزانەکە (${friend.name}) بلوککرا 🚫` : `User (${friend.name}) blocked 🚫`);
  };

  const handleUnblockUser = (blockedFriend: Friend) => {
    soundManager.playClick();
    const updatedBlocked = (userProfile.blockedUsers || []).filter((b) => b.id !== blockedFriend.id);
    const updatedFriends = [...(userProfile.friends || []), { ...blockedFriend, isBlocked: false }];

    onUpdateProfile({
      friends: updatedFriends,
      blockedUsers: updatedBlocked,
    });

    showToast(isRtl ? `بلوککردنی (${blockedFriend.name}) لادرا ✅` : `Unblocked (${blockedFriend.name}) ✅`);
  };

  if (!isOpen) return null;

  const userLevel = userProfile.level || 24;
  const userXp = userProfile.xp || 1450;
  const nextLevelXp = userProfile.nextLevelXp || 2000;
  const xpPercent = Math.min(100, Math.round((userXp / nextLevelXp) * 100));
  const userGems = userProfile.gems || 1250;
  const totalGamesNum = userProfile.totalGames || 148;
  const winsNum = userProfile.wins || Math.floor(totalGamesNum * 0.7);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 pt-16 pb-8 bg-black/85 backdrop-blur-md select-none overflow-y-auto">
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          className={`relative w-full max-w-sm rounded-[36px] p-1.5 shadow-[0_25px_60px_rgba(0,0,0,0.95)] mt-10 ${
            isRtl ? 'rtl' : 'ltr'
          }`}
          style={{
            background: 'linear-gradient(180deg, #f0b83e 0%, #b87b1c 40%, #613b02 100%)',
          }}
        >
          {/* Toast Notification Banner */}
          {toastMessage && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute -top-12 left-1/2 -translate-x-1/2 bg-amber-400 text-amber-950 font-black text-xs px-4 py-2 rounded-full border-2 border-yellow-100 shadow-2xl flex items-center gap-2 z-50 whitespace-nowrap"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-800 shrink-0" />
              <span>{toastMessage}</span>
            </motion.div>
          )}

          {/* Inner Golden Wood Box Frame */}
          <div className="relative w-full rounded-[30px] bg-gradient-to-b from-[#7a4213] via-[#4a2307] to-[#261001] border-2 border-[#d6982a] p-3.5 pt-14 text-amber-50 shadow-inner flex flex-col gap-3">
            {/* Top Left Close Button 'X' */}
            <button
              onClick={() => {
                soundManager.playClick();
                onClose();
              }}
              className="absolute top-3 left-3 w-10 h-10 rounded-full bg-gradient-to-b from-red-500 via-red-600 to-red-800 border-2 border-yellow-300 text-white shadow-[0_4px_10px_rgba(0,0,0,0.6)] flex items-center justify-center font-extrabold text-xl hover:scale-110 active:scale-95 transition cursor-pointer z-30"
            >
              <X className="w-6 h-6 stroke-[3]" />
            </button>

            {/* Top Right Edit Button (Pencil) */}
            <button
              onClick={() => {
                soundManager.playClick();
                setActiveTab(activeTab === 'edit' ? 'profile' : 'edit');
              }}
              className={`absolute top-3 right-3 w-10 h-10 rounded-full border-2 shadow-[0_4px_10px_rgba(0,0,0,0.6)] flex items-center justify-center font-bold hover:scale-110 active:scale-95 transition cursor-pointer z-30 ${
                activeTab === 'edit'
                  ? 'bg-gradient-to-b from-emerald-400 to-emerald-700 border-emerald-200 text-white'
                  : 'bg-gradient-to-b from-amber-400 via-amber-500 to-yellow-600 border-yellow-200 text-amber-950'
              }`}
            >
              <Edit2 className="w-5 h-5 stroke-[2.5]" />
            </button>

            {/* OVERLAPPING TOP AVATAR BADGE - FULLY VISIBLE & UNCROPPED */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
              <div
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('edit');
                }}
                className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-[#f0c85b] p-0.5 shadow-[0_10px_25px_rgba(0,0,0,0.8)] bg-amber-950 cursor-pointer group flex items-center justify-center overflow-visible"
              >
                {/* Full Profile Picture Display */}
                <div className="w-full h-full rounded-full overflow-hidden border border-yellow-300/60 shadow-inner bg-amber-950 flex items-center justify-center">
                  <img
                    src={userProfile.avatar}
                    alt={userProfile.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition rounded-full">
                  <Camera className="w-6 h-6 text-yellow-300" />
                </div>

                {/* Level Crown Badge on Top of Avatar - CLEAN WITHOUT LEVEL TEXT */}
                <div className="absolute -top-5 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
                  <LevelCrown
                    level={userLevel}
                    size="lg"
                    showLevelNumber={false}
                    redBackdrop={userProfile.redCrownBackdrop}
                  />
                </div>

                {/* Level Tag Badge at Bottom */}
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
                  <span className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-600 text-amber-950 text-[10px] sm:text-[11px] font-black px-3 py-0.5 rounded-full border-2 border-yellow-200 shadow-lg font-mono whitespace-nowrap flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-950 fill-amber-950" />
                    <span>LV {userLevel}</span>
                  </span>
                </div>
              </div>
            </div>

            {/* TAB SELECTOR BAR (Profile / Edit) */}
            <div className="flex items-center justify-center gap-1 bg-amber-950/90 border border-amber-700/60 rounded-xl p-1 mt-5">
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('profile');
                }}
                className={`flex-1 py-1 px-2 rounded-lg font-black text-xs transition cursor-pointer ${
                  activeTab === 'profile'
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 shadow'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                {getTranslation(language, 'playerProfile')}
              </button>

              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveTab('edit');
                }}
                className={`flex-1 py-1 px-2 rounded-lg font-black text-xs transition cursor-pointer ${
                  activeTab === 'edit'
                    ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-amber-950 shadow'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                {getTranslation(language, 'editProfile')}
              </button>
            </div>

            {/* TAB 1: MAIN PROFILE VIEW WITH XP & LOCK STATS */}
            {activeTab === 'profile' && (
              <div className="flex flex-col gap-3">
                {/* PARCHMENT HEADER SCROLL CARD */}
                <div
                  className="relative rounded-2xl p-3 text-amber-950 shadow-inner border-2 border-[#b88022] flex flex-col items-center"
                  style={{
                    background: 'linear-gradient(180deg, #fff7dc 0%, #f7e3b0 50%, #edd18a 100%)',
                  }}
                >
                  <div className="w-full flex items-center justify-between">
                    {/* Lock Profile Toggle Button */}
                    <button
                      onClick={handleToggleLockProfile}
                      title={userProfile.isLocked ? 'Unlock Profile' : 'Lock Profile'}
                      className={`p-1.5 rounded-xl border font-bold text-[10px] flex items-center gap-1 transition shadow cursor-pointer ${
                        userProfile.isLocked
                          ? 'bg-rose-600 text-white border-rose-300'
                          : 'bg-amber-200 text-amber-900 border-amber-500 hover:bg-amber-300'
                      }`}
                    >
                      {userProfile.isLocked ? (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>{isRtl ? 'قفلکراو' : 'Locked'}</span>
                        </>
                      ) : (
                        <>
                          <Unlock className="w-3.5 h-3.5" />
                          <span>{isRtl ? 'قفلکردن' : 'Lock'}</span>
                        </>
                      )}
                    </button>

                    {/* ENLARGED COUNTRY FLAG PLAQUE */}
                    <div className="bg-gradient-to-r from-[#e0be77] to-[#fce8ba] border-2 border-[#b88d3d] rounded-xl px-3 py-1 shadow flex items-center gap-1.5">
                      <span className="text-xl sm:text-2xl drop-shadow">
                        {userProfile.countryFlag || '☀️ Kurdistan'}
                      </span>
                    </div>
                  </div>

                  <h2 className="text-xl sm:text-2xl font-black text-[#3d1e02] tracking-wide text-center drop-shadow-sm mt-1">
                    {userProfile.name}
                  </h2>

                  <p className="text-xs font-semibold text-[#734614] text-center mt-0.5 mb-2 px-2">
                    {userProfile.bio || 'Introduction'}
                  </p>

                  <div className="flex items-center gap-2 bg-[#e0be77]/80 border border-[#b88d3d] rounded-lg px-3 py-1 text-xs font-black text-[#422203]">
                    <span>
                      {getTranslation(language, 'id')}: {userProfile.id}
                    </span>
                    <button
                      onClick={handleCopyId}
                      title="Copy Player ID"
                      className="p-1 rounded bg-[#fce8ba] hover:bg-yellow-200 text-amber-950 transition cursor-pointer shadow-sm"
                    >
                      {copiedId ? (
                        <Check className="w-3.5 h-3.5 text-emerald-700 stroke-[3]" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 stroke-[2.5]" />
                      )}
                    </button>
                  </div>
                </div>

                {/* REALISTIC LEVEL XP PROGRESS BAR */}
                <div className="bg-gradient-to-r from-[#592b07] via-[#3a1b04] to-[#592b07] border-2 border-[#a86e1c] rounded-2xl p-3 flex flex-col gap-1.5 shadow-lg">
                  <div className="flex items-center justify-between text-xs font-extrabold text-amber-100">
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <span>{isRtl ? 'ئەزموونی لیڤل (XP Progress)' : 'Level Experience (XP)'}</span>
                    </span>
                    <span className="text-yellow-300 font-mono text-[11px]">
                      {userXp} / {nextLevelXp} XP ({xpPercent}%)
                    </span>
                  </div>

                  {/* Golden XP Fill Bar */}
                  <div className="w-full h-3 bg-black/60 rounded-full border border-amber-600/60 overflow-hidden p-0.5">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${xpPercent}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                      className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 rounded-full shadow-[0_0_10px_rgba(234,179,8,0.8)]"
                    />
                  </div>
                </div>

                {/* GAME STATISTICS SECTION (Obscured if Profile Locked) */}
                {userProfile.isLocked ? (
                  <div className="bg-[#3a1b04]/90 border border-amber-700/60 rounded-2xl p-6 text-center text-amber-200/80 flex flex-col items-center gap-2">
                    <Lock className="w-8 h-8 text-yellow-400 animate-pulse" />
                    <span className="font-extrabold text-sm">
                      {isRtl
                        ? 'ئەم پڕۆفایلە قفلکراوە. زانیارییەکان شارراونەتەوە'
                        : 'This profile is locked. Statistics hidden.'}
                    </span>
                  </div>
                ) : (
                  <div className="bg-[#3a1b04]/90 border border-amber-700/60 rounded-2xl p-3 flex flex-col gap-2 shadow-inner">
                    <div className="text-xs font-black text-amber-200/90 tracking-wider uppercase flex items-center justify-between">
                      <span>{getTranslation(language, 'gameStats')}</span>
                      <span className="text-[10px] text-yellow-400/90 font-mono">🏆 2,850 Trophies</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      {/* Total Games Played */}
                      <div className="bg-gradient-to-b from-[#693108] to-[#451e03] border border-[#a86e1c] rounded-xl p-2.5 flex items-center justify-between shadow">
                        <div className="flex flex-col text-left rtl:text-right">
                          <span className="text-[10px] font-bold text-amber-300">
                            {isRtl ? 'تێکڕای یارییەکان' : 'Total Games'}
                          </span>
                          <span className="text-base font-black text-yellow-300 font-mono">
                            {totalGamesNum}
                          </span>
                        </div>
                        <Swords className="w-5 h-5 text-amber-400" />
                      </div>

                      {/* Total Wins */}
                      <div className="bg-gradient-to-b from-[#693108] to-[#451e03] border border-[#a86e1c] rounded-xl p-2.5 flex items-center justify-between shadow">
                        <div className="flex flex-col text-left rtl:text-right">
                          <span className="text-[10px] font-bold text-emerald-300">
                            {isRtl ? 'یارییە براوەکان' : 'Matches Won'}
                          </span>
                          <span className="text-base font-black text-emerald-400 font-mono">
                            {winsNum}
                          </span>
                        </div>
                        <Trophy className="w-5 h-5 text-yellow-400" />
                      </div>

                      {/* Win Rate */}
                      <div className="bg-gradient-to-b from-[#693108] to-[#451e03] border border-[#a86e1c] rounded-xl p-2.5 flex items-center justify-between shadow">
                        <div className="flex flex-col text-left rtl:text-right">
                          <span className="text-[10px] font-bold text-amber-300">
                            {getTranslation(language, 'winRate')}
                          </span>
                          <span className="text-sm font-black text-yellow-300 font-mono">
                            {userProfile.winRate || '70.2%'}
                          </span>
                        </div>
                        <Award className="w-5 h-5 text-cyan-400" />
                      </div>

                      {/* Total Gems / Diamonds */}
                      <div className="bg-gradient-to-b from-[#693108] to-[#451e03] border border-[#a86e1c] rounded-xl p-2.5 flex items-center justify-between shadow">
                        <div className="flex flex-col text-left rtl:text-right">
                          <span className="text-[10px] font-bold text-purple-300">
                            {isRtl ? 'ئەڵماس (Gems 💎)' : 'Diamonds'}
                          </span>
                          <span className="text-sm font-black text-purple-300 font-mono truncate">
                            {userGems.toLocaleString()} 💎
                          </span>
                        </div>
                        <Gem className="w-5 h-5 text-purple-400" />
                      </div>
                    </div>
                  </div>
                )}

                {/* BOTTOM ACTION BUTTONS: Conquest Rank Badges, Leaderboard & Logout */}
                <div className="flex flex-col gap-2 mt-1">
                  {onOpenRankBadges && (
                    <button
                      onClick={() => {
                        soundManager.playClick();
                        onOpenRankBadges();
                      }}
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 border-2 border-yellow-200 text-amber-950 font-black text-xs shadow-lg flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 transition cursor-pointer"
                    >
                      <Trophy className="w-4 h-4 text-amber-950 fill-amber-950" />
                      <span>{isRtl ? 'پلە و مدالیاکانی یاریزان (٢٠ پلەی سەرکەوتن 🏆)' : 'Conquest Badges (20 Ranks 🏆)'}</span>
                    </button>
                  )}

                  {onOpenLeaderboard && (
                    <button
                      onClick={() => {
                        soundManager.playClick();
                        onOpenLeaderboard();
                      }}
                      className="w-full py-2 rounded-xl bg-gradient-to-r from-amber-700 via-amber-600 to-amber-800 border border-amber-400 text-amber-100 font-bold text-xs shadow flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 transition cursor-pointer"
                    >
                      <Award className="w-4 h-4 text-yellow-300" />
                      <span>{isRtl ? 'تەختەی پێشەنگەکان (Leaderboard)' : 'Open Leaderboard'}</span>
                    </button>
                  )}

                  {onLogout && (
                    <button
                      onClick={() => {
                        soundManager.playClick();
                        onClose();
                        onLogout();
                      }}
                      className="w-full py-2.5 rounded-xl bg-gradient-to-r from-red-700 via-rose-600 to-red-800 border border-red-400 text-white font-black text-xs shadow-lg flex items-center justify-center gap-2 hover:brightness-110 active:scale-95 transition cursor-pointer mt-1"
                    >
                      <LogOut className="w-4 h-4 text-red-200" />
                      <span>{isRtl ? 'دەرچوون لە هەژمار (Log Out)' : 'Log Out Account'}</span>
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: EDIT PROFILE FORM */}
            {activeTab === 'edit' && (
              <div className="flex flex-col gap-3 py-1">
                <h3 className="text-center font-black text-amber-200 text-sm uppercase tracking-wider">
                  {getTranslation(language, 'editProfile')}
                </h3>

                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-amber-300">
                      {getTranslation(language, 'changeName')}
                    </label>
                    <span className="text-[10px] font-extrabold text-yellow-400 font-mono flex items-center gap-1">
                      {userProfile.hasChangedNameOnce ? (
                        <>
                          <Gem className="w-3 h-3 text-purple-400" />
                          <span>500 💎</span>
                        </>
                      ) : (
                        <span className="text-emerald-400">
                          {isRtl ? 'بۆ یەکەم جار: بە خۆڕایی FREE' : '1st Time: FREE'}
                        </span>
                      )}
                    </span>
                  </div>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-amber-950/90 border border-amber-600 rounded-xl px-3 py-2 text-amber-100 text-sm font-bold focus:outline-none focus:border-yellow-400 shadow-inner"
                    placeholder="Enter player name..."
                  />
                  {userProfile.hasChangedNameOnce && (
                    <span className="text-[10px] text-amber-300/70">
                      {isRtl
                        ? 'تێبینی: گۆڕینی ناو بۆ جارەکانی تر ٥٠٠ ئەڵماسی تێدەچێت'
                        : 'Note: Subsequent name changes cost 500 Diamonds'}
                    </span>
                  )}
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-amber-300">
                    {getTranslation(language, 'changeBio')}
                  </label>
                  <input
                    type="text"
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    className="w-full bg-amber-950/90 border border-amber-600 rounded-xl px-3 py-2 text-amber-100 text-sm font-medium focus:outline-none focus:border-yellow-400 shadow-inner"
                    placeholder="Enter bio / introduction..."
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-amber-300">
                    {getTranslation(language, 'changeAvatar')}
                  </label>
                  <div className="grid grid-cols-4 gap-2 bg-amber-950/80 p-2 rounded-xl border border-amber-700/60">
                    {AVATAR_PRESETS.map((url, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          soundManager.playClick();
                          setEditAvatar(url);
                          setCustomAvatarUrl('');
                        }}
                        className={`relative rounded-full aspect-square border-2 overflow-hidden transition cursor-pointer ${
                          editAvatar === url && !customAvatarUrl
                            ? 'border-yellow-400 scale-105 shadow-md'
                            : 'border-amber-800 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img src={url} alt={`Avatar ${idx}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>

                  <input
                    type="url"
                    value={customAvatarUrl}
                    onChange={(e) => setCustomAvatarUrl(e.target.value)}
                    className="w-full bg-amber-950/90 border border-amber-600/60 rounded-xl px-3 py-1.5 text-amber-200 text-xs focus:outline-none focus:border-yellow-400 shadow-inner mt-1"
                    placeholder="Or paste custom image URL..."
                  />
                </div>

                <button
                  onClick={handleSaveProfile}
                  disabled={false}
                  className={`w-full mt-2 py-2.5 rounded-xl bg-gradient-to-r from-yellow-500 via-amber-500 to-yellow-600 border border-yellow-200 text-amber-950 font-black text-sm shadow-xl hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer`}
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>{getTranslation(language, 'saveChanges')}</span>
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
