import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Eye,
  MessageSquare,
  Send,
  X,
  Volume2,
  VolumeX,
  Flame,
  RotateCcw,
  Camera,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';
import { LevelCrown } from './LevelCrown';

interface LiveSpectateOverlayProps {
  language: Language;
  userProfile?: UserProfile;
  whitePlayerName?: string;
  blackPlayerName?: string;
  whiteRating?: number;
  blackRating?: number;
  soundEnabled?: boolean;
  onToggleSound?: () => void;
  onExitSpectate: () => void;
  onResetCamera?: () => void;
  onToggleTopView?: () => void;
}

interface SpectatorComment {
  id: string;
  user: string;
  text: string;
  avatar: string;
  time: string;
}

interface FloatingEmoji {
  id: number;
  symbol: string;
  x: number;
}

export const LiveSpectateOverlay: React.FC<LiveSpectateOverlayProps> = ({
  language,
  userProfile,
  whitePlayerName = 'GM_Kasparov_AI',
  blackPlayerName = 'Master_Onyx_Bot',
  whiteRating = 2150,
  blackRating = 2080,
  soundEnabled = true,
  onToggleSound,
  onExitSpectate,
  onResetCamera,
  onToggleTopView,
}) => {
  const [viewersCount, setViewersCount] = useState<number>(1485);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatComments, setChatComments] = useState<SpectatorComment[]>([
    {
      id: 'c1',
      user: 'Hawler_King',
      text: 'جوڵەیەکی زۆر مەترسیدار بوو! 🔥',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=100&q=80',
      time: 'Just now',
    },
    {
      id: 'c2',
      user: 'Sulaimani_Queen',
      text: 'Awesome Queen move! ♟️✨',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      time: '1s ago',
    },
    {
      id: 'c3',
      user: 'Rwanduz_Tactician',
      text: 'دەستخۆش مامۆستا جێمینای 👏',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      time: '3s ago',
    },
  ]);

  const [inputMsg, setInputMsg] = useState('');
  const [floatingEmojis, setFloatingEmojis] = useState<FloatingEmoji[]>([]);

  // Periodically simulate live viewers fluctuations & spectator comments
  useEffect(() => {
    const interval = setInterval(() => {
      setViewersCount((prev) => prev + Math.floor(Math.random() * 5) - 2);

      const botNames = ['Kurdish_Knight', 'Duhok_Chess', 'Halabja_Pro', 'Erbil_Master', 'Soran_Gamer'];
      const botAvatars = [
        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
        'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=100&q=80',
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80',
      ];
      const botComments = [
        'دەستخۆش! 👏',
        'What a knight jump! 🔥',
        'شاو و مات نزیکبووەوە 👑',
        'شەترەنجی ئۆنیکس تا بڵێی شازە! 😍',
        'Great tactic! ♟️',
      ];

      const randomName = botNames[Math.floor(Math.random() * botNames.length)];
      const randomAvatar = botAvatars[Math.floor(Math.random() * botAvatars.length)];
      const randomText = botComments[Math.floor(Math.random() * botComments.length)];

      const newComm: SpectatorComment = {
        id: `c_${Date.now()}`,
        user: randomName,
        text: randomText,
        avatar: randomAvatar,
        time: 'Just now',
      };

      setChatComments((prev) => [...prev.slice(-15), newComm]);
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMsg.trim()) return;

    soundManager.playClick();
    const myComment: SpectatorComment = {
      id: `c_me_${Date.now()}`,
      user: userProfile?.name || 'You',
      text: inputMsg,
      avatar:
        userProfile?.avatar ||
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80',
      time: 'Just now',
    };

    setChatComments((prev) => [...prev, myComment]);
    setInputMsg('');
    triggerEmojiBurst('❤️');
  };

  const triggerEmojiBurst = (emoji: string) => {
    soundManager.playClick();
    const newEmoji: FloatingEmoji = {
      id: Date.now() + Math.random(),
      symbol: emoji,
      x: Math.random() * 50 + 25, // percentage position
    };
    setFloatingEmojis((prev) => [...prev, newEmoji]);

    setTimeout(() => {
      setFloatingEmojis((prev) => prev.filter((e) => e.id !== newEmoji.id));
    }, 2000);
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-30 flex flex-col justify-between p-3 sm:p-5">
      {/* Floating Emoji Animations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {floatingEmojis.map((emoji) => (
          <motion.div
            key={emoji.id}
            initial={{ y: '85vh', opacity: 1, scale: 0.8 }}
            animate={{ y: '15vh', opacity: 0, scale: 1.8 }}
            transition={{ duration: 2, ease: 'easeOut' }}
            style={{ left: `${emoji.x}%` }}
            className="absolute text-4xl filter drop-shadow-[0_0_12px_rgba(255,215,0,0.9)]"
          >
            {emoji.symbol}
          </motion.div>
        ))}
      </div>

      {/* TOP LIVE SPECTATE BAR */}
      <div className="w-full max-w-xl mx-auto bg-gradient-to-r from-slate-950/95 via-sky-950/95 to-slate-950/95 border-2 border-sky-400/80 rounded-2xl p-2.5 sm:p-3 shadow-[0_10px_35px_rgba(0,0,0,0.9)] pointer-events-auto backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-2.5">
        {/* Players Info with Plenty of Left Padding for Crowns */}
        <div className="flex items-center gap-3 pl-2 sm:pl-3 min-w-0">
          <div className="relative flex items-center -space-x-1.5 rtl:space-x-reverse shrink-0 pt-1">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"
                className="w-9 h-9 rounded-full border-2 border-sky-400 object-cover shadow"
                alt="White Player"
              />
              <div className="absolute -top-1 -right-1 z-10">
                <LevelCrown level={32} size="sm" showLevelNumber={false} />
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=100&q=80"
                className="w-9 h-9 rounded-full border-2 border-cyan-400 object-cover shadow"
                alt="Black Player"
              />
              <div className="absolute -top-1 -right-1 z-10">
                <LevelCrown level={28} size="sm" showLevelNumber={false} />
              </div>
            </div>
          </div>

          <div className="text-left rtl:text-right min-w-0">
            <div className="text-xs sm:text-sm font-black text-sky-100 flex items-center gap-1.5 truncate">
              <span className="truncate max-w-[90px] sm:max-w-[120px]">{whitePlayerName}</span>
              <span className="text-sky-400 font-mono text-xs">vs</span>
              <span className="truncate max-w-[90px] sm:max-w-[120px]">{blackPlayerName}</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] sm:text-[11px] text-sky-300/90 font-mono">
              <span>R: {whiteRating}</span>
              <span>•</span>
              <span>R: {blackRating}</span>
            </div>
          </div>
        </div>

        {/* Right Controls: Live Badge + Camera + Sound + Exit */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Live Viewers Indicator */}
          <div className="flex items-center gap-1.5 bg-sky-950/90 border border-sky-400/80 px-2.5 py-1 rounded-full text-xs font-mono font-black text-sky-200 shadow">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <Eye className="w-3.5 h-3.5 text-sky-400" />
            <span>{viewersCount.toLocaleString()}</span>
          </div>

          {/* Camera View Toggle */}
          {onToggleTopView && (
            <button
              onClick={() => {
                soundManager.playClick();
                onToggleTopView();
              }}
              className="p-1.5 sm:p-2 rounded-xl bg-sky-950/80 hover:bg-sky-900 border border-sky-500/80 text-sky-200 transition cursor-pointer"
              title="Camera View"
            >
              <Camera className="w-4 h-4" />
            </button>
          )}

          {/* Sound Toggle */}
          {onToggleSound && (
            <button
              onClick={() => {
                soundManager.playClick();
                onToggleSound();
              }}
              className="p-1.5 sm:p-2 rounded-xl bg-sky-950/80 hover:bg-sky-900 border border-sky-500/80 text-sky-200 transition cursor-pointer"
              title={soundEnabled ? 'Mute' : 'Unmute'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 opacity-60" />}
            </button>
          )}

          {/* Exit Spectate */}
          <button
            onClick={() => {
              soundManager.playClick();
              onExitSpectate();
            }}
            className="p-1.5 sm:p-2 rounded-xl bg-red-950 hover:bg-red-900 border border-red-600/80 text-red-200 transition cursor-pointer"
            title="Exit Spectate"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* BOTTOM / RIGHT CHAT OVERLAY & REACTION BURSTS */}
      <div className="w-full max-w-sm ml-auto rtl:mr-auto rtl:ml-0 flex flex-col gap-2 pointer-events-auto">
        {/* Live Chat Comments Feed Popup */}
        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 15, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 15, scale: 0.95 }}
              className="bg-slate-950/95 border-2 border-sky-400/80 rounded-2xl p-3 shadow-[0_10px_30px_rgba(0,0,0,0.9)] backdrop-blur-md flex flex-col h-52 sm:h-60"
            >
              <div className="flex items-center justify-between border-b border-sky-800/40 pb-1.5 mb-2">
                <span className="text-xs font-black text-sky-200 flex items-center gap-1.5">
                  <span className="text-base">🌊</span>
                  {language === 'ku' ? 'چاتی ڕاستەوخۆی بینەران' : 'Live Spectator Chat'}
                </span>
                <span className="text-[10px] text-cyan-400 font-mono font-black animate-pulse">● LIVE</span>
              </div>

              {/* Feed */}
              <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-left rtl:text-right custom-scrollbar">
                {chatComments.map((comment) => (
                  <div key={comment.id} className="flex items-start gap-2 bg-sky-950/50 p-2 rounded-xl border border-sky-800/40">
                    <img
                      src={comment.avatar}
                      className="w-6 h-6 rounded-full border border-sky-400 object-cover shrink-0"
                      alt={comment.user}
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-bold text-sky-300 truncate">{comment.user}</div>
                      <div className="text-xs text-sky-100 font-medium leading-tight break-words">{comment.text}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Send Comment Box */}
              <form onSubmit={handleSendComment} className="flex items-center gap-1.5 mt-2 pt-2 border-t border-sky-800/40">
                <input
                  type="text"
                  value={inputMsg}
                  onChange={(e) => setInputMsg(e.target.value)}
                  placeholder={language === 'ku' ? 'پەیامێک بنووسە...' : 'Type comment...'}
                  className="flex-1 bg-slate-900 border border-sky-600/60 rounded-xl py-1.5 px-3 text-xs text-sky-100 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="submit"
                  className="p-2 bg-gradient-to-r from-sky-400 to-cyan-500 text-slate-950 rounded-xl font-bold active:scale-95 transition cursor-pointer shadow"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Reaction Quick Burst Floating Bar */}
        <div className="flex items-center justify-end rtl:justify-start gap-1.5 bg-slate-950/90 backdrop-blur-md p-2 rounded-2xl border-2 border-sky-400/70 shadow-2xl self-end">
          {['🌊', '💧', '💙', '♟️', '😍'].map((emoji) => (
            <button
              key={emoji}
              onClick={() => triggerEmojiBurst(emoji)}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-sky-950/90 hover:bg-sky-900 border border-sky-600/60 flex items-center justify-center text-lg active:scale-125 transition cursor-pointer shadow"
            >
              {emoji}
            </button>
          ))}

          <button
            onClick={() => {
              soundManager.playClick();
              setIsChatOpen((prev) => !prev);
            }}
            className={`p-2 rounded-xl transition border cursor-pointer ${
              isChatOpen
                ? 'bg-gradient-to-r from-sky-400 to-cyan-500 text-slate-950 border-sky-300 font-bold'
                : 'bg-sky-900/80 border-sky-600 text-sky-200 hover:bg-sky-800'
            }`}
            title="Toggle Live Chat"
          >
            <MessageSquare className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
