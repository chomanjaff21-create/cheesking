import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { BoardSkinId, PieceSkinId } from '../types';
import { getMaterialsForCustomSkins, create3DPieceGroup } from '../lib/3dPieceGenerator';

interface BoardPreviewCanvas3DProps {
  boardSkin: BoardSkinId;
  pieceSkin?: PieceSkinId;
}

export const BoardPreviewCanvas3D: React.FC<BoardPreviewCanvas3DProps> = ({
  boardSkin,
  pieceSkin = 'basalt',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth || 320;
    const height = container.clientHeight || 220;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 4.2, 5.2);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    container.replaceChildren(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 2.5;
    controls.maxDistance = 8.0;
    controls.maxPolarAngle = Math.PI / 2 - 0.08;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 1.8;
    controlsRef.current = controls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xfffbeb, 1.5);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffedd5, 2.6);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x38bdf8, 1.3);
    fillLight.position.set(-5, 6, -4);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xfef08a, 1.8);
    rimLight.position.set(0, 7, -6);
    scene.add(rimLight);

    const materials = getMaterialsForCustomSkins(pieceSkin as PieceSkinId, boardSkin as BoardSkinId);

    // Mini 3D Chess Board Table (scaled model)
    const boardGroup = new THREE.Group();

    // Table Rim / Base
    const borderGeom = new THREE.BoxGeometry(4.4, 0.22, 4.4);
    const borderMesh = new THREE.Mesh(borderGeom, materials.border);
    borderMesh.position.y = -0.11;
    borderMesh.receiveShadow = true;
    boardGroup.add(borderMesh);

    // Gold Inlay Line
    const goldRimGeom = new THREE.BoxGeometry(4.48, 0.04, 4.48);
    const goldRimMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.95,
      roughness: 0.15,
    });
    const goldRim = new THREE.Mesh(goldRimGeom, goldRimMat);
    goldRim.position.y = -0.01;
    boardGroup.add(goldRim);

    // 8x8 Grid Squares
    const tileGeom = new THREE.BoxGeometry(0.48, 0.04, 0.48);
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const isLight = (r + c) % 2 === 0;
        const mat = isLight ? materials.boardLight : materials.boardDark;
        const tile = new THREE.Mesh(tileGeom, mat);
        tile.position.set((c - 3.5) * 0.49, 0.02, (3.5 - r) * 0.49);
        tile.receiveShadow = true;
        boardGroup.add(tile);
      }
    }

    // Sample showcase pieces on the board
    const demoPieces = [
      { type: 'k', color: 'w' as const, x: 0.49 * 0.5, z: 0.49 * 3.5 },
      { type: 'q', color: 'w' as const, x: -0.49 * 0.5, z: 0.49 * 3.5 },
      { type: 'n', color: 'w' as const, x: -0.49 * 2.5, z: 0.49 * 2.5 },
      { type: 'k', color: 'b' as const, x: 0.49 * 0.5, z: -0.49 * 3.5 },
      { type: 'q', color: 'b' as const, x: -0.49 * 0.5, z: -0.49 * 3.5 },
      { type: 'n', color: 'b' as const, x: 0.49 * 2.5, z: -0.49 * 2.5 },
    ];

    demoPieces.forEach((p) => {
      const mat = p.color === 'w' ? materials.whitePiece : materials.blackPiece;
      const pieceGroup = create3DPieceGroup(p.type, mat, pieceSkin as PieceSkinId);
      pieceGroup.scale.set(0.52, 0.52, 0.52);
      pieceGroup.position.set(p.x, 0.04, p.z);
      boardGroup.add(pieceGroup);
    });

    scene.add(boardGroup);

    // Animation Loop
    let clock = new THREE.Clock();
    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);
      clock.getElapsedTime();
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current || !renderer || !camera) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      renderer.dispose();
    };
  }, [boardSkin, pieceSkin]);

  return (
    <div className="w-full h-44 sm:h-52 relative rounded-2xl overflow-hidden bg-gradient-to-b from-black/70 via-amber-950/40 to-black/80 border border-amber-500/40 shadow-inner">
      <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[10px] text-amber-300/80 bg-black/60 px-3 py-0.5 rounded-full border border-amber-600/40 pointer-events-none font-bold whitespace-nowrap">
        🔄 دەتوانیت بە دەست بیخولێنیتەوە (Interactive 3D)
      </div>
    </div>
  );
};
