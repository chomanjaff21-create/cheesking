import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronLeft,
  ChevronRight,
  Coins,
  Crown,
  User,
  Sparkles,
  Trophy,
  Users,
  Award,
  RotateCw,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { soundManager } from '../lib/soundManager';
import { LevelCrown } from './LevelCrown';
import {
  LeaderboardCategory,
  LeaderboardEntry,
  getLeaderboard,
} from '../lib/leaderboardService';

export type { LeaderboardCategory };

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  currentUserProfile?: UserProfile | null;
}

const DEFAULT_AVATAR =
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80';

function formatCoinsDisplay(coins: number): string {
  if (coins >= 1_000_000) {
    return `${(coins / 1_000_000).toFixed(1)}M $`;
  }
  if (coins >= 10_000) {
    return `${Math.round(coins / 1_000)}K $`;
  }
  if (coins >= 1_000) {
    return `${(coins / 1_000).toFixed(1)}K $`;
  }
  return `${coins.toLocaleString()} $`;
}

function formatScore(
  player: LeaderboardEntry,
  category: LeaderboardCategory,
  isRtl: boolean
): string {
  if (category === 'rating') {
    return `${player.rating.toLocaleString()} Elo`;
  }
  if (category === 'wins') {
    return isRtl ? `${player.wins.toLocaleString()} بردنەوە` : `${player.wins.toLocaleString()} Wins`;
  }
  if (category === 'coins') {
    return formatCoinsDisplay(player.coins);
  }
  return `${player.rating.toLocaleString()} Elo`;
}

function formatSecondary(
  player: LeaderboardEntry,
  category: LeaderboardCategory,
  isRtl: boolean
): string {
  if (category === 'rating') {
    const winsLabel = isRtl ? `${player.wins} بردنەوە` : `${player.wins}W`;
    return `${winsLabel} • ${formatCoinsDisplay(player.coins)}`;
  }
  if (category === 'wins') {
    return `🏆 ${player.rating.toLocaleString()} • ${formatCoinsDisplay(player.coins)}`;
  }
  if (category === 'coins') {
    const winsLabel = isRtl ? `${player.wins} بردنەوە` : `${player.wins}W`;
    return `🏆 ${player.rating.toLocaleString()} • ${winsLabel}`;
  }
  const winsLabel = isRtl ? `${player.wins} بردنەوە` : `${player.wins}W`;
  return `${winsLabel} • ${formatCoinsDisplay(player.coins)}`;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  isOpen,
  onClose,
  language,
  currentUserProfile,
}) => {
  const [activeCategory, setActiveCategory] = useState<LeaderboardCategory>('rating');
  const [players, setPlayers] = useState<LeaderboardEntry[]>([]);
  const [currentUserRank, setCurrentUserRank] = useState<LeaderboardEntry | null>(null);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const isRtl = language === 'ku';

  // Weekly Season Reset Countdown
  const [timeLeft, setTimeLeft] = useState({
    days: 6,
    hours: 4,
    minutes: 7,
    seconds: 49,
  });

  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Server-authoritative data fetching
  const loadLeaderboard = useCallback(
    async (isManualRefresh = false) => {
      if (isManualRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        const friendIds = (currentUserProfile?.friends || [])
          .map((f: any) => (typeof f === 'string' ? f : f?.id))
          .filter(Boolean);

        const data = await getLeaderboard(activeCategory, page, 50, friendIds);
        setPlayers(data.entries || []);
        setTotal(data.total || 0);
        setTotalPages(data.totalPages || 1);
        setCurrentUserRank(data.currentUser || null);
      } catch (err: any) {
        console.error('Failed to load leaderboard:', err);
        setError(err?.message || (isRtl ? 'هەڵە لە وەرگرتنی داتا' : 'Failed to load leaderboard data'));
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
      }
    },
    [activeCategory, page, currentUserProfile, isRtl]
  );

  useEffect(() => {
    if (isOpen) {
      loadLeaderboard(false);
    }
  }, [isOpen, loadLeaderboard]);

  if (!isOpen) return null;

  // Podium Positions (1st, 2nd, 3rd)
  const top1 = players.find((p) => p.rank === 1) || players[0];
  const top2 = players.find((p) => p.rank === 2) || (players.length > 1 ? players[1] : undefined);
  const top3 = players.find((p) => p.rank === 3) || (players.length > 2 ? players[2] : undefined);
  const lowerList = players.slice(3);

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 bg-black/90 backdrop-blur-lg overflow-hidden select-none">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className={`w-full max-w-md h-full sm:h-[94vh] sm:rounded-[2.5rem] bg-gradient-to-b from-[#2a170d] via-[#1a0e08] to-[#0c0502] border-0 sm:border-2 border-amber-600/60 shadow-2xl flex flex-col relative overflow-hidden text-amber-100 ${
            isRtl ? 'rtl' : 'ltr'
          }`}
        >
          {/* Desert Sunset Background Overlay */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-600/30 via-amber-950/40 to-black/90 pointer-events-none" />

          {/* TOP HEADER */}
          <div className="relative z-10 pt-3 px-3 pb-2 flex flex-col items-center gap-2">
            {/* Top Row: Back button, Title, Refresh & Countdown */}
            <div className="w-full flex items-center justify-between">
              <button
                onClick={() => {
                  soundManager.playClick();
                  onClose();
                }}
                className="w-9 h-9 rounded-full bg-gradient-to-br from-yellow-400 to-amber-600 p-0.5 shadow-lg active:scale-95 transition cursor-pointer flex items-center justify-center"
                title={isRtl ? 'داخستن' : 'Close'}
              >
                <div className="w-full h-full rounded-full bg-amber-950 flex items-center justify-center text-amber-300 hover:text-white">
                  <ChevronLeft className="w-5 h-5 stroke-[3]" />
                </div>
              </button>

              <div className="flex items-center gap-1.5">
                <h2 className="text-lg sm:text-xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-200 via-amber-300 to-yellow-500 tracking-wide drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] flex items-center gap-1.5">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  <span>{isRtl ? 'پلەبەندی بژاردەکان' : 'Leaderboard'}</span>
                </h2>
                <button
                  onClick={() => {
                    soundManager.playClick();
                    loadLeaderboard(true);
                  }}
                  disabled={isLoading || isRefreshing}
                  className="w-7 h-7 rounded-lg bg-amber-900/80 border border-amber-600/60 flex items-center justify-center text-amber-300 hover:text-white active:scale-95 transition cursor-pointer disabled:opacity-50"
                  title={isRtl ? 'نوێکردنەوە' : 'Refresh'}
                >
                  <RotateCw
                    className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-yellow-300' : ''}`}
                  />
                </button>
              </div>

              {/* Countdown Banner */}
              <div className="flex items-center gap-1 font-mono text-[11px] font-bold text-yellow-300 bg-amber-950/80 border border-amber-600/50 px-2 py-1 rounded-xl shadow-inner">
                <div className="bg-amber-900 border border-yellow-500/60 text-yellow-200 px-1 py-0.5 rounded text-xs font-black">
                  {timeLeft.days}d
                </div>
                <div className="bg-amber-900 border border-yellow-500/60 text-yellow-200 px-1 py-0.5 rounded text-xs font-black">
                  {String(timeLeft.hours).padStart(2, '0')}h
                </div>
              </div>
            </div>

            {/* 4 CATEGORY LEADERBOARD TABS */}
            <div className="w-full grid grid-cols-4 gap-1 bg-amber-950/90 border border-amber-700/60 rounded-2xl p-1 shadow-inner">
              {/* Tab 1: Rating (Elo) */}
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveCategory('rating');
                  setPage(1);
                }}
                className={`py-1.5 px-1 rounded-xl font-black text-[11px] transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                  activeCategory === 'rating'
                    ? 'bg-gradient-to-b from-amber-500 via-yellow-400 to-amber-600 text-amber-950 shadow-lg scale-105 border border-yellow-200'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                <Award className="w-3.5 h-3.5" />
                <span className="truncate max-w-full">{isRtl ? 'ڕ. خاڵ' : 'Rating'}</span>
              </button>

              {/* Tab 2: Wins */}
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveCategory('wins');
                  setPage(1);
                }}
                className={`py-1.5 px-1 rounded-xl font-black text-[11px] transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                  activeCategory === 'wins'
                    ? 'bg-gradient-to-b from-amber-500 via-yellow-400 to-amber-600 text-amber-950 shadow-lg scale-105 border border-yellow-200'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                <span className="truncate max-w-full">{isRtl ? 'ڕ. بردنەوە' : 'Wins'}</span>
              </button>

              {/* Tab 3: Coins / Wealth */}
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveCategory('coins');
                  setPage(1);
                }}
                className={`py-1.5 px-1 rounded-xl font-black text-[11px] transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                  activeCategory === 'coins'
                    ? 'bg-gradient-to-b from-amber-500 via-yellow-400 to-amber-600 text-amber-950 shadow-lg scale-105 border border-yellow-200'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                <span className="truncate max-w-full">{isRtl ? 'ڕ. پارە' : 'Coins'}</span>
              </button>

              {/* Tab 4: Friends */}
              <button
                onClick={() => {
                  soundManager.playClick();
                  setActiveCategory('friends');
                  setPage(1);
                }}
                className={`py-1.5 px-1 rounded-xl font-black text-[11px] transition flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                  activeCategory === 'friends'
                    ? 'bg-gradient-to-b from-amber-500 via-yellow-400 to-amber-600 text-amber-950 shadow-lg scale-105 border border-yellow-200'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span className="truncate max-w-full">{isRtl ? 'هاوڕێیان' : 'Friends'}</span>
              </button>
            </div>
          </div>

          {/* MAIN CONTENT AREA */}
          {isLoading && players.length === 0 ? (
            <div className="relative z-10 flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
              <Loader2 className="w-10 h-10 text-yellow-400 animate-spin drop-shadow-[0_0_12px_rgba(250,204,21,0.7)]" />
              <p className="font-bold text-sm text-amber-200">
                {isRtl
                  ? 'داتای ڕاستەقینەی بنکەدراوە باردەکرێت...'
                  : 'Loading real database rankings...'}
              </p>
            </div>
          ) : error ? (
            <div className="relative z-10 flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
              <AlertCircle className="w-10 h-10 text-red-400" />
              <p className="font-bold text-sm text-red-200">{error}</p>
              <button
                onClick={() => loadLeaderboard(false)}
                className="mt-2 px-4 py-2 bg-gradient-to-r from-amber-600 to-yellow-600 text-amber-950 font-black text-xs rounded-xl shadow-lg hover:brightness-110 active:scale-95 transition"
              >
                {isRtl ? 'دووبارە هەوڵبدەرەوە' : 'Retry'}
              </button>
            </div>
          ) : players.length === 0 ? (
            <div className="relative z-10 flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
              <Trophy className="w-12 h-12 text-amber-500/50" />
              <p className="font-bold text-sm text-amber-300/80">
                {activeCategory === 'friends'
                  ? isRtl
                    ? 'هیچ هاوڕێیەک نەدۆزرایەوە لەم بەشەدا'
                    : 'No friends found in leaderboard yet'
                  : isRtl
                  ? 'هیچ یاریزانێک نەدۆزرایەوە'
                  : 'No players found'}
              </p>
            </div>
          ) : (
            <>
              {/* 3D PODIUM SECTION - TOP 3 POSITIONS */}
              <div className="relative z-10 px-2 pt-4 pb-2 flex items-end justify-center gap-2 sm:gap-4 border-b border-amber-800/40 min-h-[285px]">
                {/* Rank 2 (Left, Medium) */}
                {top2 ? (
                  <PodiumCard
                    player={top2}
                    category={activeCategory}
                    position={2}
                    isRtl={isRtl}
                  />
                ) : (
                  <div className="w-24 sm:w-26" />
                )}

                {/* Rank 1 (Center, Tallest) */}
                {top1 ? (
                  <PodiumCard
                    player={top1}
                    category={activeCategory}
                    position={1}
                    isFirst
                    isRtl={isRtl}
                  />
                ) : null}

                {/* Rank 3 (Right, Shorter) */}
                {top3 ? (
                  <PodiumCard
                    player={top3}
                    category={activeCategory}
                    position={3}
                    isRtl={isRtl}
                  />
                ) : (
                  <div className="w-24 sm:w-26" />
                )}
              </div>

              {/* LOWER LEADERBOARD LIST (Ranks 4+) */}
              <div className="relative z-10 flex-1 overflow-y-auto px-3 sm:px-4 py-2.5 space-y-2 custom-scrollbar">
                {lowerList.map((player) => {
                  const isCurrent =
                    currentUserProfile?.id &&
                    (currentUserProfile.id === player.id || currentUserProfile.name === player.username);

                  return (
                    <div
                      key={player.id || player.rank}
                      className={`flex items-center justify-between p-2 rounded-2xl border shadow-md transition ${
                        isCurrent
                          ? 'bg-gradient-to-r from-[#422006] via-[#2d1607] to-[#422006] border-yellow-400 ring-1 ring-yellow-400/40'
                          : 'bg-gradient-to-r from-[#2c180b] via-[#231207] to-[#2c180b] border-amber-600/50 hover:border-amber-400'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 text-center font-black text-amber-300 font-mono text-sm bg-amber-950/80 border border-amber-700/50 rounded-xl py-0.5 shadow-inner shrink-0">
                          #{player.rank}
                        </div>

                        <div className="relative shrink-0">
                          <img
                            src={player.avatar_url || DEFAULT_AVATAR}
                            alt={player.username}
                            className="w-10 h-10 rounded-full object-cover border-2 border-amber-500/70 shadow"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.currentTarget as HTMLImageElement).src = DEFAULT_AVATAR;
                            }}
                          />
                          <div className="absolute -bottom-1 -right-1">
                            <LevelCrown level={player.level} size="sm" showLevelNumber={false} />
                          </div>
                        </div>

                        <div className="flex flex-col text-left rtl:text-right">
                          <div className="font-bold text-amber-100 text-xs flex items-center gap-1">
                            <span className="truncate max-w-[120px] sm:max-w-[150px]">
                              {player.username}
                            </span>
                            {isCurrent && (
                              <span className="text-[10px] text-yellow-300 font-semibold">
                                ({isRtl ? 'تۆ' : 'You'})
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-amber-400/80 font-mono">
                            LV {player.level}
                          </div>
                        </div>
                      </div>

                      {/* Score Pill */}
                      <div className="flex flex-col items-end">
                        <div className="flex items-center gap-1 bg-black/60 border border-yellow-500/50 px-2.5 py-0.5 rounded-full shadow-inner">
                          <span className="font-extrabold text-yellow-300 text-xs font-mono">
                            {formatScore(player, activeCategory, isRtl)}
                          </span>
                          {activeCategory === 'coins' ? (
                            <Coins className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                          ) : activeCategory === 'wins' ? (
                            <Trophy className="w-3 h-3 text-yellow-400" />
                          ) : (
                            <Award className="w-3 h-3 text-yellow-400" />
                          )}
                        </div>
                        <span className="text-[9px] text-amber-300/80 font-semibold mr-1 mt-0.5">
                          {formatSecondary(player, activeCategory, isRtl)}
                        </span>
                      </div>
                    </div>
                  );
                })}

                {/* Pagination Controls */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between pt-2 pb-1 px-2 border-t border-amber-800/40">
                    <button
                      disabled={page <= 1}
                      onClick={() => {
                        soundManager.playClick();
                        setPage((p) => Math.max(1, p - 1));
                      }}
                      className="px-2.5 py-1 rounded-lg bg-amber-950 border border-amber-700/60 text-xs font-bold text-amber-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-amber-900 transition flex items-center gap-1"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                      <span>{isRtl ? 'پێشوو' : 'Prev'}</span>
                    </button>

                    <span className="text-xs font-mono font-bold text-amber-300">
                      {isRtl
                        ? `لاپەڕە ${page} لە ${totalPages}`
                        : `Page ${page} of ${totalPages}`}
                    </span>

                    <button
                      disabled={page >= totalPages}
                      onClick={() => {
                        soundManager.playClick();
                        setPage((p) => Math.min(totalPages, p + 1));
                      }}
                      className="px-2.5 py-1 rounded-lg bg-amber-950 border border-amber-700/60 text-xs font-bold text-amber-200 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-amber-900 transition flex items-center gap-1"
                    >
                      <span>{isRtl ? 'داهاتوو' : 'Next'}</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            </>
          )}

          {/* CURRENT USER STICKY BOTTOM ROW */}
          <div className="relative z-20 p-2.5 bg-gradient-to-t from-black via-[#1d0d05] to-[#291307] border-t-2 border-amber-500/70 flex items-center justify-between px-3">
            {currentUserRank ? (
              <>
                <div className="flex items-center gap-2.5">
                  <span className="w-7 text-center font-extrabold text-yellow-400 text-xs font-mono bg-amber-950 border border-yellow-500/60 rounded-lg py-0.5">
                    #{currentUserRank.rank}
                  </span>

                  <div className="relative">
                    <img
                      src={currentUserRank.avatar_url || currentUserProfile?.avatar || DEFAULT_AVATAR}
                      alt={currentUserRank.username}
                      className="w-10 h-10 rounded-full object-cover border-2 border-yellow-400 shadow overflow-hidden"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = DEFAULT_AVATAR;
                      }}
                    />
                    <div className="absolute -bottom-1 -right-1">
                      <LevelCrown
                        level={currentUserRank.level || currentUserProfile?.level || 1}
                        size="sm"
                        showLevelNumber={false}
                      />
                    </div>
                  </div>

                  <div className="flex flex-col text-left rtl:text-right">
                    <div className="font-extrabold text-amber-100 text-xs flex items-center gap-1">
                      <span className="truncate max-w-[130px] sm:max-w-[160px]">
                        {currentUserRank.username}
                      </span>
                      <span>☀️</span>
                    </div>
                    <div className="text-[10px] text-amber-400/80 font-medium">
                      {isRtl ? 'تۆ (You)' : 'You'} • LV {currentUserRank.level || currentUserProfile?.level || 1}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-black/60 border border-yellow-500/60 px-2.5 py-1 rounded-full shadow-inner">
                  <span className="font-black text-yellow-400 text-xs font-mono">
                    {formatScore(currentUserRank, activeCategory, isRtl)}
                  </span>
                  {activeCategory === 'coins' ? (
                    <Coins className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                  ) : activeCategory === 'wins' ? (
                    <Trophy className="w-3.5 h-3.5 text-yellow-400" />
                  ) : (
                    <Award className="w-3.5 h-3.5 text-yellow-400" />
                  )}
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2.5">
                  <span className="w-7 text-center font-extrabold text-amber-400/60 text-xs font-mono bg-amber-950 border border-amber-700/60 rounded-lg py-0.5">
                    #--
                  </span>

                  <div className="relative">
                    <div className="w-10 h-10 rounded-full bg-amber-900/80 border-2 border-amber-500/60 flex items-center justify-center text-amber-200 shadow overflow-hidden">
                      <User className="w-5 h-5" />
                    </div>
                  </div>

                  <div className="flex flex-col text-left rtl:text-right">
                    <div className="font-extrabold text-amber-100 text-xs">
                      {currentUserProfile?.name || (isRtl ? 'میوان' : 'Guest')}
                    </div>
                    <div className="text-[10px] text-amber-400/80 font-medium">
                      {isRtl ? 'تۆ (You)' : 'You'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 bg-black/60 border border-amber-600/50 px-2.5 py-1 rounded-full shadow-inner">
                  <span className="font-black text-amber-300 text-xs font-mono">
                    {currentUserProfile
                      ? activeCategory === 'coins'
                        ? formatCoinsDisplay(currentUserProfile.coins)
                        : activeCategory === 'wins'
                        ? `${currentUserProfile.wins} Wins`
                        : `${currentUserProfile.rating} Elo`
                      : 'Unranked'}
                  </span>
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

/* Sub-component for Podium Players (1st, 2nd, 3rd place) with Zero Overlap */
interface PodiumCardProps {
  player: LeaderboardEntry;
  category: LeaderboardCategory;
  position: 1 | 2 | 3;
  isFirst?: boolean;
  isRtl: boolean;
}

const PodiumCard: React.FC<PodiumCardProps> = ({
  player,
  category,
  position,
  isFirst,
  isRtl,
}) => {
  const isPos1 = position === 1;
  const isPos2 = position === 2;

  const frameBorder = isPos1
    ? 'from-yellow-300 via-amber-400 to-yellow-500 ring-yellow-400'
    : isPos2
    ? 'from-cyan-300 via-blue-400 to-indigo-500 ring-blue-400'
    : 'from-amber-200 via-amber-600 to-amber-800 ring-amber-600';

  const pedestalBg = isPos1
    ? 'from-red-600 via-amber-700 to-red-900 border-yellow-400'
    : isPos2
    ? 'from-blue-600 via-indigo-700 to-blue-900 border-blue-400'
    : 'from-amber-700 via-amber-800 to-amber-950 border-amber-500';

  const bannerBg = isPos1
    ? 'bg-amber-500 text-amber-950'
    : isPos2
    ? 'bg-blue-500 text-white'
    : 'bg-amber-800 text-white';

  return (
    <div
      className={`flex flex-col items-center justify-end relative transition-all ${
        isFirst ? 'w-28 sm:w-32 z-20' : 'w-24 sm:w-26 z-10'
      }`}
    >
      {/* Crown & Avatar Wrapper */}
      <div className="flex flex-col items-center mb-1 w-full">
        <div className="mb-0.5 flex items-center justify-center">
          {isPos1 ? (
            <div className="relative">
              <Crown className="w-8 h-8 text-yellow-300 fill-yellow-400 filter drop-shadow-[0_0_12px_rgba(250,204,21,0.9)] animate-pulse" />
              <Sparkles className="w-3 h-3 text-white absolute -top-1 -right-1 animate-ping" />
            </div>
          ) : isPos2 ? (
            <Crown className="w-6 h-6 text-slate-200 fill-slate-300 filter drop-shadow-[0_2px_6px_rgba(255,255,255,0.7)]" />
          ) : (
            <Crown className="w-5 h-5 text-amber-400 fill-amber-500 filter drop-shadow-[0_2px_6px_rgba(245,158,11,0.7)]" />
          )}
        </div>

        {/* Circular Avatar Frame */}
        <div className="relative">
          <div className={`p-1 rounded-full bg-gradient-to-tr ${frameBorder} shadow-xl relative`}>
            <img
              src={player.avatar_url || DEFAULT_AVATAR}
              alt={player.username}
              className={`${
                isFirst ? 'w-14 h-14 sm:w-18 sm:h-18' : 'w-11 h-11 sm:w-14 sm:h-14'
              } rounded-full object-cover border-2 border-yellow-200/90 shadow-inner`}
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = DEFAULT_AVATAR;
              }}
            />
          </div>

          <div className="absolute -bottom-1 -right-1 z-30">
            <LevelCrown level={player.level} size="sm" showLevelNumber={true} />
          </div>
        </div>

        {/* Player Name */}
        <span className="font-extrabold text-amber-100 text-xs mt-1 text-center truncate max-w-full drop-shadow flex items-center gap-1">
          <span>{player.username}</span>
        </span>

        {/* Score Pill */}
        <div className="flex items-center gap-1 bg-black/70 border border-yellow-400/80 px-2 py-0.5 rounded-full shadow-md mt-0.5">
          <span className="font-black text-yellow-300 text-[10px] sm:text-xs font-mono">
            {formatScore(player, category, isRtl)}
          </span>
          {category === 'coins' ? (
            <Coins className="w-3 h-3 text-yellow-400 fill-yellow-400" />
          ) : category === 'wins' ? (
            <Trophy className="w-3 h-3 text-yellow-400" />
          ) : (
            <Award className="w-3 h-3 text-yellow-400" />
          )}
        </div>
      </div>

      {/* 3D Pedestal Stand */}
      <div
        className={`w-full rounded-t-2xl bg-gradient-to-b ${pedestalBg} border-t-4 border-x border-yellow-400/80 shadow-2xl flex flex-col items-center justify-start relative overflow-hidden ${
          isFirst ? 'h-22 sm:h-26' : isPos2 ? 'h-16 sm:h-20' : 'h-12 sm:h-16'
        }`}
      >
        <div className="w-full h-2 bg-gradient-to-r from-yellow-500 via-amber-200 to-yellow-500 border-b border-amber-700 shadow-sm" />

        <div className="mt-1 flex flex-col items-center">
          <div
            className={`w-7 h-7 sm:w-9 sm:h-9 ${bannerBg} border-2 border-yellow-300 rounded-xl flex items-center justify-center shadow-lg relative`}
          >
            <span className="font-black text-base sm:text-xl drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] font-mono">
              #{player.rank}
            </span>
          </div>
        </div>

        <div className="absolute bottom-0 w-full h-2 bg-gradient-to-r from-yellow-600 via-amber-300 to-yellow-600 border-t border-amber-800" />
      </div>
    </div>
  );
};
