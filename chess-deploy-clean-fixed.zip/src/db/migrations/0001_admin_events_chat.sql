CREATE TABLE IF NOT EXISTS "admin_audit_log" (
	"id" text PRIMARY KEY NOT NULL,
	"admin_id" text NOT NULL,
	"action" text NOT NULL,
	"target_user_id" text,
	"old_value" jsonb,
	"new_value" jsonb,
	"reason" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "user_reports" (
	"id" text PRIMARY KEY NOT NULL,
	"reporter_id" text NOT NULL,
	"reported_user_id" text NOT NULL,
	"match_id" text,
	"reason" text NOT NULL,
	"status" text DEFAULT 'open',
	"resolution_notes" text,
	"resolved_by" text,
	"created_at" timestamp DEFAULT now(),
	"resolved_at" timestamp
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "announcements" (
	"id" text PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"body" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_by" text NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "events" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"description" text DEFAULT '',
	"banner_url" text,
	"event_type" text NOT NULL,
	"start_at" timestamp NOT NULL,
	"end_at" timestamp NOT NULL,
	"status" text DEFAULT 'draft',
	"max_participants" integer,
	"leaderboard_enabled" boolean DEFAULT true,
	"created_by" text NOT NULL,
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "event_tasks" (
	"id" text PRIMARY KEY NOT NULL,
	"event_id" text NOT NULL,
	"task_type" text NOT NULL,
	"target_amount" integer NOT NULL,
	"task_order" integer DEFAULT 0,
	"is_enabled" boolean DEFAULT true,
	"reward_coins" integer DEFAULT 0,
	"reward_gems" integer DEFAULT 0,
	"reward_item_id" text,
	"reward_xp" integer DEFAULT 0,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "event_participants" (
	"id" text PRIMARY KEY NOT NULL,
	"event_id" text NOT NULL,
	"user_id" text NOT NULL,
	"joined_at" timestamp DEFAULT now(),
	"games_played" integer DEFAULT 0,
	"games_won" integer DEFAULT 0,
	"current_win_streak" integer DEFAULT 0,
	"best_win_streak" integer DEFAULT 0,
	"puzzles_solved" integer DEFAULT 0,
	UNIQUE("event_id","user_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "event_task_claims" (
	"id" text PRIMARY KEY NOT NULL,
	"event_id" text NOT NULL,
	"task_id" text NOT NULL,
	"user_id" text NOT NULL,
	"claimed_at" timestamp DEFAULT now(),
	UNIQUE("event_id","task_id","user_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "global_chat_messages" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"username" text NOT NULL,
	"avatar" text,
	"level" integer DEFAULT 1,
	"text" text NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_events_status" ON "events" ("status");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_event_tasks_event" ON "event_tasks" ("event_id");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_event_participants_user" ON "event_participants" ("user_id");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "idx_global_chat_created" ON "global_chat_messages" ("created_at" DESC);
