CREATE TABLE "custom_rooms" (
	"code" text PRIMARY KEY NOT NULL,
	"host_id" text NOT NULL,
	"guest_id" text,
	"match_id" text NOT NULL,
	"time_min" integer DEFAULT 5,
	"stake" integer DEFAULT 0,
	"prize" integer DEFAULT 0,
	"status" text DEFAULT 'waiting',
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "friendships" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"friend_id" text NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "match_coin_transactions" (
	"id" text PRIMARY KEY NOT NULL,
	"match_id" text NOT NULL,
	"user_id" text NOT NULL,
	"type" text NOT NULL,
	"amount" integer NOT NULL,
	"balance_before" integer NOT NULL,
	"balance_after" integer NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "matches" (
	"id" text PRIMARY KEY NOT NULL,
	"white_player_id" text NOT NULL,
	"black_player_id" text NOT NULL,
	"winner_id" text,
	"moves_san" text DEFAULT '',
	"fen" text DEFAULT 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
	"status" text DEFAULT 'active',
	"turn" text DEFAULT 'w',
	"white_time_ms" integer DEFAULT 600000,
	"black_time_ms" integer DEFAULT 600000,
	"last_move_timestamp" timestamp,
	"stake" integer DEFAULT 0,
	"prize" integer DEFAULT 0,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "player_stats" (
	"id" text PRIMARY KEY NOT NULL,
	"wins" integer DEFAULT 0,
	"losses" integer DEFAULT 0,
	"draws" integer DEFAULT 0,
	"rating" integer DEFAULT 1200,
	"coins" integer DEFAULT 5000,
	"gems" integer DEFAULT 50,
	"xp" integer DEFAULT 0,
	"level" integer DEFAULT 1,
	"last_played_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "royal_pass" (
	"id" text PRIMARY KEY NOT NULL,
	"is_premium" boolean DEFAULT false,
	"claimed_free_tiers" jsonb DEFAULT '[]',
	"claimed_premium_tiers" jsonb DEFAULT '[]',
	"season_xp" integer DEFAULT 0,
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "tournament_matches" (
	"id" text PRIMARY KEY NOT NULL,
	"tournament_id" text NOT NULL,
	"round" integer NOT NULL,
	"match_index" integer NOT NULL,
	"player1_id" text,
	"player2_id" text,
	"winner_id" text,
	"match_id" text,
	"status" text DEFAULT 'pending'
);
--> statement-breakpoint
CREATE TABLE "tournament_participants" (
	"tournament_id" text NOT NULL,
	"user_id" text NOT NULL,
	"registered_at" timestamp DEFAULT now(),
	"status" text DEFAULT 'active',
	"rank" integer,
	CONSTRAINT "tournament_participants_tournament_id_user_id_pk" PRIMARY KEY("tournament_id","user_id")
);
--> statement-breakpoint
CREATE TABLE "tournaments" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"type" text DEFAULT 'monthly',
	"status" text DEFAULT 'registration',
	"start_time" timestamp,
	"entry_fee" integer DEFAULT 0,
	"prize_pool" integer DEFAULT 0,
	"max_participants" integer DEFAULT 16,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_challenges" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"challenge_type" text NOT NULL,
	"description" text NOT NULL,
	"target" integer NOT NULL,
	"progress" integer DEFAULT 0,
	"xp_reward" integer DEFAULT 50,
	"is_completed" boolean DEFAULT false,
	"is_claimed" boolean DEFAULT false,
	"expires_at" timestamp NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_daily_rewards" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"reward_type" text NOT NULL,
	"claim_date" text NOT NULL,
	"tier" integer DEFAULT 1,
	"streak_day" integer DEFAULT 1,
	"coins_awarded" integer NOT NULL,
	"gems_awarded" integer DEFAULT 0,
	"claimed_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_inventory" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"item_id" text NOT NULL,
	"item_type" text NOT NULL,
	"acquired_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_purchases" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"item_id" text NOT NULL,
	"price_coins" integer DEFAULT 0,
	"price_gems" integer DEFAULT 0,
	"purchased_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "user_puzzle_completions" (
	"id" text PRIMARY KEY NOT NULL,
	"user_id" text NOT NULL,
	"puzzle_id" text NOT NULL,
	"level_number" integer NOT NULL,
	"coins_awarded" integer NOT NULL,
	"completed_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" text PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"email" text NOT NULL,
	"password_hash" text NOT NULL,
	"avatar_url" text,
	"is_guest" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now(),
	CONSTRAINT "users_username_unique" UNIQUE("username"),
	CONSTRAINT "users_email_unique" UNIQUE("email")
);
