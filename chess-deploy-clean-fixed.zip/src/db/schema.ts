import { pgTable, text, timestamp, integer, boolean, jsonb, primaryKey } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: text('id').primaryKey(),
  username: text('username').notNull().unique(),
  email: text('email').notNull().unique(),
  password_hash: text('password_hash').notNull(),
  avatar_url: text('avatar_url'),
  is_guest: boolean('is_guest').default(false),
  created_at: timestamp('created_at').defaultNow(),
  // Admin panel: is_admin is checked server-side (DB) on every /api/admin request.
  name_changes: integer('name_changes').default(0),
  bio: text('bio'),
  equipped_piece_skin: text('equipped_piece_skin'),
  equipped_board_skin: text('equipped_board_skin'),
  tokens_valid_after: timestamp('tokens_valid_after'),
  is_admin: boolean('is_admin').default(false),
  is_banned: boolean('is_banned').default(false),
  ban_reason: text('ban_reason'),
  is_suspended: boolean('is_suspended').default(false),
  suspended_until: timestamp('suspended_until'),
});

export const player_stats = pgTable('player_stats', {
  id: text('id').primaryKey(), // User ID (from Supabase auth)
  wins: integer('wins').default(0),
  losses: integer('losses').default(0),
  draws: integer('draws').default(0),
  rating: integer('rating').default(1200),
  coins: integer('coins').default(5000),
  gems: integer('gems').default(50),
  xp: integer('xp').default(0),
  level: integer('level').default(1),
  last_played_at: timestamp('last_played_at').defaultNow(),
});

export const royal_pass = pgTable('royal_pass', {
  id: text('id').primaryKey(), // User ID (from Supabase auth)
  is_premium: boolean('is_premium').default(false),
  claimed_free_tiers: jsonb('claimed_free_tiers').default('[]'),
  claimed_premium_tiers: jsonb('claimed_premium_tiers').default('[]'),
  season_xp: integer('season_xp').default(0),
  updated_at: timestamp('updated_at').defaultNow(),
});

export const user_challenges = pgTable('user_challenges', {
  id: text('id').primaryKey(), // Random ID or user_id + challenge_id
  user_id: text('user_id').notNull(),
  challenge_type: text('challenge_type').notNull(), // 'daily' or 'weekly'
  description: text('description').notNull(),
  target: integer('target').notNull(),
  progress: integer('progress').default(0),
  xp_reward: integer('xp_reward').default(50),
  is_completed: boolean('is_completed').default(false),
  is_claimed: boolean('is_claimed').default(false),
  expires_at: timestamp('expires_at').notNull(),
  created_at: timestamp('created_at').defaultNow(),
});

export const user_inventory = pgTable('user_inventory', {
  id: text('id').primaryKey(), // user_id + '_' + item_id
  user_id: text('user_id').notNull(),
  item_id: text('item_id').notNull(),
  item_type: text('item_type').notNull(), // 'board', 'piece', 'avatar', 'cosmetic'
  acquired_at: timestamp('acquired_at').defaultNow(),
});

export const user_purchases = pgTable('user_purchases', {
  id: text('id').primaryKey(), // uuid
  user_id: text('user_id').notNull(),
  item_id: text('item_id').notNull(),
  price_coins: integer('price_coins').default(0),
  price_gems: integer('price_gems').default(0),
  purchased_at: timestamp('purchased_at').defaultNow(),
});

export const matches = pgTable('matches', {
  id: text('id').primaryKey(), // Match ID (server-generated)
  white_player_id: text('white_player_id').notNull(),
  black_player_id: text('black_player_id').notNull(),
  winner_id: text('winner_id'), // null for draw or unresolved
  moves_san: text('moves_san').default(''),
  fen: text('fen').default('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'),
  status: text('status').default('active'), // active, completed, draw, timeout, resigned
  turn: text('turn').default('w'),
  white_time_ms: integer('white_time_ms').default(600000),
  black_time_ms: integer('black_time_ms').default(600000),
  last_move_timestamp: timestamp('last_move_timestamp'),
  stake: integer('stake').default(0),
  prize: integer('prize').default(0),
  created_at: timestamp('created_at').defaultNow(),
});

export const match_coin_transactions = pgTable('match_coin_transactions', {
  id: text('id').primaryKey(), // uuid or matchId_stake_userId
  match_id: text('match_id').notNull(),
  user_id: text('user_id').notNull(),
  type: text('type').notNull(), // stake_deduction, prize_payout, draw_refund
  amount: integer('amount').notNull(),
  balance_before: integer('balance_before').notNull(),
  balance_after: integer('balance_after').notNull(),
  created_at: timestamp('created_at').defaultNow(),
});

export const user_daily_rewards = pgTable('user_daily_rewards', {
  id: text('id').primaryKey(), // user_id + '_' + reward_type + '_' + claim_date + '_' + tier
  user_id: text('user_id').notNull(),
  reward_type: text('reward_type').notNull(), // 'daily_streak', 'play_3_games', 'win_7_streak', 'royal_event', 'ad_reward'
  claim_date: text('claim_date').notNull(), // 'YYYY-MM-DD'
  tier: integer('tier').default(1),
  streak_day: integer('streak_day').default(1),
  coins_awarded: integer('coins_awarded').notNull(),
  gems_awarded: integer('gems_awarded').default(0),
  claimed_at: timestamp('claimed_at').defaultNow(),
});

export const user_puzzle_completions = pgTable('user_puzzle_completions', {
  id: text('id').primaryKey(), // user_id + '_' + puzzle_id
  user_id: text('user_id').notNull(),
  puzzle_id: text('puzzle_id').notNull(),
  level_number: integer('level_number').notNull(),
  coins_awarded: integer('coins_awarded').notNull(),
  completed_at: timestamp('completed_at').defaultNow(),
});

export const custom_rooms = pgTable('custom_rooms', {
  code: text('code').primaryKey(), // 6-digit room code
  host_id: text('host_id').notNull(),
  guest_id: text('guest_id'),
  match_id: text('match_id').notNull(),
  time_min: integer('time_min').default(5),
  stake: integer('stake').default(0),
  prize: integer('prize').default(0),
  status: text('status').default('waiting'), // 'waiting', 'active', 'completed', 'expired'
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow(),
});


export const friendships = pgTable('friendships', {
  id: text('id').primaryKey(), // Using initiator_id + '_' + target_id
  user_id: text('user_id').notNull(),
  friend_id: text('friend_id').notNull(),
  status: text('status').notNull().default('pending'), // 'pending' or 'accepted'
  created_at: timestamp('created_at').defaultNow(),
});

export const tournaments = pgTable('tournaments', {
  id: text('id').primaryKey(), // generate unique ID
  name: text('name').notNull(),
  type: text('type').default('monthly'), // daily, weekly, monthly
  status: text('status').default('registration'), // registration, active, completed
  start_time: timestamp('start_time'),
  entry_fee: integer('entry_fee').default(0),
  prize_pool: integer('prize_pool').default(0),
  max_participants: integer('max_participants').default(16),
  created_at: timestamp('created_at').defaultNow(),
});

export const tournament_participants = pgTable('tournament_participants', {
  tournament_id: text('tournament_id').notNull(),
  user_id: text('user_id').notNull(),
  registered_at: timestamp('registered_at').defaultNow(),
  status: text('status').default('active'), // active, eliminated, winner
  rank: integer('rank'),
}, (table) => {
  return {
    pk: primaryKey({ columns: [table.tournament_id, table.user_id] }),
  };
});

export const tournament_matches = pgTable('tournament_matches', {
  id: text('id').primaryKey(),
  tournament_id: text('tournament_id').notNull(),
  round: integer('round').notNull(), // 1 (Ro16), 2 (QF), 3 (SF), 4 (Final)
  match_index: integer('match_index').notNull(), // index within the round
  player1_id: text('player1_id'), // can be null if not determined yet
  player2_id: text('player2_id'),
  winner_id: text('winner_id'),
  match_id: text('match_id'), // reference to matches table if game is active/completed
  status: text('status').default('pending'), // pending, ready, active, completed
});
// Add missing primaryKey to imports if it isn't there

// --- Admin Panel tables ---

// Every sensitive admin action (ban, economy change, report resolution,
// announcement change) writes one row here — never a silent change.
export const admin_audit_log = pgTable('admin_audit_log', {
  id: text('id').primaryKey(),
  admin_id: text('admin_id').notNull(),
  action: text('action').notNull(), // 'ban' | 'unban' | 'suspend' | 'unsuspend' | 'economy_adjust' | 'resolve_report' | 'announcement_create' | ...
  target_user_id: text('target_user_id'),
  old_value: jsonb('old_value'),
  new_value: jsonb('new_value'),
  reason: text('reason'),
  created_at: timestamp('created_at').defaultNow(),
});

// Player-filed reports of another user/match — the admin side (view,
// resolve) is what this task asks for; a minimal creation endpoint exists
// too so the table isn't just an empty shell with no way to populate it
// for real, but the player-facing report UI itself is out of scope here.
export const user_reports = pgTable('user_reports', {
  id: text('id').primaryKey(),
  reporter_id: text('reporter_id').notNull(),
  reported_user_id: text('reported_user_id').notNull(),
  match_id: text('match_id'),
  reason: text('reason').notNull(),
  status: text('status').default('open'), // 'open' | 'resolved'
  resolution_notes: text('resolution_notes'),
  resolved_by: text('resolved_by'),
  created_at: timestamp('created_at').defaultNow(),
  resolved_at: timestamp('resolved_at'),
});

// Admin-authored announcements/broadcasts.
export const announcements = pgTable('announcements', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  body: text('body').notNull(),
  is_active: boolean('is_active').default(true),
  created_by: text('created_by').notNull(),
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow(),
});

// ---- Event system (server-authoritative; all times are server/DB times) ----
export const events = pgTable('events', {
  id: text('id').primaryKey(), name: text('name').notNull(), description: text('description').default(''),
  banner_url: text('banner_url'),
  event_type: text('event_type').notNull(), // 'games_played'|'games_won'|'win_streak'|'puzzles_solved'
  start_at: timestamp('start_at').notNull(), end_at: timestamp('end_at').notNull(),
  status: text('status').default('draft'), // draft|published|paused|ended
  max_participants: integer('max_participants'), leaderboard_enabled: boolean('leaderboard_enabled').default(true),
  created_by: text('created_by').notNull(), created_at: timestamp('created_at').defaultNow(), updated_at: timestamp('updated_at').defaultNow(),
});
export const event_tasks = pgTable('event_tasks', {
  id: text('id').primaryKey(), event_id: text('event_id').notNull(), task_type: text('task_type').notNull(),
  target_amount: integer('target_amount').notNull(), task_order: integer('task_order').default(0),
  is_enabled: boolean('is_enabled').default(true), reward_coins: integer('reward_coins').default(0),
  reward_gems: integer('reward_gems').default(0), reward_item_id: text('reward_item_id'),
  reward_xp: integer('reward_xp').default(0), created_at: timestamp('created_at').defaultNow(),
});
export const event_participants = pgTable('event_participants', {
  id: text('id').primaryKey(), event_id: text('event_id').notNull(), user_id: text('user_id').notNull(),
  joined_at: timestamp('joined_at').defaultNow(), games_played: integer('games_played').default(0),
  games_won: integer('games_won').default(0), current_win_streak: integer('current_win_streak').default(0),
  best_win_streak: integer('best_win_streak').default(0), puzzles_solved: integer('puzzles_solved').default(0),
});
export const event_task_claims = pgTable('event_task_claims', {
  id: text('id').primaryKey(), event_id: text('event_id').notNull(), task_id: text('task_id').notNull(),
  user_id: text('user_id').notNull(), claimed_at: timestamp('claimed_at').defaultNow(),
});

export const global_chat_messages = pgTable('global_chat_messages', {
  id: text('id').primaryKey(), user_id: text('user_id').notNull(), username: text('username').notNull(),
  avatar: text('avatar'), level: integer('level').default(1), text: text('text').notNull(),
  created_at: timestamp('created_at').defaultNow(),
});
