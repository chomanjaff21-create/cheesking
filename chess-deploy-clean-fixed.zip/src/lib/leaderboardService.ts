import { useRealtimeStore } from './realtime';
import { buildApiUrl } from './api';

export type LeaderboardCategory = 'rating' | 'wins' | 'coins' | 'friends';

export interface LeaderboardEntry {
  rank: number;
  id: string;
  username: string;
  avatar_url?: string | null;
  is_guest?: boolean;
  rating: number;
  wins: number;
  losses: number;
  draws: number;
  coins: number;
  level: number;
}

export interface LeaderboardResponse {
  success: boolean;
  category: LeaderboardCategory;
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  entries: LeaderboardEntry[];
  currentUser?: LeaderboardEntry | null;
  error?: string;
}

function getAuthHeaders(): { userId: string; headers: Record<string, string> } {
  const { session, account } = useRealtimeStore.getState();
  let token = (session?.token || '').trim();
  let userId = session?.user_id || account?.user?.id || '';

  if (!token && typeof window !== 'undefined') {
    token = (localStorage.getItem('realtime_session') || '').trim();
    try {
      const stored = localStorage.getItem('user_session_info');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (!userId) userId = parsed.user_id;
        if (!token) token = parsed.token;
      }
    } catch {}
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return { userId, headers };
}

/**
 * Fetch server-authoritative leaderboard data.
 * All ranking and sorting is executed directly in PostgreSQL.
 */
export async function getLeaderboard(
  category: LeaderboardCategory = 'rating',
  page: number = 1,
  limit: number = 50,
  friendIds: string[] = []
): Promise<LeaderboardResponse> {
  const { userId, headers } = getAuthHeaders();

  const params = new URLSearchParams();
  params.set('category', category);
  params.set('page', String(page));
  params.set('limit', String(limit));
  if (userId) {
    params.set('userId', userId);
  }
  if (category === 'friends' && friendIds.length > 0) {
    params.set('friendIds', friendIds.join(','));
  }

  const url = buildApiUrl(`/api/leaderboard?${params.toString()}`);
  const res = await fetch(url, { headers });

  if (!res.ok) {
    let errorMsg = `Server error ${res.status}`;
    try {
      const errJson = await res.json();
      if (errJson?.error) errorMsg = errJson.error;
    } catch {}
    throw new Error(errorMsg);
  }

  const data: LeaderboardResponse = await res.json();
  return data;
}
