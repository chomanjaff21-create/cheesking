import { useRealtimeStore } from './realtime';
import { buildApiUrl } from './api';

export interface DailyRewardStatus {
  success: boolean;
  canClaimStreak: boolean;
  claimedToday: boolean;
  currentStreak: number;
  streakDays: Array<{
    day: number;
    coins: number;
    gems: number;
    chestType: 'red' | 'gold' | 'purple';
    claimed: boolean;
    isCurrent: boolean;
  }>;
  play3Count: number;
  play3Claimed: boolean;
  win7Count: number;
  win7Claimed: boolean;
  royalEventClaimed: boolean;
  claimedAdTiers: number[];
  secondsUntilReset: number;
  serverDate: string;
}

export interface DailyClaimResult {
  success: boolean;
  rewardType: string;
  tier?: number;
  streakDay?: number;
  coinsAwarded: number;
  gemsAwarded: number;
  newBalance: number;
  newGems?: number;
  error?: string;
}

export interface PuzzleStatus {
  success: boolean;
  completedPuzzles: string[];
  completedLevels: number[];
  claimedRewards: number[];
}

export interface PuzzleClaimResult {
  success: boolean;
  puzzleId: string;
  levelNumber: number;
  coinsAwarded: number;
  newBalance: number;
  xpAwarded?: number;
  newXp?: number;
  newLevel?: number;
  alreadyClaimed?: boolean;
  error?: string;
}

function getAuthInfo(): { userId: string; headers: Record<string, string> } {
  const { session, account } = useRealtimeStore.getState();
  let token = (session?.token || '').trim();
  let userId = session?.user_id || account?.user?.id || '';

  if (!token && typeof window !== 'undefined') {
    token = (localStorage.getItem('realtime_session') || '').trim();
    try {
      const stored = localStorage.getItem('user_session_info');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (!userId) userId = parsed.user_id;
        if (!token) token = parsed.token;
      }
    } catch {}
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  return { userId, headers };
}

export async function fetchDailyRewardStatus(): Promise<DailyRewardStatus | null> {
  const { userId, headers } = getAuthInfo();
  if (!userId) return null;

  try {
    const res = await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/daily-reward/status`), {
      headers,
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      console.warn('fetchDailyRewardStatus failed:', res.status, errData);
      return null;
    }
    return await res.json();
  } catch (e) {
    console.error('fetchDailyRewardStatus network error:', e);
    return null;
  }
}

export async function claimDailyReward(
  type: 'daily_streak' | 'play_3_games' | 'win_7_streak' | 'royal_event' | 'ad_reward' = 'daily_streak',
  tier = 1
): Promise<DailyClaimResult> {
  const { userId, headers } = getAuthInfo();
  if (!userId) {
    return {
      success: false,
      rewardType: type,
      coinsAwarded: 0,
      gemsAwarded: 0,
      newBalance: 0,
      error: 'User not authenticated',
    };
  }

  try {
    const res = await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/daily-reward/claim`), {
      method: 'POST',
      headers,
      body: JSON.stringify({ type, tier }),
    });

    const data = await res.json().catch(() => ({ error: 'Invalid response from server' }));
    if (!res.ok || !data.success) {
      return {
        success: false,
        rewardType: type,
        coinsAwarded: 0,
        gemsAwarded: 0,
        newBalance: 0,
        error: data.error || 'Failed to claim daily reward',
      };
    }

    return data;
  } catch (e: any) {
    console.error('claimDailyReward network error:', e);
    return {
      success: false,
      rewardType: type,
      coinsAwarded: 0,
      gemsAwarded: 0,
      newBalance: 0,
      error: e.message || 'Network connection failed',
    };
  }
}

export async function fetchPuzzleStatus(): Promise<PuzzleStatus | null> {
  const { userId, headers } = getAuthInfo();
  if (!userId) return null;

  try {
    const res = await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/puzzle/status`), {
      headers,
    });
    if (!res.ok) {
      return null;
    }
    return await res.json();
  } catch (e) {
    console.error('fetchPuzzleStatus network error:', e);
    return null;
  }
}

export async function claimPuzzleReward(
  puzzleId: string,
  levelNumber?: number,
  move?: string
): Promise<PuzzleClaimResult> {
  const { userId, headers } = getAuthInfo();
  if (!userId) {
    return {
      success: false,
      puzzleId,
      levelNumber: levelNumber ?? 0,
      coinsAwarded: 0,
      newBalance: 0,
      error: 'User not authenticated',
    };
  }

  try {
    const res = await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/puzzle/claim`), {
      method: 'POST',
      headers,
      body: JSON.stringify({ puzzleId, levelNumber, move }),
    });

    const data = await res.json().catch(() => ({ error: 'Invalid response from server' }));
    if (!res.ok || !data.success) {
      return {
        success: false,
        puzzleId,
        levelNumber: levelNumber ?? 0,
        coinsAwarded: 0,
        newBalance: 0,
        alreadyClaimed: data.alreadyClaimed || false,
        error: data.error || 'Failed to claim puzzle reward',
      };
    }

    return data;
  } catch (e: any) {
    console.error('claimPuzzleReward network error:', e);
    return {
      success: false,
      puzzleId,
      levelNumber: levelNumber ?? 0,
      coinsAwarded: 0,
      newBalance: 0,
      error: e.message || 'Network connection failed',
    };
  }
}

/** Tells the server the player started watching an ad (the server times it). */
export async function startAdReward(tier: number): Promise<void> {
  const { userId, headers } = getAuthInfo();
  if (!userId) return;
  try {
    await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/ad-reward/start`), {
      method: 'POST',
      headers,
      body: JSON.stringify({ tier }),
    });
  } catch {}
}

/** vs-AI result -> server-side (capped) reward. */
export async function claimAiGameReward(result: 'win' | 'draw' | 'loss'): Promise<{
  success: boolean; rewarded: boolean; coinsAwarded: number; xpAwarded: number; coins: number; xp: number; level: number;
} | null> {
  const { userId, headers } = getAuthInfo();
  if (!userId) return null;
  try {
    const res = await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/ai-game/complete`), {
      method: 'POST',
      headers,
      body: JSON.stringify({ result }),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}
