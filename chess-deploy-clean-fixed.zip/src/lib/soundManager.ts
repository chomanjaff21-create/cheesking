export type MusicTrackId = 'royal_erbil' | 'classical_piano' | 'lofi_ambient';

class SoundManager {
  private ctx: AudioContext | null = null;
  private soundEnabled: boolean = true;
  private musicEnabled: boolean = false;
  private currentTrack: MusicTrackId = 'royal_erbil';
  private musicGainNode: GainNode | null = null;
  private musicOscillators: OscillatorNode[] = [];
  private sequenceTimer: number | null = null;
  private riverGainNode: GainNode | null = null;
  private riverSourceNode: AudioBufferSourceNode | null = null;
  private riverTimer: number | null = null;
  private desertGainNode: GainNode | null = null;
  private desertSourceNode: AudioBufferSourceNode | null = null;
  private desertTimer: number | null = null;

  constructor() {
    // Unlock audio on the very first touch/click so the FIRST move sound is not
    // delayed or lost (browsers start the AudioContext suspended).
    if (typeof window !== 'undefined') {
      const unlock = () => {
        try { this.initCtx(); } catch {}
        window.removeEventListener('pointerdown', unlock);
        window.removeEventListener('touchstart', unlock);
        window.removeEventListener('keydown', unlock);
      };
      window.addEventListener('pointerdown', unlock, { passive: true });
      window.addEventListener('touchstart', unlock, { passive: true });
      window.addEventListener('keydown', unlock);
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx({ latencyHint: 'interactive' });
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
    if (!enabled) {
      this.stopAllAmbience();
    }
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    if (enabled) {
      this.startAmbientMusic();
    } else {
      this.stopAmbientMusic();
    }
  }

  public setMusicTrack(track: MusicTrackId) {
    this.currentTrack = track;
    if (this.musicEnabled) {
      this.startAmbientMusic();
    }
  }

  public getCurrentTrack(): MusicTrackId {
    return this.currentTrack;
  }

  public playMove() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, this.ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.08);
  }

  public playCapture() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    // Heavy wooden thud + snap
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.12);

    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.12);
  }

  public playWaterSplash() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.exponentialRampToValueAtTime(1100, now + 0.05);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.12);

      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.12);
    } catch {}
  }

  public playWaterVortexCapture() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;

      // 1. Initial heavy water plunge splash
      const plungeOsc = this.ctx.createOscillator();
      const plungeGain = this.ctx.createGain();
      plungeOsc.type = 'sine';
      plungeOsc.frequency.setValueAtTime(450, now);
      plungeOsc.frequency.exponentialRampToValueAtTime(800, now + 0.04);
      plungeOsc.frequency.exponentialRampToValueAtTime(120, now + 0.28);

      plungeGain.gain.setValueAtTime(0.35, now);
      plungeGain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      plungeOsc.connect(plungeGain);
      plungeGain.connect(this.ctx.destination);
      plungeOsc.start(now);
      plungeOsc.stop(now + 0.3);

      // 2. Swirling bubbling water vortex effect
      [0, 0.06, 0.12, 0.18].forEach((offset, idx) => {
        if (!this.ctx) return;
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();
        bOsc.type = 'triangle';
        const startFreq = 500 - idx * 80;
        bOsc.frequency.setValueAtTime(startFreq, now + offset);
        bOsc.frequency.exponentialRampToValueAtTime(startFreq + 250, now + offset + 0.04);
        bOsc.frequency.exponentialRampToValueAtTime(140, now + offset + 0.12);

        bGain.gain.setValueAtTime(0.18, now + offset);
        bGain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.12);

        bOsc.connect(bGain);
        bGain.connect(this.ctx.destination);
        bOsc.start(now + offset);
        bOsc.stop(now + offset + 0.12);
      });
    } catch {}
  }

  public playCheck() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    // Dual brass alert chime
    [523.25, 659.25, 783.99].forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.06);

      gain.gain.setValueAtTime(0.2, now + idx * 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.06 + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now + idx * 0.06);
      osc.stop(now + idx * 0.06 + 0.3);
    });
  }

  public playVictory() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [440, 554.37, 659.25, 880]; // A major arpeggio
    notes.forEach((freq, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.12);

      gain.gain.setValueAtTime(0.3, now + i * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.12 + 0.5);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now + i * 0.12);
      osc.stop(now + i * 0.12 + 0.5);
    });
  }

  public playGameOver() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const notes = [440, 392, 349.23, 293.66]; // Descending minor chords
    notes.forEach((freq, i) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now + i * 0.14);

      gain.gain.setValueAtTime(0.25, now + i * 0.14);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.14 + 0.5);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now + i * 0.14);
      osc.stop(now + i * 0.14 + 0.5);
    });
  }

  public playCountdownBeep(isFinal: boolean = false) {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    if (!isFinal) {
      // Crisp metallic high beep for 3, 2, 1
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
      gain.gain.setValueAtTime(0.4, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.18);
    } else {
      // Powerful golden gong chord for START!
      const chord = [523.25, 659.25, 783.99, 1046.5]; // C Major
      chord.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + idx * 0.02);
        osc.stop(now + 0.65);
      });
    }
  }

  public playTimeoutBoom() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    // Sub-bass thump
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(24, now + 0.6);
    gain.gain.setValueAtTime(0.8, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.65);

    // Filtered noise burst for explosion crackle
    const bufferSize = this.ctx.sampleRate * 0.4;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.08));
    }
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(800, now);
    filter.frequency.exponentialRampToValueAtTime(80, now + 0.4);
    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.6, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);
    noise.start(now);
  }

  public playClick() {
    if (!this.soundEnabled) return;
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.03);

    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    osc.stop(now + 0.03);
  }

  private startAmbientMusic() {
    this.stopAmbientMusic();
    this.initCtx();
    if (!this.ctx) return;

    const now = this.ctx.currentTime;
    this.musicGainNode = this.ctx.createGain();
    this.musicGainNode.gain.setValueAtTime(0.08, now);
    this.musicGainNode.connect(this.ctx.destination);

    let baseFreqs: number[] = [];
    let leadScale: number[] = [];

    if (this.currentTrack === 'royal_erbil') {
      // Kurdish Hijaz / Bayati oriental drone pad
      baseFreqs = [110, 146.83, 220, 293.66]; // A2, D3, A3, D4
      leadScale = [220, 246.94, 261.63, 293.66, 329.63, 349.23, 392.0];
    } else if (this.currentTrack === 'classical_piano') {
      // Classical Grandmaster Am / C major pad
      baseFreqs = [110, 130.81, 164.81, 220]; // A2, C3, E3, A3
      leadScale = [220, 261.63, 329.63, 392.0, 440.0, 523.25, 659.25];
    } else {
      // Chill Lo-Fi Chess Ambient
      baseFreqs = [98.0, 123.47, 146.83, 196.0]; // G2, B2, D3, G3
      leadScale = [196.0, 220.0, 246.94, 293.66, 329.63, 392.0];
    }

    // Create sustained warm pad oscillators
    baseFreqs.forEach((freq) => {
      if (!this.ctx || !this.musicGainNode) return;
      const osc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, now);

      osc.type = this.currentTrack === 'lofi_ambient' ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(freq, now);

      // Tremolo LFO
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.setValueAtTime(0.15, now);
      lfoGain.gain.setValueAtTime(3, now);
      lfo.connect(osc.frequency);
      lfo.start();

      osc.connect(filter);
      filter.connect(this.musicGainNode);
      osc.start();

      this.musicOscillators.push(osc, lfo);
    });

    // Schedule gentle, meditative random lead chime notes every 2 seconds
    let step = 0;
    this.sequenceTimer = window.setInterval(() => {
      if (!this.ctx || !this.musicGainNode || !this.musicEnabled) return;
      const noteNow = this.ctx.currentTime;

      // Pick a harmonic note from lead scale
      const noteFreq = leadScale[step % leadScale.length];
      step = (step + Math.floor(Math.random() * 3) + 1) % leadScale.length;

      const leadOsc = this.ctx.createOscillator();
      const leadGain = this.ctx.createGain();

      leadOsc.type = this.currentTrack === 'royal_erbil' ? 'triangle' : 'sine';
      leadOsc.frequency.setValueAtTime(noteFreq, noteNow);

      leadGain.gain.setValueAtTime(0.04, noteNow);
      leadGain.gain.exponentialRampToValueAtTime(0.0005, noteNow + 1.8);

      leadOsc.connect(leadGain);
      leadGain.connect(this.musicGainNode);

      leadOsc.start(noteNow);
      leadOsc.stop(noteNow + 1.8);
    }, 2200);
  }

  private stopAmbientMusic() {
    if (this.sequenceTimer !== null) {
      clearInterval(this.sequenceTimer);
      this.sequenceTimer = null;
    }
    this.musicOscillators.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch {
        // ignore
      }
    });
    this.musicOscillators = [];
    if (this.musicGainNode) {
      try {
        this.musicGainNode.disconnect();
      } catch {
        // ignore
      }
      this.musicGainNode = null;
    }
  }

  public startRiverAmbience() {
    if (!this.soundEnabled) return;
    this.stopRiverAmbience();
    this.initCtx();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // Master River Gain (Very soft, soothing, peaceful stream sound)
      this.riverGainNode = this.ctx.createGain();
      this.riverGainNode.gain.setValueAtTime(0.001, now);
      this.riverGainNode.gain.linearRampToValueAtTime(0.045, now + 1.2);
      this.riverGainNode.connect(this.ctx.destination);

      // 2-second looped soft pink noise buffer for realistic rushing river
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        output[i] *= 0.035;
        b6 = white * 0.115926;
      }

      this.riverSourceNode = this.ctx.createBufferSource();
      this.riverSourceNode.buffer = noiseBuffer;
      this.riverSourceNode.loop = true;

      const lpFilter = this.ctx.createBiquadFilter();
      lpFilter.type = 'lowpass';
      lpFilter.frequency.setValueAtTime(360, now);

      const bpFilter = this.ctx.createBiquadFilter();
      bpFilter.type = 'bandpass';
      bpFilter.frequency.setValueAtTime(700, now);
      bpFilter.Q.setValueAtTime(1.2, now);

      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.setValueAtTime(0.18, now);
      lfoGain.gain.setValueAtTime(70, now);
      lfo.connect(lpFilter.frequency);
      lfo.start(now);

      this.riverSourceNode.connect(lpFilter);
      lpFilter.connect(this.riverGainNode);
      this.riverSourceNode.connect(bpFilter);
      bpFilter.connect(this.riverGainNode);

      this.riverSourceNode.start(now);

      // Periodic gentle water droplet / trickle sounds
      this.riverTimer = window.setInterval(() => {
        if (!this.ctx || !this.riverGainNode) return;
        const popNow = this.ctx.currentTime;
        const popOsc = this.ctx.createOscillator();
        const popGain = this.ctx.createGain();

        popOsc.type = 'sine';
        const startFreq = 750 + Math.random() * 500;
        popOsc.frequency.setValueAtTime(startFreq, popNow);
        popOsc.frequency.exponentialRampToValueAtTime(startFreq * 1.5, popNow + 0.04);

        popGain.gain.setValueAtTime(0.007, popNow);
        popGain.gain.exponentialRampToValueAtTime(0.0001, popNow + 0.05);

        popOsc.connect(popGain);
        popGain.connect(this.riverGainNode);

        popOsc.start(popNow);
        popOsc.stop(popNow + 0.05);
      }, 2000);

    } catch (e) {
      console.warn('River sound error:', e);
    }
  }

  public stopRiverAmbience() {
    if (this.riverTimer !== null) {
      clearInterval(this.riverTimer);
      this.riverTimer = null;
    }
    if (this.riverSourceNode) {
      try {
        this.riverSourceNode.stop();
        this.riverSourceNode.disconnect();
      } catch {}
      this.riverSourceNode = null;
    }
    if (this.riverGainNode) {
      try {
        if (this.ctx) {
          this.riverGainNode.gain.cancelScheduledValues(this.ctx.currentTime);
          this.riverGainNode.gain.setValueAtTime(0, this.ctx.currentTime);
        }
        this.riverGainNode.disconnect();
      } catch {}
      this.riverGainNode = null;
    }
  }

  public startDesertAmbience() {
    if (!this.soundEnabled) return;
    this.stopDesertAmbience();
    this.initCtx();
    if (!this.ctx) return;
    if (this.desertSourceNode) return;

    try {
      const now = this.ctx.currentTime;
      this.desertGainNode = this.ctx.createGain();
      this.desertGainNode.gain.setValueAtTime(0.0001, now);
      this.desertGainNode.gain.linearRampToValueAtTime(0.12, now + 1.5);
      this.desertGainNode.connect(this.ctx.destination);

      // Generate brown/pink noise buffer for warm desert wind
      const bufferSize = this.ctx.sampleRate * 4;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = output[i];
        output[i] *= 0.55;
      }

      this.desertSourceNode = this.ctx.createBufferSource();
      this.desertSourceNode.buffer = noiseBuffer;
      this.desertSourceNode.loop = true;

      const lpFilter = this.ctx.createBiquadFilter();
      lpFilter.type = 'lowpass';
      lpFilter.frequency.setValueAtTime(240, now);

      const bpFilter = this.ctx.createBiquadFilter();
      bpFilter.type = 'bandpass';
      bpFilter.frequency.setValueAtTime(420, now);
      bpFilter.Q.setValueAtTime(2.5, now);

      // Modulating desert breeze LFO
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.setValueAtTime(0.12, now);
      lfoGain.gain.setValueAtTime(120, now);
      lfo.connect(bpFilter.frequency);
      lfo.start(now);

      this.desertSourceNode.connect(lpFilter);
      lpFilter.connect(this.desertGainNode);
      this.desertSourceNode.connect(bpFilter);
      bpFilter.connect(this.desertGainNode);

      this.desertSourceNode.start(now);

      // Periodic subtle mystic desert wind whistle chime
      this.desertTimer = window.setInterval(() => {
        if (!this.ctx || !this.desertGainNode) return;
        const chimeNow = this.ctx.currentTime;
        const chimeOsc = this.ctx.createOscillator();
        const chimeGain = this.ctx.createGain();

        chimeOsc.type = 'sine';
        const freqs = [440, 523.25, 587.33, 659.25, 783.99];
        const chosenFreq = freqs[Math.floor(Math.random() * freqs.length)];
        chimeOsc.frequency.setValueAtTime(chosenFreq, chimeNow);

        chimeGain.gain.setValueAtTime(0.0001, chimeNow);
        chimeGain.gain.linearRampToValueAtTime(0.008, chimeNow + 0.4);
        chimeGain.gain.exponentialRampToValueAtTime(0.0001, chimeNow + 1.6);

        chimeOsc.connect(chimeGain);
        chimeGain.connect(this.desertGainNode);

        chimeOsc.start(chimeNow);
        chimeOsc.stop(chimeNow + 1.6);
      }, 4500);

    } catch (e) {
      console.warn('Desert sound error:', e);
    }
  }

  public stopDesertAmbience() {
    if (this.desertTimer !== null) {
      clearInterval(this.desertTimer);
      this.desertTimer = null;
    }
    if (this.desertSourceNode) {
      try {
        this.desertSourceNode.stop();
        this.desertSourceNode.disconnect();
      } catch {}
      this.desertSourceNode = null;
    }
    if (this.desertGainNode) {
      try {
        if (this.ctx) {
          this.desertGainNode.gain.cancelScheduledValues(this.ctx.currentTime);
          this.desertGainNode.gain.setValueAtTime(0, this.ctx.currentTime);
        }
        this.desertGainNode.disconnect();
      } catch {}
      this.desertGainNode = null;
    }
  }

  public stopAllAmbience() {
    this.stopRiverAmbience();
    this.stopDesertAmbience();
  }
}

export const soundManager = new SoundManager();

