import { Chess, Square, Move } from 'chess.js';
import { AIDifficulty, ChessPuzzle } from '../types';

export class ChessEngine {
  private game: Chess;

  constructor(fen?: string) {
    this.game = new Chess(fen);
  }

  public reset(fen?: string) {
    this.game = new Chess(fen);
  }

  public getFen(): string {
    return this.game.fen();
  }

  public getTurn(): 'w' | 'b' {
    return this.game.turn();
  }

  public isCheck(): boolean {
    return this.game.inCheck();
  }

  public isGameOver(): boolean {
    return this.game.isGameOver();
  }

  public isCheckmate(): boolean {
    return this.game.isCheckmate();
  }

  public isDraw(): boolean {
    return this.game.isDraw();
  }

  public isStalemate(): boolean {
    return this.game.isStalemate();
  }

  public getBoard() {
    return this.game.board();
  }

  public getLegalMoves(square?: string): Move[] {
    if (square) {
      return this.game.moves({ square: square as Square, verbose: true });
    }
    return this.game.moves({ verbose: true });
  }

  public makeMove(from: string, to: string, promotion: string = 'q'): Move | null {
    try {
      const move = this.game.move({
        from: from as Square,
        to: to as Square,
        promotion,
      });
      return move;
    } catch {
      return null;
    }
  }

  public undo(): Move | null {
    return this.game.undo();
  }

  public getHistory(): Move[] {
    return this.game.history({ verbose: true });
  }

  // Evaluate board for AI Bot with fast piece values and positional tables
  private evaluateBoard(): number {
    const board = this.game.board();
    let score = 0;

    for (let r = 0; r < 8; r++) {
      const row = board[r];
      for (let c = 0; c < 8; c++) {
        const piece = row[c];
        if (!piece) continue;

        let val = 0;
        switch (piece.type) {
          case 'p': val = 100 + (piece.color === 'w' ? (7 - r) * 10 : r * 10); break;
          case 'n': val = 320 + ((c >= 2 && c <= 5 && r >= 2 && r <= 5) ? 20 : 0); break;
          case 'b': val = 330; break;
          case 'r': val = 500; break;
          case 'q': val = 900; break;
          case 'k': val = 20000; break;
        }

        if (piece.color === 'w') {
          score += val;
        } else {
          score -= val;
        }
      }
    }
    return score;
  }

  public getBestAIMove(difficulty: AIDifficulty): Move | null {
    const legalMoves = this.game.moves({ verbose: true });
    if (legalMoves.length === 0) return null;

    if (difficulty === 'easy') {
      // 70% random, 30% capture if available
      const captures = legalMoves.filter((m) => m.captured);
      if (captures.length > 0 && Math.random() < 0.4) {
        return captures[Math.floor(Math.random() * captures.length)];
      }
      return legalMoves[Math.floor(Math.random() * legalMoves.length)];
    }

    if (difficulty === 'medium') {
      // Depth 2 minimax with move ordering
      let bestMove: Move | null = null;
      const isBlack = this.getTurn() === 'b';
      let bestEval = isBlack ? Infinity : -Infinity;

      // Sort captures first for earlier pruning
      legalMoves.sort((a, b) => (b.captured ? 10 : 0) - (a.captured ? 10 : 0));

      for (const move of legalMoves) {
        this.game.move(move);
        const evalScore = this.evaluateBoard();
        this.game.undo();

        if (isBlack) {
          if (evalScore < bestEval) {
            bestEval = evalScore;
            bestMove = move;
          }
        } else {
          if (evalScore > bestEval) {
            bestEval = evalScore;
            bestMove = move;
          }
        }
      }
      return bestMove || legalMoves[Math.floor(Math.random() * legalMoves.length)];
    }

    // Hard / Gemini Master
    // Minimax depth 3 with alpha-beta and move ordering
    const isBlack = this.getTurn() === 'b';
    let bestMove: Move | null = null;
    let bestScore = isBlack ? Infinity : -Infinity;

    // Sort moves: Captures first for maximum alpha-beta cutoff rate
    legalMoves.sort((a, b) => (b.captured ? 10 : 0) - (a.captured ? 10 : 0));

    for (const move of legalMoves) {
      this.game.move(move);
      const score = this.minimax(2, -Infinity, Infinity, !isBlack);
      this.game.undo();

      if (isBlack) {
        if (score < bestScore) {
          bestScore = score;
          bestMove = move;
        }
      } else {
        if (score > bestScore) {
          bestScore = score;
          bestMove = move;
        }
      }
    }

    return bestMove || legalMoves[Math.floor(Math.random() * legalMoves.length)];
  }

  private minimax(depth: number, alpha: number, beta: number, isMaximizing: boolean): number {
    if (depth === 0 || this.game.isGameOver()) {
      return this.evaluateBoard();
    }

    const moves = this.game.moves({ verbose: true });
    // Move ordering: sort captures and checks first to dramatically speed up alpha-beta pruning
    moves.sort((a, b) => (b.captured ? 10 : 0) - (a.captured ? 10 : 0));

    if (isMaximizing) {
      let maxEval = -Infinity;
      for (const move of moves) {
        this.game.move(move);
        const evaluation = this.minimax(depth - 1, alpha, beta, false);
        this.game.undo();
        maxEval = Math.max(maxEval, evaluation);
        alpha = Math.max(alpha, evaluation);
        if (beta <= alpha) break;
      }
      return maxEval;
    } else {
      let minEval = Infinity;
      for (const move of moves) {
        this.game.move(move);
        const evaluation = this.minimax(depth - 1, alpha, beta, true);
        this.game.undo();
        minEval = Math.min(minEval, evaluation);
        beta = Math.min(beta, evaluation);
        if (beta <= alpha) break;
      }
      return minEval;
    }
  }
}

export const samplePuzzles: ChessPuzzle[] = [
  {
    id: 'p1',
    titleKu: 'مات بە یەک جووڵە - Scholar Mate',
    titleEn: 'Mate in 1 - Scholar Classic',
    descriptionKu: 'بە وەزیر شای بەرامبەر بگرە و یاریەکە ببەرەوە!',
    descriptionEn: 'Deliver checkmate with your Queen on f7!',
    fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
    solutionMoves: ['h5f7'],
    difficulty: 'easy',
    rewardCoins: 100,
  },
  {
    id: 'p2',
    titleKu: 'چەقۆزدنی وەزیر (Fork Attack)',
    titleEn: 'Knight Fork Strategy',
    descriptionKu: 'بە ئەسپ هێرش بکەرە سەر شا و وەزیری دوژمن لە یەک کاتدا!',
    descriptionEn: 'Fork the Enemy King and Queen using your Knight on c7!',
    fen: 'r1b1k2r/pppp1ppp/8/2q5/4N3/8/PPPP1PPP/R1BQK2R w KQkq - 0 1',
    solutionMoves: ['e4c5'],
    difficulty: 'medium',
    rewardCoins: 250,
  },
  {
    id: 'p3',
    titleKu: 'ماتی پشتەوە (Back Rank Mate)',
    titleEn: 'Back Rank Mate',
    descriptionKu: 'بە ڕوخ شوێنی شای پشتەوە بگرە و مات بکە!',
    descriptionEn: 'Checkmate the trapped King on the 8th rank with your Rook!',
    fen: '6k1/5ppp/8/8/8/8/5PPP/1R4K1 w - - 0 1',
    solutionMoves: ['b1b8'],
    difficulty: 'easy',
    rewardCoins: 150,
  },
  {
    id: 'p4',
    titleKu: 'قوربانیدانی گەورەی وەزیر (Smothered Mate)',
    titleEn: 'Smothered Mate Pattern',
    descriptionKu: 'تەکتیکی ماتی خنکێنەر بۆ شای گۆشەگیرکراو!',
    descriptionEn: 'Smother the enemy King with a Knight checkmate!',
    fen: '6rk/5Npp/8/8/8/8/8/6K1 w - - 0 1',
    solutionMoves: ['f7h6'],
    difficulty: 'hard',
    rewardCoins: 500,
  },
];
