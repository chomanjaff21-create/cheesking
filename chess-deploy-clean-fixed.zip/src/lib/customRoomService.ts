import { buildApiUrl } from './api';
import { useRealtimeStore } from './realtime';

export interface CustomRoomInfo {
  code: string;
  matchId: string;
  timeMin: number;
  stake: number;
  prize: number;
  status: 'waiting' | 'active' | 'completed' | 'expired';
  assignedColor?: 'w' | 'b';
  opponent?: { userId: string; username: string; avatar?: string; rating?: number; level?: number };
}

function getAuthHeaders(): Record<string, string> {
  const { session } = useRealtimeStore.getState();
  const token = (session?.token || session?.user_id || '').trim();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export async function createCustomRoom(
  timeMin: number = 5,
  stake: number = 0
): Promise<{ success: boolean; room?: CustomRoomInfo; error?: string }> {
  try {
    const res = await fetch(buildApiUrl('/api/custom-rooms/create'), {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ timeMin, stake }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Failed to create private room' };
    }
    return { success: true, room: data.room };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error creating private room' };
  }
}

export async function joinCustomRoom(
  code: string
): Promise<{ success: boolean; room?: CustomRoomInfo; error?: string }> {
  try {
    const cleanCode = code.trim();
    const res = await fetch(buildApiUrl('/api/custom-rooms/join'), {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ code: cleanCode }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Failed to join private room' };
    }
    return {
      success: true,
      room: {
        code: data.code,
        matchId: data.matchId,
        assignedColor: data.assignedColor,
        opponent: data.opponent,
        timeMin: data.timeMin,
        stake: data.stake ?? 0,
        prize: data.prize ?? 0,
        status: 'active',
      },
    };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error joining private room' };
  }
}

export async function getCustomRoomStatus(
  code: string
): Promise<{ success: boolean; data?: any; error?: string }> {
  try {
    const res = await fetch(buildApiUrl(`/api/custom-rooms/${encodeURIComponent(code)}/status`), {
      headers: getAuthHeaders(),
    });
    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data.error || 'Failed to check room status' };
    }
    return { success: true, data };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error checking room status' };
  }
}

export async function cancelCustomRoom(code: string): Promise<{ success: boolean }> {
  try {
    const res = await fetch(buildApiUrl(`/api/custom-rooms/${encodeURIComponent(code)}/cancel`), {
      method: 'POST',
      headers: getAuthHeaders(),
    });
    return { success: res.ok };
  } catch {
    return { success: false };
  }
}
