export type ShopItemType = 'board' | 'piece' | 'avatar' | 'cosmetic';

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  type: ShopItemType;
  priceCoins?: number;
  priceGems?: number;
  imageUrl?: string;
  colorHex?: string;
}

export const SHOP_CATALOG: ShopItem[] = [
  { id: 'board_obsidian', name: 'Obsidian Board', description: 'A sleek, dark glass board.', type: 'board', priceGems: 200, colorHex: '#1e293b' },
  { id: 'board_marble', name: 'Marble Board', description: 'Classic white and gold marble.', type: 'board', priceCoins: 5000, colorHex: '#f1f5f9' },
  { id: 'piece_neon', name: 'Neon Pieces', description: 'Glowing cyberpunk chess pieces.', type: 'piece', priceGems: 400 },
  { id: 'piece_gold', name: 'Solid Gold Pieces', description: 'Show off your wealth.', type: 'piece', priceCoins: 10000 },
  { id: 'avatar_dragon', name: 'Dragon Avatar', description: 'Fierce dragon profile picture.', type: 'avatar', priceCoins: 2000 },
  { id: 'avatar_king', name: 'Royal King Avatar', description: 'The true ruler.', type: 'avatar', priceGems: 100 },
  { id: 'cosmetic_sparkle', name: 'Sparkle Move Effect', description: 'Sparkles when you move.', type: 'cosmetic', priceGems: 50 },
];
