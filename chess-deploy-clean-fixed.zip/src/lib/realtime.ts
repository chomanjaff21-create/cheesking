import { create } from 'zustand';
import { Capacitor } from '@capacitor/core';
import { signUpWithEmail, signInWithEmail, signOutUser, signInAsGuest, signInWithGoogle, upgradeAnonymousAccount, supabase } from './supabase';
import { buildApiUrl } from './api';

// --- Binary <-> Base64 helpers (WebSocket JSON messages carry match data as base64 text) ---
function uint8ToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToUint8(b64: string): Uint8Array {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

export interface MatchDataEvent {
  matchId: string;
  opCode: number;
  data: Uint8Array;
}

export interface MatchPresenceEvent {
  matchId: string;
  joins?: { user_id: string }[];
  leaves?: { user_id: string }[];
  event?: string;
  metadata?: any;
}

export interface OpponentDisconnectEvent {
  matchId: string;
  userId: string;
  gracePeriodMs: number;
  expiresAt: number;
}

export interface OpponentReconnectEvent {
  matchId: string;
  userId: string;
}

export interface MatchAbandonedEvent {
  matchId: string;
  winner: 'w' | 'b' | null;
  reason: string;
  status: string;
  disconnectedUserId?: string;
}

export interface MatchedEvent {
  matchId: string;
  assignedColor: 'w' | 'b';
  opponent: { userId: string; username: string };
  tableId?: string;
  entryFee?: number;
}

export interface BalanceUpdateEvent {
  userId: string;
  coins: number;
  matchId?: string;
}

export interface CustomRoomMatchedEvent {
  code: string;
  matchId: string;
  assignedColor: 'w' | 'b';
  opponent: { userId: string; username: string };
  timeMin: number;
  stake?: number;
  prize?: number;
}

/**
 * Lightweight realtime client used for online matchmaking and live move sync.
 * Runs over a plain WebSocket to our own server (server.ts) — no third-party
 * realtime service required.
 */
export class RealtimeSocket {
  ws: any;
  ondisconnect?: (evt?: any) => void;
  onerror?: (evt?: any) => void;
  onreconnect?: () => void;
  onreconnecting?: (attempt?: number) => void;
  onmatched?: (msg: any) => void;
  onmatchdata?: (msg: any) => void;
  onmatchpresence?: (msg: any) => void;
  onmatchstate?: (msg: any) => void;
  onmatchdisconnect?: (msg: any) => void;
  onmatchreconnect?: (msg: any) => void;
  onmatchabandoned?: (msg: any) => void;
  oncustomroommatched?: (msg: any) => void;
  onbalanceupdate?: (msg: any) => void;
  onqueueerror?: (msg: any) => void;
  onfriendinvite?: (msg: any) => void;
  onfriendinviteack?: (msg: any) => void;
  onmatchchat?: (msg: any) => void;

  constructor(ws: any) {
    this.ws = ws;

    this.ws.on('message', (data: string) => {
      let msg: any;
      try {
        msg = typeof data === 'string' ? JSON.parse(data) : data;
      } catch {
        return;
      }

      if (msg.type === 'friend_invite_received' && this.onfriendinvite) {
        this.onfriendinvite(msg);
      } else if (msg.type === 'match_chat' && this.onmatchchat) {
        this.onmatchchat(msg);
      } else if (msg.type === 'friend_invite_ack' && this.onfriendinviteack) {
        this.onfriendinviteack(msg);
      } else if (msg.type === 'match_data' && this.onmatchdata) {
        this.onmatchdata({ matchId: msg.matchId, opCode: msg.opCode, data: base64ToUint8(msg.data) });
      } else if (msg.type === 'presence' && this.onmatchpresence) {
        this.onmatchpresence({
          matchId: msg.matchId,
          joins: msg.event === 'join' ? [{ user_id: msg.userId }] : [],
          leaves: msg.event === 'leave' ? [{ user_id: msg.userId }] : [],
          event: msg.event,
          metadata: msg.metadata
        });
      } else if (msg.type === 'opponent_disconnected') {
        if (this.onmatchdisconnect) this.onmatchdisconnect(msg);
        if (this.onmatchpresence) {
          this.onmatchpresence({
            matchId: msg.matchId,
            joins: [],
            leaves: [{ user_id: msg.userId }],
            event: 'disconnected',
            metadata: msg
          });
        }
      } else if (msg.type === 'opponent_reconnected') {
        if (this.onmatchreconnect) this.onmatchreconnect(msg);
        if (this.onmatchpresence) {
          this.onmatchpresence({
            matchId: msg.matchId,
            joins: [{ user_id: msg.userId }],
            leaves: [],
            event: 'reconnect',
            metadata: msg
          });
        }
      } else if (msg.type === 'match_abandoned') {
        if (this.onmatchabandoned) this.onmatchabandoned(msg);
      } else if (msg.type === 'custom_room_matched') {
        if (this.oncustomroommatched) {
          this.oncustomroommatched(msg);
        }
        if (this.onmatched) {
          this.onmatched({
            matchId: msg.matchId,
            assignedColor: msg.assignedColor,
            opponent: msg.opponent,
            tableId: 'custom',
            entryFee: msg.stake
          });
        }
      } else if (msg.type === 'matched' && this.onmatched) {
        this.onmatched({
          matchId: msg.matchId,
          assignedColor: msg.assignedColor,
          opponent: msg.opponent,
          tableId: msg.tableId,
          entryFee: msg.entryFee
        });
      } else if (msg.type === 'balance_update' && this.onbalanceupdate) {
        this.onbalanceupdate({
          userId: msg.userId,
          coins: msg.coins,
          matchId: msg.matchId
        });
      } else if (msg.type === 'queue_error' && this.onqueueerror) {
        this.onqueueerror({ error: msg.error });
      }
    });

    this.ws.on('disconnect', (evt: any) => {
      if (this.ondisconnect) this.ondisconnect(evt);
    });

    this.ws.on('reconnect', () => {
      if (this.onreconnect) this.onreconnect();
    });

    this.ws.on('reconnect_attempt', (attempt: number) => {
      if (this.onreconnecting) this.onreconnecting(attempt);
    });

    this.ws.on('connect_error', (evt: any) => {
      if (this.onerror) this.onerror(evt);
    });
  }

  get isOpen() { return this.ws.connected; }

  /** Send a move / resign / clock event to the opponent in a match. */
  sendMatchState(matchId: string, opCode: number, data: Uint8Array) {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({ type: 'match_data', matchId, opCode, data: uint8ToBase64(data) }));
  }

  sendMatchChat(matchId: string, text: string) {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({ type: 'match_chat', matchId, text }));
  }

  sendFriendInvite(targetId: string, code: string, inviterName: string) {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({
      type: 'friend_invite',
      targetId,
      code,
      inviterName
    }));
  }

  /** Subscribe this connection to a match's events (used on join & reconnect). */
  joinMatch(matchId: string): Promise<void> {
    return new Promise(async (resolve) => {
      if (this.isOpen) this.ws.emit('message', JSON.stringify({ type: 'join_match', matchId }));
      resolve();
    });
  }

  leaveMatch(matchId: string) {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({ type: 'leave_match', matchId }));
  }

  /** Subscribe this connection to a custom room by code. */
  joinCustomRoom(code: string) {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({ type: 'join_custom_room', code }));
  }

  /** Enter the online matchmaking queue for a given table/stake. */
  joinQueue(tableId: string, username: string) {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({ type: 'queue_join', tableId, username }));
  }

  leaveQueue() {
    if (!this.isOpen) return;
    this.ws.emit('message', JSON.stringify({ type: 'queue_leave' }));
  }

  disconnect(_fireDisconnectEvent = true) {
    try {
      this.ws.close();
    } catch {}
  }
}

function getSocketServerUrl(): string {
  if (Capacitor.isNativePlatform()) {
    const envUrl = import.meta.env.VITE_APP_URL;
    if (envUrl) {
      return envUrl.replace(/\/+$/, '');
    }
  }
  const protocol = typeof window !== 'undefined' && window.location.protocol === 'https:' ? 'https:' : 'http:';
  const host = typeof window !== 'undefined' && window.location.host ? window.location.host : 'localhost:3000';
  return `${protocol}//${host}`;
}

/** Opens a WebSocket to our own server and identifies the current user. */
let connectionPromise: Promise<RealtimeSocket | null> | null = null;

export const connectRealtimeSocket = (
  session: any,
  onDisconnect?: (evt: Event) => void,
  onError?: (evt: Event) => void
): Promise<RealtimeSocket | null> => {
  if (connectionPromise) return connectionPromise;

  connectionPromise = new Promise(async (resolve) => {
    if (!session?.user_id) {
      console.warn('[Realtime] Cannot connect socket without active session');
      resolve(null);
      return;
    }

    try {
      const { io } = await import('socket.io-client');
      const socketServerUrl = getSocketServerUrl();
      const ws = io(socketServerUrl, {
        path: '/ws',
        transports: ['websocket'],
        reconnection: true,
        reconnectionAttempts: Infinity,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        timeout: 20000,
      });
      const socket = new RealtimeSocket(ws);

      socket.ondisconnect = (evt) => {
        console.warn('[Realtime Socket] Disconnected:', evt);
        useRealtimeStore.setState({ isConnected: false });
        if (onDisconnect) onDisconnect(evt);
      };

      socket.onerror = (evt) => {
        console.error('[Realtime Socket] Error:', evt);
        if (onError) onError(evt);
      };

      const sendIdentify = () => {
        const currentSession = useRealtimeStore.getState().session || session;
        if (currentSession?.user_id) {
          ws.emit('message', JSON.stringify({
            type: 'identify',
            userId: currentSession.user_id,
            token: currentSession.token,
            username: currentSession.username || 'Player'
          }));
          // If in an active match, auto rejoin room
          try {
            const activeMatchId = localStorage.getItem('active_match_id');
            if (activeMatchId) {
              ws.emit('message', JSON.stringify({ type: 'join_match', matchId: activeMatchId }));
            }
          } catch {}
        }
      };

      ws.on('connect', () => {
        sendIdentify();
        useRealtimeStore.setState({ socket, isConnected: true, error: null });
        console.log('[Realtime Socket] Connected successfully to', socketServerUrl);
        connectionPromise = null;
        resolve(socket);
      });

      ws.on('reconnect', () => {
        console.log('[Realtime Socket] Reconnected');
        sendIdentify();
        useRealtimeStore.setState({ socket, isConnected: true, error: null });
      });

      // If already connected
      if (ws.connected) {
        sendIdentify();
        useRealtimeStore.setState({ socket, isConnected: true, error: null });
        connectionPromise = null;
        resolve(socket);
      }
      
      // Add a safety timeout so it doesn't hang forever
      setTimeout(() => {
        if (!ws.connected) {
          console.warn('[Realtime Socket] Connection timed out after 5000ms');
          connectionPromise = null;
          resolve(null);
        }
      }, 5000);
    } catch (err: any) {
      console.error('[Realtime Socket] Connection failed:', err);
      useRealtimeStore.setState({ isConnected: false, error: err.message || 'Socket connection failed' });
      connectionPromise = null;
      resolve(null);
    }
  });
};

export const clearConnectionPromise = () => {
  connectionPromise = null;
};

interface RealtimeState {
  session: any | null;
  socket: RealtimeSocket | null;
  account: any | null;
  isAuthenticated: boolean;
  isConnecting: boolean;
  isConnected: boolean;
  error: string | null;
  showWelcomeReward: boolean;

  authenticate: (email: string, password: string, isRegister?: boolean, username?: string) => Promise<{ isNewUser?: boolean }>;
  authenticateDevice: (deviceId: string, username?: string) => Promise<void>;
  authenticateWithGoogle: () => Promise<void>;
  connectSocket: () => Promise<RealtimeSocket | null>;
  disconnectSocket: () => void;
  logout: () => Promise<void>;
  fetchAccount: () => Promise<void>;
  clearError: () => void;
  clearWelcomeReward: () => void;
}

const getInitialStoredSession = () => {
  if (typeof window === 'undefined') return { session: null, account: null, isAuthenticated: false };
  try {
    const raw = localStorage.getItem('user_session_info');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed?.user_id && parsed?.username) {
        return {
          session: parsed,
          account: { user: { username: parsed.username, id: parsed.user_id, email: parsed.email } },
          isAuthenticated: true,
        };
      }
    }
  } catch {}
  return { session: null, account: null, isAuthenticated: false };
};

const initialAuth = getInitialStoredSession();

export const useRealtimeStore = create<RealtimeState>((set, get) => ({
  session: initialAuth.session,
  socket: null,
  account: initialAuth.account,
  isAuthenticated: initialAuth.isAuthenticated,
  isConnecting: false,
  isConnected: false,
  error: null,
  showWelcomeReward: false,

  clearWelcomeReward: () => set({ showWelcomeReward: false }),
  clearError: () => set({ error: null }),

  connectSocket: async () => {
    const { session, socket } = get();
    if (socket) {
      if (!socket.isOpen) {
        socket.ws.connect(); // Force manual reconnect attempt if it was disconnected
      }
      return socket;
    }
    if (!session) return null;
    return await connectRealtimeSocket(session);
  },

  disconnectSocket: () => {
    const { socket } = get();
    if (socket) socket.disconnect();
    clearConnectionPromise();
    set({ socket: null, isConnected: false });
  },

  authenticate: async (email, password, isRegister = false, username = '') => {
    set({ isConnecting: true, error: null });
    try {
      let sessionObj: any = null;

      if (isRegister) {
        const supaRes = await signUpWithEmail(email, password, username);
        if (supaRes.error) {
          throw new Error(supaRes.error);
        }
        if (supaRes.requiresEmailConfirmation) {
          set({ isConnecting: false });
          throw new Error('تکایە ئیمەیڵەکەت بپشکنە بۆ پشتڕاستکردنەوەی هەژمارەکەت / Please check your email to confirm your account.');
        }
        if (supaRes.user && supaRes.session?.access_token) {
          const userMetaUsername = supaRes.user.user_metadata?.username;
          const finalUsername = userMetaUsername || username || email.split('@')[0] || 'Player';
          sessionObj = {
            token: supaRes.session.access_token,
            user_id: supaRes.user.id,
            username: finalUsername,
            email: supaRes.user.email || email,
            created_at: Date.now(),
          };
        } else {
          throw new Error('تۆمارکردن سەرکەوتوو نەبوو، کێشەیەک لە چوونەژوورەوە هەیە');
        }
      } else {
        const supaRes = await signInWithEmail(email, password);
        if (supaRes.error) {
          throw new Error(supaRes.error);
        }
        if (supaRes.user && supaRes.session?.access_token) {
          const userMetaUsername = supaRes.user.user_metadata?.username;
          const finalUsername = userMetaUsername || username || supaRes.user.email?.split('@')[0] || 'Player';
          sessionObj = {
            token: supaRes.session.access_token,
            user_id: supaRes.user.id,
            username: finalUsername,
            email: supaRes.user.email || email,
            created_at: Date.now(),
          };
        } else {
          throw new Error('چوونەژوورەوە سەرکەوتوو نەبوو، تکایە دووبارە هەوڵبدەرەوە');
        }
      }

      if (!sessionObj) {
        throw new Error('تکایە زانیارییەکانت بە دروستی بنووسە.');
      }

      // Sync backend tables
      let isNewUser = false;
      try {
        const syncRes = await fetch(buildApiUrl('/api/auth/sync-profile'), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(sessionObj.token ? { Authorization: `Bearer ${sessionObj.token}` } : {}),
          },
          body: JSON.stringify({
            id: sessionObj.user_id,
            email: sessionObj.email,
            username: sessionObj.username,
          }),
        });
        if (syncRes.ok) {
          const syncData = await syncRes.json();
          if (syncData.isNewUser) {
            isNewUser = true;
          }
        }
      } catch (err) {}

      localStorage.setItem('realtime_session', sessionObj.token);
      localStorage.setItem('user_session_info', JSON.stringify(sessionObj));

      set({
        session: sessionObj,
        account: { user: { username: sessionObj.username, id: sessionObj.user_id, email: sessionObj.email } },
        isAuthenticated: true,
        isConnecting: false,
        showWelcomeReward: isNewUser,
      });

      // Connect socket in background
      get().connectSocket().catch(() => {});
      
      return { isNewUser };
    } catch (error: any) {
      set({ error: error.message || 'چوونەژوورەوە سەرکەوتوو نەبوو', isConnecting: false });
      throw error;
    }
  },

  authenticateDevice: async (_deviceId, username = '') => {
    set({ isConnecting: true, error: null });
    try {
      const { user, session, error } = await signInAsGuest(username);
      if (error || !user || !session) {
        throw new Error(error || 'Guest authentication failed');
      }

      const sessionObj: any = {
        token: session.access_token,
        user_id: user.id,
        username: user.user_metadata?.username || `Guest_${user.id.substring(0, 6)}`,
        isGuest: true,
        created_at: Date.now(),
      };

      localStorage.setItem('realtime_session', sessionObj.token);
      localStorage.setItem('user_session_info', JSON.stringify(sessionObj));

      set({
        session: sessionObj,
        account: { user: { username: sessionObj.username, id: sessionObj.user_id } },
        isAuthenticated: true,
        isConnecting: false,
      });

      // Connect socket in background
      get().connectSocket().catch(() => {});
    } catch (error: any) {
      set({ error: error.message || 'Device Auth failed', isConnecting: false });
      throw error;
    }
  },

  authenticateWithGoogle: async () => {
    set({ isConnecting: true, error: null });
    try {
      const { error } = await signInWithGoogle();
      if (error) {
        throw new Error(error);
      }
    } catch (error: any) {
      set({ error: error.message || 'چوونەژوورەوە لەگەڵ Google سەرکەوتوو نەبوو / Google sign-in failed', isConnecting: false });
      throw error;
    }
  },

  fetchAccount: async () => {
    const { session, account } = get();
    if (!session) return;
    if (!account) {
      set({ account: { user: { username: session.username, id: session.user_id } } });
    }
  },

  logout: async () => {
    const { socket } = get();
    if (socket) {
      try {
        socket.disconnect(false);
      } catch {}
    }
    clearConnectionPromise();
    // Ask the server to invalidate this user's server-signed tokens too.
    try {
      const tk = get().session?.token;
      if (tk) await fetch(buildApiUrl('/api/auth/logout'), { method: 'POST', headers: { Authorization: `Bearer ${tk}` } }).catch(() => {});
    } catch {}
    await signOutUser().catch(() => {});
    localStorage.removeItem('realtime_session');
    localStorage.removeItem('user_session_info');
    set({ session: null, socket: null, account: null, isAuthenticated: false, isConnected: false });
  },
}));

// Auto-restore session from Supabase (handles PKCE exchange, OAuth callbacks, email confirmation, registered users, and guest users)
export const restoreSession = async () => {
  try {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const hasHash = window.location.hash && window.location.hash.includes('access_token');

    // If PKCE code is present in URL, exchange code for session safely if Supabase auto-detector hasn't done so already
    if (code) {
      console.log('[Auth Callback] PKCE code detected in URL. Checking session exchange...');
      try {
        const { data: exchangeData, error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
        if (exchangeError) {
          console.log('[Auth Callback Note] Code exchange status:', exchangeError.message);
        } else if (exchangeData?.session) {
          console.log('[Auth Callback Success] Session exchanged for user:', exchangeData.session.user.id);
        }
      } catch (err) {
        console.warn('[Auth Callback Warning] Exception during code exchange:', err);
      }
    }

    // Clean up URL parameters after code exchange or hash processing
    if (code || hasHash || window.location.pathname === '/auth/callback') {
      const cleanUrl = window.location.pathname === '/auth/callback' ? '/' : window.location.pathname;
      window.history.replaceState({}, document.title, cleanUrl);
    }

    // Retrieve active session from Supabase client
    const { data, error } = await supabase.auth.getSession();
    if (data?.session?.user && !error) {
      const user = data.session.user;
      const isGuest = user.is_anonymous || false;
      const username =
        user.user_metadata?.username ||
        user.user_metadata?.full_name ||
        user.user_metadata?.name ||
        (isGuest ? `Guest_${user.id.substring(0, 6)}` : user.email?.split('@')[0]) ||
        'Player';

      const sessionObj = {
        token: data.session.access_token,
        user_id: user.id,
        username,
        email: user.email,
        created_at: Date.now(),
        isGuest,
      };

      // Sync backend tables with real Supabase Auth user.id
      let isNewUser = false;
      try {
        const syncRes = await fetch(buildApiUrl('/api/auth/sync-profile'), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${data.session.access_token}`,
          },
          body: JSON.stringify({
            id: user.id,
            email: user.email || `${user.id}@guest.local`,
            username,
          }),
        });
        if (syncRes.ok) {
          const syncData = await syncRes.json();
          if (syncData.isNewUser) isNewUser = true;
        }
      } catch (e) {
        console.warn('[App Profile] Sync profile notice:', e);
      }

      localStorage.setItem('realtime_session', sessionObj.token);
      localStorage.setItem('user_session_info', JSON.stringify(sessionObj));

      useRealtimeStore.setState({
        session: sessionObj,
        account: { user: { username: sessionObj.username, id: sessionObj.user_id, email: sessionObj.email } },
        isAuthenticated: true,
        showWelcomeReward: isNewUser,
      });
      useRealtimeStore.getState().connectSocket().catch(() => {});
      return true;
    }
  } catch (e) {
    console.error('Supabase getSession failed:', e);
  }

  // 4. Fallback: Restore stored local guest or token session if present
  try {
    const storedInfoStr = localStorage.getItem('user_session_info');
    if (storedInfoStr) {
      const sessionObj = JSON.parse(storedInfoStr);
      if (sessionObj && sessionObj.user_id && sessionObj.username) {
        useRealtimeStore.setState({
          session: sessionObj,
          account: { user: { username: sessionObj.username, id: sessionObj.user_id, email: sessionObj.email } },
          isAuthenticated: true,
        });
        useRealtimeStore.getState().connectSocket().catch(() => {});
        return true;
      }
    }
  } catch (err) {
    // Stale session
  }

  // Clear stale items if no valid session
  localStorage.removeItem('realtime_session');
  localStorage.removeItem('user_session_info');
  useRealtimeStore.setState({
    session: null,
    account: null,
    isAuthenticated: false,
  });
  return false;
};

// Listen to Supabase Auth state changes
supabase.auth.onAuthStateChange(async (event, session) => {
  console.log('[Supabase Auth Event]:', event, session?.user?.id);
  if (
    (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'USER_UPDATED' || event === 'INITIAL_SESSION') &&
    session?.user
  ) {
    const user = session.user;
    const isGuest = user.is_anonymous || false;
    const username =
      user.user_metadata?.username ||
      user.user_metadata?.full_name ||
      user.user_metadata?.name ||
      (isGuest ? `Guest_${user.id.substring(0, 6)}` : user.email?.split('@')[0]) ||
      'Player';

    const sessionObj = {
      token: session.access_token,
      user_id: user.id,
      username,
      email: user.email,
      created_at: Date.now(),
      isGuest,
    };

    localStorage.setItem('realtime_session', sessionObj.token);
    localStorage.setItem('user_session_info', JSON.stringify(sessionObj));

    // Sync profile to database asynchronously
    fetch(buildApiUrl('/api/auth/sync-profile'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        id: user.id,
        email: user.email || `${user.id}@guest.local`,
        username,
      }),
    }).catch((e) => console.warn('[App Profile] Sync profile notice:', e));

    useRealtimeStore.setState({
      session: sessionObj,
      account: { user: { username, id: user.id, email: user.email } },
      isAuthenticated: true,
    });
  } else if (event === 'SIGNED_OUT') {
    localStorage.removeItem('realtime_session');
    localStorage.removeItem('user_session_info');
    useRealtimeStore.setState({
      session: null,
      account: null,
      isAuthenticated: false,
      isConnected: false,
    });
  }
});
