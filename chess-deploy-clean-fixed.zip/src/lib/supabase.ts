import { createClient } from '@supabase/supabase-js';
import { buildApiUrl } from './api';

// Supabase configuration
const rawUrl =
  import.meta.env.VITE_SUPABASE_URL ||
  import.meta.env.SUPABASE_URL ||
  'https://wetbwuwtjgaufqpwmunp.supabase.co';
const SUPABASE_URL = (rawUrl || '').trim().replace(/\/+$/, '');
const SUPABASE_ANON_KEY =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.SUPABASE_ANON_KEY ||
  import.meta.env.SUPABASE_PUBLISHABLE_KEY ||
  'sb_publishable_D1zimu45JZ322f_XhKTY8g_YI0qwp2Y';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export interface AuthResponse {
  user: any | null;
  session: any | null;
  error: string | null;
  requiresEmailConfirmation?: boolean;
}

/**
 * Sign up user with Email and Password using Supabase Auth directly
 */
export async function signUpWithEmail(email: string, password: string, username: string): Promise<AuthResponse> {
  try {
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanUsername = (username || cleanEmail.split('@')[0]).trim();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return { user: null, session: null, error: 'تکایە ئیمەیڵێکی دروست و ڕاستەقینە بنووسە (نموونە: name@gmail.com)' };
    }

    if (!password || password.length < 6) {
      return { user: null, session: null, error: 'پاسۆرد دەبێت لانیکەم ٦ پیت یان ژمارە بێت' };
    }

    // STEP 0: Pre-check username availability against public.users
    try {
      const checkRes = await fetch(buildApiUrl(`/api/auth/check-username?username=${encodeURIComponent(cleanUsername)}`));
      if (checkRes.ok) {
        const checkData = await checkRes.json();
        if (checkData.available === false) {
          return {
            user: null,
            session: null,
            error: checkData.error || 'ئەم ناوی بەکارهێنەرە پێشتر بەکارهاتووە، تکایە ناوێکی تر بنووسە / This username is already taken. Please choose another username.',
          };
        }
      }
    } catch {
      // Non-blocking network check fallback
    }

    // STEP 1: Call Supabase Auth signUp directly to create real auth.users record
    console.log('[Supabase Auth] Step 1: Attempting auth.signUp for:', cleanEmail);
    const { data, error } = await supabase.auth.signUp({
      email: cleanEmail,
      password: password,
      options: {
        data: {
          username: cleanUsername,
        },
      },
    });

    if (error) {
      console.warn('[Supabase Auth] Registration failed for', cleanEmail, ':', error.message);

      // Seamless fallback if Email provider is disabled in Supabase dashboard
      if (error.message?.toLowerCase().includes('disabled') || (error as any).code?.includes('disabled')) {
        console.log('[Supabase Auth Fallback] Email signups disabled in Supabase, using backend registration fallback...');
        try {
          const res = await fetch(buildApiUrl('/api/auth/register'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: cleanEmail, password, username: cleanUsername }),
          });
          const resData = await res.json();
          if (res.ok && resData?.user && resData?.token) {
            const fallbackUser = {
              id: resData.user.id,
              email: resData.user.email,
              user_metadata: { username: resData.user.username },
              is_anonymous: false,
            } as any;
            const fallbackSession = {
              access_token: resData.token,
              user: fallbackUser,
            } as any;
            return { user: fallbackUser, session: fallbackSession, error: null };
          } else if (resData?.error) {
            return { user: null, session: null, error: resData.error };
          }
        } catch (serverErr: any) {
          console.error('[Backend Register Exception]:', serverErr);
        }
      }

      let displayMessage = error.message;
      const lowerMsg = (error.message || '').toLowerCase();
      if (lowerMsg.includes('users_username_key') || lowerMsg.includes('username') || lowerMsg.includes('database error saving new user')) {
        displayMessage = 'ئەم ناوی بەکارهێنەرە پێشتر بەکارهاتووە، تکایە ناوێکی تر بنووسە / This username is already taken. Please choose another username.';
      } else if (error.code === 'over_email_send_rate_limit') {
        displayMessage = 'تکایە کەمێکی دیکە هەوڵبدەرەوە (ڕێژەی ناردنی ئیمەیڵ گەیشتووەتە پەڕپەڕ) / Email rate limit exceeded. Please wait a few minutes before trying again.';
      } else if (error.code === 'user_already_exists' || lowerMsg.includes('already registered')) {
        displayMessage = 'ئەم ئیمەیڵە پێشتر تۆمارکراوە، تکایە بچۆ ژوورەوە / Email already registered. Please sign in instead.';
      }

      return {
        user: null,
        session: null,
        error: displayMessage,
      };
    }

    if (!data || !data.user) {
      return { user: null, session: null, error: 'دروستکردنی بەکارهێنەر لە Supabase Auth سەرکەوتوو نەبوو' };
    }

    console.log('[Supabase Auth] Step 1 Success! User created:', data.user.id, data.user.email);

    // STEP 2: Sync application profile using the SAME Supabase user.id
    try {
      console.log('[App Profile] Step 2: Syncing profile for user.id:', data.user.id);
      await fetch(buildApiUrl('/api/auth/sync-profile'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(data.session?.access_token ? { Authorization: `Bearer ${data.session.access_token}` } : {}),
        },
        body: JSON.stringify({
          id: data.user.id,
          email: cleanEmail,
          username: cleanUsername,
        }),
      });
    } catch (profileErr: any) {
      // Step 2 profile error should NOT fail Auth registration (per guidelines)
      console.warn('[App Profile] Step 2 Profile Sync Warning:', profileErr?.message || profileErr);
    }

    // Handle Email Confirmation case (user != null, session == null)
    if (data.user && !data.session) {
      return {
        user: data.user,
        session: null,
        error: null,
        requiresEmailConfirmation: true,
      };
    }

    return {
      user: data.user,
      session: data.session,
      error: null,
    };
  } catch (err: any) {
    console.error('[Supabase Auth Exception]:', err);
    return { user: null, session: null, error: err.message || 'خۆتۆمارکردن سەرکەوتوو نەبوو' };
  }
}

/**
 * Sign in user with Email or Username and Password using Supabase Auth directly
 */
export async function signInWithEmail(emailOrUsername: string, password: string): Promise<AuthResponse> {
  try {
    const input = (emailOrUsername || '').trim().toLowerCase();

    if (!input || !password) {
      return { user: null, session: null, error: 'ئیمەیڵ/ناوی بەکارهێنەر و پاسۆرد پێویستە' };
    }

    let resolvedEmail = input;

    // Username login: the SERVER checks the password; the email is never sent to
    // the browser (the old resolve-email endpoint leaked it for any username).
    if (!resolvedEmail.includes('@')) {
      try {
        const res = await fetch(buildApiUrl('/api/auth/username-login'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: input, password }),
        });
        const resData = await res.json().catch(() => ({}));
        if (!res.ok || !resData.access_token) {
          return { user: null, session: null, error: resData.error || 'ئیمەیڵ یان وشەی نهێنی هەڵەیە / Invalid email or password' };
        }
        const { data: sd, error: se } = await supabase.auth.setSession({
          access_token: resData.access_token,
          refresh_token: resData.refresh_token,
        });
        if (se || !sd?.session || !sd?.user) {
          return { user: null, session: null, error: se?.message || 'چوونەژوورەوە سەرکەوتوو نەبوو' };
        }
        try {
          await fetch(buildApiUrl('/api/auth/sync-profile'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${sd.session.access_token}` },
            body: JSON.stringify({ id: sd.user.id, email: resData.email, username: sd.user.user_metadata?.username || input }),
          });
        } catch {}
        return { user: sd.user, session: sd.session, error: null };
      } catch (e: any) {
        return { user: null, session: null, error: e?.message || 'چوونەژوورەوە سەرکەوتوو نەبوو' };
      }
    }

    console.log('[Supabase Auth] Attempting signInWithPassword for:', resolvedEmail);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: resolvedEmail,
      password: password,
    });

    if (error) {
      console.warn('[Supabase Auth] Login failed for', resolvedEmail, ':', error.message);

      // Seamless fallback if Email logins are disabled in Supabase dashboard
      if (error.message?.toLowerCase().includes('disabled') || (error as any).code?.includes('disabled')) {
        console.log('[Supabase Auth Fallback] Email logins disabled in Supabase, using backend login fallback...');
        try {
          const res = await fetch(buildApiUrl('/api/auth/login'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ emailOrUser: resolvedEmail, password }),
          });
          const resData = await res.json();
          if (res.ok && resData?.user && resData?.token) {
            const fallbackUser = {
              id: resData.user.id,
              email: resData.user.email,
              user_metadata: { username: resData.user.username },
              is_anonymous: false,
            } as any;
            const fallbackSession = {
              access_token: resData.token,
              user: fallbackUser,
            } as any;
            return { user: fallbackUser, session: fallbackSession, error: null };
          } else if (resData?.error) {
            return { user: null, session: null, error: resData.error };
          }
        } catch (serverErr: any) {
          console.error('[Backend Login Exception]:', serverErr);
        }
      }

      let displayMessage = 'ئیمەیڵ یان وشەی نهێنی هەڵەیە / Invalid login credentials';
      if (error.code === 'email_not_confirmed' || error.message?.toLowerCase().includes('email not confirmed')) {
        displayMessage = 'تکایە یەکەمجار ئیمەیڵەکەت بپشکنە بۆ پشتڕاستکردنەوە / Email not confirmed. Please check your inbox.';
      } else if (error.code === 'invalid_credentials' || error.message?.toLowerCase().includes('invalid login credentials')) {
        displayMessage = 'ئیمەیڵ یان وشەی نهێنی هەڵەیە / Invalid email or password';
      } else if (error.message) {
        displayMessage = error.message;
      }

      return {
        user: null,
        session: null,
        error: displayMessage,
      };
    }

    if (!data || !data.session || !data.user) {
      return { user: null, session: null, error: 'چوونەژوورەوە لەگەڵ Supabase Auth سەرکەوتوو نەبوو' };
    }

    // STEP 2: Sync profile to database using the valid Supabase session
    try {
      await fetch(buildApiUrl('/api/auth/sync-profile'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${data.session.access_token}`,
        },
        body: JSON.stringify({
          id: data.user.id,
          email: resolvedEmail,
          username: data.user.user_metadata?.username || input,
        }),
      });
    } catch (profileErr: any) {
      console.warn('[App Profile] Sync profile warning on login:', profileErr);
    }

    return {
      user: data.user,
      session: data.session,
      error: null,
    };
  } catch (err: any) {
    console.error('[Supabase Auth Exception]:', err);
    return { user: null, session: null, error: err.message || 'چوونەژوورەوە سەرکەوتوو نەبوو' };
  }
}

/**
 * Sign in as Guest using real Supabase Auth (tries signInAnonymously, falls back to real Supabase Guest signUp)
 */
export async function signInAsGuest(customUsername?: string): Promise<AuthResponse> {
  const finalUsername = customUsername?.trim() || `Guest_${Math.floor(1000 + Math.random() * 9000)}`;

  // 1. Try Supabase Anonymous Sign-In
  try {
    const supaRes = await supabase.auth.signInAnonymously({
      options: {
        data: {
          username: finalUsername,
          is_anonymous: true,
        },
      },
    });

    if (!supaRes.error && supaRes.data?.session && supaRes.data?.user) {
      const user = supaRes.data.user;
      await syncGuestProfile(user.id, user.email || `${user.id}@guest.local`, finalUsername, supaRes.data.session.access_token);
      return { user, session: supaRes.data.session, error: null };
    }
  } catch (err) {
    console.warn('[Guest Auth] Anonymous auth notice:', err);
  }

  // 2. If Anonymous sign-in is disabled in Supabase Dashboard, create/login a real Guest user in Supabase Auth via signUp
  try {
    let storedEmail = localStorage.getItem('supabase_guest_email');
    let storedPass = localStorage.getItem('supabase_guest_password');

    if (storedEmail && storedPass) {
      const loginRes = await supabase.auth.signInWithPassword({
        email: storedEmail,
        password: storedPass,
      });
      if (!loginRes.error && loginRes.data?.session && loginRes.data?.user) {
        await syncGuestProfile(loginRes.data.user.id, loginRes.data.user.email || storedEmail, finalUsername, loginRes.data.session.access_token);
        return { user: loginRes.data.user, session: loginRes.data.session, error: null };
      }
    }

    // Register a new Guest user in Supabase Auth
    const randomTag = Math.floor(100000 + Math.random() * 900000);
    const guestEmail = `guest_${randomTag}@chessroyal.app`;
    const guestPassword = `GuestPass_${Math.random().toString(36).substring(2, 10)}!`;

    const signUpRes = await supabase.auth.signUp({
      email: guestEmail,
      password: guestPassword,
      options: {
        data: {
          username: finalUsername,
          is_anonymous: true,
        },
      },
    });

    if (signUpRes.data?.user) {
      localStorage.setItem('supabase_guest_email', guestEmail);
      localStorage.setItem('supabase_guest_password', guestPassword);

      // If session is returned immediately
      if (signUpRes.data.session) {
        await syncGuestProfile(signUpRes.data.user.id, guestEmail, finalUsername, signUpRes.data.session.access_token);
        return { user: signUpRes.data.user, session: signUpRes.data.session, error: null };
      }

      // Try signing in with the newly created guest credentials
      const signInRes = await supabase.auth.signInWithPassword({
        email: guestEmail,
        password: guestPassword,
      });

      if (signInRes.data?.session && signInRes.data?.user) {
        await syncGuestProfile(signInRes.data.user.id, guestEmail, finalUsername, signInRes.data.session.access_token);
        return { user: signInRes.data.user, session: signInRes.data.session, error: null };
      }

      return { user: signUpRes.data.user, session: null, error: null };
    }

    if (signUpRes.error) {
      console.warn('[Guest Auth SignUp Error]:', signUpRes.error.message);
    }
  } catch (err: any) {
    console.warn('[Guest Auth Registration Exception]:', err);
  }

  // 3. Try backend guest endpoint which provisions user in Supabase Auth & DB tables via service role
  try {
    const res = await fetch(buildApiUrl('/api/auth/guest'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: finalUsername }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data?.token && data?.user) {
        const guestUser: any = {
          id: data.user.user_id,
          email: data.user.email,
          user_metadata: { username: data.user.username, is_anonymous: true },
          is_anonymous: true,
        };
        const guestSession: any = {
          access_token: data.token,
          user: guestUser,
        };
        return { user: guestUser, session: guestSession, error: null };
      }
    }
  } catch (backendErr) {
    console.warn('[Backend Guest Auth Notice]:', backendErr);
  }

  // 4. No offline/mock guests: a guest must be provisioned and verified by the server.
  return {
    user: null,
    session: null,
    error: 'Could not create a guest account. The server is unreachable or rejected the request. Please check your connection and try again.',
  } as any;
}

async function syncGuestProfile(id: string, email: string, username: string, token?: string) {
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    await fetch(buildApiUrl('/api/auth/sync-profile'), {
      method: 'POST',
      headers,
      body: JSON.stringify({ id, email, username, isGuest: true }),
    });
  } catch (e) {
    console.warn('Sync profile notice:', e);
  }
}

/**
 * Upgrade an Anonymous Guest Account to a Permanent Email Account
 */
export async function upgradeAnonymousAccount(
  email: string,
  password: string,
  username: string
): Promise<AuthResponse> {
  try {
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanUsername = (username || cleanEmail.split('@')[0]).trim();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return { user: null, session: null, error: 'تکایە ئیمەیڵێکی دروست بنووسە' };
    }

    if (!password || password.length < 6) {
      return { user: null, session: null, error: 'پاسۆرد دەبێت لانیکەم ٦ پیت یان ژمارە بێت' };
    }

    // Convert anonymous user into permanent email/password account in Supabase Auth
    const { data, error } = await supabase.auth.updateUser({
      email: cleanEmail,
      password: password,
      data: {
        username: cleanUsername,
        is_anonymous: false,
      },
    });

    if (error || !data?.user) {
      return {
        user: null,
        session: null,
        error: error?.message || 'نوێکردنەوەی هەژماری میوان سەرکەوتوو نەبوو',
      };
    }

    const { data: sessionData } = await supabase.auth.getSession();

    if (sessionData?.session) {
      await fetch(buildApiUrl('/api/auth/sync-profile'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${sessionData.session.access_token}`,
        },
        body: JSON.stringify({
          id: data.user.id,
          email: cleanEmail,
          username: cleanUsername,
        }),
      }).catch(() => {});
    }

    return {
      user: data.user,
      session: sessionData?.session || null,
      error: null,
    };
  } catch (err: any) {
    return { user: null, session: null, error: err.message || 'گەشەپێدانی هەژمار سەرکەوتوو نەبوو' };
  }
}

/**
 * Sign in with Google OAuth using Supabase Auth
 */
export async function signInWithGoogle(): Promise<{ error: string | null }> {
  try {
    const redirectTo = `${window.location.origin}/auth/callback`;
    const isIframe = window.self !== window.top;
    console.log('[Google OAuth] Initiating signInWithOAuth with redirectTo:', redirectTo, 'isIframe:', isIframe);

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo,
        skipBrowserRedirect: isIframe,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        },
      },
    });

    if (error) {
      console.error('[Google OAuth Error]:', error.message);
      let userError = error.message;
      if (error.message.toLowerCase().includes('provider is not enabled') || error.message.toLowerCase().includes('unsupported provider')) {
        userError = 'دابینکەری گووگڵ لە پێگەی Supabase پەکخراوە. تکایە Google Provider بەگەڕبخە لە Supabase Dashboard / Google provider is not enabled in Supabase Dashboard.';
      }
      return { error: userError };
    }

    if (isIframe && data?.url) {
      try {
        const popup = window.open(data.url, '_blank');
        if (!popup || popup.closed || typeof popup.closed === 'undefined') {
          // If popup blocked by browser in iframe, navigate top-level window
          if (window.top) {
            window.top.location.href = data.url;
          } else {
            window.location.href = data.url;
          }
        }
      } catch (popupErr) {
        window.location.href = data.url;
      }
    }

    return { error: null };
  } catch (err: any) {
    console.error('[Google OAuth Exception]:', err);
    return { error: err.message || 'چوونەژوورەوە لەگەڵ Google سەرکەوتوو نەبوو / Google sign-in failed' };
  }
}

/**
 * Sign out user from Supabase Auth
 */
export async function signOutUser(): Promise<{ error: string | null }> {
  try {
    const { error } = await supabase.auth.signOut();
    return { error: error ? error.message : null };
  } catch (err: any) {
    return { error: err.message };
  }
}

/**
 * Send Password Reset Email
 */
export async function resetPasswordEmail(email: string): Promise<{ success: boolean; error: string | null }> {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) return { success: false, error: error.message };
    return { success: true, error: null };
  } catch (err: any) {
    return { success: false, error: err.message || 'ناردنی فایلی سەرڕاستکردنەوە سەرکەوتوو نەبوو' };
  }
}
