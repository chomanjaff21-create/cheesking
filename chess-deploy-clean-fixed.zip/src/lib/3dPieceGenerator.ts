import * as BufferGeometryUtils from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import * as THREE from 'three';
import { ThemeStyle, PieceSkinId, BoardSkinId } from '../types';

// Material Cache to avoid recreating identical WebGL materials
const customSkinMaterialCache = new Map<string, {
  whitePiece: THREE.MeshStandardMaterial | THREE.MeshPhysicalMaterial;
  blackPiece: THREE.MeshStandardMaterial | THREE.MeshPhysicalMaterial;
  boardLight: THREE.MeshStandardMaterial;
  boardDark: THREE.MeshStandardMaterial;
  border: THREE.MeshStandardMaterial;
}>();

export function getMaterialsForCustomSkins(
  pieceSkin: PieceSkinId = 'marble',
  boardSkin: BoardSkinId = 'classic_wood'
) {
  const cacheKey = `${pieceSkin}__${boardSkin}`;
  const cached = customSkinMaterialCache.get(cacheKey);
  if (cached) return cached;

  // Piece materials matching the exact visual reference image (Radiant 24K Gold & Mirror Chrome Silver)
  let whitePieceMat: THREE.MeshStandardMaterial | THREE.MeshPhysicalMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xfacc15, // Radiant 24K Polished Gold
    emissive: 0x854d0e,
    emissiveIntensity: 0.06,
    roughness: 0.12,
    metalness: 0.96,
    clearcoat: 0.9,
    clearcoatRoughness: 0.1,
    reflectivity: 1.0,
  });
  let blackPieceMat: THREE.MeshStandardMaterial | THREE.MeshPhysicalMaterial = new THREE.MeshPhysicalMaterial({
    color: 0xf1f5f9, // Polished Mirror Chrome Silver
    emissive: 0x334155,
    emissiveIntensity: 0.04,
    roughness: 0.10,
    metalness: 0.98,
    clearcoat: 1.0,
    clearcoatRoughness: 0.08,
    reflectivity: 1.0,
    userData: { isSilver: true },
  });

  switch (pieceSkin) {
    case 'royal_gold':
      whitePieceMat = new THREE.MeshPhysicalMaterial({
        color: 0xfacc15, // 24K Gold
        roughness: 0.12,
        metalness: 0.96,
        clearcoat: 0.9,
      });
      blackPieceMat = new THREE.MeshPhysicalMaterial({
        color: 0xf1f5f9, // Mirror Chrome Silver
        roughness: 0.10,
        metalness: 0.98,
        clearcoat: 1.0,
        userData: { isSilver: true },
      });
      break;
  }

  // Board materials matching the exact visual reference image (Crisp Porcelain White & Studio Neutral Silver-Gray)
  let boardLightMat: THREE.MeshStandardMaterial;
  let boardDarkMat: THREE.MeshStandardMaterial;
  let borderMat: THREE.MeshStandardMaterial;

  switch (boardSkin) {
    case 'classic_wood':
    default:
      boardLightMat = new THREE.MeshStandardMaterial({
        color: 0xf8fafc, // Crisp Porcelain White
        roughness: 0.16,
        metalness: 0.12,
      });
      boardDarkMat = new THREE.MeshStandardMaterial({
        color: 0x8a99ad, // Modern Studio Neutral Silver-Slate Gray
        roughness: 0.22,
        metalness: 0.15,
      });
      borderMat = new THREE.MeshStandardMaterial({
        color: 0xe2e8f0, // Satin Platinum Silver Border
        roughness: 0.20,
        metalness: 0.35,
      });
      break;
  }

  const result = {
    whitePiece: whitePieceMat,
    blackPiece: blackPieceMat,
    boardLight: boardLightMat,
    boardDark: boardDarkMat,
    border: borderMat,
  };
  customSkinMaterialCache.set(cacheKey, result);
  return result;
}

export function getMaterialsForTheme(theme: ThemeStyle) {
  switch (theme) {
    case 'classic_wood':
      return {
        whitePiece: new THREE.MeshStandardMaterial({
          color: 0xf4e4bc,
          roughness: 0.35,
          metalness: 0.05,
        }),
        blackPiece: new THREE.MeshStandardMaterial({
          color: 0x3d2314,
          roughness: 0.35,
          metalness: 0.05,
        }),
        boardLight: new THREE.MeshStandardMaterial({
          color: 0xedc9af,
          roughness: 0.4,
        }),
        boardDark: new THREE.MeshStandardMaterial({
          color: 0x734222,
          roughness: 0.4,
        }),
        border: new THREE.MeshStandardMaterial({
          color: 0x2b1507,
          roughness: 0.3,
        }),
      };

    case 'emerald_gold':
      return {
        whitePiece: new THREE.MeshStandardMaterial({
          color: 0xffd700,
          roughness: 0.2,
          metalness: 0.85,
        }),
        blackPiece: new THREE.MeshStandardMaterial({
          color: 0x033b28,
          roughness: 0.25,
          metalness: 0.4,
        }),
        boardLight: new THREE.MeshStandardMaterial({
          color: 0xdedede,
          roughness: 0.3,
        }),
        boardDark: new THREE.MeshStandardMaterial({
          color: 0x095237,
          roughness: 0.3,
        }),
        border: new THREE.MeshStandardMaterial({
          color: 0x1f1902,
          roughness: 0.2,
          metalness: 0.6,
        }),
      };

    case 'cyber_neon':
      return {
        whitePiece: new THREE.MeshStandardMaterial({
          color: 0x00f0ff,
          emissive: 0x005577,
          roughness: 0.1,
          metalness: 0.9,
        }),
        blackPiece: new THREE.MeshStandardMaterial({
          color: 0xff0055,
          emissive: 0x550022,
          roughness: 0.1,
          metalness: 0.9,
        }),
        boardLight: new THREE.MeshStandardMaterial({
          color: 0x1a1a2e,
          roughness: 0.2,
        }),
        boardDark: new THREE.MeshStandardMaterial({
          color: 0x0f0f1b,
          roughness: 0.2,
        }),
        border: new THREE.MeshStandardMaterial({
          color: 0x080811,
          roughness: 0.1,
          metalness: 0.9,
        }),
      };

    case 'onyx_ivory':
    default:
      return {
        whitePiece: new THREE.MeshStandardMaterial({
          color: 0xfffcf2, // Warm Ivory
          roughness: 0.18,
          metalness: 0.15,
        }),
        blackPiece: new THREE.MeshStandardMaterial({
          color: 0x141416, // Onyx Dark Obsidian
          roughness: 0.2,
          metalness: 0.3,
        }),
        boardLight: new THREE.MeshStandardMaterial({
          color: 0xebdcc3,
          roughness: 0.25,
        }),
        boardDark: new THREE.MeshStandardMaterial({
          color: 0x3d3027,
          roughness: 0.25,
        }),
        border: new THREE.MeshStandardMaterial({
          color: 0x1c130d,
          roughness: 0.2,
          metalness: 0.4,
        }),
      };
  }
}

// Procedurally generate 3D piece geometries with support for Kurdish flag standards & shields
export function create3DPieceGroup(
  type: string,
  material: THREE.Material,
  pieceSkin?: PieceSkinId,
  flagTexture?: THREE.Texture | null
): THREE.Group {
  const group = new THREE.Group();
  const lowerType = type.toLowerCase();

  // Premium Metallic Material for Crowns, Swords, Rings, and Ornaments
  // Dynamically uses Polished Chrome Silver for silver pieces, and 24K Polished Gold for gold pieces
  const isSilverPiece =
    Boolean((material as any)?.userData?.isSilver) ||
    Boolean((material as any)?.name === 'silver') ||
    Boolean(
      (material as any)?.color &&
        (material as any).color.r > 0.85 &&
        (material as any).color.g > 0.85 &&
        (material as any).color.b > 0.85 &&
        (material as any).metalness > 0.6
    );

  const goldAccentMat = isSilverPiece
    ? new THREE.MeshStandardMaterial({
        color: 0xf8fafc, // Polished Mirror Chrome Silver Accent
        metalness: 0.98,
        roughness: 0.10,
      })
    : new THREE.MeshStandardMaterial({
        color: 0xffd700, // 24K Radiant Polished Gold Accent
        metalness: 0.96,
        roughness: 0.14,
      });

  // Base Pedestal (Elegant fluted base for all pieces)
  const baseGeom = new THREE.CylinderGeometry(0.38, 0.45, 0.15, 32);
  const baseMesh = new THREE.Mesh(baseGeom, material);
  baseMesh.position.y = 0.075;
  group.add(baseMesh);

  const baseRing = new THREE.Mesh(new THREE.TorusGeometry(0.38, 0.03, 16, 32), goldAccentMat);
  baseRing.rotation.x = Math.PI / 2;
  baseRing.position.y = 0.16;
  group.add(baseRing);

  const baseStep = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.36, 0.1, 32), material);
  baseStep.position.y = 0.2;
  group.add(baseStep);

  if (lowerType === 'p') {
    // Pawn: Foot Soldier / Warrior with a small sword
    const bodyGeom = new THREE.CylinderGeometry(0.18, 0.28, 0.6, 24);
    const body = new THREE.Mesh(bodyGeom, material);
    body.position.y = 0.55;
    group.add(body);

    // Collar
    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.03, 16, 24), goldAccentMat);
    collar.rotation.x = Math.PI / 2;
    collar.position.y = 0.85;
    group.add(collar);

    // Head (Helmet)
    const headGeom = new THREE.SphereGeometry(0.18, 24, 24);
    const head = new THREE.Mesh(headGeom, material);
    head.position.y = 1.05;
    group.add(head);

    // Helmet Spike (Gold)
    const spikeGeom = new THREE.ConeGeometry(0.04, 0.15, 12);
    const spike = new THREE.Mesh(spikeGeom, goldAccentMat);
    spike.position.y = 1.3;
    group.add(spike);

    // Small Warrior Sword attached to the side
    const swordGroup = new THREE.Group();
    swordGroup.position.set(0.18, 0.6, 0.1);
    swordGroup.rotation.z = -0.3;
    swordGroup.rotation.x = 0.2;
    
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.1, 8), goldAccentMat);
    swordGroup.add(hilt);
    
    const crossguard = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.02), goldAccentMat);
    crossguard.position.y = 0.06;
    swordGroup.add(crossguard);
    
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.3, 0.01), new THREE.MeshStandardMaterial({color: 0xcccccc, metalness: 1.0, roughness: 0.2}));
    blade.position.y = 0.22;
    swordGroup.add(blade);
    
    group.add(swordGroup);

  } else if (lowerType === 'r') {
    // Rook: Fortress Tower with Golden Battlement
    const bodyGeom = new THREE.CylinderGeometry(0.26, 0.32, 0.7, 24);
    const body = new THREE.Mesh(bodyGeom, material);
    body.position.y = 0.6;
    group.add(body);

    const midRing = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.03, 16, 24), goldAccentMat);
    midRing.rotation.x = Math.PI / 2;
    midRing.position.y = 0.95;
    group.add(midRing);

    const topGeom = new THREE.CylinderGeometry(0.3, 0.26, 0.25, 24);
    const top = new THREE.Mesh(topGeom, material);
    top.position.y = 1.1;
    group.add(top);

    // Golden Battlements
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const battlement = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.15, 0.1), goldAccentMat);
      battlement.position.set(Math.cos(angle) * 0.24, 1.28, Math.sin(angle) * 0.24);
      battlement.rotation.y = -angle;
      group.add(battlement);
    }
    
  } else if (lowerType === 'n') {
    // Knight: Armored War Horse
    const bodyGeom = new THREE.CylinderGeometry(0.2, 0.3, 0.5, 24);
    const body = new THREE.Mesh(bodyGeom, material);
    body.position.y = 0.5;
    group.add(body);

    const chestArmor = new THREE.Mesh(new THREE.SphereGeometry(0.25, 24, 24, 0, Math.PI), goldAccentMat);
    chestArmor.rotation.x = -0.2;
    chestArmor.position.set(0, 0.6, 0.05);
    chestArmor.scale.set(1, 1.2, 0.6);
    group.add(chestArmor);

    const horseGroup = new THREE.Group();
    horseGroup.position.set(0, 0.9, 0.1);
    horseGroup.rotation.x = 0.2;
    horseGroup.rotation.y = Math.PI / 2; // Profile view looks better for primitive shapes

    const headGeom = new THREE.CylinderGeometry(0.15, 0.22, 0.45, 24);
    headGeom.rotateX(Math.PI / 2);
    const head = new THREE.Mesh(headGeom, material);
    head.position.set(0, 0, 0.15);
    horseGroup.add(head);

    const snoutGeom = new THREE.CylinderGeometry(0.1, 0.14, 0.3, 24);
    snoutGeom.rotateX(Math.PI / 2);
    const snout = new THREE.Mesh(snoutGeom, material);
    snout.position.set(0, -0.05, 0.45);
    horseGroup.add(snout);

    // Golden Bridle and Armor
    const bridle1 = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.02, 16, 24), goldAccentMat);
    bridle1.position.set(0, -0.05, 0.45);
    horseGroup.add(bridle1);
    
    const bridle2 = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.02, 16, 24), goldAccentMat);
    bridle2.position.set(0, 0.02, 0.25);
    bridle2.rotation.x = 0.3;
    horseGroup.add(bridle2);

    // Ears
    for(const side of [-1, 1]) {
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.15, 12), goldAccentMat);
      ear.position.set(side * 0.1, 0.22, 0);
      ear.rotation.z = side * -0.2;
      ear.rotation.x = -0.2;
      horseGroup.add(ear);
    }
    
    // Golden Mane
    const maneGeom = new THREE.BoxGeometry(0.06, 0.5, 0.2);
    const mane = new THREE.Mesh(maneGeom, goldAccentMat);
    mane.position.set(0, 0.1, -0.15);
    mane.rotation.x = -0.3;
    horseGroup.add(mane);

    group.add(horseGroup);

  } else if (lowerType === 'b') {
    // Bishop: High Priest / Advisor with Golden Mitre
    const bodyGeom = new THREE.CylinderGeometry(0.16, 0.3, 0.8, 24);
    const body = new THREE.Mesh(bodyGeom, material);
    body.position.y = 0.65;
    group.add(body);

    const sash = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.025, 16, 24), goldAccentMat);
    sash.rotation.x = Math.PI / 2 + 0.2;
    sash.position.y = 0.6;
    group.add(sash);

    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.16, 0.15, 24), goldAccentMat);
    collar.position.y = 1.1;
    group.add(collar);

    const headGroup = new THREE.Group();
    headGroup.position.y = 1.35;
    
    const mitreGeom = new THREE.SphereGeometry(0.2, 24, 24);
    mitreGeom.scale(0.8, 1.5, 0.8);
    const mitre = new THREE.Mesh(mitreGeom, material);
    headGroup.add(mitre);

    const goldCross = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.2, 0.04), goldAccentMat);
    goldCross.position.set(0, 0.1, 0.15);
    goldCross.rotation.x = 0.2;
    headGroup.add(goldCross);
    
    const goldCrossH = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.04, 0.04), goldAccentMat);
    goldCrossH.position.set(0, 0.12, 0.15);
    goldCrossH.rotation.x = 0.2;
    headGroup.add(goldCrossH);

    group.add(headGroup);
    
    // Holding a small golden staff
    const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.8, 12), goldAccentMat);
    staff.position.set(0.2, 0.7, 0.15);
    staff.rotation.z = -0.15;
    group.add(staff);
    
    const staffOrb = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 16), goldAccentMat);
    staffOrb.position.set(0.26, 1.1, 0.15);
    group.add(staffOrb);

  } else if (lowerType === 'q') {
    // Queen: Elegant Royal with intricate Golden Crown
    const bodyGeom = new THREE.CylinderGeometry(0.18, 0.32, 0.9, 32);
    const body = new THREE.Mesh(bodyGeom, material);
    body.position.y = 0.7;
    group.add(body);

    // Dress folds/rings (Gold)
    for(let i=0; i<3; i++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.25 - (i*0.03), 0.02, 16, 32), goldAccentMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.5 + (i * 0.25);
      group.add(ring);
    }

    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.16, 0.2, 24), goldAccentMat);
    collar.position.y = 1.25;
    group.add(collar);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.16, 24, 24), material);
    head.position.y = 1.45;
    group.add(head);

    // Elegant Golden Crown
    const crownGroup = new THREE.Group();
    crownGroup.position.y = 1.55;
    
    const crownBase = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.16, 0.1, 24), goldAccentMat);
    crownGroup.add(crownBase);
    
    for(let i=0; i<8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.2, 12), goldAccentMat);
      spike.position.set(Math.cos(angle) * 0.16, 0.1, Math.sin(angle) * 0.16);
      spike.rotation.x = Math.sin(angle) * 0.2;
      spike.rotation.z = -Math.cos(angle) * 0.2;
      crownGroup.add(spike);
      
      const pearl = new THREE.Mesh(new THREE.SphereGeometry(0.025, 12, 12), material);
      pearl.position.set(Math.cos(angle) * 0.18, 0.2, Math.sin(angle) * 0.18);
      crownGroup.add(pearl);
    }
    
    group.add(crownGroup);

  } else if (lowerType === 'k') {
    // King: Majestic Royal Warrior with Golden Crown and Sword
    const bodyGeom = new THREE.CylinderGeometry(0.22, 0.35, 1.0, 32);
    const body = new THREE.Mesh(bodyGeom, material);
    body.position.y = 0.75;
    group.add(body);

    const cape = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.38, 0.9, 32, 1, false, Math.PI*0.75, Math.PI*1.5), goldAccentMat);
    cape.position.y = 0.7;
    group.add(cape);

    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.2, 0.25, 24), goldAccentMat);
    collar.position.y = 1.35;
    group.add(collar);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 24, 24), material);
    head.position.y = 1.6;
    group.add(head);

    // Regal Golden Crown with Cross
    const crownGroup = new THREE.Group();
    crownGroup.position.y = 1.7;
    
    const crownBase = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.18, 0.12, 24), goldAccentMat);
    crownGroup.add(crownBase);
    
    for(let i=0; i<4; i++) {
      const arch = new THREE.Mesh(new THREE.TorusGeometry(0.14, 0.02, 16, 24, Math.PI), goldAccentMat);
      arch.rotation.y = (i * Math.PI) / 2;
      arch.rotation.x = Math.PI / 2;
      arch.position.y = 0.05;
      crownGroup.add(arch);
    }
    
    const crossVert = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.15, 0.04), goldAccentMat);
    crossVert.position.y = 0.25;
    crownGroup.add(crossVert);
    const crossHoriz = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.04, 0.04), goldAccentMat);
    crossHoriz.position.y = 0.27;
    crownGroup.add(crossHoriz);
    
    group.add(crownGroup);

    // Large King Sword resting on the ground
    const swordGroup = new THREE.Group();
    swordGroup.position.set(0.25, 0.6, 0.2);
    swordGroup.rotation.z = -0.1;
    swordGroup.rotation.x = 0.1;
    
    const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.25, 12), goldAccentMat);
    swordGroup.add(hilt);
    
    const pommel = new THREE.Mesh(new THREE.SphereGeometry(0.05, 16, 16), goldAccentMat);
    pommel.position.y = 0.12;
    swordGroup.add(pommel);
    
    const crossguard = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.04, 0.04), goldAccentMat);
    crossguard.position.y = -0.12;
    swordGroup.add(crossguard);
    
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.8, 0.02), new THREE.MeshStandardMaterial({color: 0xcccccc, metalness: 1.0, roughness: 0.2}));
    blade.position.y = -0.52;
    swordGroup.add(blade);
    
    group.add(swordGroup);
  }

  // OPTIMIZATION: Merge geometries by material to reduce draw calls
  const matMap = new Map();
  group.updateMatrixWorld(true);
  
  group.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      const mesh = child as THREE.Mesh;
      const mat = mesh.material;
      if (!matMap.has(mat)) {
        matMap.set(mat, []);
      }
      const geom = mesh.geometry.clone();
      geom.applyMatrix4(mesh.matrixWorld);
      matMap.get(mat).push(geom);
    }
  });

  const mergedGroup = new THREE.Group();
  matMap.forEach((geoms, mat) => {
    if (geoms.length > 0) {
      const mergedGeom = BufferGeometryUtils.mergeGeometries(geoms, false);
      const mergedMesh = new THREE.Mesh(mergedGeom, mat);
      mergedMesh.castShadow = true;
      mergedMesh.receiveShadow = true;
      mergedGroup.add(mergedMesh);
    }
  });
  
  return mergedGroup;
}
