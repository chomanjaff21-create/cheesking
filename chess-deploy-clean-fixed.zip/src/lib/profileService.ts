import { useRealtimeStore } from './realtime';
import { buildApiUrl } from './api';
import { UserProfile } from '../types';

const PROFILE_COLLECTION = 'user_data';
const PROFILE_KEY = 'profile';

export const getPlayerProfile = async (): Promise<UserProfile | null> => {
  const { session, account } = useRealtimeStore.getState();
  if (!session?.user_id) return null;

  const userId = session.user_id;
  const username = account?.user?.username || session.username || 'Player';

  let profileData: UserProfile | null = null;

  // 1. Try local cache first
  const localSaved = localStorage.getItem(`player_profile_${userId}`);
  if (localSaved) {
    try {
      profileData = JSON.parse(localSaved);
    } catch {}
  }

  // 2. Fallback to default if null
  if (!profileData) {
    profileData = getDefaultProfile(username, userId);
  }

  // Ensure ID and Name match current user
  profileData.id = userId;
  if (!profileData.name || profileData.name === 'New Player' || profileData.name === 'Guest') {
    profileData.name = username;
  }

  // 3. Enrich with live PostgreSQL stats (rating, coins, gems, level, xp, win/loss)
  const enriched = await enrichWithPostgresStats(profileData, userId);

  // 4. Update local cache
  try {
    localStorage.setItem(`player_profile_${userId}`, JSON.stringify(enriched));
  } catch {}

  return enriched;
};

export const getOpponentProfile = async (userId: string): Promise<UserProfile | null> => {
  let profileData: UserProfile | null = null;

  const localSaved = localStorage.getItem(`player_profile_${userId}`);
  if (localSaved) {
    try {
      profileData = JSON.parse(localSaved);
    } catch {}
  }

  if (!profileData) {
    profileData = getDefaultProfile('Opponent', userId);
  }

  return await enrichWithPostgresStats(profileData, userId);
};

async function enrichWithPostgresStats(profile: UserProfile, userId: string): Promise<UserProfile> {
  try {
    const { session } = useRealtimeStore.getState();
    const cleanToken = (session?.token || '').trim().replace(/[\r\n]/g, '');
    const cleanUserId = encodeURIComponent(userId);
    const headers: Record<string, string> = {};
    if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;

    const res = await fetch(buildApiUrl(`/api/player/${cleanUserId}/stats`), { headers });
    if (res.status === 503) {
      return { ...profile, coins: profile.coins ?? 5000, gems: profile.gems ?? 50, xp: profile.xp ?? 0, level: profile.level ?? 1, rating: profile.rating ?? 1200 };
    }
    const data = await res.json();
    if (data && data.stats) {
      const { wins, losses, draws, coins, gems, xp, level, rating, username: srvName, avatar_url: srvAvatar, bio: srvBio } = data.stats;
      const totalGames = (wins || 0) + (losses || 0) + (draws || 0);
      const winRate = totalGames > 0 ? `${Math.round(((wins || 0) / totalGames) * 100)}%` : '0%';
      return {
        ...profile,
        // Name / avatar / bio come from the server (source of truth), not from
        // whatever happens to be in this browser's localStorage.
        ...(srvName ? { name: srvName } : {}),
        ...(srvAvatar ? { avatar: srvAvatar } : {}),
        ...(srvBio ? { bio: srvBio } : {}),
        totalGames,
        wins: wins ?? profile.wins ?? 0,
        winRate,
        coins: coins ?? profile.coins ?? 5000,
        gems: gems ?? profile.gems ?? 50,
        xp: xp ?? profile.xp ?? 0,
        level: level ?? profile.level ?? 1,
        rating: rating ?? profile.rating ?? 1200
      };
    }
  } catch (e) {
    // Keep local profile stats if API call fails
  }
  return profile;
}

export const savePlayerProfile = async (profile: UserProfile, isNameChangeWithGems: boolean = false): Promise<{ success: boolean; error?: string }> => {
  const { session } = useRealtimeStore.getState();
  const userId = profile.id || session?.user_id;
  if (!userId) return { success: false, error: 'Not authenticated' };

  try {
    const cleanToken = (session?.token || '').trim().replace(/[\r\n]/g, '');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (cleanToken) headers['Authorization'] = `Bearer ${cleanToken}`;
    
    const res = await fetch(buildApiUrl(`/api/player/${encodeURIComponent(userId)}/profile`), {
      method: 'POST',
      headers,
      body: JSON.stringify({
        name: profile.name,
        avatar: profile.avatar,
        bio: profile.bio,
        deductGemsForNameChange: isNameChangeWithGems
      }),
    });
    
    const data = await res.json();
    if (!res.ok || !data.success) {
      return { success: false, error: data.error || 'Failed to update profile' };
    }
    
    // Only update local cache if server confirmed success
    try {
      localStorage.setItem(`player_profile_${userId}`, JSON.stringify(profile));
    } catch {}
    
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error updating profile' };
  }
};

export const getDefaultProfile = (username: string, userId: string): UserProfile => ({
  id: userId,
  name: username || 'Player',
  bio: 'New Chess Player',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
  level: 1,
  xp: 0,
  nextLevelXp: 100,
  coins: 5000,
  gems: 50,
  rating: 1200,
  hasChangedNameOnce: false,
  nameChangeCount: 0,
  isLocked: false,
  totalGames: 0,
  wins: 0,
  winRate: '0%',
  thisWeekRank: 'Unranked',
  lastWeekRank: 'Unranked',
  countryFlag: '🌍',
  badge: 'N',
  unlockedCrownBadge: false,
  redCrownBackdrop: false,
  friends: [],
});

