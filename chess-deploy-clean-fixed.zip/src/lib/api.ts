import { Capacitor } from '@capacitor/core';

/**
 * Returns the base URL for API requests.
 * On web, returns empty string so relative URLs like `/api/match` work.
 * On native Capacitor (Android/iOS), returns `VITE_APP_URL` or window location origin.
 */
export function getApiBaseUrl(): string {
  if (Capacitor.isNativePlatform()) {
    const envUrl = import.meta.env.VITE_APP_URL;
    if (envUrl) return envUrl.replace(/\/$/, '');
    if (typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('capacitor://') && !window.location.origin.includes('file://')) {
      return window.location.origin;
    }
  }
  return '';
}

/**
 * Builds a full URL for an API endpoint.
 */
export function buildApiUrl(endpoint: string): string {
  const base = getApiBaseUrl();
  const path = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return base ? `${base}${path}` : path;
}
