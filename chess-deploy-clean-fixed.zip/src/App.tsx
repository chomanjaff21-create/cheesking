import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'motion/react';
import confetti from 'canvas-confetti';
import { ChessEngine } from './lib/chessEngine';
import { soundManager } from './lib/soundManager';
import {
  Language,
  GameMode,
  AIDifficulty,
  ThemeStyle,
  PieceSkinId,
  BoardSkinId,
  ChessPuzzle,
  AICoachResponse,
  UserProfile,
} from './types';
import { getTranslation } from './lib/translations';
import { useRealtimeStore, restoreSession } from './lib/realtime';
import { getPlayerProfile, savePlayerProfile, getDefaultProfile } from './lib/profileService';

import { MainMenu } from './components/MainMenu';
import { Chess3DCanvas } from './components/Chess3DCanvas';
import { GameHUD } from './components/GameHUD';
import { AICoachModal } from './components/AICoachModal';
import { ShopModal } from './components/ShopModal';
import { PuzzlesModal } from './components/PuzzlesModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { SettingsModal } from './components/SettingsModal';
import { ProfileModal } from './components/ProfileModal';
import { TournamentModal } from './components/TournamentModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { FriendsModal } from './components/FriendsModal';
import { MatchmakingModal } from './components/MatchmakingModal';
import { TablesSelectionModal, ChessTable } from './components/TablesSelectionModal';
import { GameResultModal } from './components/GameResultModal';
import { LiveChatHubModal } from './components/LiveChatHubModal';
import { RoyalPassModal } from './components/RoyalPassModal';
import { RankBadgesModal } from './components/RankBadgesModal';
import { CustomRoomModal } from './components/CustomRoomModal';
import { LiveSpectateOverlay } from './components/LiveSpectateOverlay';
import { SplashScreen } from './components/SplashScreen';
import { LoginModal } from './components/LoginModal';
import { AuthScreen } from './components/AuthScreen';
import { MatchStartCountdownOverlay } from './components/MatchStartCountdownOverlay';
import { buildApiUrl } from './lib/api';
import { claimPuzzleReward, claimAiGameReward } from './lib/rewardsService';
import epicCastleTerraceBgImg from './assets/images/royal_chess_kurd_castle_bg_1788296185378.jpg';
import darkGlassHallBgImg from './assets/images/dark_glass_hall_bg_1788783496148.jpg';

export default function App() {
  const { account, isAuthenticated, showWelcomeReward, clearWelcomeReward } = useRealtimeStore();

  const hasStoredSession = typeof window !== 'undefined' && (
    !!localStorage.getItem('realtime_session') ||
    !!localStorage.getItem('user_session_info') ||
    window.location.search.includes('code=') ||
    window.location.hash.includes('access_token') ||
    window.location.pathname.includes('/auth')
  );

  // Application State
  const [showSplash, setShowSplash] = useState<boolean>(() => !isAuthenticated && !hasStoredSession);
  const [currentMode, setCurrentMode] = useState<GameMode | 'menu'>('menu');
  const [language, setLanguage] = useState<Language>('ku'); // Default Kurdish Sorani
  const [coins, setCoins] = useState<number | undefined>(undefined); 
  const [theme, setTheme] = useState<ThemeStyle>('onyx_ivory');
  
  const [equippedPieceSkin, setEquippedPieceSkin] = useState<PieceSkinId>(() => {
    return (localStorage.getItem('equippedPieceSkin') as PieceSkinId) || 'marble';
  });
  const [equippedBoardSkin, setEquippedBoardSkin] = useState<BoardSkinId>(() => {
    return (localStorage.getItem('equippedBoardSkin') as BoardSkinId) || 'classic_wood';
  });
  
  useEffect(() => {
    localStorage.setItem('equippedPieceSkin', equippedPieceSkin);
  }, [equippedPieceSkin]);
  
  useEffect(() => {
    localStorage.setItem('equippedBoardSkin', equippedBoardSkin);
  }, [equippedBoardSkin]);

  // Equipped skins are stored on the server (so they follow the account to other
  // devices); localStorage is only a fast first-paint cache.
  const skinsSyncReady = React.useRef(false);
  useEffect(() => {
    if (!isAuthenticated) { skinsSyncReady.current = false; return; }
    const { session } = useRealtimeStore.getState();
    if (!session?.user_id || !session?.token) return;
    let stop = false;
    fetch(buildApiUrl(`/api/player/${encodeURIComponent(session.user_id)}/stats`), { headers: { Authorization: `Bearer ${session.token}` } })
      .then((r) => r.ok ? r.json() : null)
      .then((d) => {
        if (stop) return;
        const st = d?.stats;
        if (st?.equipped_piece_skin) setEquippedPieceSkin(st.equipped_piece_skin as PieceSkinId);
        if (st?.equipped_board_skin) setEquippedBoardSkin(st.equipped_board_skin as BoardSkinId);
      })
      .catch(() => {})
      .finally(() => { if (!stop) skinsSyncReady.current = true; });
    return () => { stop = true; };
  }, [isAuthenticated]);

  useEffect(() => {
    if (!skinsSyncReady.current) return;
    const { session } = useRealtimeStore.getState();
    if (!session?.user_id || !session?.token) return;
    const t = setTimeout(() => {
      fetch(buildApiUrl(`/api/player/${encodeURIComponent(session.user_id)}/profile`), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.token}` },
        body: JSON.stringify({ equippedPieceSkin, equippedBoardSkin }),
      }).catch(() => {});
    }, 800);
    return () => clearTimeout(t);
  }, [equippedPieceSkin, equippedBoardSkin]);
  const [previewPieceSkin, setPreviewPieceSkin] = useState<PieceSkinId | null>(null);
  const [previewBoardSkin, setPreviewBoardSkin] = useState<BoardSkinId | null>(null);
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('medium');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(false);

  // User Profile State - Real Supabase User
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isCheckingSession, setIsCheckingSession] = useState<boolean>(() => !isAuthenticated && hasStoredSession);

  const fallbackProfile = userProfile || getDefaultProfile(account?.user?.username || 'Player', account?.user?.id || 'usr_123');

  useEffect(() => {
    let isMounted = true;
    const initSession = async () => {
      const isAlreadyAuthed = useRealtimeStore.getState().isAuthenticated;
      if (!isAlreadyAuthed && hasStoredSession) {
        setIsCheckingSession(true);
      }
      const restored = await restoreSession();
      if (!isMounted) return;

      const isAuthed = restored || useRealtimeStore.getState().isAuthenticated;
      if (isAuthed) {
        setShowSplash(false);
        setIsLoginOpen(false);
        setCurrentMode((prev) => (prev === 'menu' ? 'menu' : prev));
        const profile = await getPlayerProfile();
        const acc = useRealtimeStore.getState().account;
        if (profile) {
          setUserProfile(profile);
          setCoins(profile.coins);
        } else if (acc) {
          const newProfile = getDefaultProfile(acc.user.username || 'Player', acc.user.id);
          await savePlayerProfile(newProfile);
          setUserProfile(newProfile);
          setCoins(newProfile.coins);
        }
      }
      setIsCheckingSession(false);
    };
    initSession();
    return () => {
      isMounted = false;
    };
  }, []);

  // Sync profile & guarantee navigation to Main Menu whenever auth state becomes authenticated
  useEffect(() => {
    if (isAuthenticated) {
      setShowSplash(false);
      setIsLoginOpen(false);
      setIsCheckingSession(false);
      setCurrentMode((prev) => (prev === 'menu' ? 'menu' : prev));
      if (account) {
        const loadProfile = async () => {
          const profile = await getPlayerProfile();
          if (profile) {
            setUserProfile(profile);
            setCoins(profile.coins);
          } else {
            const newProfile = getDefaultProfile(account.user.username || 'Player', account.user.id);
            await savePlayerProfile(newProfile);
            setUserProfile(newProfile);
            setCoins(newProfile.coins);
          }
        };
        loadProfile();
      }
    }
  }, [account, isAuthenticated]);

  const handleLogout = async () => {
    soundManager.playClick();
    await useRealtimeStore.getState().logout();
    setUserProfile(null);
    setCoins(undefined);
    setIsProfileOpen(false);
    setIsSettingsOpen(false);
    setShowSplash(false);
    setIsLoginOpen(true);
    setCurrentMode('menu');
  };

  // Modals state
  const [isLoginOpen, setIsLoginOpen] = useState<boolean>(false);
  const [isCoachOpen, setIsCoachOpen] = useState<boolean>(false);
  const [isShopOpen, setIsShopOpen] = useState<boolean>(false);
  const [isPuzzlesOpen, setIsPuzzlesOpen] = useState<boolean>(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState<boolean>(false);
  const [isTournamentOpen, setIsTournamentOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isDailyRewardOpen, setIsDailyRewardOpen] = useState<boolean>(false);
  const [isFriendsOpen, setIsFriendsOpen] = useState<boolean>(false);
  const [isTablesSelectionOpen, setIsTablesSelectionOpen] = useState<boolean>(false);
  const [selectedTable, setSelectedTable] = useState<ChessTable | null>(null);
  const [matchStake, setMatchStake] = useState<number>(0);
  const [matchPrize, setMatchPrize] = useState<number>(0);
  const [isMatchmakingOpen, setIsMatchmakingOpen] = useState<boolean>(false);
  const [isGameResultOpen, setIsGameResultOpen] = useState<boolean>(false);
  // Real post-game numbers (from the server), shown on the result screen.
  const [aiReward, setAiReward] = useState<{ coins: number; xp: number; level: number } | null>(null);
  const [onlineResult, setOnlineResult] = useState<{ ratingBefore: number; ratingAfter: number; xpEarned: number; level: number } | null>(null);
  const preMatchStatsRef = useRef<{ rating: number; xp: number } | null>(null);
  const [isLiveChatHubOpen, setIsLiveChatHubOpen] = useState<boolean>(false);
  const [isRoyalPassOpen, setIsRoyalPassOpen] = useState<boolean>(false);
  const [isRankBadgesOpen, setIsRankBadgesOpen] = useState<boolean>(false);
  const [isCustomRoomOpen, setIsCustomRoomOpen] = useState<boolean>(false);
  const [customRoomInitialCode, setCustomRoomInitialCode] = useState<string | undefined>();
  const [customRoomInitialMatchId, setCustomRoomInitialMatchId] = useState<string | undefined>();
  const [customRoomInitialIsHost, setCustomRoomInitialIsHost] = useState<boolean | undefined>();

  const [friendInvite, setFriendInvite] = useState<{ inviterId: string; inviterName: string; code: string } | null>(null);

  // Camera preset state
  const [cameraPreset, setCameraPreset] = useState<'perspective' | 'top' | 'black'>('perspective');

  // Chess Engine Instance
  const engineRef = useRef<ChessEngine>(new ChessEngine());
  const [board, setBoard] = useState(engineRef.current.getBoard());
  const [turn, setTurn] = useState<'w' | 'b'>('w');
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [validMoves, setValidMoves] = useState<any[]>([]);
  const [lastMove, setLastMove] = useState<any | null>(null);
  const [isCheck, setIsCheck] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isCheckmate, setIsCheckmate] = useState<boolean>(false);
  const [winner, setWinner] = useState<'w' | 'b' | 'draw' | null>(null);

  // Captured pieces tracking
  const [capturedWhite, setCapturedWhite] = useState<string[]>([]);
  const [capturedBlack, setCapturedBlack] = useState<string[]>([]);

  // Timers (10 minutes each)
  const [whiteTime, setWhiteTime] = useState<number>(600);
  const [blackTime, setBlackTime] = useState<number>(600);

  // Active Puzzle
  const [activePuzzle, setActivePuzzle] = useState<ChessPuzzle | null>(null);

  // Online Multiplayer State
  const [onlineMatchId, setOnlineMatchId] = useState<string | null>(null);
  const [onlineOpponent, setOnlineOpponent] = useState<any | null>(null);
  const [playerColor, setPlayerColor] = useState<'w' | 'b'>('w');
  const realtimeSocket = useRealtimeStore(state => state.socket);

  // Disconnect & Reconnect Grace Period State
  const [opponentDisconnected, setOpponentDisconnected] = useState<boolean>(false);
  const [disconnectExpiresAt, setDisconnectExpiresAt] = useState<number | null>(null);
  const [disconnectCountdown, setDisconnectCountdown] = useState<number>(40);
  const [isSocketReconnecting, setIsSocketReconnecting] = useState<boolean>(false);
  const [isNetworkOffline, setIsNetworkOffline] = useState<boolean>(!navigator.onLine);
  const [isCountdownActive, setIsCountdownActive] = useState<boolean>(false);

  // Safety fallback: ensure countdown can never get stuck or block piece movement
  useEffect(() => {
    if (isCountdownActive) {
      const timer = setTimeout(() => {
        setIsCountdownActive(false);
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [isCountdownActive]);

  // AI Coach state
  const [coachLoading, setCoachLoading] = useState<boolean>(false);
  const [coachAdvice, setCoachAdvice] = useState<AICoachResponse | null>(null);

  const currentModeRef = useRef<GameMode>(currentMode);
  const playerColorRef = useRef<'w' | 'b'>(playerColor);
  useEffect(() => {
    currentModeRef.current = currentMode;
  }, [currentMode]);
  useEffect(() => {
    playerColorRef.current = playerColor;
  }, [playerColor]);

  // Update react state from chess engine
  const updateEngineState = useCallback(() => {
    const engine = engineRef.current;
    setBoard(engine.getBoard());
    setTurn(engine.getTurn());
    setIsCheck(engine.isCheck());

    const history = engine.getHistory();
    const lastM = history.length > 0 ? history[history.length - 1] : null;
    setLastMove(lastM);

    // Calculate captured pieces
    const capW: string[] = [];
    const capB: string[] = [];
    history.forEach((m) => {
      if (m.captured) {
        if (m.color === 'w') {
          capB.push(m.captured);
        } else {
          capW.push(m.captured);
        }
      }
    });
    setCapturedWhite(capW);
    setCapturedBlack(capB);

    if (engine.isGameOver()) {
      setIsGameOver(true);
      const winColor = engine.isCheckmate() ? (engine.getTurn() === 'w' ? 'b' : 'w') : 'draw';
      const activeMode = currentModeRef.current;
      const activePlayerColor = playerColorRef.current;

      // Daily quest progress (play 3 / win 7) is counted by the SERVER from the
      // matches table (see /api/player/:id/daily-reward/status). Nothing local.

      // vs_ai reward: stored on the SERVER (capped per day). It used to be added
      // only to React state + localStorage, so it was fake and vanished on reload.
      if (activeMode === 'vs_ai') {
        setAiReward(null);
        const aiResultKey = winColor === 'w' ? 'win' : (winColor === 'draw' ? 'draw' : 'loss');
        claimAiGameReward(aiResultKey).then((res) => {
          if (!res || !res.success) return;
          setAiReward({ coins: res.coinsAwarded, xp: res.xpAwarded, level: res.level });
          setCoins(res.coins);
          setUserProfile((prev) => (prev ? { ...prev, coins: res.coins, xp: res.xp, level: res.level } : null));
        }).catch(() => {});
      }

      if (engine.isCheckmate()) {
        setIsCheckmate(true);
        setWinner(winColor);
        soundManager.playVictory();
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } else {
        setWinner('draw');
      }
      setTimeout(() => {
        setIsGameResultOpen(true);
      }, 700);
    }
  }, []);

  // Disconnect grace countdown timer effect
  useEffect(() => {
    if (!opponentDisconnected || !disconnectExpiresAt) return;

    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((disconnectExpiresAt - Date.now()) / 1000));
      setDisconnectCountdown(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
        setOpponentDisconnected(false);
        setDisconnectExpiresAt(null);
        setIsGameOver(true);
        // Opponent abandoned by leaving and not reconnecting in time -> player wins!
        setWinner(playerColorRef.current);
        localStorage.removeItem('active_match_id');
        setTimeout(() => setIsGameResultOpen(true), 500);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [opponentDisconnected, disconnectExpiresAt]);

  // Authoritative Match Reconnection & Synchronization Function
  const restoreActiveMatch = useCallback(async () => {
    const activeMatchId = localStorage.getItem('active_match_id');
    if (!activeMatchId) return;

    const { session, connectSocket } = useRealtimeStore.getState();
    if (!session?.user_id) return;

    try {
      setIsSocketReconnecting(true);
      const socket = await connectSocket();
      const res = await fetch(buildApiUrl(`/api/match/${activeMatchId}`), {
        headers: session?.token ? { Authorization: `Bearer ${session.token}` } : {},
      });
      const data = await res.json();

      if (data.match) {
        const match = data.match;
        if (match.status === 'active' || match.status === 'waiting') {
          if (socket) {
            await socket.joinMatch(activeMatchId);
          }
          setOnlineMatchId(activeMatchId);
          const savedColor = (localStorage.getItem('active_match_color') as 'w' | 'b') ||
            (match.whiteId === session.user_id ? 'w' : 'b');
          setPlayerColor(savedColor);
          
          if (match.stake !== undefined) setMatchStake(match.stake);
          if (match.prize !== undefined) setMatchPrize(match.prize);

          const opp = JSON.parse(localStorage.getItem('active_match_opp') || 'null');
          if (opp) setOnlineOpponent(opp);

          setCurrentMode('online');
          setIsGameOver(false);
          setIsCheckmate(false);
          setWinner(null);

          engineRef.current.reset(match.fen);
          updateEngineState();

          setWhiteTime(Math.ceil(match.whiteTimeMs / 1000));
          setBlackTime(Math.ceil(match.blackTimeMs / 1000));

          if (match.disconnectedUserId && match.disconnectedUserId !== session.user_id) {
            setOpponentDisconnected(true);
            setDisconnectExpiresAt(match.disconnectExpiresAt);
            setDisconnectCountdown(Math.max(0, Math.ceil((match.gracePeriodRemainingMs || 0) / 1000)));
          } else {
            setOpponentDisconnected(false);
            setDisconnectExpiresAt(null);
          }
        } else {
          // Match already completed, resigned, timed out, or abandoned
          setIsGameOver(true);
          setWinner(match.winner);
          setOpponentDisconnected(false);
          setDisconnectExpiresAt(null);
          localStorage.removeItem('active_match_id');
          localStorage.removeItem('active_match_opp');
          const refreshed = await getPlayerProfile();
          if (refreshed) {
            setUserProfile(refreshed);
            setCoins(refreshed.coins);
          }
        }
      }
    } catch (e) {
      console.error('[Match Reconnect] Failed to restore active match:', e);
    } finally {
      setIsSocketReconnecting(false);
    }
  }, [updateEngineState]);

  // Handle manual reconnect triggered by user
  const handleManualReconnect = useCallback(async () => {
    setIsSocketReconnecting(true);
    const { session, connectSocket } = useRealtimeStore.getState();
    if (session?.user_id) {
      await connectSocket();
    }
    await restoreActiveMatch();
    setIsSocketReconnecting(false);
  }, [restoreActiveMatch]);

  // Handle mobile screen lock, backgrounding, and temporary network loss
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        restoreActiveMatch();
      }
    };

    const handleOffline = () => {
      setIsNetworkOffline(true);
      setIsSocketReconnecting(true);
    };

    const handleOnline = async () => {
      setIsNetworkOffline(false);
      await handleManualReconnect();
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [restoreActiveMatch, handleManualReconnect]);

  // Setup realtime socket listeners for live match events
  useEffect(() => {
    if (!realtimeSocket) return;

    // Check for active match reconnection
    restoreActiveMatch();

    realtimeSocket.ondisconnect = () => {
      console.warn('[Realtime Socket] Disconnected');
      setIsSocketReconnecting(true);
    };

    realtimeSocket.onreconnecting = (attempt) => {
      console.log(`[Realtime Socket] Reconnecting attempt ${attempt}...`);
      setIsSocketReconnecting(true);
    };

    realtimeSocket.onreconnect = async () => {
      console.log('[Realtime Socket] Successfully reconnected to game server');
      setIsSocketReconnecting(false);
      setIsNetworkOffline(false);
      await restoreActiveMatch();
    };

    realtimeSocket.onmatchdisconnect = (evt) => {
      setOpponentDisconnected(true);
      setDisconnectExpiresAt(evt.expiresAt);
      setDisconnectCountdown(Math.max(0, Math.ceil((evt.expiresAt - Date.now()) / 1000)));
    };

    realtimeSocket.onmatchreconnect = () => {
      setOpponentDisconnected(false);
      setDisconnectExpiresAt(null);
    };

    realtimeSocket.onmatchabandoned = (evt) => {
      setOpponentDisconnected(false);
      setDisconnectExpiresAt(null);
      setIsGameOver(true);
      setWinner(evt.winner);
      localStorage.removeItem('active_match_id');
      const { session } = useRealtimeStore.getState();
      const isMeWinner = evt.winner === (playerColor === 'w' ? 'white' : 'black');
      if (isMeWinner) {
        soundManager.playVictory();
        confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
      } else {
        soundManager.playGameOver();
      }
      setTimeout(() => setIsGameResultOpen(true), 400);

      if (session?.user_id) {
        fetch(buildApiUrl(`/api/player/${session.user_id}/stats`))
          .then(res => res.json())
          .then(data => {
            if (data.stats) {
              setCoins(data.stats.coins ?? 0);
              setUserProfile(prev => prev ? { ...prev, coins: data.stats.coins, rating: data.stats.rating } : null);
            }
          })
          .catch(() => {});
      }
    };

    realtimeSocket.onmatchdata = (matchState) => {
      try {
        const data = JSON.parse(new TextDecoder().decode(matchState.data));
        if (data.op_code === 1) { // Move operation
          const move = data.move;
          let moveRes = null;
          if (move && move.from && move.to) {
            try {
              moveRes = engineRef.current.makeMove(move.from, move.to, move.promotion || undefined);
            } catch (err) {
              console.warn("makeMove caught warning, will fallback to FEN sync:", err);
            }
          }

          // Authoritative FEN sync: if makeMove returned null OR if FEN diverges, force sync to server FEN
          if (data.fen && (!moveRes || engineRef.current.getFen() !== data.fen)) {
            engineRef.current.reset(data.fen);
          }

          if (move && move.from && move.to) {
            setLastMove({ from: move.from, to: move.to } as any);
          }

          if (moveRes?.captured) soundManager.playCapture();
          else soundManager.playMove();
          if (engineRef.current.isCheck()) soundManager.playCheck();

          // Sync clocks immediately from server payload
          if (data.whiteTimeMs !== undefined) {
            setWhiteTime(Math.max(0, Math.ceil(data.whiteTimeMs / 1000)));
          }
          if (data.blackTimeMs !== undefined) {
            setBlackTime(Math.max(0, Math.ceil(data.blackTimeMs / 1000)));
          }

          if (data.status && ['timeout', 'completed', 'draw', 'resigned', 'abandoned'].includes(data.status)) {
            setIsGameOver(true);
            setWinner(data.winner);
            if (data.status === 'draw') setIsCheckmate(false);
            else if (data.status === 'completed') setIsCheckmate(true);
            localStorage.removeItem('active_match_id');
            setTimeout(() => setIsGameResultOpen(true), 500);
          }

          updateEngineState();
        } else if (data.op_code === 2) { // Status sync or clock sync
          if (data.reason === 'opponent_disconnected') {
            setOpponentDisconnected(true);
            const expires = data.expiresAt || (Date.now() + 40000);
            setDisconnectExpiresAt(expires);
            setDisconnectCountdown(Math.max(0, Math.ceil((expires - Date.now()) / 1000)));
          } else if (data.reason === 'opponent_reconnected') {
            setOpponentDisconnected(false);
            setDisconnectExpiresAt(null);
          } else if (['abandoned', 'timeout', 'resigned', 'completed', 'draw'].includes(data.status) || ['abandonment', 'timeout', 'resign'].includes(data.reason)) {
            setOpponentDisconnected(false);
            setDisconnectExpiresAt(null);
            setIsGameOver(true);
            const winColor = data.winner || (data.status === 'draw' ? 'draw' : playerColor);
            setWinner(winColor);
            localStorage.removeItem('active_match_id');
            setTimeout(() => setIsGameResultOpen(true), 500);
          } else if (data.whiteTime || data.blackTime) {
            if (data.whiteTime) setWhiteTime(data.whiteTime);
            if (data.blackTime) setBlackTime(data.blackTime);
          }
        } else if (data.op_code === 3) { // Opponent Resigned / Left
          setIsGameOver(true);
          // Opponent resigned or left: the remaining player (playerColor) wins!
          const decisiveWinner = data.winner || playerColor;
          setWinner(decisiveWinner);
          localStorage.removeItem('active_match_id');
          setTimeout(() => setIsGameResultOpen(true), 500);
        } else if (data.op_code === 4) { // Full Sync from Reconnect
          if (data.match) {
            setWhiteTime(Math.ceil(data.match.whiteTimeMs / 1000));
            setBlackTime(Math.ceil(data.match.blackTimeMs / 1000));
            if (['timeout', 'completed', 'draw', 'resigned', 'abandoned'].includes(data.match.status)) {
              setIsGameOver(true);
              setWinner(data.match.winner);
              if (data.match.status === 'draw') setIsCheckmate(false);
              else if (data.match.status === 'completed') setIsCheckmate(true);
              localStorage.removeItem('active_match_id');
              setTimeout(() => setIsGameResultOpen(true), 500);
            }
            if (data.match.fen !== engineRef.current.getFen()) {
              engineRef.current.reset(data.match.fen);
              updateEngineState();
            }
          }
        }
      } catch (e) {
        console.error("Error parsing match data", e);
      }
    };

    realtimeSocket.onbalanceupdate = (evt) => {
      setUserProfile((prev) => prev ? ({ ...prev, coins: evt.coins }) : null);
      setCoins(evt.coins);
    };

    realtimeSocket.onmatchpresence = (presenceEvent) => {
      const currentUserId = useRealtimeStore.getState().session?.user_id;
      if (presenceEvent.leaves && presenceEvent.leaves.length > 0) {
        const leftOpponent = presenceEvent.leaves.find(l => l.user_id !== currentUserId);
        if (leftOpponent) {
          // Do NOT declare as loser! Opponent is in grace period
          setOpponentDisconnected(true);
          const expires = presenceEvent.metadata?.expiresAt || (Date.now() + 40000);
          setDisconnectExpiresAt(expires);
          setDisconnectCountdown(Math.max(0, Math.ceil((expires - Date.now()) / 1000)));
        }
      }
      if (presenceEvent.joins && presenceEvent.joins.length > 0) {
        const joinedOpponent = presenceEvent.joins.find(j => j.user_id !== currentUserId);
        if (joinedOpponent) {
          setOpponentDisconnected(false);
          setDisconnectExpiresAt(null);
        }
      }
    };

    realtimeSocket.onmatchabandoned = (evt) => {
      setOpponentDisconnected(false);
      setDisconnectExpiresAt(null);
      setIsGameOver(true);
      const decisiveWinner = evt.winner || playerColor;
      setWinner(decisiveWinner);
      localStorage.removeItem('active_match_id');
      setTimeout(() => setIsGameResultOpen(true), 500);
    };

    realtimeSocket.onfriendinvite = (evt) => {
      soundManager.playVictory();
      setFriendInvite({
        inviterId: evt.inviterId,
        inviterName: evt.inviterName,
        code: evt.code
      });
    };

    return () => {
      realtimeSocket.onmatchdata = () => {};
      realtimeSocket.onmatchpresence = () => {};
      realtimeSocket.onbalanceupdate = () => {};
      realtimeSocket.onmatchdisconnect = null;
      realtimeSocket.onmatchreconnect = null;
      realtimeSocket.onmatchabandoned = null;
      realtimeSocket.onfriendinvite = undefined;
    };
  }, [realtimeSocket, restoreActiveMatch, updateEngineState, playerColor, onlineMatchId]);

  // Timer Countdown Effect
  useEffect(() => {
    if (currentMode === 'menu' || isGameOver) return;

    const timer = setInterval(() => {
      if (turn === 'w') {
        setWhiteTime((prev) => {
          if (prev <= 1) {
            if (currentMode === 'online') {
              // Wait for server to authoritative handle timeout, just stick at 0
              if (onlineMatchId) {
                const { session } = useRealtimeStore.getState();
                fetch(buildApiUrl(`/api/match/${onlineMatchId}/end`), {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
                  body: JSON.stringify({ reason: 'timeout', winner: 'b', userId: session?.user_id })
                });
              }
              return 0;
            }
            // Auto-move best move on white timeout for offline play
            const bestMove = engineRef.current.getBestAIMove('medium');
            if (bestMove) {
              const res = engineRef.current.makeMove(bestMove.from, bestMove.to, bestMove.promotion);
              if (res) {
                if (res.captured) soundManager.playCapture();
                else soundManager.playMove();
                if (engineRef.current.isCheck()) soundManager.playCheck();
                updateEngineState();
                return 15; // Reset white clock with 15s bonus
              }
            }
            setIsGameOver(true);
            setWinner('b');
            return 0;
          }
          return prev - 1;
        });
      } else {
        setBlackTime((prev) => {
          if (prev <= 1) {
            if (currentMode === 'online') {
              if (onlineMatchId) {
                const { session } = useRealtimeStore.getState();
                fetch(buildApiUrl(`/api/match/${onlineMatchId}/end`), {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
                  body: JSON.stringify({ reason: 'timeout', winner: 'w', userId: session?.user_id })
                });
              }
              return 0;
            }
            // Auto-move best move on black timeout
            const bestMove = engineRef.current.getBestAIMove('medium');
            if (bestMove) {
              const res = engineRef.current.makeMove(bestMove.from, bestMove.to, bestMove.promotion);
              if (res) {
                if (res.captured) soundManager.playCapture();
                else soundManager.playMove();
                if (engineRef.current.isCheck()) soundManager.playCheck();
                updateEngineState();
                return 15; // Reset black clock with 15s bonus
              }
            }
            setIsGameOver(true);
            setWinner('w');
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [currentMode, turn, isGameOver, updateEngineState]);

  // AI Turn Execution Effect
  useEffect(() => {
    if (isGameOver) return;

    const isAITurn =
      (currentMode === 'vs_ai' && turn === 'b') ||
      currentMode === 'spectate';

    if (isAITurn) {
      const timeout = setTimeout(() => {
        try {
          const aiMove = engineRef.current.getBestAIMove(aiDifficulty);
          if (aiMove) {
            const moveRes = engineRef.current.makeMove(aiMove.from, aiMove.to, aiMove.promotion);
            if (moveRes) {
              if (moveRes.captured) {
                soundManager.playCapture();
              } else {
                soundManager.playMove();
              }

              if (engineRef.current.isCheck()) {
                soundManager.playCheck();
              }

              updateEngineState();
            } else {
              updateEngineState();
            }
          } else {
            // No legal move available (e.g. checkmate / stalemate reached)
            updateEngineState();
          }
        } catch (err) {
          console.error("AI Turn execution error:", err);
          updateEngineState();
        }
      }, 250);

      return () => clearTimeout(timeout);
    }
  }, [turn, currentMode, isGameOver, aiDifficulty, updateEngineState]);

  // Handle Square Clicks on 3D Board - Fast O(1) coordinate lookup & useCallback
  const handleSquareClick = useCallback((square: string) => {
    if (isGameOver || isCountdownActive) return;

    // Prevent player from moving opponent's pieces in AI or Spectate
    if (currentMode === 'vs_ai' && turn === 'b') return;
    if (currentMode === 'spectate') return;
    
    // In online match, prevent moving opponent's pieces
    if (onlineMatchId && turn !== playerColor) return;

    // If square is selected already and clicked a valid target move
    if (selectedSquare) {
      const isDestination = validMoves.some((m) => m.to === square);
      if (isDestination) {
        const moveRes = engineRef.current.makeMove(selectedSquare, square);
        if (moveRes) {
          if (moveRes.captured) {
            soundManager.playCapture();
          } else {
            soundManager.playMove();
          }

          if (engineRef.current.isCheck()) {
            soundManager.playCheck();
          }
          
          // Send move to opponent via realtime socket if in online match
          if (onlineMatchId) {
             const { session } = useRealtimeStore.getState();

             if (session?.user_id) {
                fetch(buildApiUrl(`/api/match/${onlineMatchId}/move`), {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
                  body: JSON.stringify({ userId: session.user_id, move: { from: selectedSquare, to: square, promotion: moveRes.promotion } })
                }).then(res => res.json()).then(data => {
                   if (data.userBalance !== undefined) {
                     setUserProfile((prev) => prev ? ({ ...prev, coins: data.userBalance }) : null);
                     setCoins(data.userBalance);
                   }
                   if (data.match) {
                     setWhiteTime(Math.ceil(data.match.whiteTimeMs / 1000));
                     setBlackTime(Math.ceil(data.match.blackTimeMs / 1000));
                     if (data.match.status === 'timeout' || data.match.status === 'completed' || data.match.status === 'draw') {
                        setIsGameOver(true);
                        setWinner(data.match.winner);
                        setTimeout(() => setIsGameResultOpen(true), 500);
                     }
                   } else if (data.error) {
                     // Rollback local state if server rejects
                     console.error("Server rejected move:", data.error);
                     engineRef.current.undo();
                     updateEngineState();
                   }
                }).catch(e => console.error("Failed to sync move with server", e));
             }
          }

          // Puzzle solution check (Server-Authoritative)
          if (currentMode === 'puzzles' && activePuzzle) {
            const moveSan = `${moveRes.from}${moveRes.to}`;
            if (activePuzzle.solutionMoves.includes(moveSan) || engineRef.current.isCheckmate()) {
              claimPuzzleReward(activePuzzle.id, (activePuzzle as any).levelNumber, moveSan)
                .then((res) => {
                  if (res.success) {
                    setCoins(res.newBalance);
                    setUserProfile((prev) => (prev ? { ...prev, coins: res.newBalance } : null));
                    confetti({ particleCount: 80, spread: 60 });
                  } else if (res.alreadyClaimed) {
                    confetti({ particleCount: 30, spread: 40 });
                  }
                })
                .catch((e) => console.error('Failed to record puzzle completion:', e));
            }
          }

          setSelectedSquare(null);
          setValidMoves([]);
          updateEngineState();
          return;
        }
      }
    }

    // Otherwise select piece on square with direct O(1) matrix lookup
    const r = 8 - parseInt(square[1], 10);
    const c = square.charCodeAt(0) - 97;
    const pieceOnSquare = (r >= 0 && r < 8 && c >= 0 && c < 8) ? engineRef.current.getBoard()[r][c] : null;

    if (pieceOnSquare && pieceOnSquare.color === turn) {
      setSelectedSquare(square);
      const moves = engineRef.current.getLegalMoves(square);
      setValidMoves(moves);
      soundManager.playClick();
    } else {
      setSelectedSquare(null);
      setValidMoves([]);
    }
  }, [isGameOver, currentMode, turn, selectedSquare, validMoves, activePuzzle, updateEngineState, onlineMatchId, playerColor, realtimeSocket]);

  // Start new game
  // Remember rating/xp at the start of an online match so the result screen can
  // show the REAL change (read back from the server after the match ends).
  useEffect(() => {
    if (currentMode === 'online' && onlineMatchId && userProfile) {
      preMatchStatsRef.current = { rating: userProfile.rating ?? 1200, xp: userProfile.xp ?? 0 };
    } else if (currentMode !== 'online') {
      preMatchStatsRef.current = null;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentMode, onlineMatchId]);

  useEffect(() => {
    if (!isGameResultOpen) { setOnlineResult(null); return; }
    if (currentMode !== 'online') return;
    const pre = preMatchStatsRef.current;
    const timer = setTimeout(async () => {
      const fresh = await getPlayerProfile();
      if (!fresh || !pre) return;
      setOnlineResult({
        ratingBefore: pre.rating,
        ratingAfter: fresh.rating ?? pre.rating,
        xpEarned: Math.max(0, (fresh.xp ?? pre.xp) - pre.xp),
        level: fresh.level ?? 1,
      });
      setCoins(fresh.coins);
      setUserProfile(fresh);
    }, 1500);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isGameResultOpen]);

  const handleStartGame = (mode: GameMode, diff?: AIDifficulty) => {
    if (diff) setAiDifficulty(diff);

    if (mode === 'puzzles') {
      setIsPuzzlesOpen(true);
      return;
    }

    if (mode !== 'online') {
       setOnlineMatchId(null);
       setOnlineOpponent(null);
       setSelectedTable(null);
       setOpponentDisconnected(false);
       setDisconnectExpiresAt(null);
       setPlayerColor('w');
    }

    engineRef.current.reset();
    setSelectedSquare(null);
    setValidMoves([]);
    setLastMove(null);
    setIsCheck(false);
    setIsGameOver(false);
    setIsCheckmate(false);
    setWinner(null);
    setWhiteTime(600);
    setBlackTime(600);
    setActivePuzzle(null);

    updateEngineState();
    setCurrentMode(mode);
  };

  // Start specific puzzle
  const handleSelectPuzzle = (puz: ChessPuzzle) => {
    setActivePuzzle(puz);
    engineRef.current.reset(puz.fen);
    setSelectedSquare(null);
    setValidMoves([]);
    setIsGameOver(false);
    updateEngineState();
    setCurrentMode('puzzles');
  };

  // Undo move
  const handleUndo = () => {
    engineRef.current.undo();
    if (currentMode === 'vs_ai') {
      engineRef.current.undo(); // Undo AI move as well
    }
    setSelectedSquare(null);
    setValidMoves([]);
    updateEngineState();
  };

  // Hint
  const handleHint = () => {
    const bestM = engineRef.current.getBestAIMove('hard');
    if (bestM) {
      setSelectedSquare(bestM.from);
      setValidMoves([bestM]);
      soundManager.playClick();
    }
  };

  // Resign match
  const handleResign = () => {
    if (isGameOver) return;
    soundManager.playGameOver();
    setIsGameOver(true);
    
    const winningColor = currentMode === 'online' 
      ? (playerColor === 'w' ? 'b' : 'w') 
      : (turn === 'w' ? 'b' : 'w');
      
    setWinner(winningColor);

    if (currentMode === 'online' && onlineMatchId) {
      const { session } = useRealtimeStore.getState();
      fetch(buildApiUrl(`/api/match/${onlineMatchId}/end`), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
        body: JSON.stringify({ reason: 'resigned', winner: winningColor, userId: session?.user_id })
      })
      .then(res => res.json())
      .then(data => {
        if (data.userBalance !== undefined) {
          setUserProfile((prev) => prev ? ({ ...prev, coins: data.userBalance }) : null);
          setCoins(data.userBalance);
        }
      })
      .catch(() => {});
      localStorage.removeItem('active_match_id');
    }

    setTimeout(() => {
      setIsGameResultOpen(true);
    }, 300);
  };

  // Ask Gemini AI Coach for advice
  const handleRequestAdvice = async () => {
    setCoachLoading(true);
    try {
      const fen = engineRef.current.getFen();
      const moves = engineRef.current.getHistory().map((m) => m.san);

      const res = await fetch(buildApiUrl('/api/gemini/advice'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fen, moves, language }),
      });

      const data = await res.json();
      setCoachAdvice(data);
    } catch {
      setCoachAdvice({
        analysisKu: 'پارچەکانت بەشێوەیەکی گونجاو بڵاو بکەرەوە بۆ پاراستنی شاو.',
        analysisEn: 'Develop your key pieces to control central squares.',
        tacticalTipKu: 'شای خۆت لە هێرشەکانی شای بەرامبەر بپارێزە.',
        tacticalTipEn: 'Ensure King safety before starting an attack.',
      });
    } finally {
      setCoachLoading(false);
    }
  };

  return (
    <div className="w-full h-screen overflow-hidden bg-slate-950 font-sans select-none">
      {/* Splash Screen - only for unauthenticated users when showSplash is true */}
      {showSplash && !isAuthenticated && (
        <SplashScreen
          language={language}
          onEnterGame={() => {
            setShowSplash(false);
            if (!useRealtimeStore.getState().isAuthenticated) {
              setIsLoginOpen(true);
            } else {
              setIsLoginOpen(false);
              setCurrentMode('menu');
            }
          }}
        />
      )}

      {currentMode === 'menu' ? (
        <MainMenu
          language={language}
          coins={coins}
          userProfile={fallbackProfile}
          soundEnabled={soundEnabled}
          musicEnabled={musicEnabled}
          onToggleSound={() => {
            const next = !soundEnabled;
            setSoundEnabled(next);
            soundManager.setSoundEnabled(next);
          }}
          onToggleMusic={() => {
            const next = !musicEnabled;
            setMusicEnabled(next);
            soundManager.setMusicEnabled(next);
          }}
          onStartGame={handleStartGame}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
          onOpenTournament={() => setIsTournamentOpen(true)}
          onOpenShop={() => setIsShopOpen(true)}
          onOpenCoach={() => {
            setIsCoachOpen(true);
            handleRequestAdvice();
          }}
          onOpenHelp={() => setIsSettingsOpen(true)}
          onOpenProfile={() => setIsProfileOpen(true)}
          onOpenDailyReward={() => setIsDailyRewardOpen(true)}
          onOpenFriends={() => setIsFriendsOpen(true)}
          onOpenMatchmaking={() => setIsTablesSelectionOpen(true)}
          onOpenLiveChatHub={() => setIsLiveChatHubOpen(true)}
          onOpenRoyalPass={() => setIsRoyalPassOpen(true)}
          onOpenCustomRoom={() => setIsCustomRoomOpen(true)}
          onLogout={handleLogout}
        />
      ) : (
        <div 
          className="relative w-full h-full bg-[#05070d] bg-cover bg-center overflow-hidden"
          style={{ backgroundImage: `url(${darkGlassHallBgImg})` }}
        >
          {/* 3D Chess Canvas */}
          <Chess3DCanvas
            board={board}
            selectedSquare={selectedSquare}
            validMoves={validMoves}
            lastMove={lastMove}
            isCheck={isCheck}
            turn={turn}
            theme={theme}
            equippedPieceSkin={
              currentMode === 'vs_ai'
                ? (previewPieceSkin || (equippedPieceSkin === 'marble' || equippedPieceSkin === 'basalt' ? 'royal_gold' : equippedPieceSkin))
                : equippedPieceSkin
            }
            equippedBoardSkin={equippedBoardSkin}
            previewPieceSkin={previewPieceSkin}
            previewBoardSkin={previewBoardSkin}
            onSquareClick={handleSquareClick}
            cameraPreset={cameraPreset}
            tableThemeStyle={
              selectedTable?.id === 1
                ? 'classic'
                : selectedTable?.id === 2
                ? 'purple'
                : selectedTable?.id === 3
                ? 'red'
                : selectedTable?.id === 4
                ? 'blue'
                : selectedTable?.id === 5
                ? 'green'
                : selectedTable?.id === 6
                ? 'gold'
                : selectedTable?.id === 7
                ? 'dark'
                : 'classic'
            }
            capturedWhite={capturedWhite}
            capturedBlack={capturedBlack}
            playerColor={playerColor}
          />

          {/* Match Start 3, 2, 1, START Countdown Overlay */}
          <MatchStartCountdownOverlay
            isActive={isCountdownActive}
            language={language}
            onFinished={() => setIsCountdownActive(false)}
          />

          {/* Live Spectate Overlay when mode is spectate, or Game HUD for active games */}
          {currentMode === 'spectate' ? (
            <LiveSpectateOverlay
              language={language}
              userProfile={fallbackProfile}
              whitePlayerName="GM_Kasparov_AI"
              blackPlayerName="Master_Onyx_Bot"
              whiteRating={2150}
              blackRating={2080}
              soundEnabled={soundEnabled}
              onToggleSound={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                soundManager.setSoundEnabled(next);
              }}
              onExitSpectate={() => {
                soundManager.stopAllAmbience();
                setCurrentMode('menu');
              }}
              onResetCamera={() => setCameraPreset('perspective')}
              onToggleTopView={() =>
                setCameraPreset((prev) => (prev === 'top' ? 'perspective' : 'top'))
              }
            />
          ) : (
            <GameHUD
              language={language}
              gameMode={currentMode}
              aiDifficulty={aiDifficulty}
              turn={turn}
              isCheck={isCheck}
              isGameOver={isGameOver}
              isCheckmate={isCheckmate}
              winner={winner}
              whiteTime={whiteTime}
              blackTime={blackTime}
              capturedWhite={capturedWhite}
              capturedBlack={capturedBlack}
              lastMoveSan={lastMove?.san}
              soundEnabled={soundEnabled}
              userProfile={fallbackProfile}
              opponentDisconnected={currentMode === 'online' ? opponentDisconnected : false}
              onlineMatchId={currentMode === 'online' ? onlineMatchId : null}
              disconnectCountdown={currentMode === 'online' ? disconnectCountdown : 0}
              isReconnecting={currentMode === 'online' ? isSocketReconnecting : false}
              isOffline={currentMode === 'online' ? isNetworkOffline : false}
              onManualReconnect={handleManualReconnect}
              onOpenProfile={() => setIsProfileOpen(true)}
              onToggleSound={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                soundManager.setSoundEnabled(next);
              }}
              onUndo={handleUndo}
              onResign={handleResign}
              onHint={handleHint}
              onAskCoach={() => {
                setIsCoachOpen(true);
                handleRequestAdvice();
              }}
              onRestart={() => handleStartGame(currentMode)}
              onMainMenu={() => {
                if (currentMode === 'online' && !isGameOver && onlineMatchId) {
                  // Resign
                  const { session } = useRealtimeStore.getState();
                  fetch(buildApiUrl(`/api/match/${onlineMatchId}/end`), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
                    body: JSON.stringify({ reason: 'resigned', winner: playerColor === 'w' ? 'b' : 'w', userId: session?.user_id })
                  })
                  .then(res => res.json())
                  .then(data => {
                    if (data.userBalance !== undefined) {
                      setUserProfile((prev) => prev ? ({ ...prev, coins: data.userBalance }) : null);
                      setCoins(data.userBalance);
                    }
                  })
                  .catch(() => {});
                  localStorage.removeItem('active_match_id');
                }
                soundManager.stopAllAmbience();
                setCurrentMode('menu');
              }}
              cameraPreset={cameraPreset}
              onChangeCamera={(preset) => setCameraPreset(preset)}
            />
          )}
        </div>
      )}

      {/* Modals */}
      <AICoachModal
        isOpen={isCoachOpen}
        onClose={() => setIsCoachOpen(false)}
        language={language}
        loading={coachLoading}
        advice={coachAdvice}
        onRequestAdvice={handleRequestAdvice}
      />

      <ShopModal
        isOpen={isShopOpen}
        onUpdateProfile={(updated) => {
          setUserProfile((prev) => (prev ? { ...prev, ...updated } : null));
          if (updated.coins !== undefined) setCoins(updated.coins);
        }}
        onClose={() => {
          setIsShopOpen(false);
          setPreviewPieceSkin(null);
          setPreviewBoardSkin(null);
        }}
        language={language}
        userProfile={fallbackProfile}
        equippedPieceSkin={equippedPieceSkin}
        equippedBoardSkin={equippedBoardSkin}
        previewPieceSkin={previewPieceSkin}
        previewBoardSkin={previewBoardSkin}
        onSelectPieceSkin={(skin) => {
          setEquippedPieceSkin(skin);
          setPreviewPieceSkin(null);
          soundManager.playClick();
        }}
        onSelectBoardSkin={(board) => {
          setEquippedBoardSkin(board);
          setPreviewBoardSkin(null);
          soundManager.playClick();
        }}
        onPreviewPieceSkin={(skin) => {
          setPreviewPieceSkin(skin);
        }}
        onPreviewBoardSkin={(board) => {
          setPreviewBoardSkin(board);
        }}
      />

      <PuzzlesModal
        isOpen={isPuzzlesOpen}
        onClose={() => setIsPuzzlesOpen(false)}
        language={language}
        onSelectPuzzle={handleSelectPuzzle}
        userCoins={coins}
        onUpdateCoins={(newCoins) => {
          setCoins(newCoins);
          setUserProfile((prev) => (prev ? { ...prev, coins: newCoins } : null));
        }}
      />

      <LeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
        language={language}
        currentUserProfile={userProfile || fallbackProfile}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        language={language}
        onSelectLanguage={(lang) => setLanguage(lang)}
        aiDifficulty={aiDifficulty}
        onSelectAIDifficulty={(diff) => setAiDifficulty(diff)}
        soundEnabled={soundEnabled}
        onToggleSound={() => {
          const next = !soundEnabled;
          setSoundEnabled(next);
          soundManager.setSoundEnabled(next);
        }}
        musicEnabled={musicEnabled}
        onToggleMusic={() => {
          const next = !musicEnabled;
          setMusicEnabled(next);
          soundManager.setMusicEnabled(next);
        }}
        onLogout={handleLogout}
      />

      <ProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        onUpdateProfile={async (updated) => {
          const newProfile = { ...fallbackProfile, ...updated };
          const deductGems = updated.gems !== undefined && updated.gems < fallbackProfile.gems;
          const res = await savePlayerProfile(newProfile, deductGems);
          if (res.success) {
            setUserProfile(newProfile);
            if (updated.gems !== undefined) setCoins(prev => prev); // trigger re-render just in case
            const { account } = useRealtimeStore.getState();
            if (account && account.user) {
              account.user.username = newProfile.name;
              useRealtimeStore.setState({ account });
            }
          }
          return res;
        }}
        onOpenLeaderboard={() => {
          setIsProfileOpen(false);
          setIsLeaderboardOpen(true);
        }}
        onOpenRankBadges={() => {
          setIsProfileOpen(false);
          setIsRankBadgesOpen(true);
        }}
        onChallengeFriend={() => {
          setIsProfileOpen(false);
          handleStartGame('vs_friend');
        }}
        onLogout={handleLogout}
      />

      <RankBadgesModal
        isOpen={isRankBadgesOpen}
        onClose={() => setIsRankBadgesOpen(false)}
        language={language}
        userProfile={fallbackProfile}
      />

      <TournamentModal
        isOpen={isTournamentOpen}
        onClose={() => setIsTournamentOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        coins={coins}
        onOpenShop={() => {
          setIsTournamentOpen(false);
          setIsShopOpen(true);
        }}
        onOpenCoach={() => {
          setIsTournamentOpen(false);
          setIsCoachOpen(true);
        }}
        onOpenProfile={() => {
          setIsTournamentOpen(false);
          setIsProfileOpen(true);
        }}
        onOpenSettings={() => {
          setIsTournamentOpen(false);
          setIsSettingsOpen(true);
        }}
        onStartSpectate={() => {
          setIsTournamentOpen(false);
          handleStartGame('spectate');
        }}
        onStartGame={() => {
          setIsTournamentOpen(false);
          handleStartGame('vs_ai', 'medium');
        }}
      />

      <DailyRewardModal
        isOpen={isDailyRewardOpen}
        onClose={() => setIsDailyRewardOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        userCoins={coins}
        onUpdateCoins={(newCoins) => {
          setCoins(newCoins);
          setUserProfile((prev) => (prev ? { ...prev, coins: newCoins } : null));
        }}
        onUpdateProfile={(updated) => setUserProfile((prev) => ({ ...prev, ...updated }))}
        onAddCoins={(amount) => {
          setCoins((prev) => prev + amount);
        }}
        onAddGems={(amount) => {
          setUserProfile((prev) => ({
            ...prev,
            gems: (prev?.gems || 0) + amount,
          }));
        }}
      />

      <FriendsModal
        isOpen={isFriendsOpen}
        onClose={() => setIsFriendsOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        onUpdateProfile={(updated) => setUserProfile(updated)}
        onChallengeFriend={(friend, code) => {
          setIsFriendsOpen(false);
          if (code) {
            setCustomRoomInitialCode(code);
            setCustomRoomInitialMatchId(undefined); // the match ID isn't needed right now for the host until matched
            setCustomRoomInitialIsHost(true);
            setIsCustomRoomOpen(true);
          } else {
            handleStartGame('vs_friend');
          }
        }}
      />

      <RoyalPassModal
        isOpen={isRoyalPassOpen}
        onClose={() => setIsRoyalPassOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        onUpdateProfile={(updated) => setUserProfile((prev) => ({ ...prev, ...updated }))}
      />

      <TablesSelectionModal
        isOpen={isTablesSelectionOpen}
        onClose={() => setIsTablesSelectionOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        onSelectTable={(table) => {
          setSelectedTable(table);
          setIsTablesSelectionOpen(false);
          setIsMatchmakingOpen(true);
        }}
      />

      <MatchmakingModal
        isOpen={isMatchmakingOpen}
        onClose={() => setIsMatchmakingOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        selectedTable={selectedTable}
        onMatchFound={(matchId, opp, assignedColor) => {
          setIsMatchmakingOpen(false);
          setIsTablesSelectionOpen(false);
          setOnlineMatchId(matchId);
          setOnlineOpponent(opp);
          setPlayerColor(assignedColor);
          setCameraPreset(assignedColor === 'b' ? 'black' : 'perspective');
          
          const fee = selectedTable?.entryFee ?? 0;
          const prize = selectedTable?.prizePool ?? (fee * 2);
          setMatchStake(fee);
          setMatchPrize(prize);

          localStorage.setItem('active_match_id', matchId);
          localStorage.setItem('active_match_color', assignedColor);
          localStorage.setItem('active_match_opp', JSON.stringify(opp));
          
          // Join WebSocket match room
          const { socket, connectSocket } = useRealtimeStore.getState();
          if (socket && socket.isOpen) {
            socket.joinMatch(matchId);
          } else {
            connectSocket().then((s) => s?.joinMatch(matchId));
          }

          const { session } = useRealtimeStore.getState();
          if (session?.user_id) {
            fetch(buildApiUrl(`/api/match/${matchId}/init`), {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}) },
              body: JSON.stringify({
                userId: session.user_id,
                assignedColor,
                tableId: selectedTable?.id,
                stake: fee,
                prize: prize
              })
            })
            .then(res => res.json())
            .then(data => {
              if (data.userBalance !== undefined) {
                setUserProfile((prev) => prev ? ({ ...prev, coins: data.userBalance }) : null);
                setCoins(data.userBalance);
              }
            })
            .catch(e => console.error("Failed to init match", e));
          }
          
          handleStartGame('online');

          const timeFormatStrKu = selectedTable?.rulesTimeFormatKu || '٥ خولەک';
          let timeMin = 10;
          if (timeFormatStrKu.includes('٥') || timeFormatStrKu.includes('5')) timeMin = 5;
          if (timeFormatStrKu.includes('١٠') || timeFormatStrKu.includes('10')) timeMin = 10;
          if (timeFormatStrKu.includes('٣') || timeFormatStrKu.includes('3')) timeMin = 3;
          
          const initialSeconds = timeMin * 60;
          setWhiteTime(initialSeconds);
          setBlackTime(initialSeconds);
          setIsCountdownActive(true);
        }}
      />

      <GameResultModal
        isOpen={isGameResultOpen}
        isVictory={currentMode === 'online' ? (winner === playerColor) : (winner === 'w')}
        isDraw={winner === 'draw'}
        rewardCoins={
          currentMode === 'online'
            ? (winner === 'draw' ? matchStake : (winner === playerColor ? matchPrize : matchStake))
            : currentMode === 'vs_ai'
            ? (aiReward?.coins ?? 0)
            : undefined
        }
        earnedXp={
          currentMode === 'online'
            ? (onlineResult?.xpEarned ?? (winner === 'draw' ? 15 : (winner === playerColor ? 35 : 0)))
            : currentMode === 'vs_ai'
            ? (aiReward?.xp ?? 0)
            : undefined
        }
        ratingBefore={currentMode === 'online' ? onlineResult?.ratingBefore : undefined}
        ratingAfter={currentMode === 'online' ? onlineResult?.ratingAfter : undefined}
        newLevel={
          currentMode === 'online'
            ? (onlineResult?.level ?? fallbackProfile?.level ?? 1)
            : currentMode === 'vs_ai'
            ? (aiReward?.level ?? fallbackProfile?.level ?? 1)
            : undefined
        }
        language={language}
        userProfile={fallbackProfile}
        onPlayAgain={async () => {
          setIsGameResultOpen(false);
          const refreshed = await getPlayerProfile();
          if (refreshed) {
            setUserProfile(refreshed);
            setCoins(refreshed.coins);
          }
          if (currentMode === 'online') {
            handleStartGame('menu');
            setIsTablesSelectionOpen(true);
          } else {
            handleStartGame(currentMode === 'menu' ? 'vs_ai' : currentMode);
          }
        }}
        onMainMenu={async () => {
          setIsGameResultOpen(false);
          setCurrentMode('menu');
          localStorage.removeItem('active_match_id');
          const refreshed = await getPlayerProfile();
          if (refreshed) {
            setUserProfile(refreshed);
            setCoins(refreshed.coins);
          }
        }}
      />

      <LiveChatHubModal
        isOpen={isLiveChatHubOpen}
        onClose={() => setIsLiveChatHubOpen(false)}
        language={language}
        userProfile={fallbackProfile}
        onWatchLiveGame={(gameId) => {
          setIsLiveChatHubOpen(false);
          handleStartGame('spectate');
        }}
        onOpenCoach={() => {
          setIsLiveChatHubOpen(false);
          setIsCoachOpen(true);
        }}
      />

      <CustomRoomModal
        isOpen={isCustomRoomOpen}
        onClose={() => setIsCustomRoomOpen(false)}
        language={language}
        initialCode={customRoomInitialCode}
        initialMatchId={customRoomInitialMatchId}
        initialIsHost={customRoomInitialIsHost}
        onMatchFound={(matchId, opp, assignedColor, timeMin, stake, prize) => {
          setIsCustomRoomOpen(false);
          setOnlineMatchId(matchId);
          setOnlineOpponent(opp);
          setPlayerColor(assignedColor);
          setCameraPreset(assignedColor === 'b' ? 'black' : 'perspective');

          const fee = stake ?? 0;
          const prizePool = prize ?? (fee * 2);
          setMatchStake(fee);
          setMatchPrize(prizePool);

          localStorage.setItem('active_match_id', matchId);
          localStorage.setItem('active_match_color', assignedColor);
          localStorage.setItem('active_match_opp', JSON.stringify(opp));

          // Join WebSocket match room
          const { socket, connectSocket } = useRealtimeStore.getState();
          if (socket && socket.isOpen) {
            socket.joinMatch(matchId);
          } else {
            connectSocket().then((s) => s?.joinMatch(matchId));
          }

          const initialSeconds = (timeMin || 5) * 60;
          setWhiteTime(initialSeconds);
          setBlackTime(initialSeconds);

          handleStartGame('online');

          // Ensure clocks reflect the custom room timeMin after handleStartGame reset
          setWhiteTime(initialSeconds);
          setBlackTime(initialSeconds);
          setIsCountdownActive(true);
        }}
      />

      {/* Session Checking Loading Screen */}
      {isCheckingSession && (
        <div className="fixed inset-0 z-[100] bg-slate-950 flex flex-col items-center justify-center p-4">
          <div className="relative flex flex-col items-center animate-pulse">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 p-0.5 shadow-2xl shadow-amber-500/30 mb-4 flex items-center justify-center">
              <span className="text-3xl font-black text-amber-950">♔</span>
            </div>
            <h2 className="text-amber-200 font-serif font-bold text-xl tracking-wider">CHESS ROYAL</h2>
            <div className="flex items-center gap-2 mt-3 text-amber-400/80 text-xs font-mono">
              <span className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
              <span>Checking Session...</span>
            </div>
          </div>
        </div>
      )}

      {/* Friend Invite Notification */}
      {friendInvite && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-gradient-to-br from-slate-900 to-slate-800 p-6 border-2 border-amber-400/50 rounded-3xl max-w-sm w-full text-center relative overflow-hidden shadow-2xl"
          >
            <h2 className="text-2xl font-black text-amber-400 mb-4">{language === 'ku' ? 'بانگێشتی یاری' : 'Game Invite'}</h2>
            <p className="text-slate-200 mb-8 font-bold text-lg">
              <span className="text-amber-300">{friendInvite.inviterName}</span> {language === 'ku' ? 'بانگێشتی کردوویت بۆ یارییەک!' : 'invited you to play a match!'}
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => {
                  soundManager.playClick();
                  setFriendInvite(null);
                }}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-white font-bold py-3 rounded-xl transition"
              >
                {language === 'ku' ? 'ڕەتکردنەوە' : 'Decline'}
              </button>
              <button
                onClick={async () => {
                  soundManager.playClick();
                  const code = friendInvite.code;
                  setFriendInvite(null);
                  
                  // Join automatically using CustomRoomService but via the CustomRoomModal
                  // Setting the code to CustomRoomModal and letting it handle joining or we can just join direct
                  setCustomRoomInitialCode(code);
                  setCustomRoomInitialIsHost(false);
                  setCustomRoomInitialMatchId(undefined);
                  setIsCustomRoomOpen(true);
                }}
                className="flex-1 bg-amber-500 hover:bg-amber-400 text-amber-950 font-black py-3 rounded-xl transition shadow"
              >
                {language === 'ku' ? 'قبوڵکردن' : 'Accept'}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Welcome Reward Notification */}
      {showWelcomeReward && (
        <div className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-gradient-to-br from-slate-900 to-slate-800 p-1 border-2 border-amber-400/50 rounded-3xl max-w-sm w-full text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-amber-400/10 animate-pulse" />
            <div className="p-8 relative z-10">
              <div className="text-6xl mb-4">🎁</div>
              <h2 className="text-3xl font-black text-amber-400 mb-2 font-serif">{language === 'ku' ? 'بەخێربێیت!' : 'Welcome!'}</h2>
              <p className="text-slate-200 text-lg mb-6 leading-relaxed">
                <span className="text-amber-400 font-bold text-2xl mx-1">5,000</span> {language === 'ku' ? 'Coins وەک خەڵاتی دەستپێکردن پێدرا.' : 'Coins awarded as a welcome bonus!'}
              </p>
              <button
                onClick={() => {
                  soundManager.playClick();
                  clearWelcomeReward();
                  setCoins((prev) => Math.max(prev, 5000));
                }}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-amber-950 font-bold text-xl py-4 rounded-2xl shadow-lg transition-transform active:scale-95"
              >
                {language === 'ku' ? 'وەرگرتن (Claim)' : 'Claim Reward'}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {!isCheckingSession && !isAuthenticated && !showSplash && (
        <LoginModal
          language={language}
          onLoginSuccess={async (username) => {
            setShowSplash(false);
            setIsLoginOpen(false);
            setCurrentMode('menu');
            const profile = await getPlayerProfile();
            if (profile) {
              setUserProfile(profile);
              setCoins(profile.coins);
            }
          }}
          onContinueAsGuest={async () => {
            setShowSplash(false);
            setIsLoginOpen(false);
            setCurrentMode('menu');
            const profile = await getPlayerProfile();
            if (profile) {
              setUserProfile(profile);
              setCoins(profile.coins);
            }
          }}
        />
      )}
    </div>
  );
}
