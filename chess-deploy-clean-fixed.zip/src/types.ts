export type Language = 'ku' | 'en';

export type GameMode = 'vs_ai' | 'pass_and_play' | 'puzzles' | 'spectate' | 'vs_friend' | 'menu' | 'online';

export type AIDifficulty = 'easy' | 'medium' | 'hard' | 'gemini_master';

export type PieceSkinId =
  | 'marble'
  | 'basalt'
  | 'maohi'
  | 'amethyst'
  | 'aztec'
  | 'hawk_eye'
  | 'obsidian'
  | 'lazuli'
  | 'topaz'
  | 'garnet'
  | 'scorodite'
  | 'masonry'
  | 'pearl'
  | 'dragon_flame'
  | 'dragon_carved'
  | 'pharaoh_dynasty'
  | 'amazon_jade'
  | 'royal_gold'
  | 'cyber_neon'
  | 'erbil_knights'
  | 'kurdistan_guardians'
  | 'kurdistan_royals'
  | 'diamond_crystal'
  | 'shadow_assassin'
  | 'vulcan_fire'
  | 'cosmic_star';

export type BoardSkinId =
  | 'maple'
  | 'oak'
  | 'ash'
  | 'olive'
  | 'padauk'
  | 'cherry'
  | 'azure'
  | 'ocean_azure'
  | 'egyptian_pyramids'
  | 'lavender'
  | 'shade'
  | 'dragon_arena'
  | 'amazon_jungle'
  | 'classic_wood'
  | 'erbil_citadel'
  | 'chess_of_kurdistan'
  | 'kurdistan_walnut'
  | 'emerald_velvet'
  | 'crimson_ruby'
  | 'cyber_neon'
  | 'vulcan_lava'
  | 'royal_palace'
  | 'diamond_glass'
  | 'galaxy_star'
  | 'obsidian_castle'
  | 'mystic_amethyst'
  | 'dragon_glass_castle';

export type EnvironmentId =
  | 'dragon_fortress'
  | 'amazon_jungle'
  | 'royal_castle'
  | 'vulcan_lava'
  | 'cyber_arena'
  | 'erbil_palace';

export type ThemeStyle = 'onyx_ivory' | 'classic_wood' | 'emerald_gold' | 'cyber_neon';

export interface Friend {
  id: string;
  name: string;
  avatar: string;
  level: number;
  isOnline: boolean;
  statusText: string;
  isBlocked?: boolean;
  coins?: number;
  trophies?: number;
  countryFlag?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  bio: string;
  avatar: string;
  level: number;
  xp?: number;
  rating?: number;
  nextLevelXp?: number;
  coins?: number;
  gems?: number;
  hasChangedNameOnce?: boolean;
  nameChangeCount?: number;
  isLocked?: boolean;
  totalGames: number;
  wins?: number;
  winRate: string;
  thisWeekRank: string;
  lastWeekRank: string;
  countryFlag: string;
  badge: string;
  friends: Friend[];
  blockedUsers?: Friend[];
  unlockedCrownBadge?: boolean;
  redCrownBackdrop?: boolean;
}

export interface PlayerInfo {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  coins: number;
  countryFlag?: string;
}

export interface ChessMoveRecord {
  from: string;
  to: string;
  piece: string;
  color: 'w' | 'b';
  captured?: string;
  san: string;
  timestamp: number;
}

export interface ChessPuzzle {
  id: string;
  titleKu: string;
  titleEn: string;
  descriptionKu: string;
  descriptionEn: string;
  fen: string;
  solutionMoves: string[]; // e.g. ["Qxf7#"] or ["e2e4", "e7e5"]
  difficulty: 'easy' | 'medium' | 'hard';
  rewardCoins: number;
}

export interface AICoachResponse {
  analysisKu: string;
  analysisEn: string;
  suggestedMoveSan?: string;
  tacticalTipKu: string;
  tacticalTipEn: string;
}

export interface LeaderboardUser {
  rank: number;
  name: string;
  avatar: string;
  rating: number;
  badge: string;
  isUser?: boolean;
}

export interface TournamentPlayer {
  id: string;
  name: string;
  avatar: string;
  level: number;
}

export interface TournamentMatch {
  id: string;
  player1: TournamentPlayer;
  player2: TournamentPlayer;
  prizePool: number;
  entryFee: number;
  spectatorsCount: number;
  mode: string;
}

