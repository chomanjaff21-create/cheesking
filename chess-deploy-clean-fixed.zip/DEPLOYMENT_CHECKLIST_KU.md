# Chess Royal — پێش بڵاوکردنەوە

## چاکسازییەکانی ئەم وەشانە

- ئەکاونتە تاقیکردنەوە هاردکۆدکراوەکان لە دەستپێکردنی سێرڤەر لابراون؛ هیچ ئەکاونتێکی پێشوەختە بە پاسۆردی هاوبەش دروست ناکرێت.
- لە Production، سێرڤەر ئەگەر `JWT_SECRET`، `DATABASE_URL` یان `SUPABASE_SECRET_KEY` نەبێت دەست پێ ناکات.
- سێرڤەر چاوەڕێی پەیوەندی PostgreSQL و تەواوبوونی schema bootstrap دەکات پێش ئەوەی پۆرتی وێب بکاتەوە.
- ئەگەر پەیوەندی یان دروستکردنی schema لە Production سەرکەوتوو نەبێت، سێرڤەر بە هەڵە دەوەستێت، نەک ئەوەی بە شێوەیەکی ناتەواو خزمەتگوزاری پێشکەش بکات.

## Environment Variables

لە Hosting ـەکەتدا ئەمانە دابنێ؛ بەها نهێنییەکان تەنها لە داشبۆردی Hosting بنووسە، نەک لە GitHub:

| Variable | پێویستی | تێبینی |
|---|---|---|
| `NODE_ENV` | پێویست | `production` |
| `PORT` | Hosting | زۆرجار Hosting خۆی دایدەنێت؛ دەستکاری مەکە ئەگەر پێویست نەبوو |
| `JWT_SECRET` | پێویست | کلیلی درێژی نهێنی و هەڕەمەکی؛ لانیکەم 64 بایت/پیتێکی هەڕەمەکی باشە |
| `DATABASE_URL` | پێویست | PostgreSQL ـی Supabase؛ پەیوەندییەکی گونجاو بۆ سێرڤەر بەکاربهێنە |
| `SUPABASE_URL` | پێویست | URL ـی پڕۆژەی Supabase |
| `SUPABASE_PUBLISHABLE_KEY` | پێویست بۆ Auth ـی سێرڤەر | کلیلی publishable/anon ـی گشتی |
| `SUPABASE_SECRET_KEY` | پێویست | کلیلی نهێنیی سێرڤەر؛ هەرگیز لە `VITE_` مەخە |
| `VITE_SUPABASE_URL` | پێویست بۆ Frontend | هەمان URL ـی Supabase |
| `VITE_SUPABASE_ANON_KEY` | پێویست بۆ Frontend | کلیلی publishable/anon؛ کلیلی secret مەبێت |
| `APP_URL` | پێویست بۆ CORS | URL ـی HTTPS ـی ماڵپەڕەکەت |
| `ALLOWED_ORIGINS` | پێویست بۆ CORS | Origin ـە ڕێگەپێدراوەکان بە کۆما جیا بکەرەوە |
| `VITE_APP_URL` | بۆ Capacitor | URL ـی HTTPS ـی ماڵپەڕ؛ پێش Build ـی ئەپی مۆبایل دابنێ |
| `GEMINI_API_KEY` | بۆ AI Coach | کلیلی Gemini؛ لە Frontend دانەمەزرێنە |
| `REDIS_URL` | ئارەزوومەندانە بۆ یەک Instance | بۆ چەند Instance و Matchmaking ـی هاوبەش پێویستە؛ بەبێ Redis تەنها یەک Instance بەکاربهێنە |

## Build و Start

- Build command: `npm install && npm run build`
- Start command: `npm start`
- پۆرت: `3000` (یان `PORT` ـی Hosting)

`VITE_*` لە کاتی Build ـدا دەخوێندرێنەوە؛ دوای گۆڕینیان Build ـەکە دووبارە بکەرەوە.

## Database و Admin

- لە یەکەم دەستپێکردنی سێرڤەر بە `DATABASE_URL`، سێرڤەر خشتەکان، Index ـەکان، Trigger ـی Supabase Auth و RLS چالاک دەکات.
- پێش ئەوەی یاریزانان بەکاربهێنن، دڵنیابە لەوەی سێرڤەر بە PostgreSQL ـی دروستەوە پەیوەست بووە و Log ـەکان هیچ هەڵەیەکی schema نیشان نادەن.
- بۆ دیاریکردنی Admin، سەرەتا بە ئەکاونتی خۆت Login/Sign up بکە؛ پاشان لە SQL Editor ـی Supabase ئەم داواکارییە بە ئیمەیڵی خۆت جێبەجێ بکە:

```sql
UPDATE public.users
SET is_admin = TRUE
WHERE id = (
  SELECT id FROM auth.users WHERE email = 'YOUR_ADMIN_EMAIL'
);
```

- `YOUR_ADMIN_EMAIL` بگۆڕە بە ئیمەیڵی خۆت. هیچ کەسێک بەهۆی ئەم فایلەوە خۆکارانە Admin نابێت.

## تاقیکردنەوە پێش بڵاوکردنەوە

1. پشکنینی `/api/health` و دڵنیابوون لە پەیوەندی Database.
2. Sign up، Sign in، Sign out و Guest.
3. Login لە دوو Browser/ئامێری جیاواز و تاقیکردنەوەی Matchmaking.
4. جووڵەی شەترەنج، کاتژمێر، Disconnect و Reconnect.
5. Coins/Gems، Stake، Shop و Daily Rewards؛ دوای Logout/Login داتاکان ون نەبن.
6. Friends، Chat، Leaderboard، Tournament و Admin.
7. هەموو تاقیکردنەوەکان لە مۆبایل و Desktop.

**ئاگاداری:** لەم وەشانەدا کۆدەکان و پشکنینی Syntax تاقی کراونەتەوە، بەڵام Build ـی تەواو و تاقیکردنەوەی Database/Online نەکراون؛ پێداویستییەکان لەم ژینگەیەدا دامەزرێنرانەوە نەبوون. پێش بانگەشەی تەواوبوون، ئەم تاقیکردنەوانە لە Hosting ـی ڕاستەقینە جێبەجێ بکە.
